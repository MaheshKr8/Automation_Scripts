
---

### **1. CI/CD Pipeline Implementation**
**Scenario:** Your team wants to automate the build, test, and deployment process using Azure DevOps. How would you design a CI/CD pipeline for a .NET or Node.js application?  

**Answer:**  
- Use **Azure Repos** or GitHub as the source code repository.  
- Create a **CI pipeline** in Azure Pipelines using YAML:  
  - Use `trigger:` to specify branch triggers.  
  - Add **build tasks** (e.g., `dotnet build`, `npm install`).  
  - Run **unit tests** (`dotnet test` or `npm test`).  
  - Store build artifacts in **Azure Artifacts**.  
- Set up a **CD pipeline** to deploy artifacts to Dev, QA, and Prod using **Azure App Service or Kubernetes**.  
- Use **approval gates** before production deployment.  

---

### **2. Multi-Stage Pipelines**
**Scenario:** You need to create a multi-stage pipeline in Azure DevOps to deploy an application across Dev, QA, and Production environments. How would you ensure approvals before deploying to production?  

**Answer:**  
- Use **Azure DevOps multi-stage YAML pipelines**.  
- Define `stages:` for **Dev, QA, and Prod**.  
- Add `environment:` settings for each stage.  
- Configure **pre-deployment approvals** in the **Environments** section.  
- Example YAML snippet:  
  ```yaml
  stages:
    - stage: Dev
      jobs:
        - job: DeployDev
          steps:
            - script: echo Deploying to Dev

    - stage: Prod
      dependsOn: Dev
      jobs:
        - deployment: DeployProd
          environment: Production
          approval: true
          steps:
            - script: echo Deploying to Prod
  ```
---

### **3. Self-Hosted vs. Microsoft-Hosted Agents**
**Scenario:** Your build times are increasing due to long queue times on Microsoft-hosted agents. What are the benefits of self-hosted agents, and how would you set them up?  

**Answer:**  
- **Benefits of Self-Hosted Agents:**
  - Faster builds since they are always available.  
  - Custom dependencies can be pre-installed.  
  - No limitations on build time.  

- **Setup Process:**
  - Go to **Azure DevOps → Organization Settings → Agent Pools**.  
  - Click **New Agent** and follow the instructions to install it on a VM.  
  - Run the agent using `./config.sh` or `./config.cmd`.  

---

### **4. YAML vs. Classic Pipelines**
**Scenario:** Your organization wants to move from Classic Pipelines to YAML-based pipelines. What are the advantages, and how would you migrate an existing pipeline?  

**Answer:**  
- **Advantages of YAML Pipelines:**
  - Pipeline as Code (version-controlled).  
  - Easier to maintain and reuse templates.  
  - Supports multi-stage pipelines.  

- **Migration Steps:**
  - Go to the **classic pipeline** → Click **View YAML**.  
  - Convert build tasks to YAML format.  
  - Save YAML file in the repository as `azure-pipelines.yml`.  
  - Create a new pipeline and reference this YAML file.  

---

### **5. Secure Secrets in Pipelines**
**Scenario:** You need to store API keys and credentials securely in Azure DevOps pipelines. How would you handle this?  

**Answer:**  
- Use **Azure DevOps Variable Groups** with secret values.  
- Use **Azure Key Vault** to manage secrets securely.  
- Reference secrets in YAML:  
  ```yaml
  steps:
    - task: AzureKeyVault@2
      inputs:
        azureSubscription: 'MyServiceConnection'
        keyVaultName: 'myKeyVault'
        secretsFilter: '*'
  ```

---

### **6. Terraform and Azure DevOps**
**Scenario:** How would you integrate Terraform with Azure DevOps for automated infrastructure provisioning?  

**Answer:**  
- Install **Terraform extension** in Azure DevOps.  
- Use a **Service Connection** to authenticate with Azure.  
- Define Terraform tasks in the pipeline:  
  ```yaml
  steps:
    - task: TerraformCLI@0
      inputs:
        command: 'apply'
        environmentServiceName: 'AzureSubscription'
  ```

---

### **7. SonarQube Integration for Code Quality**
**Scenario:** How would you integrate SonarQube into Azure DevOps?  

**Answer:**  
- Install the **SonarQube extension** in Azure DevOps.  
- Configure **SonarQube service connection**.  
- Add SonarQube tasks to the pipeline:  
  ```yaml
  steps:
    - task: SonarQubePrepare@4
      inputs:
        scannerMode: 'CLI'
        configMode: 'manual'
  ```

---

### **8. Handling Pipeline Failures**
**Scenario:** Your pipeline is failing due to missing configurations. How would you troubleshoot?  

**Answer:**  
- **Check the logs** in the Azure DevOps pipeline run.  
- Verify environment variables and secrets.  
- Run failing steps manually in a self-hosted agent.  
- Re-run the pipeline with **System.Debug=true** enabled.  

---

### **9. Blue-Green Deployment**
**Scenario:** How would you implement Blue-Green deployment in Azure DevOps?  

**Answer:**  
- Deploy a new **Green environment** while **Blue is live**.  
- Use **Azure Traffic Manager** to switch traffic.  
- Validate Green and shift traffic using scripts.  

---

### **10. Rolling Back a Deployment**
**Scenario:** A new release causes production issues. How would you roll back?  

**Answer:**  
- Use **Azure DevOps Release History** to re-deploy a previous version.  
- Store old builds in **Azure Artifacts**.  
- Automate rollbacks using **Deployment Groups**.  

---

### **11. Azure DevOps Artifacts**
**Scenario:** How would you set up Azure DevOps Artifacts for package management?  

**Answer:**  
- Navigate to **Azure Artifacts** → Create a feed.  
- Publish NuGet/npm/Maven packages using the CLI.  

---

### **12. Multi-Repository Triggers**
**Scenario:** How would you configure multi-repo triggers?  

**Answer:**  
- Use `resources.repositories` in YAML to reference multiple repos:  
  ```yaml
  resources:
    repositories:
      - repository: RepoA
        type: git
  ```

---

### **13. Kubernetes Deployment Using Azure DevOps**
**Scenario:** How would you deploy an app to **AKS**?  

**Answer:**  
- Install `kubectl` in the pipeline.  
- Authenticate using **Azure Service Principal**.  
- Deploy using `kubectl apply -f deployment.yaml`.  

---

### **14. Trivy for Container Security Scanning**
**Scenario:** How would you integrate Trivy for security scanning?  

**Answer:**  
- Install **Trivy** in the pipeline.  
- Run:  
  ```yaml
  - script: trivy image myimage:latest
  ```

---

### **15. Branching Strategy in Azure Repos**
**Scenario:** How do you enforce branch policies?  

**Answer:**  
- Go to **Repos → Branches → Policies**.  
- Enable **approvals, work item linking, and status checks**.  

---

### **16. Approvals and Gates in Release Pipelines**
**Scenario:** How do you configure approvals?  

**Answer:**  
- In the **Release pipeline**, add **Pre-deployment approvals**.  

---

### **17. Handling Secrets with Azure Key Vault**
**Scenario:** How do you use **Azure Key Vault** secrets?  

**Answer:**  
- Use `AzureKeyVault@2` task in YAML.  

---

### **18. ArgoCD and Azure DevOps Integration**
**Scenario:** How do you use **GitOps** with ArgoCD?  

**Answer:**  
- Push manifests to a Git repo watched by **ArgoCD**.  

---

### **19. Monitoring Azure DevOps Pipelines**
**Scenario:** How do you monitor pipeline failures?  

**Answer:**  
- Use **Azure Monitor** and **Application Insights**.  

---

### **20. Disaster Recovery for Azure DevOps**
**Scenario:** How do you back up Azure DevOps?  

**Answer:**  
- Use **Azure DevOps Export APIs**.  
- Store YAML and repo backups in Git.  

---
