* Here are the some 5 Docker interview questions, now enhanced with practical scripts and examples:



* 1. **Explain the difference between `docker run` and `docker start`.**
   - `docker run` creates a new container and starts it, whereas `docker start` is used to start an existing, stopped container.

   **Example Script:**
   ```sh
   # Run a new container
   docker run -d --name my_container nginx

   # Stop the container
   docker stop my_container

   # Start the stopped container
   docker start my_container
   ```

* 2. **How do you monitor Docker containers?**
   - Docker containers can be monitored using built-in Docker commands such as `docker stats`, and tools like Prometheus, Grafana, and Docker Dashboard.

   **Example Script:**
   ```sh
   # Monitor container resource usage
   docker stats my_container
   ```

* 3. **What is a Docker Swarm?**
   - Docker Swarm is Docker’s native clustering and orchestration tool.

   **Example Script:**
   ```sh
   # Initialize a Docker Swarm
   docker swarm init

   # Add a worker node to the Swarm
   docker swarm join --token <token> <manager-ip>:2377
   ```

* 4. **How do you handle environment variables in Docker?**
   - Environment variables can be passed to a Docker container in several ways, such as using the `-e` flag with `docker run` or specifying them in a Docker Compose file.

   **Example Script:**
   ```sh
   # Using -e flag with docker run
   docker run -d -e ENV_VAR=value --name my_container nginx

   # Using environment variables in a Docker Compose file
   version: '3'
   services:
     app:
       image: my_app
       environment:
         - ENV_VAR=value
   ```

* 5. **Can you explain the concept of microservices and how Docker supports this architecture?**
    - Microservices is an architectural style that structures an application as a collection of loosely coupled services. Each service is fine-grained and implements a single business capability. Docker supports microservices by providing isolated environments (containers) for each service.

    **Example Docker Compose for Microservices:**
    ```yaml
    version: '3'
    services:
      service1:
        image: service1_image
        ports:
          - "5000:5000"
      service2:
        image: service2_image
        ports:
          - "5001:5001"
      service3:
        image: service3_image
        ports:
          - "5002:5002"
    ```

    **Running the Microservices:**
    ```sh
    docker-compose up
    ```

* These scripts and examples should help reinforce the practical understanding of Docker concepts.
