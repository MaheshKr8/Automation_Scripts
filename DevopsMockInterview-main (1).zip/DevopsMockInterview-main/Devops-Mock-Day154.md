
---

### ✅ **1. A developer pushed code with a critical bug into the `main` branch. How do you stop it from reaching production?**

**Answer:**

* Implement **branch protection rules** in GitHub/GitLab.
* Add **manual approval** stages in Jenkins or GitHub Actions for production deploys.
* Use **automated tests** and **SonarQube quality gates** to reject faulty builds.
* Setup **Slack/email alerts** on merge events for awareness.

---

### ✅ **2. Your Kubernetes pod is stuck in `CrashLoopBackOff`. How do you troubleshoot it?**

**Answer:**

1. Run `kubectl describe pod <pod-name>` to view event logs.
2. Run `kubectl logs <pod-name>` to check container logs.
3. Common issues:

   * Bad image or entrypoint script.
   * Unavailable config map or secret.
   * Readiness or liveness probes failing.
4. Fix the issue and re-deploy.

---

### ✅ **3. Your application can’t reach the internet from an EC2 instance. What could be the cause?**

**Answer:**

* Check if EC2 is in a **private subnet** without a NAT Gateway.
* Verify **route tables** have proper internet gateway/NAT entries.
* Ensure **security groups and NACLs** allow outbound traffic.
* Confirm DNS resolution is working using `dig`, `nslookup`, or `curl`.

---

### ✅ **4. You need to synchronize files automatically between two S3 buckets. How do you do it?**

**Answer:**

* Use **S3 event notifications** (e.g., `s3:ObjectCreated:*`) to trigger an **AWS Lambda**.
* Lambda copies the object from Bucket A to Bucket B.
* Use `aws s3 sync` for manual or cron-based syncs.
* Set IAM policies to allow Lambda to access both buckets.

---

### ✅ **5. A Helm release upgrade failed. How do you roll it back?**

**Answer:**

```bash
helm rollback <release-name> <revision-number>
```

* Use `helm history <release-name>` to see revisions.
* For future prevention:

  * Use `--atomic` to auto-rollback on failure.
  * Validate templates with `helm template` or `helm lint`.

---

### ✅ **6. Jenkins is not picking up changes from GitHub. How do you fix it?**

**Answer:**

* Verify **webhooks** are set up in the GitHub repo.
* Check Jenkins logs for errors.
* Use **polling SCM** as a fallback.
* Validate credentials and Git plugin configurations.

---

### ✅ **7. You need to give another AWS account access to pull images from your ECR repo. How?**

**Answer:**

* Create a **repository policy** in ECR allowing access to the other account ID.
* Use `aws ecr set-repository-policy` or console.
* The other account must authenticate via `aws ecr get-login-password` and Docker login.

---

### ✅ **8. One pod needs to talk to a database pod in another namespace. How is that done in Kubernetes?**

**Answer:**

* Use the **full DNS name**:

  ```
  postgres-db.database-namespace.svc.cluster.local
  ```
* Ensure **NetworkPolicy** allows traffic.
* Make sure the service and endpoints are configured correctly.

---

### ✅ **9. How do you prevent `terraform apply` from accidentally destroying critical infrastructure?**

**Answer:**

* Use:

  ```hcl
  lifecycle {
    prevent_destroy = true
  }
  ```
* Enable **plan review** in CI/CD pipelines.
* Set up **IAM permissions** to limit access to production apply.

---

### ✅ **10. You are asked to reduce EC2 cost during off-peak hours. How do you approach it?**

**Answer:**

* Use **Instance Scheduler** or automation scripts (Lambda + CloudWatch) to stop/start EC2s based on time.
* Use **Auto Scaling Groups** with scheduled scaling.
* Move to **spot instances** or **Lambda** where possible.
* Enable **compute savings plans** in AWS.

---

