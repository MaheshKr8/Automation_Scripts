### **10 Real-Time Scenario-Based Docker Interview Questions with Troubleshooting Steps and Examples**

---

### **1. How do you troubleshoot a container that crashes immediately after starting?**

#### **Scenario**:
A container exits immediately after being launched, and you need to identify the issue.

#### **Troubleshooting Steps**:
1. **Check container logs**:
   ```bash
   docker logs <container_id>
   ```
   Look for errors in the application or startup scripts.

2. **Run the container interactively**:
   ```bash
   docker run -it <image_name> /bin/bash
   ```
   Test the commands in the container to see what causes it to crash.

3. **Inspect the container configuration**:
   ```bash
   docker inspect <container_id>
   ```
   Verify the environment variables, volume mounts, and command overrides.

#### **Real-Life Example**:
A Node.js container crashed because the `NODE_ENV` variable was not set. Setting it properly resolved the issue:
```bash
docker run -e NODE_ENV=production <image_name>
```

---

### **2. How do you debug a slow-performing Docker container?**

#### **Scenario**:
A web application running inside a container is experiencing high latency.

#### **Troubleshooting Steps**:
1. **Monitor container resource usage**:
   ```bash
   docker stats <container_id>
   ```
   Check for high CPU or memory usage.

2. **Inspect network latency**:
   Use `ping` or `curl` from inside the container to check connectivity:
   ```bash
   docker exec -it <container_id> ping <external_service>
   ```

3. **Analyze logs**:
   Check application logs for errors or bottlenecks:
   ```bash
   docker logs <container_id>
   ```

4. **Inspect disk I/O**:
   If the container depends heavily on I/O, check volume mounts and disk performance.

#### **Real-Life Example**:
A Python Flask application running in a container was slow due to insufficient memory. Increasing the memory limit resolved the issue:
```bash
docker run --memory="512m" <image_name>
```

---

### **3. How do you troubleshoot connectivity issues between two containers?**

#### **Scenario**:
Two containers in the same network cannot communicate.

#### **Troubleshooting Steps**:
1. **Verify the network**:
   ```bash
   docker network inspect <network_name>
   ```

2. **Check container connectivity**:
   Ping the target container:
   ```bash
   docker exec -it <source_container> ping <target_container>
   ```

3. **Validate ports and services**:
   Ensure the target service is running and listening on the expected port:
   ```bash
   docker exec -it <target_container> netstat -tuln
   ```

4. **Check firewall rules**:
   Verify no external firewalls or `iptables` rules are blocking traffic.

#### **Real-Life Example**:
A database container was unreachable because the service was configured to listen on `127.0.0.1` instead of `0.0.0.0`. Updating the configuration fixed the issue.

---

### **4. How do you troubleshoot volume mount issues?**

#### **Scenario**:
A container fails to read/write data from a mounted volume.

#### **Troubleshooting Steps**:
1. **Inspect volume mapping**:
   ```bash
   docker inspect <container_id>
   ```

2. **Check permissions**:
   Ensure the host directory has the correct permissions:
   ```bash
   chmod -R 777 /host/data
   ```

3. **Test volume access**:
   Run a test command inside the container to verify access:
   ```bash
   docker exec -it <container_id> ls /container/data
   ```

4. **Ensure the volume exists**:
   List and inspect Docker volumes:
   ```bash
   docker volume ls
   docker volume inspect <volume_name>
   ```

#### **Real-Life Example**:
A MySQL container failed to start because the `/var/lib/mysql` directory on the host lacked write permissions. Adjusting permissions resolved the issue.

---

### **5. How do you troubleshoot a Dockerfile build failure?**

#### **Scenario**:
The `docker build` command fails with errors.

#### **Troubleshooting Steps**:
1. **Check the Dockerfile syntax**:
   Validate the Dockerfile against best practices and syntax rules.

2. **Use build context effectively**:
   Ensure all required files are included in the build context.

3. **Run the build with detailed output**:
   ```bash
   docker build --progress=plain .
   ```

4. **Test individual steps**:
   Run problematic commands manually:
   ```bash
   docker run -it base_image /bin/bash
   ```

#### **Real-Life Example**:
A `RUN apt-get install` command failed because `apt-get update` was missing. Adding it resolved the issue:
```dockerfile
RUN apt-get update && apt-get install -y curl
```

---

### **6. How do you resolve image pull failures in Docker?**

#### **Scenario**:
A container fails to start due to an image pull error.

#### **Troubleshooting Steps**:
1. **Check internet connectivity**:
   Verify the host can connect to Docker Hub or the private registry.

2. **Authenticate to private registries**:
   Use `docker login` to authenticate:
   ```bash
   docker login <registry_url>
   ```

3. **Use specific image tags**:
   Avoid using `latest` and specify a valid version:
   ```bash
   docker run nginx:1.21
   ```

4. **Check registry access**:
   Ensure the image exists in the registry and is accessible.

#### **Real-Life Example**:
An image pull from a private registry failed because the credentials were expired. Renewing the credentials resolved the issue.

---

### **7. How do you diagnose high resource usage by a container?**

#### **Scenario**:
A container is consuming excessive CPU or memory, affecting other services.

#### **Troubleshooting Steps**:
1. **Monitor resource usage**:
   ```bash
   docker stats <container_id>
   ```

2. **Inspect container processes**:
   Use `top` inside the container:
   ```bash
   docker exec -it <container_id> top
   ```

3. **Limit container resources**:
   ```bash
   docker run --memory="512m" --cpu-shares="256" <image_name>
   ```

#### **Real-Life Example**:
A Java application in a container consumed all available memory due to an incorrect `-Xmx` setting. Adding the JVM argument fixed the issue:
```bash
docker run -e JAVA_OPTS="-Xmx256m" <image_name>
```

---

### **8. How do you troubleshoot slow image builds?**

#### **Scenario**:
The `docker build` process takes too long.

#### **Troubleshooting Steps**:
1. **Use a smaller base image**:
   Replace `ubuntu` with `alpine` if possible.

2. **Cache dependencies**:
   Install dependencies in a single layer:
   ```dockerfile
   RUN apt-get update && apt-get install -y curl
   ```

3. **Minimize COPY instructions**:
   Only copy necessary files.

4. **Leverage build tools**:
   Use BuildKit for faster builds:
   ```bash
   DOCKER_BUILDKIT=1 docker build .
   ```

#### **Real-Life Example**:
Switching from `node:14` to `node:14-alpine` reduced build time significantly.

---

### **9. How do you handle container logs that grow too large?**

#### **Scenario**:
Log files inside a container consume excessive disk space.

#### **Troubleshooting Steps**:
1. **Limit log file size**:
   Use Docker’s log rotation options:
   ```json
   "log-driver": "json-file",
   "log-opts": {
     "max-size": "10m",
     "max-file": "3"
   }
   ```

2. **Redirect logs to external storage**:
   Use logging tools like ELK or Fluentd.

3. **Inspect current logs**:
   ```bash
   docker logs <container_id>
   ```

#### **Real-Life Example**:
Rotating logs for a high-traffic NGINX container avoided disk overflow.

---

### **10. How do you debug DNS issues inside a container?**

#### **Scenario**:
A container fails to resolve domain names.

#### **Troubleshooting Steps**:
1. **Test DNS resolution**:
   ```bash
   docker exec -it <container_id> nslookup google.com
   ```

2. **Inspect DNS settings**:
   ```bash
   docker inspect <container_id> | grep DNS
   ```

3. **Set custom DNS servers**:
   ```bash
   docker run --dns=8.8.8.8 <image_name>
   ```

#### **Real-Life Example**:
A corporate firewall blocked DNS traffic. Adding `8.8.8.8` as a custom DNS server resolved the issue.

---

