
---

## **1. How do you undo the last commit but keep the changes?**
**Answer:**  
```bash
git reset --soft HEAD~1
```
This removes the commit but retains the changes in the staging area.

---

## **2. How do you undo a commit and discard the changes permanently?**
**Answer:**  
```bash
git reset --hard HEAD~1
```

---

## **3. How do you remove a file from Git history?**
**Answer:**  
Use `filter-branch` or BFG:
```bash
git filter-branch --force --index-filter 'git rm --cached --ignore-unmatch <file>' --prune-empty --tag-name-filter cat -- --all
```

---

## **4. How do you squash the last 3 commits into one?**
**Answer:**
```bash
git rebase -i HEAD~3
```
Change the second and third commits to `squash`.

---

## **5. How do you resolve a merge conflict in Git?**
**Answer:**
1. Open the conflicted files and manually edit.
2. Stage the resolved files:
```bash
git add <file>
```
3. Commit:
```bash
git commit
```

---

## **6. How do you revert a specific commit without affecting other commits?**
**Answer:**
```bash
git revert <commit-hash>
```

---

## **7. How do you find the commit that introduced a bug?**
**Answer:**
Use `git bisect`:
```bash
git bisect start
git bisect bad
git bisect good <commit-hash>
```

---

## **8. How do you create and track a new branch?**
**Answer:**
```bash
git checkout -b new-feature
```

---

## **9. How do you delete a remote branch?**
**Answer:**
```bash
git push origin --delete branch-name
```

---

## **10. How do you push a local branch to the remote repository?**
**Answer:**
```bash
git push origin branch-name
```

---

## **11. How do you configure Git to ignore certain files?**
**Answer:**
Add those files or patterns to a `.gitignore` file.

---

## **12. How do you stash changes and apply them later?**
**Answer:**
```bash
git stash
git stash apply
```

---

## **13. How do you see who modified a specific line in a file?**
**Answer:**
```bash
git blame <file>
```

---

## **14. How do you create a patch from a commit?**
**Answer:**
```bash
git format-patch -1 <commit-hash>
```

---

## **15. How do you apply a patch in Git?**
**Answer:**
```bash
git apply <patch-file>
```

---

## **16. How do you fetch changes from the remote but not merge them?**
**Answer:**
```bash
git fetch origin
```

---

## **17. How do you rebase your feature branch with the latest main branch?**
**Answer:**
```bash
git checkout feature-branch
git fetch origin
git rebase origin/main
```

---

## **18. How do you tag a commit and push the tag?**
**Answer:**
```bash
git tag v1.0 <commit-hash>
git push origin v1.0
```

---

## **19. How do you view a Git log as a graph?**
**Answer:**
```bash
git log --oneline --graph --all
```

---

## **20. How do you clone only a specific branch from a repository?**
**Answer:**
```bash
git clone --branch branch-name --single-branch <repo-url>
```

---


## **21. How do you rename a local branch in Git?**
**Answer:**
- If you’re on the branch you want to rename:
  ```bash
  git branch -m new-branch-name
  ```
- If you’re on a different branch:
  ```bash
  git branch -m old-name new-name
  ```

---

## **22. How do you handle a detached HEAD state in Git?**
**Answer:**
- You're in detached HEAD when you checkout a commit instead of a branch.
- To recover:
  ```bash
  git checkout -b new-branch
  ```
  This saves your changes in a new branch.

---

## **23. How do you cherry-pick a commit from another branch?**
**Answer:**
```bash
git checkout your-branch
git cherry-pick <commit-hash>
```
This applies the changes of that specific commit to your current branch.

---

## **24. How do you track a remote branch that wasn’t tracked before?**
**Answer:**
```bash
git checkout --track origin/branch-name
```
This links your local branch with the remote one.

---

## **25. How do you configure your name and email globally for Git?**
**Answer:**
```bash
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```

---

