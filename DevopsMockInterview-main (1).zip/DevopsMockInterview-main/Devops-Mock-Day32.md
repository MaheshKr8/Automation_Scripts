### 1. **How do you archive artifacts in Jenkins?**
**Answer:**
1. **Freestyle Jobs:** Use the **"Archive the artifacts"** post-build action.
2. **Pipeline Jobs:** Use the `archiveArtifacts` step to store build artifacts for later use.

**Example:**
```groovy
archiveArtifacts artifacts: 'target/*.jar', allowEmptyArchive: true
```

### 2. **What is a Jenkins Build Node?**
**Answer:**
A build node is a machine where Jenkins runs a job. It can be the master or an agent. Nodes can be set up to run builds in parallel or in specific environments.

### 3. **How do you integrate Jenkins with Kubernetes?**
**Answer:**
1. **Install Kubernetes Plugin:** Install the **Kubernetes** plugin from the plugin manager.
2. **Configure Cloud:** In Jenkins, add a new cloud under **Manage Jenkins** > **Clouds**, pointing to your Kubernetes cluster.
3. **Define Pods:** Define pod templates that Jenkins will use to spin up agents dynamically in Kubernetes.

### 4. **What are post-build actions in Jenkins?**
**Answer:**
Post-build actions are steps executed after the build has completed. Common post-build actions include:
- Archiving artifacts
- Sending email notifications
- Deploying build artifacts
- Running tests or analysis

### 5. **What is Jenkins Job DSL, and how is it used?**
**Answer:**
Jenkins Job DSL (Domain Specific Language) allows you to define Jenkins jobs programmatically. You can store the DSL scripts in your version control system and create or update jobs automatically.

**Example:**
```groovy
job('example') {
    scm {
        git('git://github.com/example/repo.git')
    }
    triggers {
        scm('H/15 * * * *')
    }
    steps {
        shell('make test')
    }
}
```

### 6. **How do you configure Jenkins to run builds in Docker containers?**
**Answer:**
1. **Install Docker Plugin:** Install the **Docker** and **Docker Pipeline** plugins.
2. **Use Docker in Jenkinsfile:**
   - Use the `docker` block to build and run Docker containers.

**Example:**
```groovy
pipeline {
    agent {
        docker {
            image 'node:14'
            args '-v /var/run/docker.sock:/var/run/docker.sock'
        }
    }
    stages {
        stage('Build') {
            steps {
                sh 'npm install'
            }
        }
    }
}
```

### 7. **How do you troubleshoot Jenkins build failures?**
**Answer:**
1. **Console Output:** Review the job's console output for errors or issues.
2. **System Logs:** Check the Jenkins system logs under **Manage Jenkins** > **System Log** for background issues.
3. **Agent Issues:** Ensure agents have enough resources and are correctly configured.
4. **Re-run Failed Builds:** Use the **Rebuild** plugin to re-run failed builds without manual intervention.



### 8. **What is Jenkins Multibranch Pipeline, and why is it useful?**
**Answer:**
The Multibranch Pipeline automatically creates a pipeline for each branch in your repository. This allows different branches (like feature, develop, or main) to have their own pipeline, making CI/CD practices more efficient and branch-specific.

**Why it's useful:**
- Automates pipeline creation for new branches.
- Detects Jenkinsfiles in branches and executes them.
- Useful for projects that need different pipelines for different branches.

### 9. **How do you set up Jenkins to run jobs in a specific sequence (job chaining)?**
**Answer:**
1. **Post-build Actions:** Use the post-build action **"Build other projects"** to trigger another job after one job completes.
2. **Pipeline:** In the pipeline script, use `build` to trigger sequential jobs.

**Example:**
```groovy
stage('Job 1') {
    build job: 'job1'
}
stage('Job 2') {
    build job: 'job2'
}
```

### 10. **How do you restart Jenkins safely?**
**Answer:**
Jenkins can be restarted using the following steps:
1. **Safe Restart:** This ensures that Jenkins completes all running jobs before restarting.
   - Go to **Manage Jenkins** > **Prepare for Shutdown**.
   - You can also restart Jenkins using the URL `http://<jenkins-server>/safeRestart`.
   
2. **Command Line:** You can also restart Jenkins using the command:
   ```bash
   service jenkins restart
   ```

