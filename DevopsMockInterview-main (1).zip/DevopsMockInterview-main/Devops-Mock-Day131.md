
# Jenkins Real-Time Scenario-Based Interview Questions and Answers

## 1. A Jenkins build failed suddenly after working fine for months. How do you troubleshoot?
**Answer:**  
- Check **console output** for stack traces or error logs.
- Review recent **code changes** in the repo.
- Ensure build **dependencies (e.g., Maven, Python)** haven't been updated or removed.
- Verify system resources like **disk space**, memory, and agent availability.
- Check for **plugin or Jenkins version updates** that might have affected behavior.

---

## 2. You need to deploy an application to production only after manual approval. How do you handle it in Jenkins?
**Answer:**  
Use the `input` step in a pipeline:
```groovy
stage('Approval') {
  steps {
    input message: 'Approve Deployment to Prod?'
  }
}
```

This pauses the pipeline and waits for a human to approve.

---

## 3. A Jenkins agent keeps going offline during build execution. What’s your approach?

**Answer:**

* Check **agent logs** for errors or timeouts.
* Validate **network connectivity** to the Jenkins master.
* Ensure the agent has enough **CPU/RAM**.
* If using Docker/Kubernetes agents, check the **resource quotas** and pod stability.
* Restart the agent and observe stability.

---

## 4. You’re asked to deploy a microservices-based app using Jenkins and Docker. How do you design the pipeline?

**Answer:**

* Each microservice has its own Jenkins pipeline.
* Steps include:

  * Code checkout
  * Docker image build
  * Push image to Docker registry
  * Deployment using Kubernetes or Docker Compose
* Optionally, use `parallel` stages for independent services.

---

## 5. A Jenkins pipeline job is stuck in “Waiting for next available executor.” What do you do?

**Answer:**

* Check if there are **free executors** on the node or agent.
* Ensure the agent is **online and not overloaded**.
* Verify the **labels** on the job match available nodes.
* Increase **concurrent executors** if needed under node settings.

---

## 6. Your Jenkins deployment must comply with audit requirements. How do you implement traceability?

**Answer:**

* Use **Job DSL** or `Jenkinsfile` in Git for version control of pipelines.
* Configure **build history retention**.
* Integrate **notifications** and **logging** (e.g., SLACK, email, ELK stack).
* Enable **audit logs** and install the **Audit Trail plugin**.

---

## 7. How would you implement automated rollback in Jenkins if a deployment fails?

**Answer:**

* Use a deployment stage to capture the current (stable) version/tag.
* Monitor health checks post-deploy.
* If the new deployment fails, use a `catchError` or custom logic to trigger rollback.

```groovy
try {
  deployNewVersion()
} catch (Exception e) {
  echo "Rolling back..."
  deployOldVersion()
}
```

---

## 8. The Jenkins UI is slow and builds are taking longer than expected. What steps do you take?

**Answer:**

* Check **resource usage** on Jenkins master (CPU, RAM).
* Archive or delete **old builds** to reduce load.
* Tune **Garbage Collection (GC)** settings.
* Move heavyweight jobs to **dedicated agents**.
* Consider migrating to **Kubernetes-based dynamic agents**.

---

## 9. You need to run a pipeline only if the code is pushed to the "develop" branch. How do you handle that?

**Answer:**
Use a condition in `when`:

```groovy
stage('Build') {
  when {
    branch 'develop'
  }
  steps {
    sh './build.sh'
  }
}
```

---

## 10. You’re asked to integrate Jenkins with SonarQube and fail builds if code quality is below a threshold. What’s your approach?

**Answer:**

* Install and configure the **SonarQube plugin**.
* In the pipeline:

```groovy
withSonarQubeEnv('MySonarServer') {
  sh 'sonar-scanner'
}
```

* Use **Quality Gates plugin** to automatically fail the build if the gate fails.

---


