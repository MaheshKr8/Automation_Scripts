* Let's go through each of these questions with practical examples and explanations.

### 1. Jenkins Pipeline Failure Troubleshooting
* When a Jenkins pipeline fails during deployment, here are some steps you can take to troubleshoot:

* 1. **Check the Console Output:** Review the console output of the failed job to identify the error message.
* 2. **Check the Jenkins Slave:** Ensure that the Jenkins slave node where the job ran is healthy and has enough resources.
* 3. **Check the Environment Variables:** Verify that all necessary environment variables are correctly set.
* 4. **Check the Scripts:** Review the deployment scripts for syntax errors or incorrect commands.
* 5. **Check the Logs:** Look at the logs of the application being deployed for more specific error messages.

* Example script to check console output:
```sh
# Navigate to the Jenkins job and check the console output for errors
# Example Jenkins URL: http://your-jenkins-server/job/your-job-name/lastBuild/console
```

### 2. Integrate GitHub into Jenkins
* To integrate GitHub with Jenkins, follow these steps:

* 1. **Install GitHub Plugin:** Go to Jenkins Dashboard > Manage Jenkins > Manage Plugins > Available and install the GitHub plugin.
* 2. **Configure GitHub:** Go to Jenkins Dashboard > Manage Jenkins > Configure System. Under GitHub, add the GitHub Server with your credentials.
* 3. **Create a Job:** Create a new job and in the Source Code Management section, select Git. Enter your GitHub repository URL and credentials.
* 4. **Configure Webhook:** In your GitHub repository, go to Settings > Webhooks and add a webhook with the Jenkins URL `http://your-jenkins-server/github-webhook/`.

* Example Jenkinsfile:
```groovy
pipeline {
    agent any
    stages {
        stage('Checkout') {
            steps {
                git 'https://github.com/your-repo.git'
            }
        }
        stage('Build') {
            steps {
                sh 'make build'
            }
        }
        stage('Deploy') {
            steps {
                sh 'make deploy'
            }
        }
    }
}
```

### 3. Server Creation: Manual vs Automation
* Automating server creation can be done using tools like Terraform, Ansible, or CloudFormation.

* Example Terraform script for AWS EC2 instance:
```hcl
provider "aws" {
  region = "us-west-2"
}

resource "aws_instance" "example" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  tags = {
    Name = "example-instance"
  }
}
```
* Run the script with:
```sh
terraform init
terraform apply
```

### 4. AWS Global Services
* AWS services that are global include:
- Amazon CloudFront
- AWS Identity and Access Management (IAM)
- Amazon Route 53
- AWS Web Application Firewall (WAF)

### 5. NAT Gateway vs NAT Instance
- **NAT Gateway:** Managed service by AWS, higher availability, automatically scales, and charges are based on usage.
- **NAT Instance:** Requires manual management, scaling, and updates, and charges are based on instance type and usage.

* Purpose: To enable instances in a private subnet to connect to the internet or other AWS services, but prevent the internet from initiating connections to those instances.

### 6. On-Demand vs Spot EC2 Instances
- **On-Demand Instances:** Pay for compute capacity by the hour or second with no long-term commitments.
- **Spot Instances:** Purchase unused EC2 capacity at discounted rates, which can be interrupted by AWS when they need the capacity back.

### 7. Load Balancers
* Load balancers distribute incoming application traffic across multiple targets (e.g., EC2 instances, containers). They improve the availability and fault tolerance of your application.

* Example: AWS Elastic Load Balancing (ELB) with Application Load Balancer (ALB), Network Load Balancer (NLB), or Classic Load Balancer.

* A load balancer is a system that distributes incoming network or application traffic across multiple servers. This ensures no single server bears too much load, improving the overall performance, reliability, and availability of the application or service. 

### Key Benefits of Load Balancers:

* 1. **Improved Performance and Reliability**:
   - By distributing the workload evenly, load balancers prevent any single server from becoming a bottleneck, leading to better overall performance.
   - They enhance reliability by ensuring that if one server fails, the load balancer can redirect traffic to other functioning servers.

* 2. **Scalability**:
   - Load balancers allow the addition of more servers to handle increased traffic, ensuring the system can scale to meet demand.

* 3. **Redundancy and Failover**:
   - Load balancers can detect unhealthy servers and automatically reroute traffic to healthy ones, providing high availability and redundancy.

* 4. **Maintenance Without Downtime**:
   - Servers can be taken offline for maintenance or upgrades without affecting the availability of the application, as traffic can be rerouted to other servers.

### Types of Load Balancers:

* 1. **Application Load Balancer (ALB)**:
   - Operates at the application layer (Layer 7 of the OSI model).
   - Best suited for HTTP and HTTPS traffic.
   - Can route traffic based on advanced routing mechanisms like URL paths, host headers, and more.

* 2. **Network Load Balancer (NLB)**:
   - Operates at the transport layer (Layer 4 of the OSI model).
   - Best suited for TCP and UDP traffic.
   - Provides high throughput and low latency, capable of handling millions of requests per second.

* 3. **Classic Load Balancer (CLB)**:
   - Operates at both the application and transport layers (Layer 4 and Layer 7).
   - Legacy load balancer that supports basic load balancing of HTTP/HTTPS and TCP traffic.

### Use Cases of Load Balancers:

* 1. **Web Applications**:
   - Distribute incoming HTTP and HTTPS requests across multiple web servers to ensure a responsive and resilient web application.

* 2. **Microservices Architectures**:
   - Route traffic to appropriate backend services based on the request path or other attributes.

* 3. **Database Applications**:
   - Distribute database queries across multiple database servers to balance the load and improve query performance.

* 4. **Global Applications**:
   - Use global load balancers to route traffic to different geographical regions based on the user's location for faster response times.

### Example: AWS Elastic Load Balancing (ELB):

* In AWS, Elastic Load Balancing (ELB) provides three types of load balancers:

* 1. **Application Load Balancer (ALB)**:
   - Designed for modern application architectures, including microservices and containerized applications.

* 2. **Network Load Balancer (NLB)**:
   - Designed for extreme performance and can handle millions of requests per second.

* 3. **Classic Load Balancer (CLB)**:
   - Designed for applications built within the EC2-Classic network and used for both Layer 4 and Layer 7 load balancing.

### Example Configuration in Terraform:

#### Application Load Balancer (ALB):

```hcl
resource "aws_lb" "example_alb" {
  name               = "example-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb_sg.id]
  subnets            = aws_subnet.public_subnets[*].id

  enable_deletion_protection = false
}

resource "aws_lb_target_group" "example_tg" {
  name     = "example-tg"
  port     = 80
  protocol = "HTTP"
  vpc_id   = aws_vpc.main.id

  health_check {
    interval            = 30
    path                = "/"
    timeout             = 5
    healthy_threshold   = 5
    unhealthy_threshold = 2
    matcher             = "200"
  }
}

resource "aws_lb_listener" "example_listener" {
  load_balancer_arn = aws_lb.example_alb.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.example_tg.arn
  }
}

resource "aws_lb_target_group_attachment" "example_attachment" {
  target_group_arn = aws_lb_target_group.example_tg.arn
  target_id        = aws_instance.example.id
  port             = 80
}
```

* In this example, an Application Load Balancer is configured to distribute HTTP traffic across a group of instances. The target group, listener, and security group configurations ensure that the traffic is balanced and health checks are performed to maintain availability.

* By using load balancers, you can ensure that your applications are scalable, reliable, and performant, providing a seamless experience for users.

### 8. EC2 Instance Web Server Access Issue
* Possible reasons:
- **Security Group:** Ensure the security group attached to the EC2 instance allows inbound traffic on the web server port (e.g., port 80 for HTTP, port 443 for HTTPS).
- **Network ACL:** Ensure the Network ACL associated with the subnet allows inbound and outbound traffic on the web server port.

* The issue you’re experiencing, where you can access the internet from your EC2 instance but the outside world cannot access your web server, is often related to network configuration. Here are the potential reasons and steps to troubleshoot and resolve the issue:

### Potential Reasons:

* 1. **Security Group Configuration**:
   - The security group attached to your EC2 instance might not have the correct inbound rules to allow traffic from the outside world.

* 2. **Network ACLs**:
   - The Network Access Control Lists (ACLs) associated with the subnet might be blocking incoming traffic.

* 3. **EC2 Instance Firewall**:
   - The firewall on the EC2 instance itself (e.g., iptables, firewalld) might be blocking incoming connections.

* 4. **Elastic IP Address**:
   - If your instance is in a public subnet but does not have an Elastic IP or a public IP address assigned, it won’t be accessible from the internet.

* 5. **Route Table Configuration**:
   - The route table associated with the subnet might not be correctly configured to allow internet access.

### Troubleshooting Steps:

* 1. **Check Security Group Inbound Rules**:
   - Ensure that the security group attached to your EC2 instance allows inbound traffic on the necessary port (e.g., port 80 for HTTP, port 443 for HTTPS).

   ```sh
   # Example of allowing HTTP and HTTPS traffic
   aws ec2 authorize-security-group-ingress --group-id sg-xxxxxxxx --protocol tcp --port 80 --cidr 0.0.0.0/0
   aws ec2 authorize-security-group-ingress --group-id sg-xxxxxxxx --protocol tcp --port 443 --cidr 0.0.0.0/0
   ```

* 2. **Check Network ACLs**:
   - Ensure that the Network ACLs associated with the subnet allow inbound and outbound traffic on the necessary ports.

* 3. **Verify Instance Firewall Settings**:
   - Check the firewall settings on the instance itself to ensure it is not blocking incoming connections.

   ```sh
   sudo iptables -L
   ```

* 4. **Assign an Elastic IP**:
   - If your instance does not have a public IP, assign an Elastic IP address to it.

   ```sh
   aws ec2 associate-address --instance-id i-xxxxxxxx --allocation-id eipalloc-xxxxxxxx
   ```

* 5. **Check Route Table**:
   - Ensure that the route table associated with the subnet has a route to an internet gateway (IGW).

   ```sh
   # Example route to an internet gateway
   Destination: 0.0.0.0/0
   Target: igw-xxxxxxxx
   ```

### Example Configuration:

#### Security Group:
```hcl
resource "aws_security_group" "web_sg" {
  name        = "web_sg"
  description = "Allow HTTP and HTTPS traffic"

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

#### Assigning an Elastic IP:
```hcl
resource "aws_eip" "web_eip" {
  instance = aws_instance.web_instance.id
}
```

#### Route Table:
```hcl
resource "aws_route_table" "public_rt" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }
}
```

By following these steps, you can identify and resolve the issue preventing external access to your web server on the EC2 instance.


### 9. EC2 Instance Stop and IP Address
* When an EC2 instance is stopped and started again:
- **Public IP Address:** A new public IP address will be assigned unless you use an Elastic IP.
- **Private IP Address:** Remains the same.

### 10. Terminate EC2 Instance and Elastic IP

* When an EC2 instance is terminated:
- **Elastic IP:** Remains allocated to your account and can be reassigned to another instance. It will not be automatically deleted.


### 11. IAM Roles Usage
* IAM roles are used to grant permissions to AWS services to perform actions on your behalf.

* Example:
- Assign an IAM role to an EC2 instance to allow it to access S3 buckets without storing AWS credentials on the instance.

### 12. Terraform State File
* The Terraform state file keeps track of the resources managed by Terraform. It maps the real-world resources to the configuration.

### 13. Resolving Configuration Changes in Terraform
* To manage changes:
- **terraform plan:** Review changes before applying.
- **terraform apply:** Apply changes to match the configuration.
- **terraform state:** Manage and manipulate state files.

* When someone changes the configuration of already created resources using Terraform, it involves managing the state and ensuring that the changes are applied correctly. Here are the steps to resolve it:

* 1. **Review the Changes**:
   - Use `terraform plan` to see the proposed changes. This command will show a detailed comparison of the current state and the desired state as defined in the Terraform configuration files.

* 2. **Update the Configuration**:
   - Make sure the Terraform configuration files reflect the desired changes. This might involve modifying resource definitions, adding new resources, or changing resource parameters.

* 3. **Apply the Changes**:
   - Run `terraform apply` to apply the changes. Terraform will prompt for confirmation before making any changes to the infrastructure.

* 4. **Handle State File Conflicts**:
   - Ensure that the state file is up to date and consistent. If there are multiple people working with the same state file, use a remote backend (like AWS S3, Azure Storage, etc.) to store the state file to avoid conflicts.
   - Use `terraform state pull` to fetch the latest state before making changes.
   - If necessary, manually edit the state file using `terraform state` commands to remove any conflicts or inconsistencies.

* 5. **Locking the State File**:
   - Enable state locking to prevent concurrent modifications. This can be done by configuring the backend to support locking mechanisms (e.g., DynamoDB for S3 backend).

* 6. **Communicate with Team**:
   - Ensure all team members are aware of the changes and the impact on the existing infrastructure. This is crucial to avoid surprises and ensure smooth collaboration.

* 7. **Testing and Validation**:
   - After applying the changes, test the infrastructure to ensure that the desired changes have been implemented correctly and that the system functions as expected.

### Example Workflow:

* 1. **Plan the Changes**:
   ```sh
   terraform plan
   ```

* 2. **Apply the Changes**:
   ```sh
   terraform apply
   ```

* 3. **Pull the Latest State**:
   ```sh
   terraform state pull
   ```

* 4. **State Management** (if needed):
   ```sh
   terraform state rm <resource_name>
   terraform state mv <old_resource_name> <new_resource_name>
   ```

* 5. **Lock the State**:
   - For S3 backend, configure DynamoDB for state locking.

* 6. **Collaboration**:
   - Use version control systems (like Git) to manage Terraform configuration files and collaborate with the team effectively.

* By following these steps, you can manage changes to already created resources in Terraform efficiently and ensure the infrastructure remains consistent and reliable.

### 14. NACL vs Security Groups
- **Security Groups:** Stateful, rules apply to instance-level.
- **NACL:** Stateless, rules apply to subnet-level.

### 15. Attach S3 to EC2 Instance
* You cannot directly attach S3 as a block storage device. Instead, use the AWS CLI or SDK to interact with S3.

* For block storage, use:
- **EBS (Elastic Block Store)**
- **EFS (Elastic File System)**

* Example of mounting EFS on EC2:
```sh
# Install the EFS mount helper
sudo yum install -y amazon-efs-utils

# Mount the EFS filesystem
sudo mount -t efs fs-12345678:/ /mnt/efs
```
