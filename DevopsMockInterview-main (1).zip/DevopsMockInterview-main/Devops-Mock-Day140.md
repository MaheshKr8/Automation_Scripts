
---

### ✅ **1. Scenario: Your production Kubernetes cluster was accidentally deleted. What is your recovery process?**

**Answer:**

* Immediately assess what is lost: control plane, workloads, persistent volumes.
* **Recreate the cluster** using infrastructure-as-code (e.g., Terraform or eksctl).
* Use **etcd backup** (if self-managed) or cloud provider snapshots to restore state.
* Redeploy applications from GitOps repo (e.g., ArgoCD or Flux).
* Restore PVCs using snapshot backups (e.g., EBS snapshot).
* Post-incident: enforce RBAC, backups, and cluster deletion protection policies.

---

### ✅ **2. Scenario: You need to migrate hundreds of microservices from Jenkins to GitHub Actions in a regulated environment. What is your plan?**

**Answer:**

* Create **a reusable GitHub Actions workflow template** for consistency.
* Convert Jenkins shared libraries into reusable `.yaml` workflows.
* Migrate secrets securely using GitHub’s encrypted secrets.
* Validate compliance (e.g., audit trails, approvals, logs) with GitHub Enterprise features.
* Pilot migration with 1–2 critical services → gradually scale → monitor.
* Use observability tools to ensure pipeline performance post-migration.

---

### ✅ **3. Scenario: Terraform is used to provision both staging and production, but a bug accidentally deleted production DB. What would you do differently next time?**

**Answer:**

* Immediately **stop automation**, restore DB from snapshot/backup.
* Implement **environment isolation**: use different state files, backends, and IAM roles.
* Add manual `terraform apply` approval for production.
* Introduce `prevent_destroy = true` in sensitive Terraform resources.
* Use Sentinel or OPA policies to prevent accidental deletion of critical resources.

---

### ✅ **4. Scenario: Your application gets deployed successfully, but users report latency spikes. No errors in logs. What’s your troubleshooting path?**

**Answer:**

* Check **resource metrics** (CPU, memory, I/O) using Prometheus/Grafana.
* Look for **network throttling**, **DNS latency**, or autoscaling delay.
* Use **distributed tracing** (e.g., Jaeger/OpenTelemetry) to trace request hops.
* Analyze container-level metrics and node saturation.
* Enable application profiling (e.g., flamegraphs) if needed.

---

### ✅ **5. Scenario: Your deployment pipeline is taking 40+ minutes for a microservice. How would you optimize it?**

**Answer:**

* **Profile build time**: split slow stages (build/test/lint/scan).
* Use **Docker layer caching** and parallelized multi-stage builds.
* Cache dependencies (e.g., Maven `.m2`, NPM modules) between builds.
* Use **parallel test execution** (JUnit, pytest-xdist, etc.).
* Offload test environment provisioning using ephemeral infra (e.g., test namespaces in K8s).
* Optionally split CI and CD for large apps.

---

### ✅ **6. Scenario: A DevOps engineer accidentally deleted a critical secret from production. What controls should you enforce?**

**Answer:**

* Store all secrets in a **centralized secret manager** (e.g., Vault, AWS Secrets Manager).
* Enable **RBAC** with read-only access for most users.
* Audit access logs and rotate the secret immediately.
* Introduce **backup and versioning** of secrets.
* Implement approval workflows for production secret changes.

---

### ✅ **7. Scenario: Your monitoring tool (Prometheus) is down and you’re blind to system health. What’s your emergency response plan?**

**Answer:**

* Enable **redundant monitoring** (e.g., secondary Prometheus or cloud-native solutions like CloudWatch).
* Immediately **restart Prometheus** or restore from backup.
* Switch alerting temporarily to logs or external health checks (e.g., Pingdom, NewRelic).
* Post-recovery: set up **HA Prometheus**, regular backups, and alert on monitoring failures too.

---

### ✅ **8. Scenario: Your Kubernetes cluster is under a DDoS attack. What are your containment and defense strategies?**

**Answer:**

* Scale infrastructure horizontally via HPA and Cluster Autoscaler.
* Enable **WAF**, **rate limiting**, and **bot protection** at CDN/Ingress level.
* Use **Network Policies** to limit access scope internally.
* Temporarily **throttle ingress traffic** or filter via firewall.
* Monitor and blacklist source IPs or geographic regions.
* Post-attack: add auto-scaling limits, Ingress throttling, and DDoS protection at cloud provider level.

---

### ✅ **9. Scenario: A legacy monolith must be deployed weekly with downtime. How do you transition it to a modern CI/CD strategy?**

**Answer:**

* Containerize the monolith using Docker and refactor deployment into repeatable scripts.
* Slowly **extract features into microservices** if possible.
* Use **blue/green deployment** strategy to test traffic with zero downtime.
* Replace weekly deploys with frequent trunk-based CI/CD using pipelines.
* Enable **database versioning tools** (Liquibase/Flyway) to support DB migrations safely.

---

### ✅ **10. Scenario: Your cloud bill suddenly spikes 3x without changes in traffic. What’s your debugging approach?**

**Answer:**

* Analyze billing dashboard (AWS Cost Explorer, Azure Cost Management).
* Look for:

  * **Orphaned resources** (e.g., volumes, snapshots, LB IPs).
  * Sudden **autoscaling** (e.g., runaway job, cronjob, or DDOS).
  * High egress cost due to cross-region traffic.
* Use tagging to attribute costs by team/service.
* Implement daily budget alerts and anomaly detection.

---
