
---

### ✅ **1. What is Git and why is it used?**

**Answer:**
Git is a **distributed version control system** that tracks changes in code and helps multiple developers collaborate on a project. It allows branching, merging, rollbacks, and maintaining code history efficiently.

---

### ✅ **2. What is the difference between Git and GitHub?**

**Answer:**

* **Git**: A version control tool installed locally.
* **GitHub**: A remote hosting service for Git repositories, providing collaboration features like pull requests, issue tracking, etc.

---

### ✅ **3. What is the difference between `git pull` and `git fetch`?**

**Answer:**

| Command     | Description                                                        |
| ----------- | ------------------------------------------------------------------ |
| `git fetch` | Retrieves updates from the remote repo but doesn’t apply them.     |
| `git pull`  | Fetches and immediately merges the updates into your local branch. |

**Use case**: Use `git fetch` when you want to preview changes before merging.

---

### ✅ **4. How do you resolve a merge conflict in Git?**

**Answer:**

1. Open the conflicted file(s).
2. Look for conflict markers (`<<<<<<<`, `=======`, `>>>>>>>`).
3. Edit to resolve conflicts manually.
4. Run:

   ```bash
   git add <file>
   git commit
   ```

---

### ✅ **5. What is the difference between `git reset`, `git revert`, and `git checkout`?**

**Answer:**

| Command        | Description                                                               |
| -------------- | ------------------------------------------------------------------------- |
| `git reset`    | Moves HEAD and optionally changes the staging area and working directory. |
| `git revert`   | Creates a new commit that undoes changes from a previous commit.          |
| `git checkout` | Switches branches or restores files.                                      |

Use `reset` locally, `revert` on shared branches.

---

### ✅ **6. How do you create and switch to a new branch?**

**Answer:**

```bash
git checkout -b feature-branch
```

Creates and switches to a new branch named `feature-branch`.

---

### ✅ **7. How can you undo the last commit but keep the changes?**

**Answer:**

```bash
git reset --soft HEAD~1
```

This removes the last commit but leaves your changes staged.

---

### ✅ **8. What is the purpose of `.gitignore`?**

**Answer:**
`.gitignore` specifies which files or directories Git should ignore (e.g., logs, build artifacts, secrets). Example:

```
node_modules/
*.log
.env
```

---

### ✅ **9. How do you stash changes and reapply them later?**

**Answer:**

```bash
git stash
# Work on other things
git stash apply  # or pop to remove after applying
```

Useful for saving uncommitted work temporarily.

---

### ✅ **10. How do you see who made changes to a file line-by-line?**

**Answer:**

```bash
git blame <file>
```

Shows each line of the file with the author and commit ID that last modified it.

---
