
---

### 🔥 1. **Q: You get `Error response from daemon: pull access denied` while pulling an image. What does it mean and how do you resolve it?**

**A:**
This error typically means:

* You are trying to pull a **private image** from Docker Hub or another registry.
* You're **not authenticated** to access that image.

✅ **Fix:**

```bash
docker login
```

Then pull the image again.

If it's a private repository (e.g., `myorg/private-image`), make sure you have access and credentials.

---

### 🔥 2. **Q: Why do you see `port is already allocated` error when starting a container?**

**A:**
You’re trying to bind a host port that is **already used by another container or process**.

✅ **Fix:**

* Check port usage:

  ```bash
  sudo lsof -i :<port>
  docker ps
  ```
* Stop or remove the conflicting container or change the port:

  ```bash
  docker container run -p 8081:8080 myapp
  ```

---

### 🔥 3. **Q: What does `OCI runtime create failed: container_linux.go` error mean?**

**A:**
This usually points to:

* Docker failing to create the container due to **volume, permission, or configuration issues**.

✅ **Fix:**

* Check for:

  * Invalid mount paths
  * SELinux or AppArmor restrictions
  * File permission errors

Example:

```bash
docker run -v /my/host/path:/container/path myimage
# Check if /my/host/path exists and is accessible
```

---

### 🔥 4. **Q: Why does Docker say `No such file or directory` when starting a container?**

**A:**

* The **ENTRYPOINT** or **CMD** file doesn’t exist or is not executable inside the container.

✅ **Fix:**

* Use absolute paths.
* Check if the command exists inside the container:

```dockerfile
CMD ["/bin/bash", "-c", "echo Hello"]
```

---

### 🔥 5. **Q: You get `exec format error` when running a container. Why?**

**A:**

* You built the image on a different **architecture** (e.g., ARM vs x86).

✅ **Fix:**

* Rebuild the image on the correct architecture.
* Or use multi-arch images using:

```bash
docker buildx build --platform linux/amd64 .
```

---

### 🔥 6. **Q: Container exits immediately after running. Why?**

**A:**

* Your container runs a short-lived process (e.g., echo, script) and exits.

✅ **Fix:**

* Attach a long-running process:

```dockerfile
CMD ["catalina.sh", "run"]
```

* Or run it interactively for debugging:

```bash
docker run -it myapp /bin/bash
```

---

### 🔥 7. **Q: Getting `Cannot connect to the Docker daemon` error?**

**A:**

* Docker service is not running.
* Or the user doesn’t have permission to run Docker.

✅ **Fix:**

```bash
sudo systemctl start docker
sudo usermod -aG docker $USER
```

Then re-login or reboot.

---

### 🔥 8. **Q: You face `permission denied` when mounting a volume. What’s the reason?**

**A:**

* The container process lacks permissions to access the host path.
* Or SELinux blocks it (RHEL/CentOS-based systems).

✅ **Fix:**

* Use proper permissions:

```bash
chmod -R 777 /data
```

* Or in SELinux-based systems:

```bash
docker run -v /data:/app:Z myapp
```

---

### 🔥 9. **Q: Getting `image not found` during build stage in multi-stage Dockerfile?**

**A:**

* One of the base images is misspelled or missing.

✅ **Fix:**

* Validate image names and tags:

```dockerfile
FROM node:14 AS builder
# Make sure node:14 exists
```

* Test pulling the base image manually:

```bash
docker pull node:14
```

---

### 🔥 10. **Q: Docker container builds successfully, but `docker run` fails to serve the app. What are possible causes?**

**A:**

* Application not listening on correct port/interface.
* Healthcheck failures.
* Entrypoint or command fails silently.

✅ **Fix:**

* Check logs:

```bash
docker logs <container_id>
```

* Test inside the container:

```bash
docker exec -it <container_id> /bin/bash
```

* Ensure app binds to `0.0.0.0` not `localhost`.

---

## ✅ Bonus: Tips to Impress in Interviews

| Tip                                                                        | Details                             |
| -------------------------------------------------------------------------- | ----------------------------------- |
| 🛠️ Use `docker logs`, `docker inspect`, and `docker exec` to troubleshoot | Shows real-time debugging skill     |
| 🔍 Understand networking and port binding                                  | Vital for production containers     |
| 📂 Know volume permissions and SELinux handling                            | Common in RHEL-based infra          |
| 🧱 Be confident with Dockerfile troubleshooting                            | Especially multi-stage builds       |
| 🔁 Know how to clean Docker cache and troubleshoot layer errors            | `--no-cache`, `.dockerignore`, etc. |

---

