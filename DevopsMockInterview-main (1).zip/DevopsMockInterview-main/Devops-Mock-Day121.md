
---

### ✅ 1. **What is DevOps and its core principles?**

**Answer:**
DevOps is a set of practices that combines software development and IT operations to shorten development cycles, increase deployment frequency, and ensure reliable releases.
**Core principles:** Automation, Continuous Integration/Deployment, Collaboration, Monitoring, and Infrastructure as Code.

---

### ✅ 2. **Explain CI/CD. How is it implemented?**

**Answer:**
CI/CD stands for Continuous Integration and Continuous Deployment.

* **CI**: Developers merge code regularly; automated tests and builds are triggered.
* **CD**: Once CI is successful, code is automatically deployed to staging/production.
  **Tools:** Jenkins, GitLab CI, GitHub Actions, Argo CD.

---

### ✅ 3. **What is the role of Jenkins in DevOps?**

**Answer:**
Jenkins is an open-source CI/CD tool used to automate build, test, and deployment pipelines. Supports plugins for Git, Docker, Kubernetes, and SonarQube.

---

### ✅ 4. **How do you containerize an application using Docker?**

**Answer:**

* Create a `Dockerfile` with instructions to package app and dependencies
* Build image: `docker build -t myapp .`
* Run container: `docker run -p 8080:80 myapp`

---

### ✅ 5. **What is Kubernetes? How does it work?**

**Answer:**
Kubernetes is an orchestration tool for managing containerized applications.
**Key components:** Pod, Node, Deployment, Service, ConfigMap, Secret.

---

### ✅ 6. **What is a Helm chart?**

**Answer:**
Helm is a package manager for Kubernetes. Helm charts help define, install, and upgrade Kubernetes applications using templates and values files.

---

### ✅ 7. **How do you monitor applications and infrastructure?**

**Answer:**

* **Metrics**: Prometheus, Grafana
* **Logs**: ELK Stack (Elasticsearch, Logstash, Kibana)
* **Alerts**: Alertmanager, CloudWatch

---

### ✅ 8. **What is Infrastructure as Code (IaC)?**

**Answer:**
IaC is managing infrastructure using code instead of manual processes.
**Tools:** Terraform, CloudFormation, Pulumi

---

### ✅ 9. **How do you manage Terraform state securely?**

**Answer:**
Use **remote state backend** like AWS S3 with **DynamoDB locking**, encryption, and versioning to avoid conflicts and corruption.

---

### ✅ 10. **What is Ansible? How is it used in DevOps?**

**Answer:**
Ansible is a configuration management tool used to automate software provisioning, configuration, and deployment. Written in YAML (playbooks).

---

### ✅ 11. **What are blue-green and canary deployments?**

**Answer:**

* **Blue-Green**: Two environments, switch traffic to green once it's ready.
* **Canary**: Release to a small subset of users, then gradually to all.

---

### ✅ 12. **How do you implement secrets management in Kubernetes?**

**Answer:**
Use `kubectl create secret`, or integrate with **external secret managers** (AWS Secrets Manager, Vault). Optionally use **Sealed Secrets** or **SOPS**.

---

### ✅ 13. **How do you handle rolling updates in Kubernetes?**

**Answer:**
Using `Deployment` resource:

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 1
    maxSurge: 1
```

---

### ✅ 14. **What is a load balancer and how does it work in cloud?**

**Answer:**
A load balancer distributes traffic across multiple instances.
**AWS ELB Types**: Classic, ALB (L7), NLB (L4)

---

### ✅ 15. **How do you use Git in your DevOps workflow?**

**Answer:**
Use Git for version control with branching strategies (feature, develop, main). Integrated with CI/CD tools for automation.

---

### ✅ 16. **What is the difference between a monolith and microservices architecture?**

**Answer:**

* **Monolith**: Single codebase, tightly coupled
* **Microservices**: Independent services, loosely coupled, easier to scale

---

### ✅ 17. **What is the use of Trivy or SonarQube in DevOps?**

**Answer:**

* **Trivy**: Scans container images for vulnerabilities
* **SonarQube**: Analyzes code for bugs, vulnerabilities, code smells, and test coverage

---

### ✅ 18. **How do you troubleshoot Kubernetes pod issues?**

**Answer:**

* `kubectl get pods`, `describe pod`, `logs pod`
* Check for crash loops, resource limits, readiness probes

---

### ✅ 19. **How do you automate Docker image versioning in CI/CD?**

**Answer:**
Use build tools to inject version:

```bash
docker build -t myapp:${BUILD_NUMBER} .
docker push myapp:${BUILD_NUMBER}
```

---

### ✅ 20. **How do you ensure high availability and fault tolerance?**

**Answer:**

* Deploy in **multi-AZ** or **multi-region**
* Use **auto-scaling groups**, load balancers
* Backups, monitoring, and failover mechanisms

---
