
### **1. How to check the current kernel version?**

**Command:**
```bash
uname -r
```

**Explanation:**  
The kernel is the core of the operating system, managing hardware and system resources. Knowing the current kernel version is essential for:

- **Compatibility Checks:** When installing software or drivers, you may need a specific kernel version.  
- **Debugging Issues:** Kernel updates might introduce or fix issues; checking the version helps in troubleshooting.  
- **System Updates:** Some updates require specific kernels, so it's crucial to verify the version before proceeding.  

### **2. How to check system uptime?**

**Command:**
```bash
uptime
```

**Explanation:**  
The `uptime` command shows how long the system has been running, the number of logged-in users, and the system load averages over the last 1, 5, and 15 minutes. This information is crucial for:

- **Troubleshooting Downtime:** Helps verify whether a server has rebooted unexpectedly.  
- **Performance Monitoring:** Long uptimes are often associated with stable systems, but they might also indicate missed critical updates requiring a reboot.  
- **System Health Checks:** Load averages indicate system performance and help identify potential bottlenecks.

**Example Output:**
```
15:45:26 up 12 days,  3:04,  2 users,  load average: 0.12, 0.15, 0.09
```

- **`up 12 days, 3:04`:** The system has been running for 12 days and 3 hours.
- **`2 users`:** Two users are logged in.
- **`load average`:** The system's average CPU load for 1, 5, and 15 minutes. Values below `1.00` generally indicate low system usage.

This is especially useful in real-life scenarios to ensure a stable and continuously running server in production environments.

### **3. How to display memory usage in real-time?**

**Command:**
```bash
free -h
```

**Explanation:**  
The `free` command provides a snapshot of the system's memory usage, including total, used, and available memory. Adding the `-h` option makes the output human-readable by displaying sizes in KB, MB, or GB.

**Why it’s useful:**  
- **Troubleshooting Performance:** Quickly check if the system is running low on memory.  
- **Monitoring Resource Utilization:** Identify whether applications are consuming too much memory.  
- **Planning Upgrades:** Determine if additional memory is required for the server.  

**Example Output:**
```
              total        used        free      shared  buff/cache   available
Mem:           7.8G        3.2G        1.5G        251M        3.1G        4.2G
Swap:          2.0G        512M        1.5G
```

- **`total`:** Total amount of memory available on the system.
- **`used`:** Memory currently in use by processes.
- **`free`:** Unused memory available for allocation.
- **`shared`:** Memory shared between processes (e.g., shared libraries).
- **`buff/cache`:** Memory used by the system for buffers and caches.
- **`available`:** Memory available for new applications (including reclaimable buffers/caches).

**Real-Life Use Case:**  
If an application is slowing down, use `free -h` to verify if the slowdown is due to high memory usage or excessive swapping (memory moved to disk). This information helps in optimizing applications or deciding on hardware upgrades.

### **4. How to kill a process by its name?**

**Command:**
```bash
pkill -f process_name
```

**Explanation:**  
The `pkill` command terminates processes by matching their names. Adding the `-f` option ensures the search matches the full command line of the process, not just the executable name. This is particularly useful when multiple processes share similar names.

**Why it’s useful:**  
- **Stopping Faulty Processes:** Quickly terminate a misbehaving or unresponsive application.  
- **Managing Multiple Instances:** End all instances of a specific application in one command.  
- **Automation in Scripts:** Automate the termination of processes during deployments or maintenance.

**Example Usage:**  
To kill all instances of a Python script named `my_script.py`:
```bash
pkill -f my_script.py
```

**Real-Life Use Case:**  
Imagine a scenario where multiple instances of a script, `backup.py`, are running due to a misconfigured cron job. Instead of finding each process manually using `ps` and killing them with `kill`, `pkill -f backup.py` will stop all instances efficiently.

**Caution:**  
- Use with care to avoid unintended process termination.
- Verify the process name using `ps aux | grep process_name` before using `pkill`.

### **5. How to change the hostname of a Linux server?**

**Command:**
```bash
sudo hostnamectl set-hostname new-hostname
```

**Explanation:**  
The `hostnamectl` command is used to change the system hostname on modern Linux distributions. This is a more reliable and permanent method compared to older methods like editing `/etc/hostname` directly.

**Why it’s useful:**  
- **Identifying Servers:** Changing the hostname helps to clearly identify a server on a network. This is particularly useful in large environments with many machines.
- **During System Setup:** When deploying a new server, setting a unique hostname is one of the first steps.
- **Network Management:** A correct hostname ensures smooth DNS resolution, especially in environments where systems communicate based on their hostnames.

**Example Usage:**  
To set the hostname to `web-server-01`, use:
```bash
sudo hostnamectl set-hostname web-server-01
```

**Real-Life Use Case:**  
When deploying a new server for a web application, you may want to change the hostname to something meaningful (e.g., `web-server-01`) to identify it easily in a list of production servers. After changing the hostname, the new name will appear in commands like `hostname` or in the system logs. 

To verify the change, you can use the following command:
```bash
hostnamectl
```

This will display the current hostname, along with other system information. 

### Additional Notes:
- The change will take effect immediately but may require a reboot for all services to recognize the new hostname.
- In some older distributions, you may also need to update `/etc/hosts` to reflect the new hostname, especially if it's part of a network where the hostname is resolved locally.




### **6. How to find a specific string in a file?**

**Command:**
```bash
grep 'search_string' /path/to/file
```

**Explanation:**  
The `grep` command is used to search for a specific string (or pattern) within a file. It outputs all lines in the file that contain the matching string. `grep` is a powerful tool, supporting regular expressions for more complex searches.

**Why it’s useful:**  
- **Quick Search:** Efficiently find specific entries in large log files, configuration files, or source code.
- **Debugging Logs:** Identify error messages or specific events in system logs (e.g., `syslog`, `dmesg`).
- **Automation and Scripting:** Search for specific patterns automatically in scripts or during system checks.

**Example Usage:**  
To find the string "error" in a file called `application.log`:
```bash
grep 'error' application.log
```

**Real-Life Use Case:**  
Suppose you're troubleshooting an application, and you want to find any instances of an error message in the log file. You can quickly search the log using `grep 'error' /var/log/application.log` to identify the relevant entries without manually reading the entire file.

### Useful Options:
- **Case-Insensitive Search:**
  ```bash
  grep -i 'search_string' /path/to/file
  ```
  This option allows you to search without worrying about case sensitivity (e.g., "Error" or "error").

- **Show Line Numbers:**
  ```bash
  grep -n 'search_string' /path/to/file
  ```
  This option will display the line numbers along with the matching lines, which is helpful for quickly locating where the string appears in the file.

- **Search Recursively in Directories:**
  ```bash
  grep -r 'search_string' /path/to/directory
  ```
  This command will search for the string in all files within the directory and subdirectories.

### **7. How to list all active cron jobs?**

**Command:**
```bash
crontab -l
```

**Explanation:**  
The `crontab -l` command lists all the active cron jobs for the current user. Cron jobs are scheduled tasks that run at specified times or intervals. This command is useful to review the scheduled tasks and ensure they are set up as expected.

**Why it’s useful:**  
- **Verification:** Ensure that the correct cron jobs are set up to run on time, especially for automation tasks such as backups, updates, or maintenance jobs.
- **Troubleshooting:** If a task isn’t running as expected, you can use this command to confirm whether the cron job exists and is scheduled correctly.
- **Audit:** Review cron jobs to prevent any unauthorized or forgotten jobs from running.

**Example Usage:**
```bash
crontab -l
```
The output might look like this:
```
0 2 * * * /home/user/scripts/backup.sh
30 5 * * 1 /home/user/scripts/cleanup.sh
```
This shows two scheduled cron jobs:
- **Backup job**: Runs every day at 2:00 AM.
- **Cleanup job**: Runs every Monday at 5:30 AM.

### Additional Notes:
- The `crontab -l` command shows the cron jobs for the **current user**. To view the cron jobs for other users (if you're an admin), you can run:
  ```bash
  sudo crontab -l -u username
  ```
- Cron jobs are typically stored in `/var/spool/cron/crontabs` (in most distributions), but it's not recommended to edit these files directly; use `crontab -e` to edit the jobs safely.

### **8. How to find the size of all files in a directory?**

**Command:**
```bash
du -ah /path/to/directory | sort -h
```

**Explanation:**  
The `du` (disk usage) command is used to estimate file space usage in a directory. The options used in this command are:

- **`-a`**: Displays the size of all files (not just directories).
- **`-h`**: Provides human-readable output, showing file sizes in KB, MB, or GB.
- **`sort -h`**: Sorts the results by size in human-readable format, from smallest to largest.

**Why it’s useful:**  
- **Disk Space Management:** Identify large files consuming excessive disk space in a directory.  
- **Cleanup or Migration:** Helps in deciding which files to delete, move, or archive when disk space is running out.
- **Monitoring:** Regularly checking file sizes can help ensure the directory doesn't grow unexpectedly large due to log files or backups.

**Example Usage:**
```bash
du -ah /var/log | sort -h
```
This will display all files and their sizes under `/var/log`, sorted from smallest to largest.

**Example Output:**
```
4.0K    /var/log/syslog.1
4.0K    /var/log/auth.log.1
12K     /var/log/dmesg
100K    /var/log/syslog
1.5G    /var/log/mysql/
2.3G    /var/log/
```

In this example:
- The command shows the sizes of individual files as well as directories within `/var/log`, sorted by size.
- The largest directory or file is listed at the bottom (in this case, `/var/log/mysql/`).

### Additional Notes:
- **Total Size of a Directory:** If you only want the total size of a directory (without listing individual files), use:
  ```bash
  du -sh /path/to/directory
  ```
  The `-s` option shows only the total size, while `-h` makes it human-readable.

### **9. How to get the public IP of a server?**

**Command:**
```bash
curl -s ifconfig.me
```

**Explanation:**  
The `curl` command is used to make HTTP requests from the command line. By using the URL `ifconfig.me`, this command retrieves the public IP address of the server by querying an external service.

- **`curl`**: Transfers data from or to a server.
- **`-s`**: Suppresses the progress meter or error messages for a cleaner output.
- **`ifconfig.me`**: A simple service that returns the public IP address of the machine making the request.

**Why it’s useful:**  
- **Quick Access:** Instantly find out the public IP address of a server, which is crucial for network configuration, firewall settings, or troubleshooting.
- **Remote Access Setup:** When setting up remote access, you'll often need to know the server’s public IP for configurations such as SSH, VPNs, or firewall rules.
- **Cloud or VPS Management:** Cloud providers typically assign dynamic public IPs, and this command helps track those addresses quickly.

**Example Usage:**
```bash
curl -s ifconfig.me
```
Output:
```
203.0.113.45
```

This shows the public IP address of the server, in this case, `203.0.113.45`.

### Additional Notes:
- **Alternative Services:** There are other services that can also provide the public IP, like `ipinfo.io`, `icanhazip.com`, etc. For example:
  ```bash
  curl -s https://ipinfo.io/ip
  ```
- **Using in Scripts:** This command is often used in automation or monitoring scripts to dynamically retrieve the server's public IP.

### **10. How to restart a service?**

**Command:**
```bash
sudo systemctl restart service_name
```

**Explanation:**  
The `systemctl` command is used to control system services on Linux systems that use `systemd` for service management. The `restart` option stops and then starts the service again.

- **`sudo`**: Executes the command with superuser privileges (necessary for managing system services).
- **`systemctl`**: The system and service manager in Linux.
- **`restart`**: Stops and then immediately starts the service.
- **`service_name`**: The name of the service you want to restart (e.g., `nginx`, `apache2`, `mysql`).

**Why it’s useful:**  
- **Service Troubleshooting:** If a service is not behaving correctly, restarting it can resolve temporary issues, such as crashes or configuration reloads.
- **Applying Configuration Changes:** After modifying a service's configuration file, restarting it ensures the new settings are applied.
- **Service Recovery:** If a service is stuck or frozen, restarting can often resolve the problem.

**Example Usage:**
To restart the `nginx` web server:
```bash
sudo systemctl restart nginx
```

**Real-Life Use Case:**  
Imagine you're modifying the configuration of the `nginx` server to change the listening port or enable a new module. After making these changes, you would use the `systemctl restart` command to apply the new configuration:
```bash
sudo systemctl restart nginx
```

### Additional Notes:
- **Check Service Status After Restart:** To ensure the service restarted successfully, use:
  ```bash
  sudo systemctl status service_name
  ```
- **If the service fails to restart:** Check the service logs using `journalctl` to diagnose potential issues:
  ```bash
  sudo journalctl -u service_name
  ```

---
### **File Management Scenarios**
---

#### **11. How to copy a file from one location to another?**
```bash
cp /path/to/source /path/to/destination
```

#### **12. How to rename a file?**
```bash
mv old_file_name new_file_name
```

#### **13. How to move all `.log` files to another directory?**
```bash
mv *.log /path/to/destination/
```

#### **14. How to create a symbolic link?**
```bash
ln -s /original/file /path/to/link
```

#### **15. How to compare two files line by line?**
```bash
diff file1 file2
```

#### **16. How to count the number of lines in a file?**
```bash
wc -l file_name
```

#### **17. How to delete empty files from a directory?**
```bash
find /path/to/dir -type f -empty -delete
```

#### **18. How to create a compressed zip file?**
```bash
zip -r archive.zip /path/to/directory
```

#### **19. How to extract a `.tar.gz` file?**
```bash
tar -xvzf archive.tar.gz
```

#### **20. How to check the file type of a specific file?**
```bash
file file_name
```

