### **1. What is Kubernetes?**

Kubernetes, often abbreviated as **K8s**, is an **open-source container orchestration platform** designed to automate the deployment, scaling, and management of containerized applications. Initially developed by Google, it is now maintained by the **Cloud Native Computing Foundation (CNCF)**.

---

### **Key Features of Kubernetes**
1. **Container Orchestration**: Automatically manages containerized applications, ensuring efficient resource utilization.
2. **Self-Healing**: Detects and replaces failed containers automatically, ensuring high availability.
3. **Load Balancing and Service Discovery**: Automatically balances traffic across containers and discovers services using built-in DNS.
4. **Automated Rollouts and Rollbacks**: Handles rolling updates to the application and reverts changes in case of failure.
5. **Horizontal Scaling**: Dynamically adjusts the number of running containers based on demand using metrics.
6. **Storage Orchestration**: Mounts and manages persistent storage volumes for stateful applications.
7. **Configuration Management**: Manages application configuration and secrets without embedding sensitive information in images.

---

### **How Kubernetes Works**
1. **Cluster Architecture**:
   - **Master Node (Control Plane)**: Manages the overall cluster and coordinates tasks.
     - Components: API Server, Controller Manager, Scheduler, etcd (key-value store).
   - **Worker Nodes**: Run the application workloads.
     - Components: Kubelet, Kube Proxy, Container Runtime (e.g., Docker, containerd).

2. **Core Concepts**:
   - **Pods**: The smallest deployable unit in Kubernetes, encapsulating one or more containers.
   - **Services**: Abstracts and exposes a set of pods as a network service.
   - **Deployments**: Defines the desired state of an application, enabling rolling updates.
   - **ConfigMaps and Secrets**: Manage configuration and sensitive data separately from application code.

---

### **Real-Life Example:**
**Scenario**: Deploying a web application with Kubernetes.
1. **Application Image**: Build a Docker image for your web app.
2. **Deployment**:
   - Create a Kubernetes `Deployment` YAML file to define the app’s desired state:
     ```yaml
     apiVersion: apps/v1
     kind: Deployment
     metadata:
       name: my-app
     spec:
       replicas: 3
       selector:
         matchLabels:
           app: my-app
       template:
         metadata:
           labels:
             app: my-app
         spec:
           containers:
           - name: app-container
             image: my-app:latest
             ports:
             - containerPort: 80
     ```
3. **Service**:
   - Expose the app to the outside world using a `Service`:
     ```yaml
     apiVersion: v1
     kind: Service
     metadata:
       name: my-app-service
     spec:
       selector:
         app: my-app
       ports:
       - protocol: TCP
         port: 80
         targetPort: 80
       type: LoadBalancer
     ```
4. **Scaling**:
   - Scale the app to handle more traffic:
     ```bash
     kubectl scale deployment my-app --replicas=5
     ```

---

### **Benefits of Kubernetes**
- **High Availability**: Ensures application uptime with automatic failover and self-healing.
- **Portability**: Works across different environments (on-premises, cloud, hybrid).
- **Cost Efficiency**: Optimizes resource utilization and scales workloads dynamically.
- **Extensibility**: Supports custom plugins and integrations.

---

### **2. What are the main Components of Kubernetes**

Kubernetes operates on a **cluster architecture** comprising a **Control Plane** (master node) and **Worker Nodes**. Here’s a detailed breakdown of its key components:

---

### **1. Control Plane Components**
The **Control Plane** manages the overall state and coordination of the Kubernetes cluster.

#### **a. API Server (`kube-apiserver`)**
- **Role**: Acts as the front-end for the Kubernetes control plane. All external and internal communications with the cluster go through the API Server.
- **Function**:
  - Processes REST API requests for resource management (e.g., Pods, Deployments).
  - Validates and executes configuration changes.
- **Example**: 
  ```bash
  kubectl get pods
  ```
  This command interacts with the API Server to fetch pod information.

#### **b. Controller Manager (`kube-controller-manager`)**
- **Role**: Manages controllers that ensure the desired state of the cluster matches the actual state.
- **Controllers Include**:
  - **Node Controller**: Monitors the health of nodes.
  - **Replication Controller**: Ensures the specified number of pod replicas are running.
  - **Endpoints Controller**: Manages service endpoints.
  - **Service Account and Token Controllers**: Manage service accounts and authentication tokens.

#### **c. Scheduler (`kube-scheduler`)**
- **Role**: Assigns newly created pods to appropriate nodes based on resource requirements and constraints.
- **Function**:
  - Analyzes pod specifications (e.g., CPU, memory) and node capacity.
  - Ensures efficient resource utilization and workload distribution.

#### **d. etcd**
- **Role**: A distributed key-value store that serves as the cluster's database.
- **Function**:
  - Stores all cluster data, including configuration and state information.
  - Ensures high availability with distributed storage.
- **Example**: Stores pod and node states.

#### **e. Cloud Controller Manager**
- **Role**: Interacts with cloud-specific APIs for managing resources like load balancers, storage, and networking.
- **Components**:
  - **Node Controller**: Checks if a node has been deleted in the cloud.
  - **Route Controller**: Configures routes in the cloud for cluster networking.
  - **Volume Controller**: Manages cloud storage volumes.

---

### **2. Node Components**
The **Worker Nodes** handle application workloads by running containerized applications.

#### **a. Kubelet**
- **Role**: The primary agent running on each worker node.
- **Function**:
  - Ensures containers are running in pods as specified in the manifest files.
  - Communicates with the API Server to manage pod lifecycle.
- **Example**:
  Monitors a pod and restarts it if it fails.

#### **b. Kube Proxy**
- **Role**: Maintains network rules on nodes and handles pod-to-pod or pod-to-service communication.
- **Function**:
  - Implements service discovery and load balancing.
  - Routes traffic to the appropriate pod.

#### **c. Container Runtime**
- **Role**: Runs and manages containers on each worker node.
- **Supported Runtimes**:
  - Docker
  - containerd
  - CRI-O

---

### **3. Add-Ons (Optional Components)**
Enhance the functionality of Kubernetes clusters.

#### **a. CoreDNS**
- **Role**: Provides DNS-based service discovery within the cluster.
- **Example**:
  Resolves `my-service.default.svc.cluster.local` to the service's ClusterIP.

#### **b. Dashboard**
- **Role**: A web-based user interface for managing the Kubernetes cluster.

#### **c. Metrics Server**
- **Role**: Aggregates resource metrics (e.g., CPU, memory) from nodes and pods.
- **Example**:
  Used by the Horizontal Pod Autoscaler (HPA) to scale applications.

---

### **Summary of Kubernetes Architecture**
| Component          | Role                               | Location         |
|--------------------|------------------------------------|------------------|
| API Server         | Cluster front-end                 | Control Plane    |
| Controller Manager | Ensures desired state             | Control Plane    |
| Scheduler          | Assigns pods to nodes             | Control Plane    |
| etcd               | Stores cluster data               | Control Plane    |
| Kubelet            | Manages pods on worker nodes      | Worker Node      |
| Kube Proxy         | Manages networking for pods       | Worker Node      |
| Container Runtime  | Runs containers (e.g., Docker)    | Worker Node      |

---

### **3. What is a Pod in Kubernetes?**

A **Pod** is the **smallest deployable unit** in Kubernetes, representing a single instance of a running process in the cluster. It is an abstraction over a container or a group of tightly coupled containers.

Pods provide a higher-level structure than containers and allow Kubernetes to manage and orchestrate workloads efficiently.

---

### **Key Characteristics of Pods**

1. **Single or Multiple Containers**:
   - A Pod can run **one container (most common scenario)** or multiple containers that share resources.
   - Multi-container Pods are useful when the containers are tightly coupled and need to communicate frequently (e.g., sidecar pattern).

2. **Shared Resources**:
   Containers within a Pod share:
   - **Network Namespace**: They communicate using `localhost` and share the same IP address.
   - **Storage Volumes**: Can mount the same persistent volumes.
   - **Configuration**: Share environment variables and other configurations.

3. **Ephemeral Nature**:
   - Pods are designed to be **temporary** and are created, destroyed, and replaced as needed.
   - If a Pod dies, Kubernetes replaces it, but the replacement will have a different identity (UID).

---

### **Pod Lifecycle**
1. **Pending**: The Pod is created but is waiting for resources or scheduling.
2. **Running**: The Pod has been scheduled and containers are up and running.
3. **Succeeded**: The Pod's containers have completed successfully.
4. **Failed**: The Pod's containers failed to execute successfully.
5. **Unknown**: The Pod state cannot be determined due to an error in communication.

---

### **Pod Example**

#### Single-Container Pod YAML:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
  labels:
    app: my-app
spec:
  containers:
  - name: app-container
    image: nginx:latest
    ports:
    - containerPort: 80
```
- **Explanation**:
  - Creates a Pod named `my-pod`.
  - Runs an `nginx` container listening on port `80`.

#### Multi-Container Pod YAML (Sidecar Pattern):

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: multi-container-pod
spec:
  containers:
  - name: main-app
    image: my-app:latest
    ports:
    - containerPort: 8080
  - name: log-collector
    image: log-collector:latest
    args: ["--follow=/var/log/my-app.log"]
    volumeMounts:
    - name: shared-logs
      mountPath: /var/log
  volumes:
  - name: shared-logs
    emptyDir: {}
```
- **Explanation**:
  - `main-app`: The primary application container.
  - `log-collector`: A sidecar container that collects logs from `main-app`.
  - Both containers share a volume (`emptyDir`).

---

### **Key Benefits of Pods**
1. **Networking**:
   - Pods provide a unique IP address within the cluster.
   - All containers within the Pod share this IP, enabling seamless communication.

2. **Resource Sharing**:
   - Containers can share storage and configuration easily using shared volumes.

3. **Scaling**:
   - Pods are scalable through Kubernetes objects like **Deployments** and **ReplicaSets**.

---

### **Real-Life Example**
- **Scenario**: You want to run a web server (nginx) with a sidecar container for monitoring logs.
- **Solution**: Use a Pod with two containers—one for `nginx` and one for log monitoring. They share resources, making it easier to manage and deploy them together.

---

### **4. What is a ReplicaSet in Kubernetes?**

A **ReplicaSet (RS)** in Kubernetes is a resource object used to ensure a specified number of **replica Pods** are running at any given time. It automatically manages the scaling up or down of Pods to maintain the desired state.

---

### **Key Features of ReplicaSet**
1. **Pod Replication**:
   - Ensures a fixed number of replicas of a Pod are running.
   - If a Pod crashes or is deleted, the ReplicaSet will create a new one to replace it.

2. **Declarative State Management**:
   - You declare the desired state (e.g., number of replicas) in the YAML file, and Kubernetes ensures this state is maintained.

3. **Pod Selection with Labels**:
   - Uses **label selectors** to identify the Pods it manages. This makes it flexible in managing Pods created independently.

4. **High Availability**:
   - Ensures applications remain available by maintaining the required number of Pod replicas.

---

### **Example of a ReplicaSet**

#### ReplicaSet YAML Definition:

```yaml
apiVersion: apps/v1
kind: ReplicaSet
metadata:
  name: my-replicaset
  labels:
    app: my-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-container
        image: nginx:latest
        ports:
        - containerPort: 80
```

#### Explanation:
1. **replicas**:
   - Specifies the desired number of Pod replicas (3 in this case).

2. **selector**:
   - Matches Pods with the label `app: my-app`.

3. **template**:
   - Defines the Pod specification (container image, ports, etc.) for the replicas.

---

### **How ReplicaSet Works**

1. **Initial Creation**:
   - When a ReplicaSet is applied, Kubernetes creates the specified number of Pod replicas based on the template.

2. **Self-Healing**:
   - If a Pod crashes, the ReplicaSet will detect it and create a new Pod to maintain the desired count.

3. **Scaling**:
   - You can scale the ReplicaSet manually or automatically:
     - **Manually**: Update the `replicas` field.
       ```bash
       kubectl scale rs my-replicaset --replicas=5
       ```
     - **Automatically**: Use **Horizontal Pod Autoscaler (HPA)**.

4. **Pod Matching**:
   - ReplicaSet uses labels to identify which Pods it manages. If Pods with matching labels already exist, they are adopted by the ReplicaSet.

---

### **Real-Life Use Case**

#### Scenario:
You’re running a web application with high traffic and need to ensure:
1. At least 5 instances of your app are always available.
2. If traffic increases, you can scale up easily.

#### Solution:
- Deploy a ReplicaSet with `replicas: 5`.
- Use Horizontal Pod Autoscaler (HPA) to scale dynamically based on CPU or memory usage.

---

### **ReplicaSet vs. Deployment**
- While a ReplicaSet ensures the desired number of Pods, it lacks advanced features like **rolling updates** or **rollbacks**. For these, you should use a **Deployment**, which internally manages a ReplicaSet.

| Feature               | ReplicaSet         | Deployment            |
|-----------------------|--------------------|-----------------------|
| Pod Replication       | ✅                 | ✅                    |
| Rolling Updates       | ❌                 | ✅                    |
| Rollbacks             | ❌                 | ✅                    |
| Manual Pod Management | ✅                 | ✅ (via ReplicaSet)   |

---

### **Commands for Managing ReplicaSets**

1. **Create a ReplicaSet**:
   ```bash
   kubectl apply -f replicaset.yaml
   ```

2. **List ReplicaSets**:
   ```bash
   kubectl get rs
   ```

3. **Scale a ReplicaSet**:
   ```bash
   kubectl scale rs my-replicaset --replicas=5
   ```

4. **Delete a ReplicaSet**:
   ```bash
   kubectl delete rs my-replicaset
   ```

---

### **5. What is a Deployment in Kubernetes?**

A **Deployment** in Kubernetes is a higher-level abstraction that manages **ReplicaSets** and provides advanced features like rolling updates, rollbacks, and scaling. It allows you to declaratively define the desired state of your application and ensures the cluster matches that state.

---

### **Key Features of a Deployment**

1. **Declarative Updates**:
   - Define the desired state in a YAML/JSON file, and Kubernetes ensures the cluster matches this state.

2. **Rolling Updates**:
   - Deployments can update Pods incrementally, ensuring minimal downtime.

3. **Rollbacks**:
   - If something goes wrong during an update, the Deployment can roll back to a previous version.

4. **Scaling**:
   - Easily scale the number of replicas either manually or automatically using **Horizontal Pod Autoscalers (HPA)**.

5. **Self-Healing**:
   - Replaces failed Pods automatically.

6. **Version Control**:
   - Each Deployment update creates a new **ReplicaSet**, providing a history of changes.

---

### **Example of a Deployment**

#### Deployment YAML Definition:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-deployment
  labels:
    app: my-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: my-app
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-container
        image: nginx:1.21.1
        ports:
        - containerPort: 80
```

#### Explanation:
1. **replicas**:
   - Specifies the desired number of Pods (3 in this case).

2. **selector**:
   - Matches Pods with the label `app: my-app`.

3. **template**:
   - Defines the Pod specification (container image, ports, etc.) for the replicas.

---

### **How Deployment Works**

1. **Creation**:
   - When a Deployment is applied, Kubernetes creates a **ReplicaSet**, which in turn manages the Pods.

2. **Rolling Updates**:
   - If you update the Deployment (e.g., change the container image), Kubernetes incrementally replaces the old Pods with new ones.

   Example:
   ```yaml
   spec:
     containers:
     - name: my-container
       image: nginx:1.21.2
   ```

   Update the Deployment:
   ```bash
   kubectl apply -f deployment.yaml
   ```

3. **Scaling**:
   - Increase or decrease the number of replicas to handle traffic changes.
   ```bash
   kubectl scale deployment my-deployment --replicas=5
   ```

4. **Rollback**:
   - Roll back to a previous version if an update fails:
   ```bash
   kubectl rollout undo deployment my-deployment
   ```

---

### **Advanced Features**

#### **Rolling Update Example**
Command to monitor the update progress:
```bash
kubectl rollout status deployment my-deployment
```

#### **Pause and Resume Updates**
- Pause an ongoing update:
  ```bash
  kubectl rollout pause deployment my-deployment
  ```
- Resume a paused update:
  ```bash
  kubectl rollout resume deployment my-deployment
  ```

#### **History of Rollouts**
View the revision history of a Deployment:
```bash
kubectl rollout history deployment my-deployment
```

---

### **Deployment Use Cases**

1. **Blue-Green Deployment**:
   - Create a new version alongside the current version, then switch traffic when ready.

2. **Canary Deployment**:
   - Gradually roll out the new version to a subset of users before a full rollout.

3. **High Availability**:
   - Use Deployments to ensure a minimum number of Pods are always running.

---

### **Deployment vs ReplicaSet**

| **Feature**           | **ReplicaSet**                | **Deployment**                     |
|------------------------|-------------------------------|-------------------------------------|
| Pod Management         | ✅                            | ✅ (via ReplicaSet)                |
| Rolling Updates        | ❌                            | ✅                                 |
| Rollbacks              | ❌                            | ✅                                 |
| Scaling                | ✅                            | ✅                                 |
| Declarative Updates    | ❌                            | ✅                                 |
| Advanced Features      | Limited                      | Supports Blue-Green, Canary, etc. |

---

### **Commands for Managing Deployments**

1. **Create a Deployment**:
   ```bash
   kubectl apply -f deployment.yaml
   ```

2. **List Deployments**:
   ```bash
   kubectl get deployments
   ```

3. **Scale a Deployment**:
   ```bash
   kubectl scale deployment my-deployment --replicas=5
   ```

4. **Update a Deployment**:
   ```bash
   kubectl set image deployment my-deployment my-container=nginx:1.21.2
   ```

5. **Delete a Deployment**:
   ```bash
   kubectl delete deployment my-deployment
   ```

---


### **6. How Kubernetes Handles Container Scaling**

Kubernetes provides **scaling mechanisms** to handle increased or decreased workload demands. It supports both **manual scaling** and **automatic scaling**, ensuring efficient resource utilization and application availability.

---

### **1. Manual Scaling**
You can scale the number of Pods in a Deployment or ReplicaSet manually by specifying the desired number of replicas.

#### **Commands for Manual Scaling**
- Scale a Deployment:
  ```bash
  kubectl scale deployment <deployment-name> --replicas=<desired-number>
  ```
  Example:
  ```bash
  kubectl scale deployment my-deployment --replicas=5
  ```
- Verify the updated number of Pods:
  ```bash
  kubectl get pods
  ```

**Use Case**: When you know the expected workload and want to manage scaling proactively.

---

### **2. Horizontal Pod Autoscaler (HPA)**
The **Horizontal Pod Autoscaler** adjusts the number of Pods in a Deployment, ReplicaSet, or StatefulSet based on observed **CPU**, **memory utilization**, or custom metrics.

#### **How HPA Works**
1. Kubernetes monitors metrics (e.g., CPU usage) from the **Metrics Server**.
2. Based on thresholds defined in the HPA configuration, it scales Pods up or down.

#### **HPA Configuration Example**

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: my-deployment-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: my-deployment
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 75
```

**Explanation**:
- Scales the `my-deployment` Deployment between 2 and 10 replicas.
- Adds more Pods when CPU utilization exceeds 75% on average.

#### **Commands for HPA**
- Apply an HPA:
  ```bash
  kubectl apply -f hpa.yaml
  ```
- Check HPA status:
  ```bash
  kubectl get hpa
  ```

**Use Case**: Automatically handle fluctuating workloads like high traffic spikes.

---

### **3. Vertical Pod Autoscaler (VPA)**
The **Vertical Pod Autoscaler** adjusts the resource requests and limits (CPU and memory) of containers within Pods based on observed usage.

#### **How VPA Works**
- Kubernetes adjusts the container resources dynamically.
- Pods may be restarted to apply the updated resource configurations.

#### **VPA Configuration Example**

```yaml
apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata:
  name: my-deployment-vpa
spec:
  targetRef:
    apiVersion: "apps/v1"
    kind: Deployment
    name: my-deployment
  updatePolicy:
    updateMode: "Auto"
```

**Explanation**:
- Automatically updates resource requests and limits for the Pods in the `my-deployment`.

**Use Case**: When workload demands change gradually and resource allocation optimization is required.

---

### **4. Cluster Autoscaler**
The **Cluster Autoscaler** dynamically adjusts the size of the cluster (adding or removing worker nodes) to accommodate the resource demands of Pods.

#### **How Cluster Autoscaler Works**
1. If the cluster lacks sufficient resources to schedule Pods, it adds nodes.
2. If nodes are underutilized, it removes them.

#### **Setup Example**
1. Enable Cluster Autoscaler in managed Kubernetes platforms like **AWS EKS**, **GKE**, or **AKS**.
2. Use a configuration file or a cloud provider’s dashboard to set minimum and maximum node limits.

---

### **Real-Life Example of Scaling**

#### **Scenario**: Handling Traffic Spikes in an E-Commerce Application
1. **Initial Setup**:
   - Deployment is set to 3 replicas.
   - HPA is configured to scale between 3 and 15 replicas based on CPU usage.

2. **Traffic Spike**:
   - During a sale, traffic increases, and CPU utilization exceeds the threshold.
   - HPA scales the Pods to 15.

3. **Traffic Normalizes**:
   - As traffic decreases, HPA reduces the Pods to the minimum required (3).

4. **Cluster Autoscaler**:
   - If the workload exceeds cluster capacity, Cluster Autoscaler adds more nodes.
   - When demand drops, it removes unused nodes.

---

### **Benefits of Kubernetes Scaling**
1. **High Availability**:
   - Ensures application uptime during peak loads.
2. **Cost Optimization**:
   - Scales down resources during low demand, reducing costs.
3. **Automation**:
   - Reduces the need for manual intervention during unexpected workload spikes.
4. **Efficiency**:
   - Optimizes resource utilization across the cluster.

---


### **7. What is a Kubernetes Namespace?**

A **Kubernetes Namespace** is a logical partition within a Kubernetes cluster that allows you to divide cluster resources among multiple users or teams. It provides a way to organize, isolate, and manage resources like Pods, Services, and Deployments in a shared cluster environment.

---

### **Key Features of Namespaces**

1. **Resource Isolation**:
   - Separate resources for different environments (e.g., development, testing, production).

2. **Access Control**:
   - Apply Role-Based Access Control (RBAC) to restrict access to specific Namespaces.

3. **Resource Quotas**:
   - Limit the amount of resources (e.g., CPU, memory) that can be consumed within a Namespace.

4. **Multi-Tenancy**:
   - Enable multiple teams or projects to share the same cluster without interfering with one another.

5. **Logical Organization**:
   - Group related resources together for easier management.

---

### **How Namespaces Work**

- Each resource in Kubernetes belongs to a Namespace, except for **cluster-wide resources** like Nodes and PersistentVolumes, which are not namespaced.
- By default, Kubernetes creates the following Namespaces:
  1. **default**: Used for resources without a specified Namespace.
  2. **kube-system**: Reserved for system components like the API server and DNS.
  3. **kube-public**: A publicly accessible Namespace.
  4. **kube-node-lease**: For Node heartbeats and lease objects.

---

### **Creating a Namespace**

#### YAML Definition:
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: my-namespace
```

#### Apply the Namespace:
```bash
kubectl apply -f namespace.yaml
```

---

### **Using a Namespace**

1. **Create a Resource in a Specific Namespace**:
   Include the `namespace` field in the resource YAML:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: my-deployment
     namespace: my-namespace
   spec:
     replicas: 2
     selector:
       matchLabels:
         app: my-app
     template:
       metadata:
         labels:
           app: my-app
       spec:
         containers:
         - name: my-container
           image: nginx
   ```

2. **Set a Namespace Context for kubectl**:
   ```bash
   kubectl config set-context --current --namespace=my-namespace
   ```

3. **List Resources in a Specific Namespace**:
   ```bash
   kubectl get pods -n my-namespace
   ```

---

### **Switching Between Namespaces**

- View all Namespaces:
  ```bash
  kubectl get namespaces
  ```
- Switch Namespace for a single command:
  ```bash
  kubectl get pods -n kube-system
  ```

---

### **Resource Quotas in Namespaces**

Namespaces can have **ResourceQuotas** to control resource usage.

#### Example: Applying a Resource Quota

```yaml
apiVersion: v1
kind: ResourceQuota
metadata:
  name: resource-quota
  namespace: my-namespace
spec:
  hard:
    pods: "10"
    requests.cpu: "4"
    requests.memory: "8Gi"
    limits.cpu: "8"
    limits.memory: "16Gi"
```

- This limits the Namespace `my-namespace` to a maximum of:
  - 10 Pods
  - 4 CPUs for requests
  - 8 CPUs for limits

Apply the quota:
```bash
kubectl apply -f resource-quota.yaml
```

---

### **Real-Life Use Cases for Namespaces**

1. **Environment Separation**:
   - Use separate Namespaces for development, testing, and production environments.

2. **Multi-Tenancy**:
   - Host multiple projects or teams within the same cluster, each in its own Namespace.

3. **Access Control**:
   - Restrict user access to specific Namespaces using RBAC.

4. **Resource Management**:
   - Set quotas to prevent resource exhaustion by any single team or project.

---

### **Commands for Managing Namespaces**

1. **List Namespaces**:
   ```bash
   kubectl get namespaces
   ```

2. **Describe a Namespace**:
   ```bash
   kubectl describe namespace my-namespace
   ```

3. **Delete a Namespace**:
   ```bash
   kubectl delete namespace my-namespace
   ```

---

### **Namespace Best Practices**

1. **Group Resources Logically**:
   - Assign related resources (e.g., services, Pods, ConfigMaps) to the same Namespace.

2. **Use Resource Quotas**:
   - Prevent resource starvation by applying quotas to Namespaces.

3. **Avoid Using the Default Namespace**:
   - Always specify a custom Namespace for better isolation and organization.

4. **Implement RBAC Policies**:
   - Secure Namespaces by defining roles and permissions for users and teams.

---

### **8. How Kubernetes Handles Service Discovery and Load Balancing**

Kubernetes provides **built-in mechanisms** for service discovery and load balancing, ensuring seamless communication between applications within a cluster.

---

### **1. Service Discovery**

Service discovery in Kubernetes allows applications to find and communicate with other services without knowing their exact IP addresses. Kubernetes dynamically tracks and manages service endpoints.

#### **Mechanisms for Service Discovery**:

1. **Environment Variables**:
   - When a Pod is started, Kubernetes injects environment variables containing service details into the Pod.
   - Example:
     ```bash
     MY_SERVICE_SERVICE_HOST=10.96.0.1
     MY_SERVICE_SERVICE_PORT=80
     ```

2. **DNS-Based Discovery**:
   - Kubernetes uses the **kube-dns** or **CoreDNS** add-ons to provide DNS resolution for services.
   - Services are accessible using their DNS names in the format:
     ```
     <service-name>.<namespace>.svc.cluster.local
     ```
   - Example: A service named `my-service` in the `default` namespace is resolved as:
     ```
     my-service.default.svc.cluster.local
     ```

#### **Real-Life Example**:
- A front-end application (Pod) communicates with a back-end service using the DNS name `backend-service.default.svc.cluster.local` instead of hardcoding IPs.

---

### **2. Load Balancing**

Kubernetes provides load balancing at multiple levels:

#### **a) Internal Load Balancing (ClusterIP)**
- By default, every service in Kubernetes is assigned a **ClusterIP**, an internal virtual IP.
- The ClusterIP load balances traffic across all Pods in the service.

**How it works**:
1. When a request is sent to the service's ClusterIP, Kubernetes forwards it to one of the Pods selected by the service.
2. The load balancing mechanism uses **iptables** or **IPVS** rules.

#### **b) External Load Balancing (LoadBalancer)**
- For services exposed to the external world, Kubernetes integrates with cloud provider load balancers (e.g., AWS, Azure, GCP).
- A **LoadBalancer** type service automatically provisions an external load balancer and directs traffic to the service.

**Example YAML**:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-service
spec:
  type: LoadBalancer
  selector:
    app: my-app
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8080
```

#### **c) NodePort**
- Exposes a service on a specific port of each Node in the cluster.
- Traffic sent to `<NodeIP>:<NodePort>` is forwarded to the service.

---

### **Service Types in Kubernetes**
1. **ClusterIP** (default):
   - Internal traffic only within the cluster.
   - Example:
     ```bash
     kubectl expose deployment my-app --type=ClusterIP --port=80
     ```

2. **NodePort**:
   - Exposes the service on a port accessible from outside the cluster.
   - Example:
     ```bash
     kubectl expose deployment my-app --type=NodePort --port=80 --target-port=8080
     ```

3. **LoadBalancer**:
   - Provisions an external load balancer.
   - Example:
     ```bash
     kubectl expose deployment my-app --type=LoadBalancer --port=80
     ```

4. **ExternalName**:
   - Maps a Kubernetes service to an external DNS name.
   - Example:
     ```yaml
     apiVersion: v1
     kind: Service
     metadata:
       name: external-service
     spec:
       type: ExternalName
       externalName: example.com
     ```

---

### **Traffic Flow Example**

1. **Service Creation**:
   A Service is created to expose Pods of a Deployment.
   ```yaml
   apiVersion: v1
   kind: Service
   metadata:
     name: my-service
   spec:
     selector:
       app: my-app
     ports:
     - protocol: TCP
       port: 80
       targetPort: 8080
   ```

2. **Request Handling**:
   - A request sent to `my-service`'s ClusterIP is routed to one of the Pods with the label `app: my-app`.
   - Kubernetes uses **round-robin** or other algorithms to distribute traffic across Pods.

---

### **Real-Life Scenario**

#### Scenario:
A web application has multiple Pods (replicas) running for high availability and performance. A Kubernetes Service is used to:
1. Distribute incoming traffic evenly among Pods.
2. Ensure DNS-based service discovery for backend communication.

#### Steps:
1. **Create a Deployment**:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: web-app
   spec:
     replicas: 3
     selector:
       matchLabels:
         app: web-app
     template:
       metadata:
         labels:
           app: web-app
       spec:
         containers:
         - name: nginx
           image: nginx
           ports:
           - containerPort: 80
   ```

2. **Expose the Deployment with a Service**:
   ```yaml
   apiVersion: v1
   kind: Service
   metadata:
     name: web-service
   spec:
     selector:
       app: web-app
     ports:
     - protocol: TCP
       port: 80
       targetPort: 80
     type: LoadBalancer
   ```

3. **Traffic Flow**:
   - Users access the application via the load balancer's external IP.
   - The service routes traffic to the Pods in the Deployment.
   - DNS is used internally for communication between services.

---

### **Benefits of Kubernetes Service Discovery and Load Balancing**

1. **Dynamic Scaling**:
   - Automatically adjusts to the number of Pods.

2. **DNS Integration**:
   - Simplifies communication by using service names instead of IPs.

3. **Traffic Distribution**:
   - Ensures even load distribution across replicas for performance and reliability.

4. **High Availability**:
   - Keeps applications accessible even if some Pods fail.

---


### **9. What is the Role of Kubernetes ConfigMap?**

A **ConfigMap** in Kubernetes is an API object that allows you to store configuration data in a key-value format. It is used to decouple configuration details from the application code, making your applications more flexible and portable.

---

### **Key Features of ConfigMap**

1. **Externalized Configuration**:
   - Separates configuration settings from application code.

2. **Dynamic Updates**:
   - Applications can reload configuration without needing to rebuild the container image.

3. **Environment-Specific Settings**:
   - Store different configurations for development, testing, and production environments.

4. **Lightweight and Flexible**:
   - ConfigMaps can store small amounts of data, such as environment variables, command-line arguments, or application-specific settings.

---

### **How ConfigMaps Work**

- ConfigMaps provide configuration data to Pods, which can consume them as:
  1. **Environment Variables**
  2. **Command-Line Arguments**
  3. **Mounted Files**

- A ConfigMap does not contain confidential data. For sensitive information, use **Secrets** instead.

---

### **Creating a ConfigMap**

#### **1. Using a YAML Manifest**

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  APP_ENV: production
  APP_DEBUG: "false"
  APP_PORT: "8080"
```

Apply the ConfigMap:
```bash
kubectl apply -f configmap.yaml
```

#### **2. From Literal Key-Value Pairs**

```bash
kubectl create configmap app-config --from-literal=APP_ENV=production --from-literal=APP_DEBUG=false
```

#### **3. From a File**

```bash
kubectl create configmap app-config --from-file=config.properties
```
Where `config.properties` contains:
```
APP_ENV=production
APP_DEBUG=false
APP_PORT=8080
```

---

### **Using ConfigMap in Pods**

#### **1. As Environment Variables**
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: app-pod
spec:
  containers:
  - name: app-container
    image: nginx
    envFrom:
    - configMapRef:
        name: app-config
```
- The ConfigMap values will be available as environment variables in the container.

#### **2. As Command-Line Arguments**
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: app-pod
spec:
  containers:
  - name: app-container
    image: nginx
    args:
    - "--env=${APP_ENV}"
    env:
    - name: APP_ENV
      valueFrom:
        configMapKeyRef:
          name: app-config
          key: APP_ENV
```

#### **3. Mounted as Files**
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: app-pod
spec:
  containers:
  - name: app-container
    image: nginx
    volumeMounts:
    - name: config-volume
      mountPath: /etc/config
  volumes:
  - name: config-volume
    configMap:
      name: app-config
```
- The ConfigMap keys become filenames, and their values become file contents.

---

### **Real-Life Example**

#### Scenario:
A web application requires different configurations for development and production environments.

1. **Create ConfigMaps for Each Environment**:
   - **Development ConfigMap**:
     ```yaml
     apiVersion: v1
     kind: ConfigMap
     metadata:
       name: dev-config
     data:
       APP_ENV: development
       APP_DEBUG: "true"
       APP_PORT: "3000"
     ```
   - **Production ConfigMap**:
     ```yaml
     apiVersion: v1
     kind: ConfigMap
     metadata:
       name: prod-config
     data:
       APP_ENV: production
       APP_DEBUG: "false"
       APP_PORT: "80"
     ```

2. **Reference the Appropriate ConfigMap in the Deployment**:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: web-app
   spec:
     replicas: 2
     selector:
       matchLabels:
         app: web-app
     template:
       metadata:
         labels:
           app: web-app
       spec:
         containers:
         - name: web-container
           image: my-web-app:latest
           envFrom:
           - configMapRef:
               name: prod-config
   ```

3. **Dynamic Configuration Updates**:
   - Update the production ConfigMap without redeploying the application:
     ```bash
     kubectl edit configmap prod-config
     ```

---

### **Best Practices for Using ConfigMaps**

1. **Separate Configurations from Code**:
   - Use ConfigMaps to make your applications portable across environments.

2. **Avoid Large Data**:
   - Use ConfigMaps for lightweight configuration; store large data in Persistent Volumes.

3. **Use Secrets for Sensitive Data**:
   - Do not store credentials, tokens, or private keys in ConfigMaps.

4. **Version Control**:
   - Maintain ConfigMap YAML files in version control systems like Git.

5. **Namespace Isolation**:
   - Keep ConfigMaps scoped to specific namespaces to avoid conflicts.

---

### **Common Commands**

1. **List ConfigMaps**:
   ```bash
   kubectl get configmaps
   ```

2. **Describe a ConfigMap**:
   ```bash
   kubectl describe configmap app-config
   ```

3. **Get ConfigMap Details**:
   ```bash
   kubectl get configmap app-config -o yaml
   ```

4. **Delete a ConfigMap**:
   ```bash
   kubectl delete configmap app-config
   ```

---

### **10. How to Expose a Kubernetes Deployment to the Outside World**

Exposing a Kubernetes Deployment to the outside world allows external users to access the application running in your cluster. Kubernetes provides multiple ways to expose a Deployment based on your requirements, such as whether you need internal cluster communication or external access.

---

### **Methods to Expose a Kubernetes Deployment**

#### **1. Using a Service**

Kubernetes Services provide a stable way to expose Pods. There are three common service types to expose Deployments to the outside world:

---

#### **a) NodePort**

- **How It Works**:
  - Opens a static port on each Node in the cluster.
  - Traffic sent to `<NodeIP>:<NodePort>` is forwarded to the Pods in the Deployment.

- **Example YAML**:
  ```yaml
  apiVersion: v1
  kind: Service
  metadata:
    name: my-service
  spec:
    type: NodePort
    selector:
      app: my-app
    ports:
      - port: 80        # Service port
        targetPort: 8080 # Pod container port
        nodePort: 30007 # Exposed port on the Node
  ```

- **Access**:
  ```
  http://<NodeIP>:30007
  ```

- **Use Case**:
  Suitable for development or testing environments.

---

#### **b) LoadBalancer**

- **How It Works**:
  - Creates an external load balancer with a public IP using the cloud provider's infrastructure (e.g., AWS ELB, Azure Load Balancer, GCP Load Balancer).
  - Traffic is routed to the service and then to the Deployment.

- **Example YAML**:
  ```yaml
  apiVersion: v1
  kind: Service
  metadata:
    name: my-service
  spec:
    type: LoadBalancer
    selector:
      app: my-app
    ports:
      - port: 80
        targetPort: 8080
  ```

- **Access**:
  Once the service is created, run:
  ```bash
  kubectl get service my-service
  ```
  It provides an **External IP** to access the application.

- **Use Case**:
  Best for production workloads in cloud environments.

---

#### **c) ClusterIP with Ingress**

- **How It Works**:
  - Exposes the Deployment internally using a **ClusterIP** Service.
  - An **Ingress** resource is configured to route HTTP/HTTPS traffic to the service and Deployment.

- **Service YAML**:
  ```yaml
  apiVersion: v1
  kind: Service
  metadata:
    name: my-service
  spec:
    selector:
      app: my-app
    ports:
      - protocol: TCP
        port: 80
        targetPort: 8080
  ```

- **Ingress YAML**:
  ```yaml
  apiVersion: networking.k8s.io/v1
  kind: Ingress
  metadata:
    name: my-ingress
  spec:
    rules:
    - host: my-app.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: my-service
              port:
                number: 80
  ```

- **Access**:
  - Ensure an **Ingress Controller** (like NGINX Ingress Controller) is installed.
  - Access the application via `http://my-app.example.com`.

- **Use Case**:
  Ideal for managing HTTP/HTTPS traffic with advanced routing and TLS support.

---

#### **2. Using Port Forwarding**

- **How It Works**:
  - Temporarily forwards traffic from your local machine to the Deployment’s Pods for debugging or development.

- **Command**:
  ```bash
  kubectl port-forward deployment/my-deployment 8080:80
  ```

- **Access**:
  ```
  http://localhost:8080
  ```

- **Use Case**:
  Suitable for local testing and debugging.

---

#### **3. Using ExternalName Service**

- **How It Works**:
  - Maps a Kubernetes service to an external DNS name, enabling external applications to access the Deployment.

- **Example YAML**:
  ```yaml
  apiVersion: v1
  kind: Service
  metadata:
    name: external-service
  spec:
    type: ExternalName
    externalName: example.com
  ```

- **Use Case**:
  Used for accessing external services, not for exposing Kubernetes Deployments.

---

### **Traffic Flow Example with LoadBalancer**

1. **Deployment**:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: my-app
   spec:
     replicas: 2
     selector:
       matchLabels:
         app: my-app
     template:
       metadata:
         labels:
           app: my-app
       spec:
         containers:
         - name: nginx
           image: nginx
           ports:
           - containerPort: 80
   ```

2. **LoadBalancer Service**:
   ```yaml
   apiVersion: v1
   kind: Service
   metadata:
     name: my-service
   spec:
     type: LoadBalancer
     selector:
       app: my-app
     ports:
     - port: 80
       targetPort: 80
   ```

3. **Traffic Flow**:
   - User sends a request to the **external IP** of the load balancer.
   - The load balancer forwards the request to the service's **ClusterIP**.
   - The service forwards the request to one of the Pods in the Deployment.

---

### **Best Practices**

1. Use **Ingress** with TLS certificates for secure HTTP traffic in production.
2. Use **NodePort** sparingly, as it exposes all nodes to external traffic.
3. Use **LoadBalancer** in cloud environments for simple external access.
4. Monitor traffic and logs for exposed services to detect unauthorized access.
5. Implement **Network Policies** to restrict unwanted traffic.

---
