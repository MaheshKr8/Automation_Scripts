
---

### **🔹 Docker Scenario-Based Questions**
#### **1. Your application running inside a Docker container is crashing repeatedly. How would you debug and resolve this?**  
✅ **Approach:**  
- Check logs: `docker logs <container_id>`  
- Inspect container status: `docker ps -a`  
- Use interactive mode: `docker exec -it <container_id> /bin/sh`  
- Verify environment variables: `docker inspect <container_id>`  
- Look for resource constraints: `docker stats`  

---

#### **2. A containerized application works on your local machine but fails in production. How do you troubleshoot this?**  
✅ **Possible Issues & Fixes:**  
- **Check for missing dependencies** → Verify base image and dependencies in `Dockerfile`.  
- **Environment-specific issues** → Use `docker inspect` to compare environments.  
- **Network issues** → Ensure correct ports are exposed using `docker network ls` and `docker ps`.  
- **Volume mounts** → Ensure correct file permissions and paths.  

---

#### **3. How do you optimize a Docker image for faster deployment?**  
✅ **Optimization Strategies:**  
- Use **smaller base images** (`alpine`, `scratch`)  
- Use **multi-stage builds**  
- Avoid `COPY . /app` → Instead, copy only required files  
- Reduce image layers by combining `RUN` commands  
- Use `.dockerignore` to exclude unnecessary files  

---

#### **4. Your application requires persistent data, but data is lost after restarting the container. How do you fix this?**  
✅ **Solution:**  
Use Docker **volumes**:  
```bash
docker volume create mydata
docker run -d -v mydata:/app/data myapp:latest
```
Or bind mount:  
```bash
docker run -d -v /local/path:/container/path myapp:latest
```

---

#### **5. Your containerized app cannot connect to an external database. What steps do you take?**  
✅ **Troubleshooting Steps:**  
- Ensure the database hostname/IP is correct.  
- Verify `docker network inspect <network_name>`.  
- Test connectivity with `nc -zv <db_host> <db_port>`.  
- Use `--network` option in `docker run`.  

---

#### **6. Your application running in Docker needs SSL/TLS security. How would you implement it?**  
✅ **Solution:**  
Use **certificates** inside Docker container with a **reverse proxy** like Nginx:  
```nginx
server {
    listen 443 ssl;
    ssl_certificate /etc/ssl/certs/server.crt;
    ssl_certificate_key /etc/ssl/private/server.key;
}
```
Mount the certificate directory:  
```bash
docker run -d -v /path/to/certs:/etc/ssl my-secure-app
```

---

#### **7. How do you scale a Dockerized application to handle high traffic?**  
✅ **Approach:**  
- Use **Docker Swarm**:  
  ```bash
  docker service create --replicas=5 -p 8080:80 myapp
  ```
- Or deploy in **Kubernetes** using a `Deployment` with `replicas`.

---

#### **8. How do you secure Docker containers?**  
✅ **Best Practices:**  
- Use non-root users (`USER` in Dockerfile)  
- Scan images for vulnerabilities (`docker scan myimage`)  
- Enable resource limits (`--memory=500m --cpus=0.5`)  
- Restrict container privileges (`--cap-drop=ALL`)  

---

#### **9. How do you monitor Docker containers in real-time?**  
✅ **Tools:**  
- `docker stats` for resource usage  
- `docker logs -f <container_id>` for logs  
- Use **Prometheus & Grafana** for metrics  
- Use **ELK stack** for centralized logging  

---

#### **10. A service in Docker Compose cannot reach another service by hostname. How do you fix it?**  
✅ **Solution:**  
- Ensure both services are in the **same Docker network**.  
- Check if the hostname matches the **service name** in `docker-compose.yml`.  
- Use `ping <service_name>` inside the container.  

---

### **🔹 Kubernetes Scenario-Based Questions**
#### **11. Your Kubernetes pod is in `CrashLoopBackOff` state. How do you troubleshoot?**  
✅ **Steps:**  
- Check logs: `kubectl logs <pod>`  
- Describe pod: `kubectl describe pod <pod>`  
- Verify resource limits: `kubectl get pod <pod> -o yaml`  
- Check init containers and startup probes  

---

#### **12. How do you expose a Kubernetes service externally?**  
✅ **Methods:**  
1. **NodePort**:  
   ```yaml
   type: NodePort
   ```
2. **LoadBalancer** (Cloud-managed):  
   ```yaml
   type: LoadBalancer
   ```
3. **Ingress Controller** (Recommended for HTTP/HTTPS)  

---

#### **13. Your Kubernetes pod cannot access an external database. What do you check?**  
✅ **Troubleshooting:**  
- Check `kubectl get svc` to ensure correct DNS  
- Verify pod’s network policy  
- Use `kubectl exec` to test connectivity  

---

#### **14. How do you enable auto-scaling for Kubernetes pods?**  
✅ **Use Horizontal Pod Autoscaler (HPA)**:  
```bash
kubectl autoscale deployment myapp --cpu-percent=50 --min=2 --max=10
```
Or define it in YAML:  
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
spec:
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 50
```

---

#### **15. How do you implement zero-downtime deployments in Kubernetes?**  
✅ **Use Rolling Updates:**  
```yaml
spec:
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 1
      maxSurge: 1
```
To rollback:  
```bash
kubectl rollout undo deployment myapp
```

---

### **🔥 Summary**
| **Category**     | **Key Topics** |
|-----------------|---------------|
| **Docker** | Debugging, networking, security, persistent storage, scaling, CI/CD |
| **Kubernetes** | Auto-scaling, networking, service discovery, deployments, monitoring |

