

---

## **1. Scenario: You committed the wrong file and want to undo the last commit without losing changes. How do you do it?**  
**Solution:**  
- Use `git reset` to undo the last commit but keep changes:  
  ```bash
  git reset --soft HEAD~1
  ```
- If you also want to unstage the changes:  
  ```bash
  git reset HEAD <file>
  ```
- If you want to completely discard the changes:  
  ```bash
  git reset --hard HEAD~1
  ```

---

## **2. Scenario: You accidentally committed sensitive data (passwords, keys). How do you remove it from Git history?**  
**Solution:**  
- Remove the file and rewrite history:  
  ```bash
  git filter-branch --force --index-filter 'git rm --cached --ignore-unmatch <file>' --prune-empty --tag-name-filter cat -- --all
  ```
- Alternatively, use **BFG Repo-Cleaner** for better performance:  
  ```bash
  bfg --delete-files <file>
  ```
- Push changes forcefully:  
  ```bash
  git push origin --force --all
  ```

---

## **3. Scenario: Your local branch is behind `main`, and you need to update it. How do you do it?**  
**Solution:**  
- Option 1: **Merge** (keeps all history)  
  ```bash
  git checkout feature-branch
  git merge main
  ```
- Option 2: **Rebase** (keeps history clean)  
  ```bash
  git checkout feature-branch
  git rebase main
  ```

---

## **4. Scenario: You made multiple commits but want to combine them into one before pushing. How do you do it?**  
**Solution:**  
Use interactive rebase:  
```bash
git rebase -i HEAD~<number-of-commits>
```
- Change `pick` to `squash (s)` for unwanted commits.
- Save and push forcefully if already pushed:  
  ```bash
  git push origin feature-branch --force
  ```

---

## **5. Scenario: You accidentally deleted a local branch. How do you recover it?**  
**Solution:**  
- Check the reflog to find the last commit:  
  ```bash
  git reflog
  ```
- Restore the branch:  
  ```bash
  git checkout -b <branch> <commit-hash>
  ```

---

## **6. Scenario: You need to delete a remote branch. How do you do it?**  
**Solution:**  
- Delete locally:  
  ```bash
  git branch -d feature-branch
  ```
- Delete remotely:  
  ```bash
  git push origin --delete feature-branch
  ```

---

## **7. Scenario: You need to find which commit introduced a bug. How do you do it?**  
**Solution:**  
Use **Git Bisect**:  
```bash
git bisect start
git bisect bad   # Mark current commit as bad
git bisect good <commit-hash>  # Mark last known good commit
```
Git will guide you to test commits until the faulty one is found.

---

## **8. Scenario: You need to push a commit but don’t want to trigger the CI/CD pipeline. How do you do it?**  
**Solution:**  
- Use `[skip ci]` in the commit message:  
  ```bash
  git commit -m "Update config [skip ci]"
  ```
- Some CI/CD tools support `[ci skip]` as well.

---

## **9. Scenario: Your merge request was rejected due to a messy commit history. How do you fix it?**  
**Solution:**  
Use **interactive rebase** to clean up:  
```bash
git rebase -i main
```
- Squash or edit unnecessary commits.
- Force push the cleaned branch:  
  ```bash
  git push origin feature-branch --force
  ```

---

## **10. Scenario: You need to find out who changed a specific line of a file. How do you do it?**  
**Solution:**  
```bash
git blame <file>
```
This shows the commit, author, and timestamp for each line.

---

## **11. Scenario: You cloned a large repository but only need one branch. How do you do it?**  
**Solution:**  
```bash
git clone --branch <branch-name> --single-branch <repo-url>
```

---

## **12. Scenario: Your team follows GitFlow, and you need to release a new version. What’s the correct approach?**  
**Solution:**  
1. Create a **release branch** from `develop`:  
   ```bash
   git checkout -b release-1.0 develop
   ```
2. Perform final testing and bug fixes.
3. Merge into `main` and tag the release:  
   ```bash
   git checkout main
   git merge release-1.0
   git tag v1.0
   git push origin main --tags
   ```
4. Merge back into `develop`:  
   ```bash
   git checkout develop
   git merge main
   git push origin develop
   ```
5. Delete the release branch:  
   ```bash
   git branch -d release-1.0
   git push origin --delete release-1.0
   ```

---

## **13. Scenario: You are working on a feature branch and need the latest changes from `main`. What’s the best way to do it?**  
**Solution:**  
- Merge method (keeps all history):  
  ```bash
  git checkout feature-branch
  git merge main
  ```
- Rebase method (linear history):  
  ```bash
  git checkout feature-branch
  git rebase main
  ```
- If conflicts occur, resolve them and continue:  
  ```bash
  git rebase --continue
  ```

---

## **14. Scenario: A teammate force-pushed to `main`, causing conflicts. How do you recover?**  
**Solution:**  
- Fetch the latest changes:  
  ```bash
  git fetch origin
  ```
- View logs and compare changes:  
  ```bash
  git log --oneline --graph --decorate --all
  ```
- Reset if necessary:  
  ```bash
  git reset --hard origin/main
  ```
- If you had local changes, stash them before resetting:  
  ```bash
  git stash
  git reset --hard origin/main
  git stash pop
  ```

---

## **15. Scenario: You need to share changes with a teammate before pushing them to the remote repository. How do you do it?**  
**Solution:**  
Use **git bundle** or a patch:  
- Create a patch:  
  ```bash
  git format-patch -1 <commit-hash>
  ```
- Apply the patch on the teammate’s machine:  
  ```bash
  git apply <patch-file>
  ```
Alternatively, use `git bundle` to share a repository file.

---

# **Conclusion**
| **Scenario**                                       | **Solution**  |
|----------------------------------------------------|---------------|
| Undo last commit but keep changes | `git reset --soft HEAD~1` |
| Remove sensitive data | `git filter-branch`, `BFG Repo-Cleaner` |
| Merge vs. Rebase | `git merge` (keeps history), `git rebase` (clean history) |
| Find a bug's origin | `git bisect` |
| Clean commit history | `git rebase -i` |
| Prevent CI/CD trigger | `[skip ci]` in commit message |

