
---

### **1. How do you handle a failed deployment in production?**

**Answer:**

* Rollback strategy using **blue/green** or **canary deployment**.
* Keep last stable version ready (in **S3, Nexus, or Docker registry**).
* Automate rollback in **Jenkins/GitHub Actions pipeline**.
* Investigate logs with **CloudWatch, ELK, or Prometheus/Grafana**.
* Post-mortem to fix root cause (infra, config, or code).

---

### **2. How do you secure secrets (like API keys, DB passwords) in CI/CD pipelines?**

**Answer:**

* Store in **AWS Secrets Manager, HashiCorp Vault, or Kubernetes Secrets**.
* Never commit secrets in Git.
* Use **environment variables with restricted IAM roles**.
* Enable **audit logging** to detect secret misuse.

---

### **3. You see pods in Kubernetes are in `CrashLoopBackOff`. What steps do you take?**

**Answer:**

1. Run `kubectl describe pod <pod>` → check events.
2. Run `kubectl logs <pod> -c <container>` → check application error.
3. Check **image version**, **entrypoint/command mismatch**, **config errors**.
4. Validate **resource limits (CPU/memory)**.
5. Debug with `kubectl exec -it <pod> -- sh`.

---

### **4. How do you achieve zero downtime deployment in Kubernetes?**

**Answer:**

* Use **Rolling updates** (default in Deployments).
* Define `maxUnavailable=0` and `maxSurge=1`.
* Use **readiness/liveness probes** to avoid routing traffic to unhealthy pods.
* For safer rollout, use **canary deployments** or **blue/green with ArgoCD/Spinnaker**.

---

### **5. How do you handle stateful applications in Kubernetes?**

**Answer:**

* Use **StatefulSets** instead of Deployments.
* Attach **PersistentVolume (EBS, EFS, CSI drivers)**.
* Enable **PodDisruptionBudgets (PDB)** for HA.
* Use **Headless Service** for stable network identity.

---

### **6. How do you monitor microservices running on Kubernetes?**

**Answer:**

* **Prometheus** + **Grafana** → metrics.
* **ELK / EFK stack (Elastic/Fluentd/Kibana)** → logs.
* **Jaeger / OpenTelemetry** → distributed tracing.
* Setup **alerts in Prometheus/CloudWatch**.

---

### **7. Jenkins pipeline is stuck, how do you debug it?**

**Answer:**

* Check **Jenkins console logs** and **workspace**.
* Verify **agent/node availability**.
* Check for **stale locks in Jenkinsfile** (`lock()`, `sh "sleep"` issues).
* Restart pipeline from failed stage using `when` conditions.
* Check **plugins** and **Jenkins master logs**.

---

### **8. How do you scale Jenkins to handle thousands of jobs?**

**Answer:**

* Use **master-agent architecture** with auto-scaling agents (EC2/EKS).
* Store build artifacts in **S3/Nexus/Artifactory** instead of Jenkins.
* Use **Job DSL or Jenkinsfile as code** to manage pipelines.
* Use **Distributed builds with Kubernetes plugin**.

---

### **9. Terraform apply is failing due to state lock. How do you resolve it?**

**Answer:**

* Happens if someone else is running Terraform.
* Check DynamoDB lock table (if using remote backend).
* If confirmed stale → manually delete lock entry.
* Best practice: use `terraform plan -out=tfplan` and CI/CD pipelines for controlled apply.

---

### **10. How do you design a disaster recovery (DR) strategy in AWS?**

**Answer:**

* **RTO & RPO analysis**.
* Multi-AZ + Multi-Region setup.
* Use **S3 Cross-Region Replication**.
* **Route 53 failover routing**.
* Automated backup with **AWS Backup or Lambda**.
* DR drill testing quarterly.

---

### **11. How do you optimize Docker images for faster CI/CD pipelines?**

**Answer:**

* Use **multi-stage builds**.
* Use **alpine base image** instead of Ubuntu.
* Avoid copying unnecessary files (`.dockerignore`).
* Cache dependencies (pip/npm/apt).
* Keep image size small → faster pulls/deployments.

---

### **12. What steps will you take if EC2 instance is not reachable?**

**Answer:**

1. Check **Security Groups / NACLs**.
2. Check **VPC Route Table**.
3. If still unreachable, check **instance console logs & system logs**.
4. Try **Session Manager (SSM)** access.
5. If corrupted → detach root volume, mount to another instance, fix configs.

---

### **13. How do you enforce compliance & security in AWS?**

**Answer:**

* Use **AWS Config Rules** for compliance (e.g., unencrypted S3 detection).
* Use **CloudTrail + CloudWatch Alarms** for monitoring activities.
* Enable **GuardDuty & Security Hub**.
* Enforce IAM **least privilege** and **MFA**.
* Automate remediation with **AWS Lambda**.

---

### **14. How do you implement GitOps for Kubernetes?**

**Answer:**

* Use **ArgoCD** or **FluxCD**.
* Store Kubernetes manifests/Helm charts in Git repo.
* Git becomes **single source of truth**.
* Any PR/Merge updates ArgoCD, which syncs cluster automatically.
* Provides **auditability, rollback, and drift detection**.

---

### **15. How do you troubleshoot high CPU/memory utilization in production?**

**Answer:**

* Use **CloudWatch / Prometheus** to identify spike.
* Check **application logs** for memory leaks.
* Run `htop` or `kubectl top pod` to identify culprit.
* Scale horizontally with **ASG (EC2)** or **HPA (K8s)**.
* Optimize app performance and tune JVM/GC if applicable.

---
