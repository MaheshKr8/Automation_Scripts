
---

### ✅ 1. **Task:** Clone a Git repository and create a new feature branch.

**Answer:**

```bash
git clone https://github.com/org/repo.git
cd repo
git checkout -b feature/my-feature
```

---

### ✅ 2. **Task:** Write a Dockerfile to run a Node.js application.

**Answer:**

```Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
CMD ["node", "index.js"]
```

---

### ✅ 3. **Task:** Build and run a Docker image.

**Answer:**

```bash
docker build -t myapp:1.0 .
docker run -d -p 3000:3000 myapp:1.0
```

---

### ✅ 4. **Task:** Push a Docker image to Docker Hub.

**Answer:**

```bash
docker login
docker tag myapp:1.0 username/myapp:1.0
docker push username/myapp:1.0
```

---

### ✅ 5. **Task:** Write a Jenkins pipeline to build and deploy a Java application.

**Answer (Jenkinsfile):**

```groovy
pipeline {
  agent any
  stages {
    stage('Build') {
      steps {
        sh 'mvn clean package'
      }
    }
    stage('Docker Build & Push') {
      steps {
        sh 'docker build -t myapp .'
        sh 'docker push myapp'
      }
    }
  }
}
```

---

### ✅ 6. **Task:** Install and configure NGINX using Ansible.

**Answer (Ansible Playbook):**

```yaml
- name: Install NGINX
  hosts: webservers
  become: yes
  tasks:
    - name: Install nginx
      apt:
        name: nginx
        state: present
    - name: Start nginx
      service:
        name: nginx
        state: started
        enabled: true
```

---

### ✅ 7. **Task:** Create an S3 bucket using Terraform.

**Answer (main.tf):**

```hcl
resource "aws_s3_bucket" "my_bucket" {
  bucket = "my-devops-demo-bucket"
  acl    = "private"
}
```

---

### ✅ 8. **Task:** Trigger a Jenkins job remotely via API.

**Answer:**

```bash
curl -X POST http://<jenkins-url>/job/myjob/build \
--user user:APITOKEN
```

---

### ✅ 9. **Task:** Roll back a Kubernetes deployment.

**Answer:**

```bash
kubectl rollout undo deployment myapp-deployment
```

---

### ✅ 10. **Task:** Create a ConfigMap in Kubernetes and mount it in a pod.

**Answer:**

```bash
kubectl create configmap app-config --from-literal=env=prod
```

Pod spec:

```yaml
env:
  - name: ENV
    valueFrom:
      configMapKeyRef:
        name: app-config
        key: env
```

---

### ✅ 11. **Task:** Set up Prometheus and Grafana using Helm.

**Answer:**

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/kube-prometheus-stack
```

---

### ✅ 12. **Task:** Scan Docker images for vulnerabilities using Trivy.

**Answer:**

```bash
trivy image myapp:1.0
```

---

### ✅ 13. **Task:** Archive logs and clean files older than 30 days.

**Answer:**

```bash
find /var/log/myapp/ -type f -mtime +30 -exec rm -f {} \;
```

---

### ✅ 14. **Task:** Perform a rolling update in Kubernetes.

**Answer:**

```bash
kubectl set image deployment/myapp myapp=myapp:v2
```

---

### ✅ 15. **Task:** Implement basic CI/CD using GitHub Actions.

**Answer (.github/workflows/main.yml):**

```yaml
name: CI

on:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: npm install
      - run: npm test
```

---

### ✅ 16. **Task:** Backup and restore a MySQL database in Kubernetes.

**Answer:**

```bash
kubectl exec -it mysql-pod -- mysqldump -u root -p mydb > backup.sql
kubectl exec -i mysql-pod -- mysql -u root -p mydb < backup.sql
```

---


## ✅ **Task 17: Configure HTTPS for a Kubernetes Application Using Let's Encrypt and NGINX Ingress**

### 🎯 Goal:

Secure your application with **free SSL/TLS certificates** from **Let’s Encrypt**, using **NGINX Ingress** and **Cert-Manager**.

---

### 🧩 **Prerequisites**:

* Kubernetes cluster (EKS, GKE, minikube, etc.)
* Helm installed
* Your domain pointing to the app (e.g., `myapp.example.com`)
* Ingress controller (e.g., NGINX) already set up

---

### 🔧 Step-by-Step Solution:

---

### ✅ **Step 1: Install Cert-Manager**

```bash
kubectl apply --validate=false -f https://github.com/jetstack/cert-manager/releases/latest/download/cert-manager.yaml
```

Verify:

```bash
kubectl get pods -n cert-manager
```

---

### ✅ **Step 2: Create a ClusterIssuer for Let's Encrypt**

```yaml
# cluster-issuer.yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: your-email@example.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
```

Apply:

```bash
kubectl apply -f cluster-issuer.yaml
```

---

### ✅ **Step 3: Create an Ingress Resource with TLS Annotations**

```yaml
# ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: myapp-ingress
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - myapp.example.com
    secretName: myapp-tls
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: myapp-service
            port:
              number: 80
```

Apply:

```bash
kubectl apply -f ingress.yaml
```

---

### ✅ **Step 4: Confirm HTTPS is Working**

Run:

```bash
kubectl describe certificate
kubectl get certificates
```

Visit:
`https://myapp.example.com` — it should now be **secured with a valid Let's Encrypt certificate**.

---


### ✅ 18. **Task:** Create a Helm chart for a web application.

**Answer:**

```bash
helm create mywebapp
# Modify templates/deployment.yaml and values.yaml
helm install mywebapp ./mywebapp
```

---

### ✅ 19. **Task:** Use `kubectl` to check why a pod is not starting.

**Answer:**

```bash
kubectl describe pod <pod-name>
kubectl logs <pod-name>
```

---

### ✅ 20. **Task:** Create a Git tag and push it.

**Answer:**

```bash
git tag -a v1.0 -m "Initial release"
git push origin v1.0
```

---
