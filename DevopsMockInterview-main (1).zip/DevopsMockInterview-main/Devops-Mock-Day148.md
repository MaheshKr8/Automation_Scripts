

---

### **1. How do you configure health checks in Kubernetes for an application?**

**Answer:**
Use **liveness** and **readiness probes** in the Pod spec:

```yaml
livenessProbe:
  httpGet:
    path: /health
    port: 8080
  initialDelaySeconds: 5
  periodSeconds: 10

readinessProbe:
  httpGet:
    path: /ready
    port: 8080
  initialDelaySeconds: 3
  periodSeconds: 5
```

* Liveness restarts unhealthy Pods.
* Readiness controls traffic only to healthy Pods.

---

### **2. Your app needs different configs for dev, test, and prod. How do you handle this in Kubernetes?**

**Answer:**

* Use **ConfigMaps** for non-sensitive data.
* Use **Secrets** for sensitive data.
* Combine with **Helm charts** or **Kustomize** to template environment-specific configs.

---

### **3. A Pod cannot reach another Pod in the same namespace. What would you check?**

**Answer:**

1. **DNS resolution** (check via `nslookup` inside a Pod).
2. **NetworkPolicy** (might be blocking).
3. **Endpoints** in the Service are populated:

   ```bash
   kubectl get endpoints <service-name>
   ```
4. **CNI plugin** (Calico, Flannel) is running.

---

### **4. How do you achieve zero-downtime deployment for a database migration in Kubernetes?**

**Answer:**

* Use **StatefulSets** for DB to maintain identity and persistent volumes.
* Apply **init containers** for schema migration.
* Deploy a **read replica** before the migration and cut over traffic after validation.

---

### **5. How do you handle logging for all Pods in a cluster?**

**Answer:**

* Deploy **Fluentd or Fluent Bit DaemonSets** to capture logs.
* Store logs in **Elasticsearch (EFK stack)** or **Loki** for centralized access.

---

### **6. A Deployment is failing because of insufficient CPU. How do you fix this?**

**Answer:**

* Check requests/limits in Pod spec:

```yaml
resources:
  requests:
    cpu: "200m"
    memory: "512Mi"
  limits:
    cpu: "500m"
    memory: "1Gi"
```

* Scale cluster nodes or adjust resource quotas.

---

### **7. How do you secure traffic between microservices in Kubernetes?**

**Answer:**

* Use **mTLS** with a service mesh (Istio/Linkerd).
* Apply **NetworkPolicies** to restrict Pod-to-Pod communication.
* Use **Secrets** for TLS certificates.

---

### **8. How do you handle persistent data for stateful workloads?**

**Answer:**

* Use **PersistentVolumes (PVs)** and **PersistentVolumeClaims (PVCs)**.
* Leverage **StorageClasses** for dynamic provisioning.
* Use **StatefulSets** for stable Pod identities.

---

### **9. How do you monitor Kubernetes cluster health and app performance?**

**Answer:**

* Use **Prometheus** for metrics collection.
* Visualize with **Grafana**.
* Use **Alertmanager** for alerts (CPU, memory, node failures).

---

### **10. How do you roll back a failed application update in Kubernetes?**

**Answer:**

```bash
kubectl rollout undo deployment <deployment-name>
kubectl rollout status deployment <deployment-name>
```

* Always check rollout history first:

```bash
kubectl rollout history deployment <deployment-name>
```

---
