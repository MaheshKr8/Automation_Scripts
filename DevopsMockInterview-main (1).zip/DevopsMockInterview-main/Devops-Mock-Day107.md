

### **1. What is Docker, and how does it differ from Virtual Machines?**  
✅ **Answer:**  
Docker is a **containerization** platform that packages applications and dependencies into lightweight, portable containers. Unlike **Virtual Machines (VMs)**, which require an entire OS per instance, Docker **shares the host OS kernel**, making it more efficient.  

✅ **Key Differences:**  
| Feature       | Virtual Machines | Docker Containers |
|--------------|----------------|----------------|
| Boot Time   | Slow (minutes) | Fast (seconds) |
| OS Overhead | Each VM has its own OS | Shared OS |
| Performance | High resource usage | Lightweight |
| Portability | Limited | Easily portable |

---

### **2. How do you persist data in Docker?**  
✅ **Scenario:** Your container restarts, and all data is lost. How do you persist it?  

✅ **Solution:** Use **Volumes** or **Bind Mounts**  
1️⃣ **Using Volumes (Recommended):**  
```bash
docker volume create mydata
docker run -d -v mydata:/app/data myapp
```
2️⃣ **Using Bind Mounts:**  
```bash
docker run -d -v /local/path:/container/path myapp
```

---

### **3. How do you optimize Docker image size?**  
✅ **Strategies:**  
- Use **small base images** (`alpine`, `scratch`)  
- **Multi-stage builds**  
- Minimize `RUN` layers  
- Add `.dockerignore`  

✅ **Example:** Using **multi-stage builds**  
```dockerfile
# Stage 1: Build
FROM golang:alpine AS builder
WORKDIR /app
COPY . .
RUN go build -o app

# Stage 2: Run
FROM alpine
WORKDIR /app
COPY --from=builder /app/app .
CMD ["./app"]
```
🚀 **Benefits:** Smaller image, faster deployments.  

---

### **4. How do you troubleshoot a failing container?**  
✅ **Steps:**  
1️⃣ Check logs → `docker logs <container_id>`  
2️⃣ Inspect container → `docker inspect <container_id>`  
3️⃣ Start an interactive shell → `docker exec -it <container_id> /bin/sh`  
4️⃣ Check health status → `docker ps`  

✅ **Example:** Debugging an Nginx container  
```bash
docker logs nginx-container
docker exec -it nginx-container /bin/sh
```

---

### **5. How do you secure a Docker container?**  
✅ **Best Practices:**  
- Run as **non-root user** (`USER` directive in Dockerfile)  
- **Limit container capabilities** (`--cap-drop=ALL`)  
- Use **signed images**  
- Enable **Docker Content Trust (DCT)**  

✅ **Example:** Running a container with restricted privileges  
```bash
docker run --read-only --cap-drop=ALL --security-opt no-new-privileges myapp
```

---

### **6. How do you monitor Docker containers?**  
✅ **Monitoring Tools:**  
- **Docker Stats:** `docker stats`  
- **Docker Logs:** `docker logs -f <container>`  
- **Third-party tools:** **Prometheus**, **Grafana**, **ELK Stack**  

✅ **Example:** Setting up Prometheus to monitor containers  
1️⃣ Install Prometheus  
2️⃣ Configure `docker-compose.yml`:  
```yaml
services:
  prometheus:
    image: prom/prometheus
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"
```
3️⃣ Start monitoring:  
```bash
docker-compose up -d
```

---

### **7. What is a Docker Multi-Stage Build?**  
✅ **Answer:** Multi-stage builds help reduce **image size** by using intermediate containers.  

✅ **Example:**  
```dockerfile
# Build Stage
FROM golang:alpine AS builder
WORKDIR /app
COPY . .
RUN go build -o app

# Final Stage
FROM alpine
COPY --from=builder /app/app .
CMD ["./app"]
```
🚀 **Advantage:** The final image contains only the necessary binaries.

---

### **8. How do you restart a container automatically?**  
✅ **Solution:** Use `--restart` policies  
```bash
docker run --restart=always -d myapp
```
✅ **Restart Policies:**  
| Policy | Description |
|--------|-------------|
| `no` | Never restart |
| `always` | Always restart |
| `on-failure` | Restart on failure |
| `unless-stopped` | Restart unless manually stopped |

---

### **9. How do you run multiple services in a containerized environment?**  
✅ **Solution:** Use **Docker Compose**  
`docker-compose.yml`  
```yaml
version: '3'
services:
  web:
    image: nginx
    ports:
      - "80:80"
  db:
    image: postgres
    environment:
      POSTGRES_PASSWORD: secret
```
Start services:  
```bash
docker-compose up -d
```

---

### **10. What is the difference between Docker Swarm and Kubernetes?**  
✅ **Comparison:**  
| Feature | Docker Swarm | Kubernetes |
|---------|-------------|------------|
| Ease of Setup | Easier | More complex |
| Load Balancing | Built-in | External service required |
| Scaling | Limited | Advanced |
| Networking | Swarm overlay | CNI Plugins |

---

### **11. How do you limit container CPU and memory usage?**  
✅ **Example:**  
```bash
docker run --memory=512m --cpus=1 myapp
```

---

### **12. What is the difference between `docker run`, `docker create`, and `docker start`?**  
| Command | Description |
|---------|-------------|
| `docker run` | Creates and starts a container |
| `docker create` | Creates a container but doesn't start it |
| `docker start` | Starts a stopped container |

✅ **Example:**  
```bash
docker create --name mycontainer nginx
docker start mycontainer
```

---

### **13. How do you remove all stopped containers and unused images?**  
✅ **Command:**  
```bash
docker system prune -a
```

---

### **14. How do you scan Docker images for vulnerabilities?**  
✅ **Solution:** Use **Docker Scan**  
```bash
docker scan myimage
```

---

### **15. How do you configure a private Docker registry?**  
✅ **Steps:**  
1️⃣ Run a private registry:  
```bash
docker run -d -p 5000:5000 --name registry registry:2
```
2️⃣ Tag and push an image:  
```bash
docker tag myapp localhost:5000/myapp
docker push localhost:5000/myapp
```
3️⃣ Pull the image:  
```bash
docker pull localhost:5000/myapp
```

---
