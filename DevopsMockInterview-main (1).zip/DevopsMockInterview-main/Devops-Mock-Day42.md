

1. **How do you manually scale a Kubernetes Deployment?**
    - **Explanation**: You can manually scale a Deployment using the `kubectl scale` command.
    - **Real-life example**: Increasing the number of replicas of a web application during a high-traffic event.
    - **Command**:
      ```bash
      kubectl scale deployment my-app --replicas=5
      ```

2. **How do you drain a node for maintenance in Kubernetes?**
    - **Explanation**: Draining a node safely evicts all Pods so that the node can be maintained or decommissioned.
    - **Real-life example**: Draining a node for an upgrade while ensuring Pods are rescheduled on other nodes.
    - **Command**:
      ```bash
      kubectl drain <node-name> --ignore-daemonsets
      ```

3. **What is a taint and a toleration in Kubernetes?**
    - **Explanation**: Taints and tolerations ensure certain Pods only run on specific nodes.
    - **Real-life example**: Tainting a node to run only critical workloads like databases, and ensuring only those workloads tolerate the taint.
    - **Command**:
      ```bash
      kubectl taint nodes <node-name> key=value:NoSchedule
      ```

4. **How do you perform a node upgrade in Kubernetes?**
    - **Explanation**: You can upgrade a node by draining it, updating the node software, and then uncordoning it.
    - **Real-life example**: Upgrading worker nodes to the latest version of Kubernetes without disrupting workloads.
    - **Command**:
      ```bash
      kubectl drain <node-name>
      # Perform upgrade
      kubectl uncordon <node-name>
      ```


5. **How do you use affinity and anti-affinity in Kubernetes?**
    - **Explanation**: Affinity and anti-affinity rules control how Pods are scheduled on nodes based on labels.
    - **Real-life example**: Ensuring Pods of the same application are spread across different nodes for high availability.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: Deployment
      metadata:
        name: my-app
      spec:
        replicas: 3
        template:
          metadata:
            labels:
              app: my-app
          spec:
            affinity:
              podAntiAffinity:
                requiredDuringSchedulingIgnoredDuringExecution:
                  - labelSelector:
                      matchExpressions:
                        - key: app
                          operator: In
                          values:
                            - my-app
                    topologyKey: "kubernetes.io/hostname"
      ```

6. **How do you implement a load balancer in Kubernetes?**
    - **Explanation**: Kubernetes Services of type `LoadBalancer` create an external load balancer.
    - **Real-life example**: Exposing a web application to the internet using a cloud provider’s load balancer (e.g., AWS, GCP).
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Service
      metadata:
        name: my-service
      spec:
        type: LoadBalancer
        selector:
          app: my-app
        ports:
          - protocol: TCP
            port: 80
            targetPort: 8080
      ```

7. **How do you control the rollout of a new application version using canary deployments?**
    - **Explanation**: Canary deployments allow you to roll out new versions to a subset of users before a full deployment.
    - **Real-life example**: Gradually deploying a new feature to 10% of the users before rolling it out to all users.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: Deployment
      metadata:
        name: my-app
      spec:
        replicas: 1
        template:
          metadata:
            labels:
              app: my-app
              version: canary
          spec:
            containers:
              - name: my-app
                image: my-app:v2
      ```

8. **How do you handle Pod disruption during a node failure?**
    - **Explanation**: Kubernetes automatically reschedules Pods on other available nodes when a node fails.
    - **Real-life example**: Ensuring high availability for a microservices-based application during node failures.
    - **Command**:
      ```bash
      kubectl get pods -o wide --field-selector spec.nodeName=<failed-node>
      ```

9. **What are DaemonSets, and how are they used in Kubernetes?**
    - **Explanation**: DaemonSets ensure that a copy of a Pod runs on all (or selected) nodes.
    - **Real-life example**: Running a monitoring agent (e.g., Fluentd or Prometheus Node Exporter) on every node in the cluster.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: DaemonSet
      metadata:
        name: node-exporter
      spec:
        selector:
          matchLabels:
            name: node-exporter
        template:
          metadata:
            labels:
              name: node-exporter
          spec:
            containers:
              - name: node-exporter
                image: prom/node-exporter
      ```

10. **How do you use Pod Disruption Budgets (PDB) in Kubernetes?**
    - **Explanation**: PDBs ensure that a minimum number of Pods are running during voluntary disruptions like node maintenance.
    - **Real-life example**: Ensuring that during rolling updates or node draining, at least 2 out of 5 application Pods remain available.
    - **Command**:
      ```yaml
      apiVersion: policy/v1beta1
      kind: PodDisruptionBudget
      metadata:
        name: my-app-pdb
      spec:
        minAvailable: 2
        selector:
          matchLabels:
            app: my-app
      ```

