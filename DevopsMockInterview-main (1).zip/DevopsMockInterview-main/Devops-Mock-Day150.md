
---

### **1. How do you handle a situation where two team members run `terraform apply` at the same time, causing state conflicts?**

**Answer:**

* Use a **remote backend** (like S3) with **state locking (DynamoDB)**.
* Locking ensures only one apply can run at a time.

**Example**:

```hcl
terraform {
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "prod/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-lock"
  }
}
```

---

### **2. What will you do if a resource is created outside Terraform (manually), but you now want to manage it with Terraform?**

**Answer:**

* Import it into Terraform:

```bash
terraform import aws_instance.web i-0a12b3456cdef7890
```

* Add the resource block in `.tf` to match the imported configuration.

---

### **3. How do you roll back if a Terraform apply caused downtime or issues?**

**Answer:**

1. Roll back to a **previous commit** in version control:

```bash
git checkout <last_good_commit>
terraform apply
```

2. If state is corrupted, restore from a **state backup**:

```bash
terraform state push backup.tfstate
```

---

### **4. How do you detect and fix drift (manual changes) in Terraform-managed infrastructure?**

**Answer:**

* Run:

```bash
terraform plan
```

* To sync state without applying:

```bash
terraform refresh
```

* Then decide whether to update infrastructure or code.

---

### **5. How do you handle multiple environments (dev, staging, prod) without duplicating code?**

**Answer:**

* Use **workspaces** or **modules**.

**Example (workspace):**

```bash
terraform workspace new dev
terraform workspace select dev
terraform apply
```

**Example (directory structure):**

```
environments/
  ├── dev/
  ├── staging/
  └── prod/
```

---

### **6. How do you ensure that a critical resource (like a database) is never deleted accidentally?**

**Answer:**

* Use `prevent_destroy` in lifecycle:

```hcl
resource "aws_db_instance" "prod" {
  lifecycle {
    prevent_destroy = true
  }
}
```

---

### **7. What if a Terraform apply fails midway and leaves partial resources? How do you fix it?**

**Answer:**

1. Check what was created:

```bash
terraform state list
```

2. Either:

   * Fix configuration and run `terraform apply` again.
   * Or clean up:

```bash
terraform destroy -target=aws_instance.web
```

---

### **8. How do you enforce tagging policies on all resources (e.g., every resource must have `Environment` tag)?**

**Answer:**

* Use **Sentinel (Terraform Cloud)** or **pre-commit hooks**.
* Example with a reusable tag variable:

```hcl
variable "tags" {
  default = {
    Environment = "prod"
    Owner       = "DevOps"
  }
}
```

Apply `tags = var.tags` to all resources.

---

### **9. How do you safely change a resource attribute that forces recreation (like changing subnet of an EC2)?**

**Answer:**

* Plan carefully using:

```bash
terraform plan -target=aws_instance.web
```

* Use `create_before_destroy` lifecycle:

```hcl
resource "aws_instance" "web" {
  lifecycle {
    create_before_destroy = true
  }
}
```

This avoids downtime.

---

### **10. How do you optimize Terraform for faster execution in a large environment with 100+ resources?**

**Answer:**

* Run with **parallelism**:

```bash
terraform apply -parallelism=20
```

* Break infrastructure into **modules** and manage separately.
* Avoid unnecessary `depends_on`.

---

