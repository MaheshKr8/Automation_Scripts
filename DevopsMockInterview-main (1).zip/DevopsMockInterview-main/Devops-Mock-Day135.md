
---

### **1. How do you manage servers in AWS and Azure using dynamic inventory in Ansible?**

**Answer:**
Use **dynamic inventory plugins**:

* **AWS**: Use `aws_ec2` plugin.
* **Azure**: Use `azure_rm` plugin.

**Steps for AWS (aws\_ec2.yml):**

```yaml
plugin: aws_ec2
regions:
  - us-east-1
filters:
  tag:Environment: production
keyed_groups:
  - key: tags.Name
```

**Steps for Azure (azure\_rm.yml):**

```yaml
plugin: azure_rm
include_vm_resource_groups:
  - MyResourceGroup
auth_source: auto
```

Then run:

```bash
ansible -i aws_ec2.yml,azure_rm.yml all -m ping
```

---

### **2. How do you do a rolling update on a cluster using Ansible?**

**Answer:**
Use `serial` to update a few hosts at a time:

```yaml
- name: Rolling update
  hosts: web_servers
  serial: 5
  tasks:
    - name: Restart app
      service:
        name: myapp
        state: restarted
```

This ensures only 5 servers are updated at a time.

---

### **3. How do you secure passwords and secrets in Ansible?**

**Answer:**
Use **Ansible Vault** to encrypt secrets like API keys or DB passwords.

Example:

```bash
ansible-vault create secrets.yml
```

Add:

```yaml
db_password: mysecurepass
```

Use in playbook:

```yaml
vars_files:
  - secrets.yml
```

Run with:

```bash
ansible-playbook playbook.yml --ask-vault-pass
```

---

### **4. How do you ensure idempotency in your playbooks?**

**Answer:**

* Use Ansible modules (like `file`, `package`, `service`) instead of raw shell commands.
* Example:

```yaml
- name: Ensure nginx is installed
  apt:
    name: nginx
    state: present
```

This installs nginx only if it’s not already installed — ensures **idempotency**.

---

### **5. How do you manage different environments (dev/stage/prod) using Ansible?**

**Answer:**

* Use **inventory grouping** and **group\_vars**.
* Folder structure:

```
inventories/
  dev/
    hosts
    group_vars/
      all.yml
  prod/
    hosts
    group_vars/
      all.yml
```

Run:

```bash
ansible-playbook -i inventories/prod/hosts site.yml
```

---

### **6. How do you handle failed tasks in a playbook without stopping execution?**

**Answer:**
Use `ignore_errors: yes` or `rescue` block:

```yaml
- name: Try to stop app
  command: systemctl stop app
  ignore_errors: yes
```

Or:

```yaml
- block:
    - name: Task that may fail
      command: /bin/false
  rescue:
    - name: Handle failure
      debug:
        msg: "Something went wrong"
```

---

### **7. How do you manage application deployment using Ansible?**

**Answer:**
Typical steps:

```yaml
- name: Deploy Java App
  hosts: app_servers
  tasks:
    - name: Copy WAR file
      copy:
        src: myapp.war
        dest: /opt/tomcat/webapps/

    - name: Restart Tomcat
      service:
        name: tomcat
        state: restarted
```

---

### **8. How do you reuse tasks across playbooks?**

**Answer:**
Use **roles** for reusability:

```bash
ansible-galaxy init roles/apache
```

In playbook:

```yaml
roles:
  - apache
```

Roles allow splitting configs into tasks, handlers, vars, etc.

---

### **9. How do you run a playbook on a specific host or group only?**

**Answer:**
Use the `--limit` option:

```bash
ansible-playbook site.yml --limit "web01"
```

Or use tags:

```yaml
- name: Install nginx
  apt:
    name: nginx
    state: present
  tags: install
```

Run with:

```bash
ansible-playbook site.yml --tags install
```

---

### **10. How do you manage OS-specific tasks in the same playbook?**

**Answer:**
Use `when` condition:

```yaml
- name: Install nginx on Ubuntu
  apt:
    name: nginx
    state: present
  when: ansible_facts['os_family'] == "Debian"

- name: Install nginx on RHEL
  yum:
    name: nginx
    state: present
  when: ansible_facts['os_family'] == "RedHat"
```

---

