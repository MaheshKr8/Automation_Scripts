
---

### ✅ 1. **What is DevOps and why is it important?**

**Answer:**
DevOps is a cultural and technical movement that bridges the gap between development and operations. It emphasizes:

* Continuous Integration & Delivery (CI/CD)
* Automation of infrastructure and deployments
* Faster feedback loops
* Monitoring and reliability

**Benefits**:

* Faster release cycles
* Better collaboration
* Increased deployment success rate

---

### ✅ 2. **What are the key components of a CI/CD pipeline?**

**Answer:**

1. **Source Control** – Git, GitHub, GitLab, Bitbucket
2. **Build** – Maven, Gradle, npm
3. **Test** – JUnit, Selenium, SonarQube
4. **CI Tools** – Jenkins, GitLab CI, CircleCI
5. **Artifact Repository** – Nexus, Artifactory, ECR
6. **Deployment** – Terraform, Ansible, Helm, Argo CD
7. **Monitoring** – Prometheus, Grafana, ELK, Datadog

---

### ✅ 3. **What is the difference between Continuous Integration, Continuous Delivery, and Continuous Deployment?**

**Answer:**

* **CI**: Automate building and testing code on each commit.
* **CD (Delivery)**: Automatically prepare and push code to staging after CI.
* **CD (Deployment)**: Automatically deploy to production after passing all tests.

---

### ✅ 4. **How do you handle secret management in DevOps pipelines?**

**Answer:**

* Store secrets securely in tools like:

  * **AWS Secrets Manager**
  * **Vault by HashiCorp**
  * **Kubernetes Secrets**
  * **Jenkins Credentials Store**

Avoid hardcoding credentials and mask them in logs.

---

### ✅ 5. **What are Infrastructure as Code (IaC) tools, and which ones have you used?**

**Answer:**
**IaC** automates infrastructure provisioning using code.

**Popular IaC tools**:

* **Terraform** – cloud-agnostic
* **CloudFormation** – AWS specific
* **Ansible** – configuration management
* **Pulumi** – supports modern languages like TypeScript, Python

---

### ✅ 6. **How do you ensure high availability in a cloud architecture?**

**Answer:**

* Use **Multi-AZ deployments**
* **Load Balancers** (ALB/NLB)
* **Auto Scaling Groups**
* **Failover DNS (Route53)**
* **Health checks** and **monitoring**

---

### ✅ 7. **What is the difference between Docker and a Virtual Machine?**

**Answer:**

| Docker (Container)  | Virtual Machine |
| ------------------- | --------------- |
| Shares host kernel  | Has full OS     |
| Lightweight         | Heavyweight     |
| Fast startup        | Slower startup  |
| Uses less resources | Uses more       |

Docker is ideal for microservices and portable deployments.

---

### ✅ 8. **How do you monitor applications and infrastructure in production?**

**Answer:**

* **Application Monitoring**: Prometheus + Grafana, Datadog, New Relic
* **Log Monitoring**: ELK stack (Elasticsearch, Logstash, Kibana), Fluentd
* **Alerting**: Alertmanager, PagerDuty, Opsgenie

---

### ✅ 9. **What is a blue-green deployment?**

**Answer:**
A deployment strategy that maintains two environments:

* **Blue**: current production
* **Green**: new version

Switch traffic to Green only when it's fully tested. This ensures **zero downtime** and **easy rollback**.

---

### ✅ 10. **What are some common challenges you’ve faced in a DevOps environment and how did you resolve them?**

**Answer:**
Examples:

* **Configuration drift**: Solved using Terraform + CI pipeline drift detection.
* **Slow deployments**: Fixed by introducing Docker & parallel stages in Jenkins.
* **Secrets leakage**: Implemented Vault + rotated credentials regularly.
* **Environment parity issues**: Adopted containers for local + production parity.

---

