
---

### 🧠 **1. What is Kubernetes and why is it used?**

**Answer:**
Kubernetes is an open-source container orchestration platform for automating deployment, scaling, and management of containerized applications. It's used to ensure high availability, self-healing, auto-scaling, and simplified deployments.

---

### 🧠 **2. What are the key components of a Kubernetes cluster?**

**Answer:**

* **Master Node** (Control Plane): API Server, Scheduler, Controller Manager, etcd.
* **Worker Node**: kubelet, kube-proxy, container runtime (Docker/containerd).
* **Pods**: Smallest deployable units containing containers.

---

### 🧠 **3. What is a Pod and how is it different from a container?**

**Answer:**
A Pod is the smallest deployable unit in Kubernetes and can hold one or more tightly coupled containers that share the same IP, storage, and namespace.

---

### 🧠 **4. What is a ReplicaSet?**

**Answer:**
ReplicaSet ensures a specified number of pod replicas are running at all times. It replaces the older ReplicationController.

---

### 🧠 **5. What is a Deployment in Kubernetes?**

**Answer:**
A Deployment manages ReplicaSets and enables rolling updates, rollbacks, and scaling operations easily through declarative configuration.

---

### 🧠 **6. What is a Service in Kubernetes?**

**Answer:**
A Service exposes a set of Pods as a network service. It allows load balancing and stable endpoints using DNS.

Types:

* ClusterIP
* NodePort
* LoadBalancer
* ExternalName

---

### 🧠 **7. What is a ConfigMap and Secret in Kubernetes?**

**Answer:**

* **ConfigMap**: Externalizes configuration data (e.g., app settings).
* **Secret**: Stores sensitive data (e.g., passwords, TLS certs) in base64 encoded format.

---

### 🧠 **8. How do you scale an application in Kubernetes?**

**Answer:**
Manually:

```bash
kubectl scale deployment my-app --replicas=5
```

Automatically:
Using **Horizontal Pod Autoscaler (HPA)** based on CPU/memory usage.

---

### 🧠 **9. What is a Namespace in Kubernetes?**

**Answer:**
Namespaces provide isolation within the same cluster and are useful for multi-tenant environments or team-based development.

---

### 🧠 **10. How does Kubernetes handle service discovery and load balancing?**

**Answer:**

* Each pod gets a DNS entry via kube-dns/CoreDNS.
* Services expose endpoints to load-balance requests across pods using kube-proxy.

---

### 🧠 **11. What is a StatefulSet and how is it different from a Deployment?**

**Answer:**
Used for **stateful applications** like databases (e.g., MongoDB, Cassandra). It maintains:

* Persistent identity (name, network)
* Stable storage using PVCs
* Ordered deployment and scaling

---

### 🧠 **12. How do you manage persistent data in Kubernetes?**

**Answer:**
By using:

* **PersistentVolume (PV)**: Provisioned storage.
* **PersistentVolumeClaim (PVC)**: Pod's request for PV.
* **StorageClass**: Defines how storage is dynamically provisioned.

---

### 🧠 **13. What is an Ingress in Kubernetes?**

**Answer:**
Ingress manages external access (HTTP/HTTPS) to services inside the cluster. It supports SSL termination, path-based routing, etc.

---

### 🧠 **14. How does Kubernetes handle container health checks?**

**Answer:**
Using:

* **Liveness Probe**: Detects if the container needs to be restarted.
* **Readiness Probe**: Indicates if the container is ready to receive traffic.

Defined in the pod spec:

```yaml
readinessProbe:
  httpGet:
    path: /healthz
    port: 8080
```

---

### 🧠 **15. How do you update applications in Kubernetes with zero downtime?**

**Answer:**
Use `rollingUpdate` strategy in Deployment:

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 1
    maxSurge: 1
```

---

### 🧠 **16. How do you perform a rollback in Kubernetes?**

**Answer:**

```bash
kubectl rollout undo deployment <deployment-name>
```

---

### 🧠 **17. How do you secure Kubernetes secrets?**

**Answer:**

* Use RBAC to restrict access.
* Mount Secrets as environment variables or volumes.
* Use tools like HashiCorp Vault or Sealed Secrets for encryption at rest.

---

### 🧠 **18. How does Kubernetes networking work internally?**

**Answer:**

* Every Pod gets its own IP.
* All Pods can talk to each other via flat networking (via CNI plugins like Calico, Flannel).
* `kube-proxy` handles routing traffic to services.

---

### 🧠 **19. How do you monitor Kubernetes clusters?**

**Answer:**

* **Prometheus** + **Grafana** for metrics
* **ELK stack** or **Loki** for logs
* **Kube-state-metrics** and **Node Exporter**

---

### 🧠 **20. How do you debug a failed Pod?**

**Answer:**

```bash
kubectl get pods
kubectl describe pod <pod-name>
kubectl logs <pod-name>
kubectl exec -it <pod-name> -- /bin/sh
```

---
