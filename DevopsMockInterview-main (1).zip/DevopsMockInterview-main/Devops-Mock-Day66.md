
1. **How do you prevent conflicts in Git?**
    - **Answer**: Regularly pulling changes from the remote, communicating with team members, and maintaining small, focused commits help reduce conflicts

.

2. **What is Git cherry-picking, and when is it useful?**
    - **Answer**: Cherry-picking allows you to apply specific commits to another branch without merging the entire branch, useful for hotfixes.

3. **What is the purpose of a Git hook?**
    - **Answer**: Git hooks are scripts that run automatically at certain points in the Git lifecycle, allowing automated tasks like code checks or formatting.

4. **Explain the importance of commit messages.**
    - **Answer**: Clear commit messages help track changes effectively, especially in collaborative projects, aiding in code review and troubleshooting.

5. **How do you handle dependencies in a project using Git?**
    - **Answer**: Use tools like Git submodules or dependency managers (e.g., NPM, Maven) to manage dependencies rather than including them in the repository.



6. **How do you handle sensitive data in Git?**
    - **Answer**: Avoid committing sensitive data by using environment variables, `.gitignore`, or tools like `git-secrets` to prevent accidental commits.

7. **What are Git submodules?**
    - **Answer**: Git submodules allow you to include and track repositories within another repository, useful for managing dependencies.

8. **How do you remove sensitive information from Git history?**
    - **Answer**: Use `git filter-branch` or `BFG Repo-Cleaner` to remove sensitive data from history.

9. **Explain Git’s distributed nature.**
    - **Answer**: Git is distributed, meaning each developer has a full copy of the repository, allowing offline work and reducing dependency on a central server.

10. **What is the difference between `git fork` and `git clone`?**
    - **Answer**: Forking creates a copy of a repository on a remote platform (e.g., GitHub), while cloning makes a local copy of an existing repository.

