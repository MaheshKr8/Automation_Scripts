
---

### ✅ **1. What is Git, and why is it used in real-time projects?**

**Answer:**
Git is a distributed version control system used to track changes in source code. In real-time projects, Git helps teams collaborate, manage code versions, roll back to previous states, and maintain code integrity through branching and merging strategies.

---

### ✅ **2. How do you resolve merge conflicts in Git?**

**Answer:**
When two branches have conflicting changes, Git shows conflict markers (`<<<<<<<`, `=======`, `>>>>>>>`) in files. Resolve by:

```bash
# Open conflicted file, edit to fix conflicts
git add <filename>
git commit
```

Tools like VSCode or `git mergetool` help visualize and fix conflicts.

---

### ✅ **3. What is the difference between `git pull` and `git fetch`?**

**Answer:**

* `git fetch`: Downloads changes from remote but doesn’t merge.
* `git pull`: Fetches and merges in one step.

**Real-time usage:** Use `git fetch` to inspect changes before merging:

```bash
git fetch origin
git diff origin/main
```

---

### ✅ **4. How do you revert a commit already pushed to a shared branch?**

**Answer:**
Use `git revert` to safely undo a commit:

```bash
git revert <commit-hash>
```

This creates a new commit that reverses the changes, preserving history.

---

### ✅ **5. Explain `git rebase` with a real-time example.**

**Answer:**
Used to move or combine commits to a new base:

```bash
git checkout feature
git rebase main
```

**Scenario:** Keeping feature branches updated with the latest `main` branch without merge commits.

---

### ✅ **6. What is a detached HEAD state? How do you fix it?**

**Answer:**
Occurs when checking out a specific commit:

```bash
git checkout <commit-hash>
```

Fix by switching to a branch or creating a new one:

```bash
git switch -c new-branch
```

---

### ✅ **7. How do you undo the last commit but keep the changes?**

**Answer:**

```bash
git reset --soft HEAD~1
```

This undoes the commit but preserves the changes in staging.

---

### ✅ **8. How do you clone a specific branch from a repo?**

**Answer:**

```bash
git clone -b branch-name --single-branch <repo-url>
```

---

### ✅ **9. How do you stash changes and apply them later?**

**Answer:**

```bash
git stash
# Later
git stash apply
```

**Real-time usage:** Useful when switching branches without committing WIP.

---

### ✅ **10. How do you see the history of a file?**

**Answer:**

```bash
git log <file-path>
```

Shows all commits where the file was changed.

---

### ✅ **11. How do you delete a remote branch?**

**Answer:**

```bash
git push origin --delete branch-name
```

---

### ✅ **12. How do you squash multiple commits into one?**

**Answer:**

```bash
git rebase -i HEAD~3
```

Use `pick` and `squash` in the editor to combine commits.

---

### ✅ **13. What’s the difference between `origin/main` and `main`?**

**Answer:**

* `main`: Local branch.
* `origin/main`: Remote tracking branch.

Use `git fetch` to update `origin/main`.

---

### ✅ **14. How do you create a Git tag and push it?**

**Answer:**

```bash
git tag v1.0
git push origin v1.0
```

**Usage:** Marking release versions.

---

### ✅ **15. How do you remove files from Git but keep them locally?**

**Answer:**

```bash
git rm --cached <file>
```

Used when accidentally committing sensitive or large files.

---

### ✅ **16. How do you find which commit introduced a bug?**

**Answer:**

```bash
git bisect start
git bisect bad
git bisect good <commit>
```

Git will guide through checking commits to find the bad one.

---

### ✅ **17. What is the difference between `git reset` and `git revert`?**

**Answer:**

* `git reset`: Alters commit history (destructive).
* `git revert`: Adds a new commit to undo changes (safe for shared branches).

---

### ✅ **18. How to handle large binary files in Git?**

**Answer:**
Use **Git LFS (Large File Storage)**:

```bash
git lfs install
git lfs track "*.zip"
```

---

### ✅ **19. How do you rename a branch both locally and remotely?**

**Answer:**

```bash
git branch -m old-name new-name
git push origin :old-name new-name
git push origin -u new-name
```

---

### ✅ **20. How do you contribute to an open-source project using Git?**

**Answer:**

1. Fork the repo.
2. Clone your fork: `git clone <fork-url>`
3. Create a branch: `git checkout -b feature-x`
4. Push and create a PR:

   ```bash
   git push origin feature-x
   ```

---
