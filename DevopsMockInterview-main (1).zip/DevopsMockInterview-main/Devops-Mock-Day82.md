### **15 Real-Time Scenario-Based Kubernetes Interview Questions and Answers**

Here are practical Kubernetes questions to test troubleshooting and real-world implementation skills:

---

### **1. How do you troubleshoot a Pod stuck in "Pending" state?**

#### **Scenario**:
You deploy a Pod, but it remains in the "Pending" state.

#### **Approach**:
1. Check Pod events:
   ```bash
   kubectl describe pod <pod_name>
   ```
2. Verify node capacity:
   ```bash
   kubectl describe nodes
   ```
3. Check if a matching `NodeSelector` or `Taint` is causing scheduling issues.

#### **Real-Life Example**:
A Pod with high CPU and memory requests was stuck because no node had enough resources. Adjusting resource requests fixed the issue.

---

### **2. How do you debug a failing Deployment rollout?**

#### **Scenario**:
You update a Deployment, but the rollout fails.

#### **Approach**:
1. Check rollout status:
   ```bash
   kubectl rollout status deployment <deployment_name>
   ```
2. Inspect Pod logs:
   ```bash
   kubectl logs <pod_name>
   ```
3. Check events for errors:
   ```bash
   kubectl describe deployment <deployment_name>
   ```

#### **Real-Life Example**:
A Deployment failed because the container image tag was incorrect. Updating the image tag fixed the issue.

---

### **3. How do you handle a Pod that frequently restarts?**

#### **Scenario**:
A Pod is in a "CrashLoopBackOff" state.

#### **Approach**:
1. Check the container logs:
   ```bash
   kubectl logs <pod_name>
   ```
2. Review the liveness probe configuration.
3. Test the container image locally to verify its functionality.

#### **Real-Life Example**:
An application container was crashing due to missing environment variables. Adding them fixed the issue.

---

### **4. How do you troubleshoot DNS issues in Kubernetes?**

#### **Scenario**:
A Pod cannot resolve domain names.

#### **Approach**:
1. Verify CoreDNS is running:
   ```bash
   kubectl get pods -n kube-system
   ```
2. Test DNS resolution from inside the Pod:
   ```bash
   kubectl exec -it <pod_name> -- nslookup google.com
   ```
3. Check `/etc/resolv.conf` inside the Pod.

#### **Real-Life Example**:
CoreDNS was failing due to high memory usage. Increasing resource limits resolved the issue.

---

### **5. How do you scale a Deployment during a traffic spike?**

#### **Scenario**:
Your web application is experiencing a sudden surge in traffic.

#### **Approach**:
1. Manually scale the Deployment:
   ```bash
   kubectl scale deployment <deployment_name> --replicas=10
   ```
2. Configure a Horizontal Pod Autoscaler (HPA):
   ```yaml
   apiVersion: autoscaling/v2
   kind: HorizontalPodAutoscaler
   metadata:
     name: web-app-hpa
   spec:
     scaleTargetRef:
       apiVersion: apps/v1
       kind: Deployment
       name: web-app
     minReplicas: 3
     maxReplicas: 10
     metrics:
     - type: Resource
       resource:
         name: cpu
         target:
           type: Utilization
           averageUtilization: 75
   ```

---

### **6. How do you expose a Kubernetes application to the internet?**

#### **Scenario**:
Your application needs to be accessible externally.

#### **Approach**:
1. Use a Service of type `LoadBalancer`:
   ```yaml
   apiVersion: v1
   kind: Service
   metadata:
     name: web-service
   spec:
     type: LoadBalancer
     selector:
       app: web-app
     ports:
       - port: 80
         targetPort: 8080
   ```
2. Use Ingress for advanced routing and TLS:
   ```yaml
   apiVersion: networking.k8s.io/v1
   kind: Ingress
   metadata:
     name: web-ingress
   spec:
     rules:
     - host: my-app.example.com
       http:
         paths:
         - path: /
           pathType: Prefix
           backend:
             service:
               name: web-service
               port:
                 number: 80
   ```

---

### **7. How do you implement persistent storage in Kubernetes?**

#### **Scenario**:
A database requires persistent data storage.

#### **Approach**:
1. Define a PersistentVolume (PV):
   ```yaml
   apiVersion: v1
   kind: PersistentVolume
   metadata:
     name: pv-storage
   spec:
     capacity:
       storage: 5Gi
     accessModes:
     - ReadWriteOnce
     hostPath:
       path: /data
   ```

2. Create a PersistentVolumeClaim (PVC):
   ```yaml
   apiVersion: v1
   kind: PersistentVolumeClaim
   metadata:
     name: pvc-storage
   spec:
     resources:
       requests:
         storage: 5Gi
   ```

---

### **8. How do you debug failed liveness or readiness probes?**

#### **Scenario**:
Pods are failing due to misconfigured probes.

#### **Approach**:
1. Review the probe configuration in the Deployment:
   ```yaml
   livenessProbe:
     httpGet:
       path: /health
       port: 8080
     initialDelaySeconds: 10
   ```
2. Test the endpoint manually:
   ```bash
   curl http://<pod_ip>:8080/health
   ```

---

### **9. How do you secure secrets in Kubernetes?**

#### **Scenario**:
You need to securely store and access sensitive information like database credentials.

#### **Approach**:
1. Create a Secret:
   ```bash
   kubectl create secret generic db-secret --from-literal=username=admin --from-literal=password=pass123
   ```
2. Use the Secret in a Pod:
   ```yaml
   env:
   - name: DB_USERNAME
     valueFrom:
       secretKeyRef:
         name: db-secret
         key: username
   ```

---

### **10. How do you monitor resource usage in a cluster?**

#### **Scenario**:
You need to ensure the cluster is not running out of resources.

#### **Approach**:
1. Install the Metrics Server:
   ```bash
   kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
   ```
2. View resource usage:
   ```bash
   kubectl top pods
   kubectl top nodes
   ```

---

### **11. How do you manage application logs in Kubernetes?**

#### **Scenario**:
You need to centralize and analyze logs from multiple Pods.

#### **Approach**:
1. Use `kubectl logs` for individual Pods:
   ```bash
   kubectl logs <pod_name>
   ```
2. Use a logging solution like Fluentd with Elasticsearch and Kibana (EFK).

---

### **12. How do you troubleshoot network issues in Kubernetes?**

#### **Scenario**:
Pods cannot communicate with each other.

#### **Approach**:
1. Verify the network policies:
   ```bash
   kubectl describe networkpolicy
   ```
2. Test Pod-to-Pod communication using `ping` or `curl`.

---

### **13. How do you ensure a StatefulSet application has consistent Pod ordering?**

#### **Scenario**:
A database cluster requires sequential startup and unique identities.

#### **Approach**:
1. Use a StatefulSet:
   ```yaml
   apiVersion: apps/v1
   kind: StatefulSet
   metadata:
     name: db-cluster
   spec:
     serviceName: "db-service"
     replicas: 3
     selector:
       matchLabels:
         app: db
   ```

---

### **14. How do you handle a node marked as "NotReady"?**

#### **Scenario**:
A node is not scheduling Pods due to health issues.

#### **Approach**:
1. Check node status:
   ```bash
   kubectl describe node <node_name>
   ```
2. Investigate kubelet logs on the node:
   ```bash
   journalctl -u kubelet
   ```

---

### **15. How do you deploy a blue-green deployment in Kubernetes?**

#### **Scenario**:
You want to release a new version of an application without downtime.

#### **Approach**:
1. Deploy a new version alongside the existing version:
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: web-v2
   spec:
     replicas: 3
     selector:
       matchLabels:
         app: web-v2
   ```
2. Update the service to point to the new version:
   ```bash
   kubectl apply -f service.yaml
   ```

---
