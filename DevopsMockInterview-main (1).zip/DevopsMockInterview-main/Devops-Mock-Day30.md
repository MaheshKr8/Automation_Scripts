### 1. **How do you set environment variables in Jenkins?**

**Answer:**
Environment variables in Jenkins can be set in multiple ways:
1. **In the Job Configuration:**
   - Use the **"Inject environment variables"** option to set variables in the job's configuration.

2. **Inside Jenkinsfile:**
   - Set environment variables using the `environment` block in the pipeline.

**Example:**
```groovy
pipeline {
    environment {
        MY_VAR = 'value'
    }
    stages {
        stage('Build') {
            steps {
                echo "Environment Variable: ${env.MY_VAR}"
            }
        }
    }
}
```

### 2. **What are Jenkins shared libraries, and how do you use them?**

**Answer:**
Jenkins shared libraries are a way to reuse common pipeline code across multiple Jenkins pipelines. You define reusable functions and scripts in a central repository and call them from various Jenkins pipelines.

**Steps to Set Up Shared Libraries:**
1. **Create the Library:**
   - Create a Git repository for the shared library. It must have the correct structure, with `vars/` and `src/` folders.

2. **Configure the Library in Jenkins:**
   - Go to **Manage Jenkins** > **Configure System** and add the shared library repository under **Global Pipeline Libraries**.

3. **Use the Library in Jenkinsfile:**
   - Include the shared library using the `@Library` annotation.

**Example:**
```groovy
@Library('my-shared-library') _
myFunction()
```

### 3. **What is the role of the Jenkins Master-Slave architecture?**

**Answer:**
Jenkins follows a master-slave architecture to support distributed builds:
- **Jenkins Master:** Handles job scheduling, dispatches builds to slaves, manages user interactions, and monitors jobs.
- **Jenkins Slave:** Executes build jobs assigned by the master. It can be configured on different environments to allow for cross-platform builds and testing.


### 4. **How do you configure Jenkins for distributed builds?**

**Answer:**
1. **Install Jenkins on Slave Machines:**
   - Set up Jenkins agents on remote machines or use cloud agents like AWS or Docker.
   
2. **Connect Slaves to Jenkins Master:**
   - Go to **Manage Jenkins** > **Manage Nodes and Clouds** > **New Node** to add a new agent.
   
3. **Configure Labels:**
   - Assign labels to slaves, which can be used in pipeline scripts to direct specific jobs to certain agents.

4. **Run Jobs on Agents:**
   - In the Jenkinsfile or job configuration, specify which agent to use based on labels.

**Example:**
```groovy
pipeline {
    agent { label 'linux' }
    stages {
        stage('Build') {
            steps {
                echo 'Running build on Linux agent'
            }
        }
    }
}
```

### 5. **How do you integrate Jenkins with Docker?**

**Answer:**
1. **Install Docker Plugin:**
   - Go to **Manage Jenkins** > **Manage Plugins** and install the Docker plugin.

2. **Configure Docker Daemon:**
   - Ensure Docker is installed and running on Jenkins agents.

3. **Use Docker in Jenkins Pipeline:**
   - In the pipeline, use Docker commands to build and run containers.

**Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Build Docker Image') {
            steps {
                script {
                    docker.build('my-app-image').inside {
                        sh 'npm test'
                    }
                }
            }
        }
    }
}
```

### 6. **What is Jenkins multibranch pipeline, and how does it work?**

**Answer:**
The multibranch pipeline in Jenkins allows you to automatically create Jenkins pipelines for each branch in a source control repository. Each branch can have its own Jenkinsfile defining its pipeline.

### 7. **How do you configure Jenkins to deploy to AWS?**

**Answer:**
1. **Install AWS Plugin:**
   - Install the **AWS Credentials** and **S3** or **EC2** plugin from the plugin manager.

2. **Configure AWS Credentials:**
   - Add AWS credentials under **Manage Jenkins** > **Manage Credentials**.

3.

 **Create a Jenkins Pipeline:**
   - In the Jenkinsfile, use AWS CLI commands or AWS SDK to interact with services like EC2, S3, and Lambda.

**Example AWS CLI Command:**
```groovy
sh 'aws s3 cp my-app.zip s3://my-bucket'
```

### 8. **What are the different types of jobs in Jenkins?**
**Answer:**
1. **Freestyle Project:** Simple job with predefined options for building, testing, and deployment.
2. **Pipeline Job:** A job that runs a Jenkinsfile, allowing more complex build pipelines.
3. **Multibranch Pipeline:** Automatically creates a pipeline for each branch in a repository.
4. **Folder Item:** A way to organize jobs into folders.
5. **Matrix Project:** A job for running tests or builds on multiple environments simultaneously.
6. **External Job:** Used to monitor non-Jenkins processes.

### 9. **How do you manage and configure Jenkins plugins?**
**Answer:**
1. **Install Plugins:** Go to **Manage Jenkins** > **Manage Plugins**. You can browse and install new plugins from the **Available** tab.
2. **Update Plugins:** Plugins can be updated from the **Updates** tab.
3. **Remove Plugins:** Uninstall plugins from the **Installed** tab.
4. **Plugin Configuration:** After installing plugins, configure them from the **Configure System** or individual job configurations.

### 10. **What is Jenkins Distributed Build Architecture?**
**Answer:**
Jenkins allows you to distribute builds across multiple machines (agents/slaves) to manage load, perform builds on different environments, or use specific hardware. The master schedules jobs, and the agents execute them.
