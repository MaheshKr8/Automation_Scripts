
1. **How do you manage dynamic inventories?**
    - **Answer**: Dynamic inventory scripts allow fetching hosts from cloud providers (AWS, Azure).
    - **Example**: Use `aws_ec2` plugin for dynamic inventory with AWS.

2. **How can you improve Ansible performance?**
    - **Answer**: By using `forks` to run tasks in parallel, using `strategy: free`, and limiting host patterns.


     * 1. **Forks**: Imagine you’re deploying updates to 100 servers. By default, Ansible might handle them one at a time. If you set `forks: 10`, it will update 10 servers simultaneously, reducing the total time from hours to minutes.

     * 2. **Strategy: Free**: Suppose you have a playbook that configures a web server and a database server. With the default strategy, Ansible waits for one task to complete before starting the next. Using `strategy: free` allows both configurations to run at the same time, speeding up deployment.

     * 3. **Limiting Host Patterns**: If you only need to update your application on a subset of servers, you can specify just those hosts in your inventory. This avoids running tasks on all servers, saving time and resources.

     * These examples demonstrate how adjusting these settings can lead to quicker and more efficient automation.

3. **How do you troubleshoot playbooks?**
    - **Answer**: Use `-v`, `-vv`, or `-vvv` for increasing verbosity during execution.

4. **What are facts in Ansible, and how are they used?**
    - **Answer**: Facts are automatically collected system variables.
    - **Example**:
      ```yaml
      - hosts: localhost
        tasks:
          - debug:
              var: ansible_facts['distribution']
      ```

5. **How would you handle errors in Ansible?**
    - **Answer**: Use `ignore_errors: yes` or `failed_when` to handle errors gracefully.

---


6. **How do you configure Ansible to manage Windows machines?**
    - **Answer**: By using WinRM for communication and setting up an inventory file for Windows hosts.
    - **Script Example**:
      ```ini
      [windows]
      win1 ansible_host=192.168.1.10 ansible_user=admin ansible_password=pass ansible_connection=winrm
      ```

7. **How would you automate a multi-tier application deployment using Ansible?**
    - **Answer**: Use roles to separate tasks for each tier (database, application, web).

8. **How do you back up configuration files before modifying them?**
    - **Answer**: Use `backup: yes` in modules like `copy` or `template`.
    - **Script Example**:
      ```yaml
      - name: Copy config file with backup
        copy:
          src: /etc/nginx/nginx.conf
          dest: /etc/nginx/nginx.conf.bak
          backup: yes
      ```

9. **How do you use Ansible for patch management?**
    - **Answer**: Create playbooks to check and install updates on all managed servers.

10. **What would you do if an Ansible task fails in the middle of playbook execution?**
    - **Answer**: Use `serial` to limit the number of hosts a playbook runs on simultaneously, reducing failure impact.

---

### **Real-Life Scripts to Practice**

1. **Deploy Nginx on Multiple Servers**:
   ```yaml
   - hosts: webservers
     become: yes
     tasks:
       - name: Install Nginx
         apt:
           name: nginx
           state: present
   ```

2. **Rolling Restart of Application Servers**:
   ```yaml
   - hosts: app
     serial: 1
     tasks:
       - name: Restart app server
         service:
           name: myapp
           state: restarted
   ```

3. **Backup and Deploy Application**:
   ```yaml
   - hosts: appservers
     tasks:
       - name: Backup existing application
         copy:
           src: /var/www/html/app
           dest: /var/backups/app.bak
           remote_src: yes
       - name: Deploy new application
         copy:
           src: /local/path/to/app
           dest: /var/www/html/app
   ```

4. **Windows Server Patch Management**:
   ```yaml
   - hosts: windows
     tasks:
       - name: Install Windows updates
         win_updates:
           category_names:
             - SecurityUpdates
   ```

5. **Database Backup Automation**:
   ```yaml
   - hosts: db
     tasks:
       - name: Backup MySQL database
         mysql_db:
           name: mydb
           state: dump
           target: /backups/mydb.sql
   ```

---

These questions and scripts are designed to cover a broad range of real-world scenarios and practical usage of Ansible. Practicing these examples will prepare you for interviews as well as hands-on use in production environments.
