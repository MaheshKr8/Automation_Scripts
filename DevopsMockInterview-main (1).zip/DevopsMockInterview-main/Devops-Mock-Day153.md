
---

### 🚨 **1. What steps would you take if a production deployment accidentally took down a live service?**

**Answer:**

1. **Roll back immediately** via GitOps or deployment tool (e.g., ArgoCD, Helm rollback, Jenkins pipeline).
2. **Trigger Incident Response Process** (alert on-call, open war room).
3. Analyze logs & metrics to determine the root cause.
4. Create a **postmortem**: include what failed, how it failed, and how it was fixed.
5. Add tests, deployment gates, or approvals to prevent recurrence.

---

### ⚠️ **2. Your Terraform destroy command was accidentally triggered in production. What would you do?**

**Answer:**

1. **Interrupt the destroy process** if still running.
2. Use **Terraform state backup** to understand what resources are affected.
3. If destroyed, restore from **infrastructure snapshots**, **EBS backups**, or **RDS snapshots**.
4. Implement:

   * **RBAC** (Terraform runs limited to staging).
   * **Approval pipelines** before apply/destroy.
   * `prevent_destroy = true` in sensitive resources.

---

### 🔐 **3. You found secrets (AWS keys, DB passwords) checked into Git. What are your immediate steps?**

**Answer:**

1. **Revoke/rotate the compromised keys** immediately.
2. Use tools like **git-secrets** or **truffleHog** to scan the repo.
3. Clean the Git history (e.g., `git filter-branch` or BFG).
4. Move to secret managers:

   * **AWS Secrets Manager**
   * **HashiCorp Vault**
   * **Kubernetes Secrets + Sealed Secrets**

---

### 🔁 **4. A CI/CD pipeline suddenly started deploying to production without approvals. What do you do?**

**Answer:**

1. Stop the pipeline immediately.
2. Investigate:

   * Check **audit logs**.
   * Validate pipeline config and credential leaks.
3. Fix:

   * Add **manual approval gates**.
   * Implement RBAC and role separation.
   * Validate branch protection and commit signatures.

---

### 🧠 **5. If you had to recover an entire region outage in AWS, what’s your DR approach?**

**Answer:**

* Maintain **multi-region architecture** with:

  * **S3 cross-region replication**
  * **RDS Global Databases**
  * **DNS failover (Route 53)**
* Use **Terraform/CloudFormation** to redeploy infra.
* Store **AMIs and container images** in multiple regions.
* Use warm/active DR and validate with **DR drills** quarterly.

---

### ☠️ **6. A Kubernetes cluster was compromised. How do you mitigate and prevent such attacks?**

**Answer:**

1. Revoke cluster access and isolate nodes.
2. Rotate all secrets and tokens.
3. Investigate using:

   * **audit logs**
   * **Falco/OPA** logs
4. Preventive:

   * **RBAC + Network Policies**
   * Enable **PodSecurityPolicies**, OPA/Gatekeeper
   * Run **Trivy** scans on all images

---

### 💣 **7. You noticed one pod is using 100% CPU and affecting others. How do you handle this?**

**Answer:**

1. **Evict the pod** or reduce replicas temporarily.
2. Add proper **resource requests and limits**:

   ```yaml
   resources:
     requests:
       cpu: "250m"
       memory: "512Mi"
     limits:
       cpu: "500m"
       memory: "1Gi"
   ```
3. Implement **HPA** (Horizontal Pod Autoscaler).
4. Use **Pod QoS classes** to prioritize workloads.

---

### 🛑 **8. What if someone force pushed to the `main` branch and overwrote production code?**

**Answer:**

1. Immediately lock the branch.
2. Revert using reflog if possible: `git reflog` → `git reset --hard <commit>`
3. Restore previous tag/deployment via GitOps or CI pipeline.
4. Add:

   * Branch protection rules
   * Disallow force-pushes
   * Signed commits

---

### 🔧 **9. How do you recover from a corrupted Terraform state file?**

**Answer:**

1. Use a **backup of the state** (Terraform Cloud/S3 backend).
2. Use `terraform state pull` and fix manually if needed.
3. Last resort: Import resources manually with `terraform import`.
4. Enable **state locking**, **versioning**, and **remote backend** protection.

---

### 🔁 **10. What if an EC2 instance with crucial data crashed and wasn't backed up?**

**Answer:**

1. If possible, try to **detach the EBS volume** and reattach to another instance.
2. If volume is corrupted and no backup exists:

   * You may need **data recovery services** (time-consuming/expensive).
3. Preventive:

   * Always enable **EBS snapshots**
   * Use **AutoRecovery**
   * Store data in **S3 or RDS** instead of EC2 local

---

