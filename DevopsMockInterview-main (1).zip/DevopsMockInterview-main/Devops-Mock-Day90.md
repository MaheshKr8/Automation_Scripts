### 🐳 **10 Real-Time Docker Interview Questions with Answers and Examples**

---

### **1. How do you troubleshoot a failing Docker container?**

✅ **Answer:**  
To troubleshoot a failing Docker container:

1. **Check Container Logs:**
   ```bash
   docker logs <container_id>
   ```
2. **Inspect the Container’s Status:**
   ```bash
   docker ps -a
   ```
3. **Execute a Shell Inside the Container:**
   ```bash
   docker exec -it <container_id> /bin/bash
   ```
4. **Check Container Events:**
   ```bash
   docker events
   ```
5. **Inspect Container Details:**
   ```bash
   docker inspect <container_id>
   ```

✅ **Example:**  
If your **Nginx** container is failing, you can check the logs:
```bash
docker logs nginx-container
```
If there’s a configuration error, enter the container:
```bash
docker exec -it nginx-container /bin/sh
```

---

### **2. How do you optimize Docker images for better performance?**

✅ **Answer:**  
Strategies to optimize Docker images:
1. **Use Multi-Stage Builds**:
   ```Dockerfile
   # Build Stage
   FROM golang:1.21 AS builder
   WORKDIR /app
   COPY . .
   RUN go build -o main .

   # Run Stage
   FROM alpine:latest
   COPY --from=builder /app/main /main
   ENTRYPOINT ["/main"]
   ```
2. **Use Official Base Images:**  
   Prefer lighter images like `alpine` over `ubuntu`.
3. **Minimize Layers:**  
   Combine multiple `RUN` commands to reduce layers.
4. **Use Docker Ignore Files:**  
   Create a `.dockerignore` file to exclude unnecessary files.

---

### **3. How do you handle persistent data in Docker containers?**

✅ **Answer:**  
Use **volumes** or **bind mounts** to store persistent data.

1. **Named Volumes (Recommended for Persistence)**:
   ```bash
   docker volume create my_data
   docker run -d -v my_data:/data nginx
   ```
2. **Bind Mounts (For Local Development)**:
   ```bash
   docker run -d -v /home/user/data:/data nginx
   ```

✅ **Example:**  
Persist MySQL data:
```bash
docker run -d --name mysql-db -v mysql_data:/var/lib/mysql mysql
```

---

### **4. How do you secure sensitive information in Docker?**

✅ **Answer:**  
1. **Use Docker Secrets (Docker Swarm Mode Required)**:
   ```bash
   echo "my_password" | docker secret create db_password -
   ```
   Use in `docker-compose.yml`:
   ```yaml
   secrets:
     db_password:
       external: true
   ```
2. **Environment Variables (For Non-Critical Data)**:
   ```bash
   docker run -e DB_PASSWORD=mysecretpassword myapp
   ```

---

### **5. How do you debug Docker networking issues?**

✅ **Answer:**  
1. **Check Container Networks:**
   ```bash
   docker network ls
   docker network inspect <network_name>
   ```
2. **Connect to a Container’s Shell:**
   ```bash
   docker exec -it <container_id> /bin/bash
   ```
3. **Ping Between Containers:**
   ```bash
   docker exec -it <container_id> ping <other_container>
   ```
4. **Check IP Address of Containers:**
   ```bash
   docker inspect -f '{{range.NetworkSettings.Networks}}{{.IPAddress}}{{end}}' <container_id>
   ```

✅ **Example:**  
If two services can’t communicate, ensure they are on the same Docker network:
```bash
docker network create my_network
docker run --network my_network app1
docker run --network my_network app2
```

---

### **6. How do you implement auto-restart for Docker containers?**

✅ **Answer:**  
Use the `--restart` policy when starting containers:

1. **Always Restart the Container**:
   ```bash
   docker run -d --restart=always nginx
   ```
2. **Restart on Failure**:
   ```bash
   docker run -d --restart=on-failure:3 myapp
   ```
3. **Docker-Compose Restart Policy**:
   ```yaml
   version: '3.8'
   services:
     app:
       image: myapp
       restart: always
   ```

---

### **7. What is Docker Compose, and how is it useful in multi-container applications?**

✅ **Answer:**  
Docker Compose is a tool to define and run multi-container applications using a `docker-compose.yml` file.

✅ **Example:**  
To run a **Node.js** app with **MongoDB**:
```yaml
version: '3.8'
services:
  app:
    image: node:18
    ports:
      - "3000:3000"
    depends_on:
      - mongo
  mongo:
    image: mongo
    volumes:
      - mongo_data:/data/db
volumes:
  mongo_data:
```
Start the containers:
```bash
docker-compose up -d
```

---

### **8. How do you handle logs in Docker?**

✅ **Answer:**  
1. **View Container Logs:**
   ```bash
   docker logs <container_id>
   ```
2. **Stream Logs Continuously:**
   ```bash
   docker logs -f <container_id>
   ```
3. **Configure Docker Logging Driver:**
   Use **json-file**, **syslog**, or **ELK stack** for centralized logging.
   ```yaml
   logging:
     driver: "json-file"
     options:
       max-size: "10m"
       max-file: "3"
   ```

---

### **9. How do you clean up unused Docker resources?**

✅ **Answer:**  
1. **Stop and Remove All Containers:**
   ```bash
   docker stop $(docker ps -aq) && docker rm $(docker ps -aq)
   ```
2. **Remove Unused Images:**
   ```bash
   docker image prune -a
   ```
3. **Delete Dangling Volumes and Networks:**
   ```bash
   docker volume prune
   docker network prune
   ```
4. **Full Cleanup:**
   ```bash
   docker system prune -a
   ```

---

### **10. How do you monitor Docker containers?**

✅ **Answer:**  
1. **Inspect Resource Usage:**
   ```bash
   docker stats
   ```
2. **Use Docker Events for Real-Time Monitoring:**
   ```bash
   docker events
   ```
3. **Monitor Logs Using External Tools**:
   Use **Prometheus**, **Grafana**, or **ELK (Elasticsearch, Logstash, Kibana)** for in-depth monitoring.

✅ **Example:**  
Install **cAdvisor** for container monitoring:
```bash
docker run -d \
  --name=cadvisor \
  --volume=/:/rootfs:ro \
  --volume=/var/run:/var/run:ro \
  --volume=/sys:/sys:ro \
  google/cadvisor:latest
```

---
