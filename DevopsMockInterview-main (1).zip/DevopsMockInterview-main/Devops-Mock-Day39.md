
1. **How do you handle persistent storage in Kubernetes?**
    - **Explanation**: Kubernetes uses Persistent Volumes (PV) and Persistent Volume Claims (PVC) to manage storage.
    - **Real-life example**: A database that requires persistent storage across Pod restarts.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: PersistentVolumeClaim
      metadata:
        name: my-pvc
      spec:
        accessModes:
          - ReadWriteOnce
        resources:
          requests:
            storage: 

1Gi
      ```

2. **What is the difference between PersistentVolume and PersistentVolumeClaim?**
    - **Explanation**: PersistentVolumes (PV) are physical storage, while PersistentVolumeClaims (PVC) are requests for that storage.
    - **Real-life example**: Provisioning storage dynamically using cloud storage classes.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: PersistentVolume
      metadata:
        name: my-pv
      spec:
        capacity:
          storage: 10Gi
        accessModes:
          - ReadWriteOnce
        hostPath:
          path: "/mnt/data"
      ```

Here are the remaining Kubernetes real-time scenario-based interview questions and answers, with real-life examples and explanations:



3. **How do you provision dynamic storage in Kubernetes?**
    - **Explanation**: Dynamic provisioning automatically creates storage based on PVC using a StorageClass.
    - **Real-life example**: Using AWS EBS as dynamic storage for your Kubernetes cluster.
    - **Command**:
      ```yaml
      apiVersion: storage.k8s.io/v1
      kind: StorageClass
      metadata:
        name: aws-ebs
      provisioner: kubernetes.io/aws-ebs
      ```

4. **How do you configure a StatefulSet for stateful applications?**
    - **Explanation**: StatefulSets manage the deployment and scaling of stateful applications.
    - **Real-life example**: Running a Cassandra database with each Pod having its own persistent volume.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: StatefulSet
      metadata:
        name: cassandra
      spec:
        serviceName: "cassandra"
        replicas: 3
        selector:
          matchLabels:
            app: cassandra
        template:
          metadata:
            labels:
              app: cassandra
          spec:
            containers:
              - name: cassandra
                image: cassandra
                volumeMounts:
                  - name: data
                    mountPath: /var/lib/cassandra/data
        volumeClaimTemplates:
          - metadata:
              name: data
            spec:
              accessModes: ["ReadWriteOnce"]
              resources:
                requests:
                  storage: 1Gi
      ```

5. **What happens if a Pod in a StatefulSet is deleted?**
    - **Explanation**: Kubernetes recreates the deleted Pod with the same identity (persistent storage and network identity).
    - **Real-life example**: Deleting a Cassandra Pod in a StatefulSet, which Kubernetes automatically recreates.
    - **Command**:
      ```bash
      kubectl delete pod cassandra-1
      ```

6. **How do you manage volume snapshots in Kubernetes?**
    - **Explanation**: Volume snapshots allow you to create backups of PersistentVolumes.
    - **Real-life example**: Creating a snapshot of a database volume before an upgrade.
    - **Command**:
      ```yaml
      apiVersion: snapshot.storage.k8s.io/v1
      kind: VolumeSnapshot
      metadata:
        name: my-snapshot
      spec:
        volumeSnapshotClassName: my-snapshot-class
        source:
          persistentVolumeClaimName: my-pvc
      ```

7. **How do you resize a PersistentVolumeClaim in Kubernetes?**
    - **Explanation**: You can resize PVCs if the underlying storage supports it.
    - **Real-life example**: Expanding the storage for a database to handle more data.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: PersistentVolumeClaim
      metadata:
        name: my-pvc
      spec:
        resources:
          requests:
            storage: 5Gi
      ```



8. **How do you monitor a Kubernetes cluster?**
    - **Explanation**: Kubernetes can be monitored using tools like Prometheus, Grafana, and metrics-server.
    - **Real-life example**: Setting up Prometheus and Grafana to visualize cluster metrics like CPU and memory usage.
    - **Command**:
      ```bash
      # Install Prometheus using Helm
      helm install prometheus prometheus-community/prometheus
      ```

9. **What is Kubernetes Horizontal Pod Autoscaler (HPA), and how does it work?**
    - **Explanation**: HPA scales Pods based on CPU/memory usage or custom metrics.
    - **Real-life example**: Scaling a web app based on CPU usage during high traffic periods.
    - **Command**:
      ```bash
      kubectl autoscale deployment my-app --cpu-percent=50 --min=1 --max=10
      ```

10. **How do you configure custom metrics for HPA?**
    - **Explanation**: Custom metrics allow HPA to scale based on application-specific metrics like request count.
    - **Real-life example**: Scaling Pods based on the number of HTTP requests per second.
    - **Command**:
      ```yaml
      apiVersion: autoscaling/v2beta2
      kind: HorizontalPodAutoscaler
      metadata:
        name: custom-metrics-hpa
      spec:
        scaleTargetRef:
          apiVersion: apps/v1
          kind: Deployment
          name: my-app
        minReplicas: 1
        maxReplicas: 10
        metrics:
          - type: Object
            object:
              metric:
                name: http_requests
              describedObject:
                kind: Service
                name: my-service
                apiVersion: v1
              target:
                type: Value
                value: "100"
      ```

11. **How do you collect logs from Kubernetes Pods?**
    - **Explanation**: Logs can be collected from Pods using tools like Fluentd, Elasticsearch, and Kibana (ELK stack).
    - **Real-life example**: Collecting and analyzing application logs using ELK.
    - **Command**:
      ```bash
      kubectl logs <pod-name>
      ```

12. **How do you monitor Kubernetes nodes and Pods?**
    - **Explanation**: Use `kubectl top` or tools like Prometheus to monitor resource utilization.
    - **Real-life example**: Monitoring CPU and memory usage of nodes to ensure no resource exhaustion.
    - **Command**:
      ```bash
      kubectl top nodes
      kubectl top pods
      ```

13. **How do you troubleshoot a failing Pod in Kubernetes?**
    - **Explanation**: Use `kubectl describe` and `kubectl logs` to gather detailed information.
    - **Real-life example**: A Pod failing due to an incorrect configuration, and using `kubectl describe` to investigate.
    - **Command**:
      ```bash
      kubectl describe pod <pod-name>
      kubectl logs <pod-name>
      ```



14. **How do you secure communication between Pods?**
    - **Explanation**: Use Network Policies to control traffic between Pods.
    - **Real-life example**: Only allowing backend Pods to receive traffic from frontend Pods.
    - **Command**:
      ```yaml
      apiVersion: networking.k8s.io/v1
      kind: NetworkPolicy
      metadata:
        name: allow-frontend
      spec:
        podSelector:
          matchLabels:
            app: backend
        policyTypes:
          - Ingress
        ingress:
          - from:
              - podSelector:
                  matchLabels:
                    app: frontend
      ```

15. **What is Role-Based Access Control (RBAC) in Kubernetes?**
    - **Explanation**: RBAC restricts access to resources in Kubernetes based on user roles.
    - **Real-life example**: Granting a user read-only access to Pods.
    - **Command**:
      ```yaml
      apiVersion: rbac.authorization.k8s.io/v1
      kind: Role
      metadata:
        namespace: default
        name: pod-reader
      rules:
        - apiGroups: [""]
          resources: ["pods"]
          verbs: ["get", "list", "watch"]
      ```
