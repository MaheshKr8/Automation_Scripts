
---

### **1. How do you find which users have sudo privileges?**
**Solution:**
```bash
sudo cat /etc/sudoers
getent group sudo
```
**Real-World Use Case:**  
Ensures only authorized users have administrative access.

---

### **2. How do you check system uptime?**
**Solution:**
```bash
uptime
```
**Real-World Use Case:**  
Helpful in identifying if the system has recently rebooted due to failures.

---

### **3. How do you check the number of open file descriptors for a process?**
**Solution:**
```bash
lsof -p PID | wc -l
```
**Real-World Use Case:**  
Prevents **Too many open files** errors caused by resource leaks.

---

### **4. How do you track which files are being written in real-time in a directory?**
**Solution:**
```bash
inotifywait -m /path/to/directory
```
**Real-World Use Case:**  
Used for **monitoring application logs, debugging, or intrusion detection**.

---

### **5. How do you list all the environment variables in Linux?**
**Solution:**
```bash
printenv
```
**Real-World Use Case:**  
Useful when troubleshooting **environment-related application issues**.

---

### **6. How do you check the default gateway of a Linux system?**
**Solution:**
```bash
ip route show | grep default
```
**Real-World Use Case:**  
Used in **network troubleshooting**.

---

### **7. How do you clear swap memory without rebooting?**
**Solution:**
```bash
sudo swapoff -a && sudo swapon -a
```
**Real-World Use Case:**  
Prevents performance degradation when **swap is overused**.

---

### **8. How do you find the number of CPUs in a Linux system?**
**Solution:**
```bash
nproc
```
or  
```bash
cat /proc/cpuinfo | grep processor | wc -l
```
**Real-World Use Case:**  
Helps in **capacity planning** and **scaling workloads**.

---

### **9. How do you see system load averages?**
**Solution:**
```bash
uptime
cat /proc/loadavg
```
**Real-World Use Case:**  
Used to identify **system performance bottlenecks**.

---

### **10. How do you check which Linux distribution is running?**
**Solution:**
```bash
cat /etc/os-release
```
or  
```bash
lsb_release -a
```
**Real-World Use Case:**  
Helpful in managing **cross-distro automation scripts**.

---

### **11. How do you block all incoming connections except SSH?**
**Solution:**
```bash
sudo ufw default deny incoming
sudo ufw allow ssh
sudo ufw enable
```
**Real-World Use Case:**  
Improves security while maintaining **remote access**.

---

### **12. How do you check disk I/O usage in real-time?**
**Solution:**
```bash
iostat -x 1
```
**Real-World Use Case:**  
Used to identify **disk bottlenecks in high-load systems**.

---

### **13. How do you find the process consuming the most memory?**
**Solution:**
```bash
ps aux --sort=-%mem | head -5
```
**Real-World Use Case:**  
Used to **detect memory leaks** in applications.

---

### **14. How do you copy a directory from one server to another using SSH?**
**Solution:**
```bash
rsync -avz -e ssh /local/dir/ user@remote:/target/dir/
```
**Real-World Use Case:**  
Used for **backup and deployments**.

---

### **15. How do you enable IP forwarding in Linux?**
**Solution:**
```bash
echo 1 > /proc/sys/net/ipv4/ip_forward
```
or permanently:
```bash
sudo sysctl -w net.ipv4.ip_forward=1
```
**Real-World Use Case:**  
Needed for **NAT, VPN, and routing configurations**.

---

### **16. How do you forcefully unmount a stuck NFS mount?**
**Solution:**
```bash
sudo umount -l /mnt/nfs
```
**Real-World Use Case:**  
Prevents **hung processes due to NFS disconnections**.

---

### **17. How do you see the inode usage of a filesystem?**
**Solution:**
```bash
df -i
```
**Real-World Use Case:**  
Prevents **"No space left on device"** errors even when disk space appears available.

---

### **18. How do you create a symbolic link in Linux?**
**Solution:**
```bash
ln -s /path/to/original /path/to/link
```
**Real-World Use Case:**  
Used for **managing configurations and versioning**.

---

### **19. How do you schedule a shutdown for a specific time?**
**Solution:**
```bash
sudo shutdown -h 02:00
```
**Real-World Use Case:**  
Used for **automated maintenance windows**.

---

### **20. How do you enable a firewall in Linux?**
**Solution:**
```bash
sudo ufw enable
```
**Real-World Use Case:**  
Mandatory for **server hardening**.

---
