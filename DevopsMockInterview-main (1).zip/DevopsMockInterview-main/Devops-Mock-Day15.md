
---

### 1. What is a StatefulSet, and when would you use it?
StatefulSet is a Kubernetes workload API object used to manage stateful applications. It provides guarantees about the ordering and uniqueness of Pods. StatefulSets are used for applications that require stable network identities and persistent storage.

**Use Cases:**
- Databases like MySQL, MongoDB.
- Distributed systems like Kafka, Zookeeper.
- Applications needing stable identities and storage.

**Manifest File:**
```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: example-statefulset
spec:
  serviceName: "example"
  replicas: 3
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: k8s.gcr.io/nginx-slim:0.8
        ports:
        - containerPort: 80
          name: web
        volumeMounts:
        - name: www
          mountPath: /usr/share/nginx/html
  volumeClaimTemplates:
  - metadata:
      name: www
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 1Gi
```

### 2. Explain the concept of Persistent Volumes (PV) and Persistent Volume Claims (PVC).
Persistent Volumes (PV) are storage resources in a Kubernetes cluster. Persistent Volume Claims (PVC) are requests for those resources. PVs and PVCs provide a way to abstract storage and decouple the lifecycle of persistent data from Pods.

**Manifest File:**
```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-example
spec:
  capacity:
    storage: 1Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/mnt/data"

---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc-example
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
```

### 3. How does the Kubernetes scheduler work?
The Kubernetes scheduler watches for newly created Pods with no assigned node and selects a suitable node for them to run on based on resource requirements, constraints, and policies.

**Key Steps:**
1. Filtering: Nodes that do not meet the Pod’s requirements are filtered out.
2. Scoring: Remaining nodes are scored to find the most suitable one.
3. Binding: The Pod is bound to the chosen node.

### 4. What is a DaemonSet, and how is it used?
A DaemonSet ensures that a copy of a Pod runs on all or some of the nodes in a cluster. It is typically used for deploying system-level applications like log collection, monitoring, or networking services.

**Manifest File:**
```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: daemonset-example
spec:
  selector:
    matchLabels:
      name: fluentd
  template:
    metadata:
      labels:
        name: fluentd
    spec:
      containers:
      - name: fluentd
        image: fluentd:latest
        resources:
          limits:
            memory: 200Mi
            cpu: 100m
```

### 5. Describe the purpose and use of a Kubernetes Ingress.
Ingress is an API object that manages external access to services in a cluster, typically HTTP/HTTPS. It provides load balancing, SSL termination, and name-based virtual hosting.

**Manifest File:**
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ingress-example
spec:
  rules:
  - host: example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: example-service
            port:
              number: 80
```

### 6. How do you monitor a Kubernetes cluster?
Monitoring a Kubernetes cluster involves tracking the health and performance of nodes, Pods, and the Kubernetes control plane. Common tools include:
- Prometheus and Grafana for metrics.
- ELK stack (Elasticsearch, Logstash, Kibana) for logging.
- Kubernetes Dashboard for a web-based UI.

### 7. What is Helm, and how does it simplify Kubernetes management?
Helm is a package manager for Kubernetes that simplifies deployment and management of applications. It uses "charts," which are packages of pre-configured Kubernetes resources.

**Helm Commands:**
- `helm install <release_name> <chart_name>`
- `helm upgrade <release_name> <chart_name>`
- `helm rollback <release_name> <revision>`

### 8. Explain the use of Kubernetes ConfigMaps and Secrets.
ConfigMaps and Secrets are used to manage configuration data. ConfigMaps store non-sensitive data, while Secrets store sensitive information like passwords.

**ConfigMap Manifest File:**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: configmap-example
data:
  config-key: config-value
```

**Secret Manifest File:**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: secret-example
type: Opaque
data:
  secret-key: c2VjcmV0LXZhbHVlCg==
```

### 9. What are Kubernetes Operators, and how do they work?
Operators extend Kubernetes capabilities by managing applications and resources using custom resources and controllers. They automate operational tasks like deployments, backups, and updates.

### 10. How do you handle logging in a Kubernetes environment?
Logging in Kubernetes involves collecting logs from applications and system components. Common approaches include:
- Using a DaemonSet to run log collectors like Fluentd or Logstash on each node.
- Centralizing logs in a system like ELK stack or Loki.

### 11. What is the purpose of taints and tolerations in Kubernetes?
Taints and tolerations work together to control which Pods can be scheduled on which nodes. Taints prevent Pods from being scheduled on certain nodes unless the Pod has a matching toleration.

**Taint Command:**
```sh
kubectl taint nodes node1 key=value:NoSchedule
```

**Toleration Example:**
```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pod-example
spec:
  tolerations:
  - key: "key"
    operator: "Equal"
    value: "value"
    effect: "NoSchedule"
```

### 12. How do you secure a Kubernetes cluster?
Securing a Kubernetes cluster involves several practices:
- Using RBAC (Role-Based Access Control) to restrict access.
- Encrypting sensitive data using Secrets.
- Ensuring secure communication with TLS.
- Regularly updating Kubernetes and its components.
- Network policies to control traffic flow.

### 13. What is a Kubernetes Job, and how does it differ from a Deployment?
A Kubernetes Job creates one or more Pods and ensures that a specified number of them successfully terminate. It is used for batch processing tasks. In contrast, a Deployment manages Pods to ensure a specified number of them are always running.

**Job Manifest File:**
```yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: job-example
spec:
  template:
    spec:
      containers:
      - name: pi
        image: perl
        command: ["perl",  "-Mbignum=bpi", "-wle", "print bpi(2000)"]
      restartPolicy: Never
  backoffLimit: 4
```

### 14. Explain the concept of Kubernetes Network Policies.
Network Policies control the network traffic flow to and from Pods. They define rules for allowing or denying traffic based on namespaces, labels, and ports.

**Network Policy Manifest File:**
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: networkpolicy-example
spec:
  podSelector:
    matchLabels:
      role: db
  policyTypes:
  - Ingress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          role: frontend
    ports:
    - protocol: TCP
      port: 3306
```

### 15. How do you troubleshoot a failing Pod in Kubernetes?
Troubleshooting a failing Pod involves:
- Checking Pod status with `kubectl get pods`.
- Viewing logs with `kubectl logs <pod-name>`.
- Describing the Pod with `kubectl describe pod <pod-name>`.
- Inspecting events with `kubectl get events`.
- Checking the node status and resources.

---
