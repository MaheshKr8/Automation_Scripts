### **15 Scenario-Based Docker Interview Questions and Answers**

Here are additional scenario-based Docker interview questions with explanations to test real-world problem-solving skills.

---

### **1. How do you update a running container without downtime?**

#### **Scenario**:
Your web application is running in a container, and you need to deploy a new version without interrupting service.

#### **Approach**:
- Use Docker Compose or Docker Swarm with rolling updates.
- Example:
  ```bash
  docker service update --image my-app:v2 my-service
  ```

---

### **2. How do you handle an image build that consistently fails due to dependency conflicts?**

#### **Scenario**:
A Docker image fails during the build stage because of version mismatches in dependencies.

#### **Approach**:
1. Pin dependency versions in your `Dockerfile` or application files.
2. Example:
   ```dockerfile
   RUN pip install requests==2.26.0
   ```
3. Use `--no-cache` to force a fresh dependency resolution:
   ```bash
   docker build --no-cache -t my-app .
   ```

---

### **3. What would you do if you suspect a container has been compromised?**

#### **Scenario**:
Your monitoring system alerts you to suspicious activity in a container.

#### **Approach**:
1. Stop the container immediately:
   ```bash
   docker stop <container_id>
   ```
2. Inspect the container logs and filesystem:
   ```bash
   docker logs <container_id>
   docker exec -it <container_id> /bin/bash
   ```
3. Scan the image for vulnerabilities using tools like `Trivy`.

---

### **4. How do you handle port conflicts when running multiple containers?**

#### **Scenario**:
Two containers need to expose the same port on the host machine.

#### **Approach**:
1. Map the container ports to different host ports:
   ```bash
   docker run -p 8080:80 nginx
   docker run -p 8081:80 apache
   ```
2. Use an orchestrator like Kubernetes to handle port conflicts automatically.

---

### **5. How do you debug a container that refuses to stop?**

#### **Scenario**:
Running `docker stop` fails to stop a container.

#### **Approach**:
1. Use `docker kill`:
   ```bash
   docker kill <container_id>
   ```
2. Check for processes using the container's resources:
   ```bash
   lsof -i
   ```
3. Investigate logs for stuck processes.

---

### **6. How do you handle Docker images growing too large?**

#### **Scenario**:
Your CI pipeline fails due to large Docker image sizes.

#### **Approach**:
1. Use multi-stage builds:
   ```dockerfile
   FROM golang:alpine AS builder
   WORKDIR /app
   COPY . .
   RUN go build -o app

   FROM alpine
   WORKDIR /app
   COPY --from=builder /app/app .
   CMD ["./app"]
   ```
2. Remove unnecessary files and cache in `Dockerfile`.

---

### **7. What would you do if you suspect a memory leak in a containerized application?**

#### **Scenario**:
A container consistently consumes more memory over time.

#### **Approach**:
1. Monitor resource usage:
   ```bash
   docker stats <container_id>
   ```
2. Limit memory usage:
   ```bash
   docker run --memory="500m" <image_name>
   ```
3. Use profiling tools like `top` or `ps` inside the container to identify the issue.

---

### **8. How do you resolve a failed `docker pull` due to "rate limit exceeded"?**

#### **Scenario**:
Your pipeline fails because Docker Hub rate limits pulls for anonymous users.

#### **Approach**:
1. Authenticate to Docker Hub:
   ```bash
   docker login
   ```
2. Use a private registry to cache frequently used images.

---

### **9. How do you manage container logs that grow indefinitely?**

#### **Scenario**:
A high-traffic application generates logs that consume disk space.

#### **Approach**:
1. Enable log rotation:
   ```json
   {
     "log-driver": "json-file",
     "log-opts": {
       "max-size": "10m",
       "max-file": "3"
     }
   }
   ```
2. Redirect logs to an external system like ELK or Fluentd.

---

### **10. How do you debug a container that has network issues?**

#### **Scenario**:
A container cannot connect to an external API.

#### **Approach**:
1. Inspect the container network:
   ```bash
   docker network inspect <network_name>
   ```
2. Check DNS settings inside the container:
   ```bash
   docker exec -it <container_id> cat /etc/resolv.conf
   ```
3. Attach the container to the correct network:
   ```bash
   docker network connect <network_name> <container_id>
   ```

---

### **11. How do you migrate a legacy application to Docker?**

#### **Scenario**:
You need to containerize an old monolithic application.

#### **Approach**:
1. Create a `Dockerfile` with the necessary dependencies.
2. Refactor configurations to use environment variables.
3. Test the application in a staging environment before production deployment.

---

### **12. How do you handle a dangling volume consuming disk space?**

#### **Scenario**:
Volumes created by containers that no longer exist are taking up disk space.

#### **Approach**:
1. List dangling volumes:
   ```bash
   docker volume ls -f dangling=true
   ```
2. Remove them:
   ```bash
   docker volume prune
   ```

---

### **13. How do you configure a multi-container application for local development?**

#### **Scenario**:
You need to run a web application with a database locally.

#### **Approach**:
1. Use Docker Compose:
   ```yaml
   version: "3.8"
   services:
     web:
       image: nginx
       ports:
         - "8080:80"
     db:
       image: postgres
       environment:
         POSTGRES_PASSWORD: password
   ```
2. Start the services:
   ```bash
   docker-compose up
   ```

---

### **14. How do you monitor the health of running containers?**

#### **Scenario**:
You want to check whether your application is running as expected.

#### **Approach**:
1. Add a health check to the `Dockerfile`:
   ```dockerfile
   HEALTHCHECK CMD curl -f http://localhost:8080/ || exit 1
   ```
2. Inspect the health status:
   ```bash
   docker inspect <container_id>
   ```

---

### **15. How do you debug high disk usage by Docker?**

#### **Scenario**:
The host machine is running out of disk space due to Docker artifacts.

#### **Approach**:
1. Identify the culprit:
   ```bash
   docker system df
   ```
2. Clean up unused resources:
   ```bash
   docker system prune -a
   ```
3. Verify large images or logs:
   ```bash
   docker image ls
   ```

---
