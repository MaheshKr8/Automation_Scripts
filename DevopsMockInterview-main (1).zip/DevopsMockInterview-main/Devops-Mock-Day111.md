
---
### ✅ **1. How do you manage version control and branching in a DevOps pipeline?**

**Answer:**  
Use Git (GitHub/GitLab/Bitbucket). Follow **GitFlow** or **trunk-based** branching.  
Typical branches:
- `main/master`: production
- `develop`: staging/testing
- `feature/*`, `hotfix/*`: for respective tasks  
Integrate CI to auto-build/test PRs before merging.

---

### ✅ **2. A Jenkins pipeline failed in the middle. What’s your debugging approach?**

**Answer:**  
- Check console output of the failed stage.  
- Inspect environment variables or credentials.  
- Look for recent changes in the `Jenkinsfile`.  
- Run the failing commands manually in the agent for deeper debug.

---

### ✅ **3. Your Terraform `apply` command fails due to state lock. What do you do?**

**Answer:**  
- Check if another user or CI job is running `terraform apply`.  
- For S3 backend, remove the lock via DynamoDB.  
- Last resort: manually delete lock if you're sure it’s orphaned.

---

### ✅ **4. How do you ensure secure secret management in DevOps?**

**Answer:**  
- Use **AWS Secrets Manager**, **Vault**, or **Kubernetes Secrets**.  
- Avoid hardcoding secrets in code or CI config.  
- Use env variables or secret injection during runtime.  
- Rotate secrets periodically.

---

### ✅ **5. How do you manage infrastructure across multiple environments (dev/stage/prod)?**

**Answer:**  
- Use **Terraform workspaces**, separate state files, or environment folders.  
- Externalize variables using `*.tfvars` files or CI/CD inputs.  
- Tag resources appropriately for identification.

---

### ✅ **6. Application is working locally but fails in Docker. How do you troubleshoot?**

**Answer:**  
- Check base image compatibility.  
- Validate ports, volumes, and environment variables.  
- Use `docker logs`, `docker inspect` for details.  
- Test with interactive shell: `docker run -it <image> /bin/sh`.

---

### ✅ **7. How do you implement blue-green or canary deployment?**

**Answer:**  
- **Blue-Green**: Deploy new version to a separate environment and switch traffic using load balancer.  
- **Canary**: Release to a small percentage of users first using service mesh (e.g., Istio) or weighted routing.

---

### ✅ **8. One of your Kubernetes pods is in `CrashLoopBackOff`. How do you fix it?**

**Answer:**  
- Run `kubectl logs <pod>` and `kubectl describe pod`.  
- Check readiness/liveness probes.  
- Validate startup command, image, and mounted secrets/config.

---

### ✅ **9. A new pipeline stage is taking too long. What do you do?**

**Answer:**  
- Analyze the logs — identify slow scripts.  
- Use Docker caching or parallel stages.  
- Offload heavy jobs (e.g., security scans) to nightly pipelines.

---

### ✅ **10. How do you manage rollbacks in a CI/CD pipeline?**

**Answer:**  
- Maintain previous build artifacts.  
- For Kubernetes, use `kubectl rollout undo`.  
- In Jenkins, use "Build with Parameters" for selecting a rollback version.

---

### ✅ **11. You see high CPU usage in your Kubernetes cluster. Next steps?**

**Answer:**  
- Use `kubectl top pod` or Prometheus/Grafana.  
- Check for memory leaks or infinite loops in app.  
- Set resource limits and requests.

---

### ✅ **12. How do you scan container images for vulnerabilities?**

**Answer:**  
- Use tools like **Trivy**, **Grype**, **Aqua**, or **Anchore**.  
- Integrate into CI: scan images before pushing.  
- Fail builds on critical vulnerabilities.

---

### ✅ **13. How do you implement monitoring and alerting?**

**Answer:**  
- Use **Prometheus** for metrics, **Grafana** for visualization.  
- Define alert rules (e.g., pod down, CPU > 90%).  
- Send alerts to Slack, PagerDuty, or email.

---

### ✅ **14. How do you deploy infrastructure using Terraform with CI/CD?**

**Answer:**  
- Create pipeline stages: `terraform init`, `plan`, `apply`.  
- Use remote backend (S3 + DynamoDB).  
- Review plan as a PR comment before apply.

---

### ✅ **15. What’s your process for handling downtime during deployments?**

**Answer:**  
- Use rolling updates in K8s.  
- Pre-deployment checks: health, CPU, memory.  
- Post-deployment monitoring.  
- Implement rollback plan.

---

### ✅ **16. How do you implement security best practices in DevOps?**

**Answer:**  
- Use **IAM roles**, **least privilege**, **multi-factor auth**.  
- Perform **static analysis (SAST)** and **dynamic analysis (DAST)**.  
- Scan infra with **TFSEC**, **Checkov**.  
- Regularly patch OS and dependencies.

---

### ✅ **17. You see inconsistent state in your Terraform-managed infra. What do you do?**

**Answer:**  
- Run `terraform plan` to compare state vs real infra.  
- Use `terraform refresh` or `import` if resources are out-of-band.  
- Avoid manual infra changes; always use IaC.

---

### ✅ **18. How do you integrate code quality tools in CI?**

**Answer:**  
- Use **SonarQube**, **ESLint**, **Pylint**, etc.  
- Add quality gate check in pipeline.  
- Fail builds if code coverage or issues exceed threshold.

---

### ✅ **19. How do you manage log aggregation?**

**Answer:**  
- Use **ELK Stack (Elasticsearch + Logstash + Kibana)** or **EFK**.  
- Forward logs using Fluentd/FluentBit.  
- Tag logs by environment, pod, app for filtering.

---

### ✅ **20. What steps do you take to onboard a new project into your CI/CD pipeline?**

**Answer:**  
- Review app structure and dependencies.  
- Create Dockerfile and Helm charts if needed.  
- Setup Git repo, pipeline config (`Jenkinsfile`, `.gitlab-ci.yml`).  
- Connect secrets, triggers, and quality checks.

---

