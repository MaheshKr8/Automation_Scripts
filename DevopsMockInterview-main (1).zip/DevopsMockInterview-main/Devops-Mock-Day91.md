### **Top 10 Real-Time Kubernetes Interview Questions with Answers**  

---

### **1. How does Kubernetes handle container scaling in real time?**
✅ **Answer:**  
Kubernetes provides **Horizontal Pod Autoscaler (HPA)** and **Vertical Pod Autoscaler (VPA)** for real-time scaling.  
- **HPA** scales pods **horizontally** based on CPU, memory, or custom metrics.
- **VPA** adjusts the resource requests/limits of a running pod.
- **Cluster Autoscaler** scales the number of nodes when needed.

🔹 **Example: HPA scaling based on CPU usage**
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: my-app-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: my-app
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 60
```

✅ **Scenario:** If CPU usage exceeds 60%, Kubernetes automatically adds more pods.

---

### **2. How do you expose a Kubernetes application to the outside world?**
✅ **Answer:**  
Kubernetes provides **three** ways to expose applications:
1. **NodePort** (Exposes service on a fixed port across all nodes)
2. **LoadBalancer** (Used in cloud environments like AWS, GCP, Azure)
3. **Ingress Controller** (Manages external access with domain-based routing)

🔹 **Example: Exposing a service via NodePort**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-app-service
spec:
  type: NodePort
  selector:
    app: my-app
  ports:
    - protocol: TCP
      port: 80
      targetPort: 8080
      nodePort: 30007
```

✅ **Scenario:** A user accesses `http://<NodeIP>:30007` to reach the application.

---

### **3. How does Kubernetes handle service discovery and load balancing?**
✅ **Answer:**  
Kubernetes uses **CoreDNS** for service discovery and **kube-proxy** for load balancing.  
- **Service Discovery**: Every service gets a **ClusterIP** and a DNS name (`my-service.default.svc.cluster.local`).  
- **Load Balancing**: Kubernetes distributes requests among available pods.

🔹 **Example: Internal service communication**
```bash
curl http://my-service.default.svc.cluster.local:8080
```

✅ **Scenario:** Microservices inside the cluster can communicate using service names instead of IPs.

---

### **4. How do you implement security best practices in Kubernetes?**
✅ **Answer:**  
- Use **RBAC (Role-Based Access Control)** to limit permissions.
- Use **Network Policies** to restrict traffic between pods.
- Enable **Pod Security Policies** to enforce security constraints.
- Use **Secrets & ConfigMaps** to store sensitive data.

🔹 **Example: RBAC for limiting user access**
```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: default
  name: pod-reader
rules:
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["get", "list"]
```

✅ **Scenario:** A user with this role can only list and read pods but cannot modify them.

---

### **5. How do you debug a failing pod in Kubernetes?**
✅ **Answer:**  
Use the following commands to troubleshoot:
```bash
kubectl get pods --namespace=my-namespace
kubectl describe pod <pod-name>   # View pod events
kubectl logs <pod-name>           # View logs
kubectl exec -it <pod-name> -- /bin/sh  # Access container shell
kubectl get events                # Check cluster events
```

✅ **Scenario:** If a pod is stuck in a `CrashLoopBackOff` state, use `kubectl describe` to check for resource constraints, missing dependencies, or application errors.

---

### **6. What is a Kubernetes ConfigMap and how is it used?**
✅ **Answer:**  
A **ConfigMap** is used to store configuration data separately from application code.

🔹 **Example: Creating a ConfigMap**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  DATABASE_URL: "postgres://user:password@db:5432/mydb"
```

🔹 **Mounting ConfigMap as environment variables**
```yaml
env:
  - name: DATABASE_URL
    valueFrom:
      configMapKeyRef:
        name: app-config
        key: DATABASE_URL
```

✅ **Scenario:** You can change application configuration **without redeploying** the pod.

---

### **7. How do you set up monitoring for Kubernetes?**
✅ **Answer:**  
Monitoring can be set up using **Prometheus and Grafana**.

🔹 **Steps:**
1. Deploy **Prometheus Operator** to scrape metrics.
2. Deploy **Grafana** for visualization.
3. Expose Prometheus metrics in applications.

🔹 **Example: Simple Prometheus deployment**
```yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: app-monitor
spec:
  selector:
    matchLabels:
      app: my-app
  endpoints:
    - port: http
      path: /metrics
```

✅ **Scenario:** You can track CPU, memory, and network usage in **Grafana dashboards**.

---

### **8. How do you perform a rolling update in Kubernetes?**
✅ **Answer:**  
A **rolling update** gradually replaces old pods with new ones without downtime.

🔹 **Command:**
```bash
kubectl set image deployment/my-app my-app=nginx:latest
```

🔹 **Example: Deployment with rolling updates**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 1
      maxSurge: 1
  template:
    spec:
      containers:
        - name: my-app
          image: my-app:v2
```

✅ **Scenario:** Ensures **zero-downtime deployment** by updating one pod at a time.

---

### **9. How do you enable persistent storage in Kubernetes?**
✅ **Answer:**  
Kubernetes uses **PersistentVolumes (PV)** and **PersistentVolumeClaims (PVC)** to retain data.

🔹 **Example: Define a Persistent Volume**
```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: my-pv
spec:
  capacity:
    storage: 10Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/mnt/data"
```

🔹 **Example: Claim the volume using PVC**
```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: my-pvc
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
```

✅ **Scenario:** Database containers can store persistent data that survives pod restarts.

---

### **10. How do you troubleshoot Kubernetes networking issues?**
✅ **Answer:**  
Use the following steps:
1. Check service and pod connectivity using `kubectl get svc` and `kubectl get pods -o wide`.
2. Test DNS resolution inside a pod:
   ```bash
   kubectl exec -it <pod> -- nslookup my-service
   ```
3. Verify network policies using:
   ```bash
   kubectl get networkpolicy
   ```
4. Debug kube-proxy:
   ```bash
   kubectl logs -n kube-system kube-proxy
   ```

✅ **Scenario:** If a pod cannot reach another pod, check **Network Policies** and **Service Endpoints**.

---

## **Conclusion**
These **10 real-time Kubernetes interview questions** cover **scalability, networking, security, troubleshooting, and monitoring**—all critical areas for DevOps engineers.
