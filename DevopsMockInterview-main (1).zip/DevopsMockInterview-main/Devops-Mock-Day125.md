
---

## ✅ **1. How do you troubleshoot a failing Jenkins build?**

**Answer:**

* Check **console output** for errors.
* Validate build tools (e.g., Maven/Gradle).
* Ensure correct Git branch or credentials.
* Check workspace or permission issues.
* Use `echo`, `set -x`, and `sh` for debugging.

---

## ✅ **2. How do you resolve a stuck Kubernetes pod in `CrashLoopBackOff`?**

**Answer:**

* Check logs: `kubectl logs <pod-name>`
* Describe pod: `kubectl describe pod <pod-name>`
* Common issues:

  * Misconfigured env vars or secrets
  * App crashing on startup
  * Liveness/readiness probes misconfigured

---

## ✅ **3. How do you handle secrets in CI/CD pipelines?**

**Answer:**

* Use tools like:

  * Jenkins credentials plugin
  * GitHub Actions secrets
  * AWS Secrets Manager
  * Vault by HashiCorp
* Avoid hardcoding secrets in scripts or code.

---

## ✅ **4. How do you perform a zero-downtime deployment in Kubernetes?**

**Answer:**

* Use `RollingUpdate` strategy in Deployment:

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1
    maxUnavailable: 0
```

---

## ✅ **5. What happens if your Terraform apply fails midway?**

**Answer:**

* Terraform saves the state and will resume/roll back based on next plan.
* Fix the issue and re-run `terraform apply`.

---

## ✅ **6. How do you automate Docker image vulnerability scans?**

**Answer:**

* Use tools like **Trivy**, **Grype**, or integrate in CI:

```bash
trivy image myapp:latest
```

* Fail the build if vulnerabilities are found.

---

## ✅ **7. How do you roll back a Helm release?**

**Answer:**

```bash
helm history my-release
helm rollback my-release <revision-number>
```

---

## ✅ **8. How do you reduce build time in Jenkins pipelines?**

**Answer:**

* Use **Docker caching**.
* Parallelize stages.
* Use `when` conditions.
* Archive/reuse artifacts.

---

## ✅ **9. How do you troubleshoot a failed `terraform plan` or `apply`?**

**Answer:**

* Check for:

  * Syntax errors
  * Missing variables
  * Misconfigured backends
* Run with:

```bash
terraform plan -var-file="dev.tfvars"
```

---

## ✅ **10. How do you monitor CPU/Memory usage in a Kubernetes cluster?**

**Answer:**

* Use `kubectl top pods/nodes`
* Install Prometheus + Grafana
* Set up HPA for auto-scaling

---

## ✅ **11. What steps do you follow to secure a Docker image?**

**Answer:**

* Use minimal base images (e.g., `alpine`)
* Avoid root user
* Scan images with Trivy
* Keep images updated

---

## ✅ **12. How do you troubleshoot Git merge conflicts in a Jenkins pipeline?**

**Answer:**

* Enable verbose Git output in Jenkins.
* Use `git pull --rebase` instead of merge.
* Manually resolve on a feature branch if required.

---

## ✅ **13. How do you enable auto-scaling in Kubernetes?**

**Answer:**

* Use **Horizontal Pod Autoscaler** (HPA):

```bash
kubectl autoscale deployment myapp --cpu-percent=70 --min=2 --max=5
```

---

## ✅ **14. How do you create immutable infrastructure with Terraform?**

**Answer:**

* Avoid in-place updates.
* Use `create_before_destroy`.
* Design infrastructure as code modules.

---

## ✅ **15. How do you configure blue-green deployment in Kubernetes?**

**Answer:**

* Create 2 deployments (`v1` and `v2`)
* Use Ingress to switch traffic
* Can use Argo Rollouts for automation

---

## ✅ **16. How do you configure alerts for failed deployments?**

**Answer:**

* Integrate **Prometheus + Alertmanager** or cloud monitoring (e.g., AWS CloudWatch).
* Trigger Slack/email/webhook alerts.

---

## ✅ **17. How do you troubleshoot a Docker container that exits immediately?**

**Answer:**

* Check logs: `docker logs <container>`
* Run interactively: `docker run -it --entrypoint /bin/sh <image>`
* Check CMD/ENTRYPOINT in Dockerfile.

---

## ✅ **18. How do you implement CI/CD for a microservices architecture?**

**Answer:**

* Use Git triggers → Jenkins/GitHub Actions pipelines.
* Separate pipeline per service.
* Use Helm for deployment.
* Version control each microservice image/tag.

---

## ✅ **19. How do you perform log aggregation in a Kubernetes cluster?**

**Answer:**

* Use ELK stack (Elasticsearch, Logstash, Kibana) or EFK (Fluentd).
* Fluent Bit or Loki + Grafana for lighter setups.

---

## ✅ **20. How do you handle infrastructure drift in Terraform-managed environments?**

**Answer:**

* Use `terraform plan` frequently.
* Automate drift detection via CI/CD.
* Lock state files (e.g., in S3 with DynamoDB for AWS).

---

