
---

### ✅ **1. How do you design a highly available application infrastructure on AWS?**

**Answer:**  
- Deploy across **multiple AZs**.  
- Use **Auto Scaling Groups** for EC2.  
- Place database (RDS/Aurora) in Multi-AZ mode.  
- Use **Elastic Load Balancer (ELB)**.  
- Use Route53 with health checks and failover routing.

---

### ✅ **2. What’s the difference between a rolling update and recreate strategy in Kubernetes?**

**Answer:**  
- **RollingUpdate**: Gradually replace old pods with new ones; no downtime.  
- **Recreate**: Kill all old pods first, then create new ones; downtime likely.

---

### ✅ **3. How do you ensure a Docker image is small and production-ready?**

**Answer:**  
- Use a **minimal base image** (e.g., `alpine`).  
- Use **multi-stage builds** to separate build and runtime.  
- Remove unnecessary files (`rm -rf /tmp/*`).  
- Pin versions of dependencies.

---

### ✅ **4. Jenkins master is overloaded. How will you scale Jenkins architecture?**

**Answer:**  
- Set up **Jenkins agents** (static or dynamic using Kubernetes, EC2, etc.).  
- Use a **controller-agent model**.  
- Offload heavy build tasks to workers.

---

### ✅ **5. How do you manage database schema changes in DevOps pipelines?**

**Answer:**  
- Use **migration tools** like Liquibase, Flyway.  
- Apply migrations as part of the CI/CD release process.  
- Backup database before applying changes.

---

### ✅ **6. How do you handle configuration drift in servers?**

**Answer:**  
- Use **Configuration Management tools** like Ansible, Puppet, Chef.  
- Regularly run compliance checks.  
- Detect drifts using AWS Config or custom scripts.

---

### ✅ **7. How do you perform blue-green deployment with Terraform-managed infra?**

**Answer:**  
- Create two separate environments (blue and green).  
- Update DNS or Load Balancer to point to the new environment after validation.  
- Rollback simply by switching back.

---

### ✅ **8. How can you optimize a Kubernetes cluster cost in production?**

**Answer:**  
- Use **Cluster Autoscaler** to scale nodes dynamically.  
- Set proper **resource requests/limits**.  
- Use **spot instances** or **Graviton** instances where possible.  
- Use **vertical/horizontal pod autoscalers**.

---

### ✅ **9. Explain how GitOps helps in a DevOps workflow?**

**Answer:**  
- Infrastructure and application deployments are managed declaratively through Git.  
- Git is the **single source of truth**.  
- Tools like **ArgoCD** or **FluxCD** sync Git state with cluster automatically.

---

### ✅ **10. What happens during `terraform plan` vs `terraform apply`?**

**Answer:**  
- **terraform plan**: Shows what changes will happen; no change occurs.  
- **terraform apply**: Actually **executes the changes** on cloud providers.

---

### ✅ **11. If a deployment fails in ArgoCD, how do you recover?**

**Answer:**  
- Check error details in the ArgoCD app view.  
- Use `argocd app rollback` to a previous working version.  
- Fix YAML/git repo issues if needed and sync again.

---

### ✅ **12. How do you ensure S3 bucket policies are secure?**

**Answer:**  
- Block public access unless explicitly needed.  
- Use **bucket policies** with least-privilege permissions.  
- Enable **server-side encryption** (SSE).  
- Enable **access logging**.

---

### ✅ **13. How do you build an immutable infrastructure?**

**Answer:**  
- Deploy new servers/images instead of patching running ones.  
- Use tools like **Packer** to build machine images.  
- Destroy and recreate infra with every release.

---

### ✅ **14. What is a service mesh and why would you use one?**

**Answer:**  
- Service mesh (like **Istio**, **Linkerd**) manages **service-to-service communication**.  
- Provides traffic routing, retries, mTLS encryption, observability without app code changes.

---

### ✅ **15. How do you implement dynamic scaling for a microservices app?**

**Answer:**  
- Use **Horizontal Pod Autoscaler (HPA)** in Kubernetes based on CPU/memory or custom metrics.  
- Use cloud provider **Auto Scaling Groups (ASG)** for underlying VMs.  
- Enable **Event-driven autoscaling (KEDA)** for queue-based or request-based scaling.

---
