
---

## **1. How do you migrate an on-prem Kubernetes cluster to AWS EKS with zero downtime?**

**Solution:**

* **Preparation:**

  * Audit workloads, PVCs, secrets, ingress rules.
  * Sync manifests to Git repo for GitOps deployment.
* **Data migration:**

  * Use Velero for backup/restore of resources and PV snapshots.
  * Sync databases using replication (e.g., MySQL binlog, MongoDB replica set).
* **Traffic switch:**

  * Run workloads in both clusters temporarily.
  * Shift traffic gradually via DNS weight (Route 53).

---

## **2. During high load, your Kubernetes API server becomes unresponsive. How do you fix it?**

**Solution:**

* Check control plane resource usage (CPU, memory).
* Increase API server instance size in EKS or kubeadm setup.
* Reduce kubelet/node heartbeats (lower API load).
* Use aggregated API servers for CRDs.
* Scale etcd horizontally or vertically.

---

## **3. Your AWS EKS cluster's pods can’t pull images from a private ECR in another account. What’s the fix?**

**Solution:**

* Create an **ECR cross-account policy**.
* Attach IAM role to node group or pod (IRSA).
* Example policy:

  ```json
  {
    "Effect": "Allow",
    "Action": ["ecr:GetAuthorizationToken", "ecr:BatchCheckLayerAvailability", "ecr:GetDownloadUrlForLayer"],
    "Resource": "*"
  }
  ```
* Test with `aws ecr get-login-password`.

---

## **4. How do you recover a Kubernetes cluster after an etcd corruption?**

**Solution:**

* Restore from last known etcd snapshot:

  ```bash
  ETCDCTL_API=3 etcdctl snapshot restore snapshot.db --data-dir=/var/lib/etcd
  ```
* Bring API server back up and verify resources.
* Reapply missing manifests from GitOps repo.

---

## **5. Your EKS cluster pods in a private subnet can’t reach the internet. How do you fix it?**

**Solution:**

* Ensure NAT Gateway in public subnet.
* Route private subnet's route table to NAT Gateway.
* Verify security group and NACL rules.

---

## **6. How do you perform a Kubernetes version upgrade with zero downtime in production?**

**Solution:**

* Upgrade control plane first (managed in EKS).
* Upgrade node groups gradually:

  * Create new node group with new version.
  * Use pod disruption budgets (PDB) to avoid mass eviction.
  * Drain old nodes one by one.

---

## **7. Your Kubernetes deployment rollback fails because the old image is not in the registry. How do you handle it?**

**Solution:**

* Always tag images with both `version` and `latest`.
* Keep an **image retention policy** in ECR.
* If missing, rebuild old commit from Git and push image manually.

---

## **8. In AWS, you need a Disaster Recovery setup between regions for EKS workloads. How do you design it?**

**Solution:**

* **Active-Passive:**

  * Main EKS in Region A, standby EKS in Region B.
  * Replicate data using S3 Cross-Region Replication, RDS read replicas.
  * Store manifests in Git; sync to both clusters via ArgoCD.
* Failover: Switch Route 53 DNS to Region B.

---

## **9. How do you debug intermittent pod-to-pod communication failures in Kubernetes?**

**Solution:**

* Check CNI plugin logs (Calico, Cilium).
* Verify MTU settings for overlay networks.
* Use `kubectl exec` with ping/curl to test pod DNS and IP reachability.
* Check for NetworkPolicies blocking traffic.

---

## **10. You have to restore a Kubernetes cluster from an S3 backup in AWS after total cluster deletion. How do you do it?**

**Solution:**

* Provision new EKS cluster.
* Restore manifests from GitOps repo.
* Restore PVs:

  * If EBS volumes exist, reattach to new cluster.
  * If deleted, restore from EBS snapshots or Velero backup in S3.

---

