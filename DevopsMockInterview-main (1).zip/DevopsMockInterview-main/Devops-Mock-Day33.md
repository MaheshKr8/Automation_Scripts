### 1. **What is the purpose of the `input` step in Jenkins Pipeline?**
**Answer:**
The `input` step in a Jenkins pipeline allows you to pause the pipeline and wait for manual approval or user input before proceeding to the next stage.

**Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Build') {
            steps {
                echo 'Building...'
            }
        }
        stage('Approval') {
            steps {
                input 'Deploy to production?'
            }
        }
        stage('Deploy') {
            steps {
                echo 'Deploying...'
            }
        }
    }
}
```

### 2. **What is a Jenkins node label, and how is it used?**
**Answer:**
A Jenkins node label is a tag applied to agents (nodes) that categorize them based on their capabilities (e.g., OS, hardware, or installed software). Labels are used to direct specific jobs to specific nodes.

**Usage in Pipeline:**
```groovy
pipeline {
    agent { label 'linux' }
    stages {
        stage('Test') {
            steps {
                echo 'Running on Linux'
            }
        }
    }
}
```

### 3. **How do you set up notifications in Jenkins (e.g., email, Slack)?**
**Answer:**
1. **Email Notification:**
   - Install the **Email Extension Plugin**.
   - Configure the SMTP server under **Manage Jenkins** > **Configure System**.
   - Use the `emailext` step in the pipeline to send email notifications.
   
**Example:**
```groovy
post {
    failure {
        emailext to: 'team@example.com', subject: 'Build Failed', body: 'The build has failed.'
    }
}
```

2. **Slack Notification:**
   - Install the **Slack Notification Plugin**.
   - Configure the Slack channel and credentials under **Manage Jenkins** > **Configure System**.
   - Use the `slackSend` step in your Jenkinsfile.

**Example:**
```groovy
slackSend channel: '#devops', color: 'danger', message: 'Build Failed!'
```

### 4. **How do you configure Jenkins to execute parallel tests across multiple nodes?**
**Answer:**
1. **Using Pipeline Parallelism:**
   - In the Jenkins pipeline, use the `parallel` block to run stages concurrently.
2. **Distribute across Agents:**
   - Define the `agent` block inside each parallel stage to run it on different nodes.

**Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Parallel Tests') {
            parallel {
                stage('Unit Tests') {
                    agent { label 'linux' }
                    steps {
                        echo 'Running unit tests on Linux'
                    }
                }
                stage('Integration Tests') {
                    agent { label 'windows' }
                    steps {
                        echo 'Running integration tests on Windows'
                    }
                }
            }
        }
    }
}
```

### 5. **How can you use Jenkins for building Docker images and deploying them to a registry?**
**Answer:**
1. **Install Docker Pipeline Plugin:** Install the Docker and Docker Pipeline plugins.
2. **Use Jenkinsfile to Build and Push Docker Image:**
   - Use the `docker.build` method to build the image and `docker.withRegistry` to push it to a registry (e.g., Docker Hub, AWS ECR).

**Example:**
```groovy
pipeline {
    agent {
        docker {
            image 'docker:19.03'
            args '-v /var/run/docker.sock:/var/run/docker.sock'
        }
    }
    stages {
        stage('Build Docker Image') {
            steps {
                script {
                    def app = docker.build('my-app')
                    app.push('latest')
                }
            }
        }
    }
}
```

### 6. **How do you configure a job to trigger on SCM changes (GitHub or GitLab)?**
**Answer:**
1. **Freestyle Job:**
   - Go to the **Build Triggers** section and select **Poll SCM** to check for changes periodically.
   - Alternatively, configure a webhook in GitHub/GitLab to trigger builds automatically on code pushes.
   
2. **Pipeline Job:**
   - Use the `git` step and configure SCM polling in the pipeline script.
   
**Example for Polling:**
```groovy
pipeline {
    agent any
    triggers {
        pollSCM('H/5 * * * *')
    }
    stages {
        stage('Build') {
            steps {
                git 'https://github.com/user/repo.git'
                sh 'build.sh'
            }
        }
    }
}
```

### 7. **How do you add conditional logic in a Jenkins pipeline?**
**Answer:**
You can add conditional logic in a Jenkins pipeline using the `when` directive.

**Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Build') {
            when {
                branch 'main'
            }
            steps {
                echo 'Building only on the main branch'
            }
        }
    }
}
```

### 8. **How do you use a shared library in Jenkins?**
**Answer:**
1. **Define the Library:**
   - Create a repository for the shared library, with scripts placed in the `vars/` directory.
   
2. **Configure Jenkins:**
   - Go to **Manage Jenkins** > **Configure System** > **Global Pipeline Libraries**, and add the shared library repository.
   
3. **Use the Shared Library in the Pipeline:**
   - Use the `@Library` annotation in the Jenkinsfile.

**Example:**
```groovy
@Library('my-shared-library') _
mySharedFunction()
```

### 9. **How do you generate parameterized builds in Jenkins?**
**Answer:**
Parameterized builds allow users to pass input before running a job. In **Freestyle jobs**, you can add parameters in the **This build is parameterized** section. For **Pipeline jobs**, define parameters in the Jenkinsfile.

**Example:**
```groovy
pipeline {
    agent any
    parameters {
        string(name: 'DEPLOY_ENV', defaultValue: 'dev', description: 'Environment to deploy')
    }
    stages {
        stage('Deploy') {
            steps {
                echo "Deploying to ${params.DEPLOY_ENV}"
            }
        }
    }
}
```

### 10. **How do you rollback to a previous build version in Jenkins?**
**Answer:**
1. **Manual Rollback:** Jenkins itself doesn't manage rollbacks, but you can trigger a job that deploys the previously successful build or artifact.
2. **Artifact Archive:** Use Jenkins' artifact archiving feature to store previous build versions. In case of a failure, you can redeploy the older artifact by triggering a specific build manually.
3. **Git Integration:** Use version control (like Git) to roll back code, and trigger a new build based on that revision.

