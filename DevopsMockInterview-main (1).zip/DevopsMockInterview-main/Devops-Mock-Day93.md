
---

## **🔍 10 Advanced Kubernetes Interview Questions**

### **1. How do you perform a zero-downtime deployment in Kubernetes?**  
✅ **Answer:**  
Zero-downtime deployments are managed using **Rolling Updates** in Kubernetes.  

✅ **Steps:**  
- **Use `maxUnavailable: 0`** to ensure no downtime.  
- **Use `maxSurge: 1`** to add a new pod before deleting the old one.  

✅ **Example Deployment with Rolling Update:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-app
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0
      maxSurge: 1
  template:
    metadata:
      labels:
        app: my-app
    spec:
      containers:
      - name: my-app
        image: my-app:latest
```
📌 **Ensures smooth rollouts without downtime.**  

---

### **2. How do you debug a Kubernetes pod that is failing to start?**  
✅ **Answer:**  
1. **Check pod logs:**  
   ```bash
   kubectl logs <pod-name>
   ```
2. **Describe the pod to check events and errors:**  
   ```bash
   kubectl describe pod <pod-name>
   ```
3. **Check for resource allocation issues:**  
   ```bash
   kubectl get nodes -o wide
   ```

---

### **3. How does Kubernetes handle stateful applications?**  
✅ **Answer:**  
Kubernetes manages stateful applications using **StatefulSets** and **Persistent Volumes (PVs)**.  

✅ **Example StatefulSet with Persistent Storage:**
```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: my-database
spec:
  serviceName: "my-database"
  replicas: 2
  selector:
    matchLabels:
      app: my-database
  template:
    metadata:
      labels:
        app: my-database
    spec:
      containers:
      - name: my-db-container
        image: postgres:latest
        volumeMounts:
        - name: db-storage
          mountPath: /var/lib/postgresql/data
  volumeClaimTemplates:
  - metadata:
      name: db-storage
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 10Gi
```
📌 **Ensures each pod gets persistent storage across restarts.**  

---

### **4. How do you secure sensitive data in Kubernetes?**  
✅ **Answer:**  
Sensitive data should be stored in **Secrets** instead of ConfigMaps.  

✅ **Create a Kubernetes Secret:**  
```bash
kubectl create secret generic db-secret --from-literal=username=admin --from-literal=password=secure123
```
✅ **Use it in a Pod:**  
```yaml
env:
  - name: DB_USERNAME
    valueFrom:
      secretKeyRef:
        name: db-secret
        key: username
```
📌 **Keeps credentials hidden from logs and code.**  

---

### **5. What is a Kubernetes DaemonSet and when should you use it?**  
✅ **Answer:**  
A **DaemonSet** ensures that a specific pod runs on **every node** in the cluster.  
It is used for **log collectors, monitoring agents, or networking tools**.  

✅ **Example DaemonSet for Fluentd Logging:**  
```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluentd-logger
spec:
  selector:
    matchLabels:
      name: fluentd
  template:
    metadata:
      labels:
        name: fluentd
    spec:
      containers:
      - name: fluentd
        image: fluentd:latest
```
📌 **Ensures logging agents are present on every node.**  

---

### **6. How does Kubernetes handle network communication between pods?**  
✅ **Answer:**  
Kubernetes uses a **flat networking model** where every pod gets a unique IP.  
- **CNI Plugins (Flannel, Calico, Cilium)** manage network policies.  
- **Services** provide stable communication.  

✅ **Check network policies:**  
```bash
kubectl get networkpolicy -n my-namespace
```
📌 **Pods can communicate using Service DNS names.**  

---

### **7. How do you monitor Kubernetes cluster performance?**  
✅ **Answer:**  
Use **Prometheus** and **Grafana** for real-time monitoring.  

✅ **Deploy Prometheus & Grafana using Helm:**  
```bash
helm install prometheus prometheus-community/kube-prometheus-stack
```
📌 **Helps visualize cluster health & metrics.**  

---

### **8. How do you implement Horizontal Pod Autoscaling (HPA) in Kubernetes?**  
✅ **Answer:**  
HPA scales pods **based on CPU/memory utilization**.  

✅ **Example HPA:**
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: my-app-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: my-app
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 50
```
📌 **Automatically scales pods based on demand.**  

---

### **9. How do you implement Blue-Green Deployment in Kubernetes?**  
✅ **Answer:**  
Use two Deployments (Blue & Green) and switch traffic using a Service.  

✅ **Example Service Switching to Green Deployment:**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-app
spec:
  selector:
    app: my-app-green
  ports:
  - port: 80
    targetPort: 8080
```
📌 **Safely deploy new versions without downtime.**  

---

### **10. How do you troubleshoot Kubernetes node failures?**  
✅ **Answer:**  
1. **Check node status:**  
   ```bash
   kubectl get nodes
   ```
2. **Describe failing node:**  
   ```bash
   kubectl describe node <node-name>
   ```
3. **Check system logs:**  
   ```bash
   journalctl -u kubelet -f
   ```
4. **Drain node before maintenance:**  
   ```bash
   kubectl drain <node-name> --ignore-daemonsets
   ```
📌 **Ensures smooth cluster operation.**  

---

