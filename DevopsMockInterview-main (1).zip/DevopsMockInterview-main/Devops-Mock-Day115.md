
---

## 🐳 Docker + ☸️ Kubernetes (1–20)

---

### **1. How do you configure auto-restart for a failed container in Docker?**

**Answer:**
Use the `--restart` policy.

```bash
docker run --restart=on-failure:5 myapp
```

This restarts the container up to 5 times if it fails.

---

### **2. How do you implement health checks in a Docker container?**

**Answer:**
Use `HEALTHCHECK` in Dockerfile:

```dockerfile
HEALTHCHECK CMD curl --fail http://localhost:8080 || exit 1
```

---

### **3. How do you clean up unused Docker images and containers automatically?**

**Answer:**

```bash
docker system prune -a
```

Be cautious — it removes unused images, containers, volumes, and networks.

---

### **4. How do you monitor Docker container performance?**

**Answer:**
Use:

* `docker stats`
* Tools like **cAdvisor**, **Prometheus**, **Grafana**, **Datadog**

---

### **5. What is multi-stage Docker build and how does it help?**

**Answer:**
It separates build and runtime environments, reducing image size.

```dockerfile
FROM node:16 as builder
WORKDIR /app
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
```

---

### **6. How do you share a Docker image with another team securely?**

**Answer:**

* Push to **private Docker registry**
* Use authentication (e.g., Amazon ECR, Harbor, JFrog)

---

### **7. How do you run stateful applications in Kubernetes?**

**Answer:**
Use **StatefulSets** with Persistent Volume Claims (PVCs).

---

### **8. How do you troubleshoot network issues between Kubernetes pods?**

**Answer:**

* Use `kubectl exec` + ping/curl between pods
* Check NetworkPolicy
* Verify if services and endpoints exist using:

```bash
kubectl get endpoints
```

---

### **9. What are Init Containers in Kubernetes and when do you use them?**

**Answer:**
Special containers that run before app containers to perform setup tasks.

Example use case: wait for DB to be ready.

---

### **10. How do you restrict resource usage in Kubernetes?**

**Answer:**
Use resource **limits** and **requests**:

```yaml
resources:
  requests:
    memory: "128Mi"
    cpu: "250m"
  limits:
    memory: "512Mi"
    cpu: "500m"
```

---

### **11. How do you update Kubernetes secrets or configmaps without pod restarts?**

**Answer:**
You **can’t force-update** env-injected values, but mounting as **volumes** allows dynamic reload.

Use apps that support config reload like NGINX, Spring Boot, etc.

---

### **12. How do you prevent a pod from being scheduled on certain nodes?**

**Answer:**
Use **node taints** and **tolerations** or **node affinity**.

---

### **13. How do you roll back a Kubernetes deployment?**

**Answer:**

```bash
kubectl rollout undo deployment <name>
```

---

### **14. What is a sidecar container and give an example?**

**Answer:**
A helper container within the same pod.
**Example:** A log collector like Fluentd that reads logs from the main app.

---

### **15. How do you enforce security in Docker containers?**

**Answer:**

* Use non-root users
* Minimize image layers
* Use Docker Bench Security
* Scan images with Trivy or Snyk

---

### **16. What is the difference between `docker-compose` and Kubernetes?**

**Answer:**

* Docker Compose is for local multi-container management.
* Kubernetes handles orchestration, scaling, service discovery, and more in production.

---

### **17. How do you inject TLS/SSL certificates into a Kubernetes pod?**

**Answer:**

* Store as secrets

```bash
kubectl create secret tls my-tls --cert=cert.pem --key=key.pem
```

* Mount into container

```yaml
volumes:
- name: tls-cert
  secret:
    secretName: my-tls
```

---

### **18. How do microservices talk to each other securely in Kubernetes?**

**Answer:**

* Use **service-to-service encryption** (e.g., mTLS via Istio)
* Network policies for traffic control
* DNS-based service discovery

---

### **19. How do you version control Kubernetes manifests?**

**Answer:**

* Store YAMLs in Git
* Use **GitOps tools** like ArgoCD or Flux

---

### **20. How do you automate deployment to Kubernetes using CI/CD?**

**Answer:**
Use tools like Jenkins, GitLab CI, or GitHub Actions to:

1. Build Docker image
2. Push to registry
3. Apply/update manifests via `kubectl` or Helm

**Example GitHub Action:**

```yaml
- name: Deploy to Kubernetes
  run: kubectl apply -f k8s/deployment.yaml
```

---

