
---

## 🐳 **Docker (1–10)**

---

### **1. How do you persist data in Docker containers?**

**Answer:**  
Use **volumes** or **bind mounts**.

**Example:**
```bash
docker run -v mydata:/app/data myapp
```

**Use Case:**  
Ensures data (e.g., DB or logs) remains intact even after container deletion.

---

### **2. How do you troubleshoot a container that fails to start?**

**Answer:**
```bash
docker logs <container-id>
docker inspect <container-id>
```

Check for:
- Entrypoint errors
- Missing dependencies
- Incorrect environment variables

---

### **3. How can you reduce the size of your Docker image?**

**Answer:**
- Use **Alpine base image**
- **Multi-stage builds**
- Clean caches and temp files

```dockerfile
FROM golang:1.20 as builder
WORKDIR /app
COPY . .
RUN go build -o myapp

FROM alpine
COPY --from=builder /app/myapp /myapp
ENTRYPOINT ["/myapp"]
```

---

### **4. How do you pass secrets securely into Docker containers?**

**Answer:**  
Use `--env-file`, `docker secrets` (Swarm), or `vault`.

```bash
docker run --env-file .env myapp
```

---

### **5. How do you expose multiple ports in a Docker container?**

**Answer:**
```bash
docker run -p 8080:8080 -p 9090:9090 myapp
```

---

### **6. How do you debug network issues between two containers?**

**Answer:**
- Ensure they are in the same **Docker network**
- Use `docker network inspect`
- Use `ping`, `curl` inside containers

```bash
docker exec -it container1 ping container2
```

---

### **7. How do you handle Docker container crashes automatically?**

**Answer:**
Use restart policies:
```bash
docker run --restart=always myapp
```

---

### **8. How do you run a multi-container application in Docker?**

**Answer:**  
Use **Docker Compose**.

**docker-compose.yml**
```yaml
version: '3'
services:
  web:
    image: nginx
  app:
    image: myapp
    depends_on:
      - db
  db:
    image: postgres
```

---

### **9. How do you check which container is using high resources?**

**Answer:**
```bash
docker stats
```

---

### **10. How do you share data between two containers?**

**Answer:**
Use a **named volume**:
```bash
docker volume create shared-vol
docker run -v shared-vol:/data container1
docker run -v shared-vol:/data container2
```

---

## ☸️ **Kubernetes (11–20)**

---

### **11. How do you scale an application in Kubernetes?**

**Answer:**
```bash
kubectl scale deployment myapp --replicas=5
```

Use **HPA** for auto-scaling:
```bash
kubectl autoscale deployment myapp --cpu-percent=80 --min=2 --max=10
```

---

### **12. What’s the use of ConfigMaps in Kubernetes?**

**Answer:**  
ConfigMaps store configuration data separately from application code.

```bash
kubectl create configmap app-config --from-literal=env=prod
```

Mount as:
```yaml
envFrom:
  - configMapRef:
      name: app-config
```

---

### **13. How do you persist data in Kubernetes pods?**

**Answer:**
Use **Persistent Volumes (PV)** and **Persistent Volume Claims (PVC)**.

```yaml
volumeMounts:
- mountPath: "/data"
  name: data-volume
```

---

### **14. How do you troubleshoot a pod in CrashLoopBackOff state?**

**Answer:**
```bash
kubectl logs <pod>
kubectl describe pod <pod>
```

Check:
- Probes
- Exit code
- OOMKilled or startup errors

---

### **15. How do you expose your app outside the cluster?**

**Answer:**
Use:
- **NodePort** (for dev/testing)
- **LoadBalancer** (for cloud)
- **Ingress** (for routing multiple services)

---

### **16. How do microservices discover each other in Kubernetes?**

**Answer:**  
Via internal DNS:
```bash
http://<service-name>.<namespace>.svc.cluster.local
```

Kube-DNS or CoreDNS handles this resolution.

---

### **17. How do you manage environments (dev, test, prod) in Kubernetes?**

**Answer:**  
Use **Namespaces**:
```bash
kubectl create namespace dev
kubectl create namespace prod
```

---

### **18. What is a readiness probe vs liveness probe?**

**Answer:**
- **Liveness**: App is healthy and running
- **Readiness**: App is ready to serve traffic

---

### **19. How do you perform zero-downtime deployments?**

**Answer:**
Use **RollingUpdate strategy** in deployments:
```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1
    maxUnavailable: 0
```

---

### **20. How do you inject secrets securely into pods?**

**Answer:**
Use Kubernetes Secrets:
```bash
kubectl create secret generic db-secret --from-literal=password=pass123
```

Mount via env vars or volumes.

---
