### **Jenkins Real-Time Scenario-Based Interview Questions and Answers**

---

### **1. How do you set up a Jenkins pipeline to deploy an application to a Kubernetes cluster?**

#### **Answer:**
To deploy an application to Kubernetes using Jenkins, you need to:
- Use a `Jenkinsfile` to define the pipeline.
- Build the application.
- Create a Docker image and push it to a registry.
- Use `kubectl` to deploy the image to Kubernetes.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    environment {
        IMAGE_NAME = "my-app"
        IMAGE_TAG = "latest"
        REGISTRY = "mydockerhub"
        KUBE_CONFIG = credentials('kube-config') // Kubernetes config stored in Jenkins
    }
    stages {
        stage('Build') {
            steps {
                sh 'mvn clean package'
            }
        }
        stage('Docker Build & Push') {
            steps {
                sh """
                    docker build -t ${REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG} .
                    docker login -u myusername -p mypassword
                    docker push ${REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}
                """
            }
        }
        stage('Deploy to Kubernetes') {
            steps {
                sh """
                    export KUBECONFIG=$KUBE_CONFIG
                    kubectl apply -f k8s/deployment.yaml
                    kubectl rollout status deployment/${IMAGE_NAME}
                """
            }
        }
    }
}
```
---

### **2. How do you handle rollback in Jenkins if a deployment fails?**

#### **Answer:**
To handle rollback in Jenkins:
1. Maintain versioned Docker images.
2. Use `kubectl rollout undo` in case of failure.

#### **Jenkinsfile Example with Rollback Logic:**
```groovy
pipeline {
    agent any
    stages {
        stage('Deploy') {
            steps {
                script {
                    try {
                        sh 'kubectl apply -f k8s/deployment.yaml'
                        sh 'kubectl rollout status deployment/my-app'
                    } catch (Exception e) {
                        echo 'Deployment failed, rolling back...'
                        sh 'kubectl rollout undo deployment/my-app'
                        throw e
                    }
                }
            }
        }
    }
}
```
---

### **3. How do you implement blue-green deployment in Jenkins?**

#### **Answer:**
Blue-green deployment involves running two environments: one active (blue) and one idle (green). The new version is deployed to the idle environment and switched when it's ready.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Deploy to Green') {
            steps {
                sh 'kubectl apply -f k8s/deployment-green.yaml'
            }
        }
        stage('Switch Traffic to Green') {
            steps {
                sh 'kubectl apply -f k8s/service-green.yaml'
            }
        }
    }
}
```
---

### **4. How do you trigger a Jenkins build when a code change is pushed to GitHub?**

#### **Answer:**
Use GitHub Webhooks:
1. Go to Jenkins → Manage Jenkins → Configure System → GitHub.
2. Add a Webhook in GitHub: **Settings → Webhooks → Add Webhook**.
3. Select **Push Event**.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    triggers {
        githubPush()
    }
    stages {
        stage('Build') {
            steps {
                sh 'mvn clean package'
            }
        }
    }
}
```
---

### **5. How do you implement parallel execution in Jenkins to speed up a pipeline?**

#### **Answer:**
Parallel execution allows different stages to run simultaneously.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Parallel Execution') {
            parallel {
                stage('Unit Tests') {
                    steps {
                        sh 'mvn test'
                    }
                }
                stage('Static Code Analysis') {
                    steps {
                        sh 'sonar-scanner'
                    }
                }
                stage('Security Scan') {
                    steps {
                        sh 'trivy image my-app'
                    }
                }
            }
        }
    }
}
```
---

### **6. How do you pass credentials securely in Jenkins pipelines?**

#### **Answer:**
Use Jenkins credentials:
1. Store credentials in **Jenkins → Manage Jenkins → Credentials**.
2. Retrieve credentials in `Jenkinsfile`.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    environment {
        DOCKER_USER = credentials('docker-user')
        DOCKER_PASS = credentials('docker-pass')
    }
    stages {
        stage('Login to Docker') {
            steps {
                sh 'echo $DOCKER_PASS | docker login -u $DOCKER_USER --password-stdin'
            }
        }
    }
}
```
---

### **7. How do you run Jenkins on a Docker container?**

#### **Answer:**
Run Jenkins using the following command:
```sh
docker run -d -p 8080:8080 -p 50000:50000 --name jenkins -v jenkins_home:/var/jenkins_home jenkins/jenkins:lts
```

For persistent data:
```sh
docker volume create jenkins_home
docker run -d -p 8080:8080 -p 50000:50000 --name jenkins -v jenkins_home:/var/jenkins_home jenkins/jenkins:lts
```
---

### **8. How do you implement CI/CD for a Java project using Jenkins and SonarQube?**

#### **Answer:**
1. Configure SonarQube in Jenkins.
2. Run SonarQube analysis as a pipeline step.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    environment {
        SONAR_TOKEN = credentials('sonar-token')
    }
    stages {
        stage('Build') {
            steps {
                sh 'mvn clean package'
            }
        }
        stage('SonarQube Analysis') {
            steps {
                sh 'mvn sonar:sonar -Dsonar.host.url=http://sonarqube:9000 -Dsonar.login=$SONAR_TOKEN'
            }
        }
    }
}
```
---

### **9. How do you send notifications in Jenkins when a build fails?**

#### **Answer:**
Use email or Slack for notifications.

#### **Jenkinsfile Example (Email Notification):**
```groovy
pipeline {
    agent any
    post {
        failure {
            mail to: 'team@example.com',
                 subject: "Build Failed: ${currentBuild.fullDisplayName}",
                 body: "Build URL: ${env.BUILD_URL}"
        }
    }
}
```

#### **Jenkinsfile Example (Slack Notification):**
```groovy
pipeline {
    agent any
    post {
        failure {
            slackSend channel: '#build-failures', message: "Build ${env.JOB_NAME} failed!"
        }
    }
}
```
---

### **10. How do you archive artifacts in Jenkins after a build?**

#### **Answer:**
Use the `archiveArtifacts` step.

#### **Jenkinsfile Example:**
```groovy
pipeline {
    agent any
    stages {
        stage('Build') {
            steps {
                sh 'mvn clean package'
                archiveArtifacts artifacts: 'target/*.jar', fingerprint: true
            }
        }
    }
}
```
---
