
---

### **1. What is the difference between Rolling Update and Blue-Green Deployment?**

**Answer:**

* **Rolling Update**: Gradually replaces instances of the old version with the new one.

  * No downtime.
  * May mix old and new versions.
* **Blue-Green Deployment**: A second environment (green) is deployed. Traffic is switched once tested.

  * Zero downtime.
  * Easy rollback (switch traffic back to blue).

> Use Rolling Update for minor upgrades; Blue-Green for critical releases.

---

### **2. How do you store sensitive credentials securely in Jenkins?**

**Answer:**

* Use **Jenkins Credentials Plugin**.
* Store as **Secret Text**, **Username/Password**, or **SSH Key**.
* Access via:

  ```groovy
  withCredentials([string(credentialsId: 'secret-id', variable: 'SECRET')]) {
    sh 'echo $SECRET'
  }
  ```
* Avoid hardcoding credentials in Jenkinsfile.

---

### **3. How would you patch a running Kubernetes pod with a new environment variable without downtime?**

**Answer:**
You can't modify a pod directly. Instead:

* Update the **Deployment**:

  ```bash
  kubectl set env deployment/myapp ENV_VAR=value
  ```
* This triggers a rolling update with the new pod spec.

---

### **4. How do you monitor infrastructure in a production environment?**

**Answer:**

* Use **Prometheus** + **Grafana** for metrics.
* **ELK/EFK stack** for logs (Elasticsearch + Fluentd + Kibana).
* **Alertmanager** or **PagerDuty** for alerts.
* Integrate with cloud-native monitoring like **CloudWatch**, **Datadog**, or **New Relic**.

---

### **5. What is the difference between Terraform `count` and `for_each`?**

**Answer:**

* `count`: Used for simple repetitions.

  ```hcl
  count = 3
  ```
* `for_each`: Used when working with maps or sets for **named/unique resources**.

  ```hcl
  for_each = var.servers
  ```

> Prefer `for_each` when resource names should be predictable and manageable.

---

### **6. How do you handle zero-downtime deployment in Kubernetes?**

**Answer:**

* Use **readiness probes** to avoid traffic to initializing pods.
* Enable **rolling updates** in Deployment with:

  ```yaml
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0
  ```
* Use **liveness probes** to kill bad pods.

---

### **7. How do you debug if an EC2 instance suddenly stops responding?**

**Answer:**

* Check **CloudWatch logs and metrics** (CPU, disk, memory).
* Use **EC2 serial console** for deep OS-level troubleshooting.
* Verify **security groups/NACLs** for SSH or app port blocking.
* Review **system logs** with SSM or `Get-Console-Output`.

---

### **8. What is a race condition in CI/CD pipelines? How do you avoid it?**

**Answer:**

* A race condition occurs when two builds/pipelines run in parallel and interfere with each other.
* **Fixes**:

  * Use **locking plugins** (e.g., Jenkins Lockable Resources Plugin).
  * Implement **mutual exclusion** per environment.
  * Use **versioned artifacts** and immutable builds.

---

### **9. How do you secure a Docker container in production?**

**Answer:**

* Use **non-root user** inside Dockerfile.
* Scan image with **Trivy**, **Clair**, or **AquaSec**.
* Limit container capabilities (`--cap-drop=ALL`).
* Use **read-only filesystem**, restrict mounts.
* Enable **Seccomp/AppArmor** profiles.

---

### **10. What is the use of `terraform taint` and when do you use it?**

**Answer:**

* `terraform taint RESOURCE_NAME` marks a resource for recreation on next `apply`.
* Use when a resource is **in a bad state** or **corrupt**, but you don’t want to destroy everything.

---

