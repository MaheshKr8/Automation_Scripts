
### **1. How do you troubleshoot a CrashLoopBackOff pod?**

🧠 **Answer:**  
This indicates a pod is crashing repeatedly.

🔧 **Steps:**
```bash
kubectl get pods
kubectl describe pod <pod-name>
kubectl logs <pod-name>
```

🔍 **Check for:**  
- Application errors in logs  
- Liveness/Readiness probe misconfigurations  
- Resource limits causing OOMKilled

---

### **2. How does Kubernetes perform load balancing across pods?**

🧠 **Answer:**  
Kubernetes uses **Services** (ClusterIP/NodePort/LoadBalancer) to load balance traffic across pods.

📌 Example:
```yaml
apiVersion: v1
kind: Service
metadata:
  name: my-service
spec:
  selector:
    app: myapp
  ports:
    - port: 80
      targetPort: 8080
  type: ClusterIP
```

---

### **3. What is a readiness vs. liveness probe?**

🧠 **Answer:**
- **Readiness Probe**: Determines if the app is ready to serve traffic.  
- **Liveness Probe**: Determines if the app is healthy and running.

📌 Example:
```yaml
livenessProbe:
  httpGet:
    path: /healthz
    port: 8080
  initialDelaySeconds: 15
  periodSeconds: 10
```

---

### **4. How do you scale pods automatically in Kubernetes?**

🧠 **Answer:**  
Use **Horizontal Pod Autoscaler (HPA)**.

📌 Example:
```bash
kubectl autoscale deployment myapp --cpu-percent=70 --min=2 --max=5
```

💡 Uses metrics from `metrics-server`.

---

### **5. How do you manage secrets securely in Kubernetes?**

🧠 **Answer:**  
Use **Secrets** and mount them as environment variables or files.

📌 Example:
```bash
kubectl create secret generic db-secret --from-literal=password=MyS3cr3t
```

---

### **6. How do you expose your app to the internet using Ingress?**

🧠 **Answer:**  
Use an **Ingress Controller** like NGINX and configure rules.

📌 `ingress.yaml`:
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: example-ingress
spec:
  rules:
  - host: app.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: myapp-service
            port:
              number: 80
```

---

### **7. How do you configure persistent storage for a pod?**

🧠 **Answer:**  
Use **PersistentVolume (PV)** and **PersistentVolumeClaim (PVC)**.

📌 Example:
```yaml
volumeMounts:
- mountPath: "/data"
  name: data-volume

volumes:
- name: data-volume
  persistentVolumeClaim:
    claimName: mypvc
```

---

### **8. What are namespaces in Kubernetes and how are they used?**

🧠 **Answer:**  
Namespaces are logical partitions in a cluster, used to separate environments (e.g., dev, test, prod).

📌 Example:
```bash
kubectl create namespace dev
kubectl get pods --namespace=dev
```

---

### **9. How do you perform a rolling update in Kubernetes?**

🧠 **Answer:**  
Kubernetes Deployments support rolling updates by default.

📌 Example:
```bash
kubectl set image deployment/myapp myapp=nginx:1.19
```

Check rollout:
```bash
kubectl rollout status deployment/myapp
```

---

### **10. How do you rollback a failed deployment?**

🧠 **Answer:**
```bash
kubectl rollout undo deployment/myapp
```

---

### **11. How does Kubernetes handle service discovery?**

🧠 **Answer:**  
Each service gets a **DNS name** and **ClusterIP**. Pods use **CoreDNS** for resolving service names.

📌 Example:  
`http://my-service.default.svc.cluster.local`

---

### **12. How do you debug a pod stuck in "Pending" state?**

🧠 **Answer:**
```bash
kubectl describe pod <pod-name>
```

🔍 Check:
- Node resource availability
- Storage class issues
- Taints/Tolerations

---

### **13. What are taints and tolerations?**

🧠 **Answer:**  
**Taints** prevent pods from scheduling on a node unless they have **tolerations**.

📌 Taint a node:
```bash
kubectl taint nodes node1 key=value:NoSchedule
```

📌 Pod toleration:
```yaml
tolerations:
- key: "key"
  operator: "Equal"
  value: "value"
  effect: "NoSchedule"
```

---

### **14. How do you restrict pod resource usage?**

🧠 **Answer:**  
Use **resource requests and limits** in the pod spec.

📌 Example:
```yaml
resources:
  requests:
    memory: "64Mi"
    cpu: "250m"
  limits:
    memory: "128Mi"
    cpu: "500m"
```

---

### **15. How do you view logs of a failed pod that has been terminated?**

🧠 **Answer:**  
Use `--previous` to view logs from the crashed container:
```bash
kubectl logs <pod-name> --previous
```

---

