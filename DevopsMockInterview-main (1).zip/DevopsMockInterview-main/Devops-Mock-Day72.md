

1. **Explain Docker volumes and their types.**  

    - **Answer**: Docker volumes store data outside the container lifecycle. Types:  
      - **Named volumes**: Managed by Docker.  
      - **Bind mounts**: Host file system paths.  
    - **Example**:  
      ```bash
      docker volume create myvolume
      docker run -v myvolume:/app/data nginx
      ```

---

2. **What is the purpose of `docker network`?**  

    - **Answer**: It manages communication between containers. Types include bridge, host, and overlay networks.  
    - **Example**:  
      ```bash
      docker network create mynetwork
      docker run --network mynetwork nginx
      ```

---

3. **How do you build a multi-stage Dockerfile?**  
    - **Answer**: Multi-stage builds optimize image size by using multiple `FROM` statements.  
    - **Example**:  
      ```dockerfile
      FROM golang:alpine as builder
      RUN go build -o app main.go
      FROM alpine
      COPY --from=builder /app /app
      CMD ["/app"]
      ```

---

4. **How do you limit container resources?**  
    - **Answer**: Use flags like `--memory` and `--cpus`.  
    - **Example**:  
      ```bash
      docker run --memory=500m --cpus=1 nginx
      ```

---

5. **How do you troubleshoot a failing container?**  
    - **Answer**:  
      - Check logs: `docker logs <container_id>`  
      - Inspect: `docker inspect <container_id>`  

---

6. **What is Docker Hub, and how do you push an image to it?**  
    - **Answer**: Docker Hub is a registry for Docker images.  
    - **Example**:  
      ```bash
      docker tag myimage username/myimage
      docker push username/myimage
      ```

---

7. **How do you run a container in detached mode?**  
    - **Answer**: Use the `-d` flag.  
    - **Example**:  
      ```bash
      docker run -d nginx
      ```

---

8. **What is the difference between `ENTRYPOINT` and `CMD`?**  
    - **Answer**: Both specify the default executable, but `ENTRYPOINT` is preferred for fixed commands, and `CMD` provides default arguments.  
    - **Example**:  
      ```dockerfile
      ENTRYPOINT ["nginx"]
      CMD ["-g", "daemon off;"]
      ```

---

9. **How do you clean up unused containers, images, and volumes?**  
    - **Answer**: Use `docker system prune`.  
    - **Example**:  
      ```bash
      docker system prune -a
      ```

---

10. **How do you handle environment variables in Docker?**  
    - **Answer**: Use the `ENV` keyword in Dockerfile or `--env` during runtime.  
    - **Example**:  
      ```dockerfile
      ENV APP_ENV production
      ```

### **11. What are Docker Secrets, and How Are They Used?**

---

#### **Answer:**

Docker Secrets is a feature that securely manages sensitive data (such as passwords, SSH keys, or API tokens) used by containers. It ensures that sensitive data is:

1. **Encrypted**: Stored and transmitted securely.
2. **Accessible Only to Specific Containers**: Controlled by strict permissions.
3. **Not Embedded in Images**: Keeps sensitive information out of your Dockerfiles and images.

Docker Secrets is primarily used in **Docker Swarm** mode for managing secret data.

---

#### **Key Features:**

1. **Secure storage**: Secrets are stored in an encrypted manner in the Swarm manager node.
2. **Restricted access**: Secrets are only available to the containers that explicitly request them.
3. **Temporary availability**: Secrets are stored in-memory within the container, not on disk.

---

### **How Are Docker Secrets Used?**

Here’s a step-by-step example of creating and using Docker Secrets:

---

#### **Scenario: Securely Pass MySQL Root Password Using Docker Secrets**

---

1. **Initialize Docker Swarm**:  
   Docker Secrets requires Swarm mode.  
   ```bash
   docker swarm init
   ```

---

2. **Create a Secret**:  
   Use the `docker secret create` command to store sensitive data.  
   ```bash
   echo "my_secure_password" | docker secret create mysql_root_password -
   ```

   - **Key Points**:
     - `mysql_root_password` is the name of the secret.
     - The secret data is passed via standard input (using `echo` in this case).

---

3. **Create a Service That Uses the Secret**:  
   When deploying a service, specify which secrets it can access.  
   ```bash
   docker service create \
     --name mysql_service \
     --secret mysql_root_password \
     -e MYSQL_ROOT_PASSWORD_FILE="/run/secrets/mysql_root_password" \
     mysql:latest
   ```

   - **Explanation**:
     - The `--secret` flag specifies the secret the service can access.
     - `MYSQL_ROOT_PASSWORD_FILE` environment variable points to the file containing the secret inside the container (secrets are mounted at `/run/secrets` by default).

---

4. **Verify the Secret Is Used**:  
   Check the logs or inspect the service to confirm the secret is being used:  
   ```bash
   docker service logs mysql_service
   ```

---

5. **Remove the Secret**:  
   Once no longer needed, you can delete the secret:  
   ```bash
   docker secret rm mysql_root_password
   ```

---

### **Advantages of Using Docker Secrets:**

1. **Enhanced Security**: Secrets are encrypted and not stored on disk in the container.
2. **Granular Access Control**: Secrets are accessible only to authorized services.
3. **Ease of Use**: Integrates seamlessly with Docker services.

---

### **Real-World Use Case:**

**Scenario**: A company deploys multiple microservices in a Docker Swarm cluster. Each service requires different credentials to access databases or APIs. Using Docker Secrets ensures:

- The credentials are encrypted.
- Only the specific service that needs a credential can access it.
- Credentials are not hardcoded in Dockerfiles or environment variables.

---

### **12. How Do You Configure Docker Swarm for Container Orchestration?**

---

#### **Answer:**

Docker Swarm is Docker’s native tool for container orchestration. It allows you to manage a cluster of Docker nodes as a single virtual system, enabling features such as service scaling, load balancing, and high availability.

To configure Docker Swarm for container orchestration, follow these steps:

---

### **Steps to Configure Docker Swarm**

---

#### **1. Initialize the Swarm**

The first step is to initialize a Swarm cluster on the manager node.  
```bash
docker swarm init
```

- **Key Points**:
  - The node where this command is run becomes the Swarm **manager**.
  - The output provides a join token for worker nodes to join the cluster.

---

#### **2. Add Worker Nodes to the Swarm**

On each worker node, use the join token to add them to the Swarm cluster.  

```bash
docker swarm join --token <worker_token> <manager_ip>:2377
```

- **Replace** `<worker_token>` and `<manager_ip>` with the actual token and IP from the `docker swarm init` output.
- Run `docker node ls` on the manager to confirm the worker nodes have joined.

---

#### **3. Deploy a Service**

In Swarm, containers are deployed as **services**. Create a service using the `docker service create` command:  

```bash
docker service create --name my_web_service --replicas 3 -p 8080:80 nginx
```

- **Explanation**:
  - `--name`: Names the service.
  - `--replicas`: Specifies the number of container instances (replicas).
  - `-p 8080:80`: Maps port 8080 on the host to port 80 in the container.

---

#### **4. Verify the Service**

Check the status of the service and its replicas:  
```bash
docker service ls
docker service ps my_web_service
```

---

#### **5. Scale the Service**

Scale the number of replicas as needed:  
```bash
docker service scale my_web_service=5
```

- **Explanation**: This scales the service to 5 container instances, distributing them across the cluster nodes.

---

#### **6. Implement Load Balancing**

Docker Swarm provides built-in load balancing. When you access the service via the published port (e.g., `http://<manager_ip>:8080`), requests are automatically distributed across replicas.

---

#### **7. Update the Service**

Update the service with new configurations or image versions:  
```bash
docker service update --image nginx:latest my_web_service
```

- **Explanation**: This updates the service to use the latest Nginx image.

---

#### **8. Manage Swarm Nodes**

You can promote a worker to a manager or demote a manager to a worker:  

- Promote a worker:  
  ```bash
  docker node promote <worker_node_name>
  ```

- Demote a manager:  
  ```bash
  docker node demote <manager_node_name>
  ```

---

#### **9. Remove a Node from the Swarm**

To remove a node, first drain it to stop assigning new tasks:  
```bash
docker node update --availability drain <node_name>
```

Then remove it:  
```bash
docker swarm leave
```

On the manager, forcefully remove a node if necessary:  
```bash
docker node rm <node_name>
```

---

### **Real-World Use Case**

**Scenario**: Deploying a high-availability web application.  

- **Setup**:
  - Use 3 manager nodes and 5 worker nodes for redundancy.
  - Deploy a service with 10 replicas of a Node.js app.
  - Use Docker Swarm’s built-in load balancing to distribute traffic.

**Command Example**:
```bash
docker service create --name node_app --replicas 10 -p 3000:3000 my_node_image
```

- This setup ensures fault tolerance, automatic failover, and seamless scaling.

---

### **Advantages of Docker Swarm:**

1. **High Availability**: Distributes tasks across multiple nodes.  
2. **Scaling**: Easily scale services up or down.  
3. **Built-in Load Balancing**: Automatically balances requests across replicas.  
4. **Secure Communication**: TLS encryption between nodes.  
5. **Ease of Use**: Simple CLI-based management.

---
