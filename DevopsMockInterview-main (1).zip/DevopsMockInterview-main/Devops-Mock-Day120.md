
---

### ✅ **1. What is DevOps and why is it important?**

**Answer:**
DevOps is a set of practices that combines software development (Dev) and IT operations (Ops). It helps shorten the SDLC, increase deployment frequency, and improve release quality using automation, CI/CD, monitoring, and collaboration.

---

### ✅ **2. Explain CI/CD and its benefits.**

**Answer:**
CI (Continuous Integration) automates code integration and testing. CD (Continuous Delivery/Deployment) automates releasing code to staging/production.
**Benefits:** faster delivery, reduced errors, improved collaboration, consistent environments.

---

### ✅ **3. What tools have you used for CI/CD pipelines?**

**Answer:**

* **CI:** Jenkins, GitHub Actions, GitLab CI
* **CD:** Argo CD, Spinnaker, Helm
* **Other:** SonarQube, Trivy, Docker, Kubernetes, Terraform

---

### ✅ **4. How do you handle version control in your projects?**

**Answer:**
We use **Git** with branching strategies like **GitFlow** or **trunk-based development**. Each feature/fix is merged via pull requests and reviewed via CI checks (lint, test, security).

---

### ✅ **5. What is a Jenkins pipeline and how do you create one?**

**Answer:**
A Jenkins pipeline is a set of steps scripted in **Jenkinsfile** using **Declarative or Scripted syntax**. It defines stages like Build, Test, and Deploy.
Example:

```groovy
pipeline {
  agent any
  stages {
    stage('Build') {
      steps {
        sh 'mvn clean install'
      }
    }
  }
}
```

---

### ✅ **6. What is Docker and how have you used it?**

**Answer:**
Docker is a containerization platform that packages applications with dependencies.
I use Docker to:

* Create reproducible environments
* Build and run microservices
* Push images to Docker Hub or AWS ECR
* Deploy containers in Kubernetes

---

### ✅ **7. What is Kubernetes and how does it work?**

**Answer:**
Kubernetes is a container orchestration platform that manages container deployment, scaling, and availability.
It uses resources like **pods, services, deployments, and ingress** to manage workloads declaratively.

---

### ✅ **8. How do you handle secrets in Kubernetes?**

**Answer:**
We use **Kubernetes Secrets**, **external secret managers** (AWS Secrets Manager, Vault), and tools like **Sealed Secrets** or **SOPS** to encrypt and manage sensitive data securely.

---

### ✅ **9. What is Infrastructure as Code (IaC)? How do you implement it?**

**Answer:**
IaC means managing infrastructure using code. I use **Terraform** to define cloud resources (VPCs, EC2, EKS, RDS). Changes are tracked via Git, and validated using `terraform plan` before applying.

---

### ✅ **10. How do you manage Terraform state securely?**

**Answer:**
We store state in **remote backends** like AWS S3 (encrypted) and lock using **DynamoDB**. This prevents concurrent changes and ensures versioned, shared state management.

---

### ✅ **11. What are modules in Terraform?**

**Answer:**
Modules are reusable Terraform configurations. We use them to define common components like **VPC, EKS, RDS**, and reuse across environments with input variables.

---

### ✅ **12. What is Ansible and how have you used it?**

**Answer:**
Ansible is a configuration management tool. I’ve used it to automate:

* Package installations
* User setup
* Application deployment
* Server patching

Using **YAML playbooks** and dynamic inventories.

---

### ✅ **13. How do you monitor infrastructure and applications?**

**Answer:**

* **Metrics:** Prometheus + Grafana
* **Logs:** ELK/EFK stack or Loki
* **Alerts:** Alertmanager, CloudWatch Alarms
* We define SLAs/SLIs and monitor CPU, memory, latency, and uptime.

---

### ✅ **14. How do you troubleshoot issues in Kubernetes?**

**Answer:**

* `kubectl get pods`, `describe`, `logs` for pod-level issues
* Check `events` for failures
* Use `kubectl exec` for debugging inside the container
* Monitor using Prometheus/Grafana

---

### ✅ **15. What is a Load Balancer and how is it different from a Reverse Proxy?**

**Answer:**

* **Load Balancer:** Distributes traffic across multiple servers (L4/L7)
* **Reverse Proxy:** Forwards requests to backend servers and can also handle caching, SSL, and routing (e.g., Nginx, HAProxy)

---

### ✅ **16. What are the different deployment strategies?**

**Answer:**

* **Rolling Update:** Replaces old pods gradually
* **Blue-Green:** Two identical environments, switch traffic
* **Canary:** Gradual rollout to a subset of users
* **Recreate:** Stop old, then start new (downtime involved)

---

### ✅ **17. What is a webhook and how is it used in CI/CD?**

**Answer:**
A webhook is an HTTP callback triggered by events (e.g., Git push). Used to **automatically trigger Jenkins/GitHub Actions** when code is pushed or PRs are created.

---

### ✅ **18. How do you secure your CI/CD pipeline?**

**Answer:**

* Use **credentials plugins** for secrets
* Scan code/images with **SonarQube, Trivy**
* Restrict access using **RBAC**
* Sign Docker images and enforce approval policies
* Encrypt and audit logs

---

### ✅ **19. How do you perform blue-green deployment with zero downtime?**

**Answer:**
Deploy the new version to a **green environment**, run tests, then switch traffic using a **load balancer** or **Ingress controller**. If issues arise, revert to the blue environment.

---

### ✅ **20. How do you handle system failures or DR scenarios?**

**Answer:**

* **Backups**: Automated snapshots (RDS, S3)
* **Multi-AZ/Region deployments**
* **Health checks** and **auto-scaling**
* Use **infrastructure automation** to recreate environments
* Regular **DR drills** and documentation

---
