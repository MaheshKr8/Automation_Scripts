
---

### ✅ **1. Scenario: Your Jenkins build job fails with “No space left on device”. What’s your resolution plan?**

**Solution:**

* Clean old builds: `Manage Jenkins → Disk Usage → Discard Old Builds`.
* Delete unused workspace directories (`$JENKINS_HOME/workspace`).
* Schedule a `cron` job or Jenkins pipeline to auto-clean periodically.
* Mount larger volume if builds are genuinely large.

---

### ✅ **2. Scenario: Application works locally but fails in container during deployment. How do you debug?**

**Solution:**

* Check differences between local and image runtime (e.g., config/env/permissions).
* Use `docker run -it image /bin/sh` or `kubectl exec` to inspect container.
* Validate environment variables, file paths, or missing volumes in the pod.

---

### ✅ **3. Scenario: Jenkins build gets triggered twice on a single Git push.**

**Solution:**

* Check if both SCM polling and GitHub webhook triggers are enabled—use only **one**.
* Validate GitHub webhook payload and Jenkins job trigger configuration.
* Consider using **Multibranch Pipeline** to avoid redundant triggers.

---

### ✅ **4. Scenario: Kubernetes pod is stuck in `CrashLoopBackOff`. How do you handle it?**

**Solution:**

* Check logs: `kubectl logs <pod>`
* Describe pod: `kubectl describe pod <name>` for events like OOMKilled, secret/env missing.
* Check liveness/readiness probes.
* Investigate misconfigurations or exceptions in entrypoint script.

---

### ✅ **5. Scenario: You need to deploy different app configurations for dev, stage, and prod in Kubernetes.**

**Solution:**

* Use **Helm values.yaml** per environment.
* Or use **Kustomize overlays** for env-specific differences.
* Keep secrets and sensitive data in **Kubernetes Secrets** or **external secret managers** (like Vault).

---

### ✅ **6. Scenario: You were asked to roll back a Kubernetes deployment after a bad release.**

**Solution:**

* Rollback using `kubectl rollout undo deployment/<name>`.
* For Helm releases, use `helm rollback <release> <revision>`.
* Ensure previous versions are tagged and configurations are version-controlled in Git.

---

### ✅ **7. Scenario: Docker image scan using Trivy reports critical vulnerabilities. What do you do next?**

**Solution:**

* Check if vulnerabilities are fixable: upgrade packages or use patched base image.
* If not fixable, use `--ignore-unfixed`, but document exception and monitor.
* Integrate Trivy scan as a mandatory gate in CI pipeline.

---

### ✅ **8. Scenario: Terraform apply fails due to state lock. What steps do you take?**

**Solution:**

* Check if another Terraform operation is ongoing.
* If lock is stale (e.g., crashed), manually remove it:
  For AWS backend:
  `terraform force-unlock <lock-id>`
* Avoid multiple users running `apply` at the same time—enforce CI-driven provisioning.

---

### ✅ **9. Scenario: How do you handle a secret leak (API key pushed to Git)?**

**Solution:**

* Revoke the compromised key **immediately**.
* Rotate and replace the secret.
* Use `git-filter-repo` or `BFG` to clean secret from Git history.
* Enable **pre-commit hooks** and secret scanning in CI (e.g., Gitleaks).

---

### ✅ **10. Scenario: A Jenkins pipeline needs to run differently for dev and prod. How would you design it?**

**Solution:**
Use parameters or conditionals:

```groovy
parameters {
  choice(name: 'ENV', choices: ['dev', 'prod'], description: 'Choose Environment')
}

stage('Deploy') {
  when {
    expression { params.ENV == 'prod' }
  }
  steps {
    sh 'kubectl apply -f k8s/prod.yaml'
  }
}
```

---

### ✅ **11. Scenario: You want to avoid deploying unscanned images to production. How do you enforce this in CI/CD?**

**Solution:**

* Integrate image scanning (Trivy) **before** deployment stages.
* Fail pipeline if scan result contains high/critical issues:

```bash
trivy image --severity HIGH,CRITICAL --exit-code 1 my-app:tag
```

* Use Kubernetes Admission Controllers to block untrusted images.

---

### ✅ **12. Scenario: One of your Terraform resources was deleted manually in AWS. What happens and how do you fix it?**

**Solution:**

* `terraform plan` will show drift and try to recreate the resource.
* If unintended, import it back using:
  `terraform import aws_instance.example i-xxxxxxxxx`
* Educate teams on **not manually changing** infra managed by Terraform.

---

### ✅ **13. Scenario: CI/CD pipeline fails due to “connection timeout” to Nexus/DockerHub. How do you approach this?**

**Solution:**

* Check internet access, proxy configuration, DNS resolution.
* Retry with exponential backoff logic.
* Use a local caching proxy (e.g., Nexus) to avoid repeated external calls.

---

### ✅ **14. Scenario: After a GitHub merge, your CI pipeline skips test execution. How do you avoid this?**

**Solution:**

* Check that your pipeline has `mvn test` or equivalent stage.
* Validate the test folder and configuration are included (`src/test/java`).
* Add a quality gate to ensure minimum test coverage.

---

### ✅ **15. Scenario: You need to notify Slack/Teams when a deployment fails in Jenkins. How would you do it?**

**Solution:**

* Use **Slack Notification Plugin** or `curl` to post a message to Webhook URL:

```groovy
post {
  failure {
    slackSend(channel: '#deployments', message: "🚨 Deployment failed on ${env.JOB_NAME}")
  }
}
```

* Customize notifications based on environment and stage.

---

