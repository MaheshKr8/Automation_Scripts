
### **1. How do you use `count` in Terraform?**
**Answer**: The `count` parameter allows you to create multiple instances of a resource or module based on a variable.

#### **Real-Life Example**: Creating Multiple EC2 Instances
```hcl
resource "aws_instance" "web" {
  count         = 3
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  tags = {
    Name = "WebServer-${count.index}"
  }
}
```

---

### **2. What is `terraform graph`, and how does it help?**
**Answer**: The `terraform graph` command visualizes the dependency graph of Terraform resources, helping you understand how resources are related.

#### **Real-Life Example**: Generate and View the Graph
```bash
terraform graph | dot -Tpng > graph.png
```

---

### **3. How do you manage different versions of a Terraform module?**
**Answer**: You can specify module versions in the `source` argument using Git tags, or by referring to a specific module version on the Terraform registry.

#### **Real-Life Example**: Using Specific Module Versions
```hcl
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "2.0.0"
}
```

---

### **4. What is `terraform workspace` and when would you use it?**
**Answer**: Terraform workspaces allow you to manage multiple states (environments) within a single configuration, useful for managing dev/staging/prod environments.

#### **Real-Life Example**: Using Workspaces
```bash
terraform workspace new dev
terraform apply
```

---

### **5. How do you handle errors or exceptions in Terraform?**
**Answer**: Terraform doesn't have traditional exception handling but provides ways to check for conditions using `validation` rules or data sources to prevent issues.

#### **Real-Life Example**: Validating Input Variables
```hcl
variable "instance_type" {
  type    = string
  default = "t2.micro"

  validation {
    condition     = contains(["t2.micro", "t2.small"], var.instance_type)
    error_message = "Instance type must be t2.micro or t2.small."
  }
}
```

---

### **6. How do you destroy a specific resource in Terraform?**
**Answer**: You can use the `terraform destroy -target` command to destroy a specific resource without affecting others.

#### **Real-Life Example**: Destroying a Specific AWS EC2 Instance
```bash
terraform destroy -target=aws_instance.web
```

---

### **7. What are `terraform` resource taints, and when would you use them?**
**Answer**: Resource tainting forces Terraform to destroy and recreate a resource during the next `apply`.

#### **Real-Life Example**: Tainting a Resource
```bash
terraform taint aws_instance.web
```

---

### **8. How do you create reusable modules in Terraform?**
**Answer**: Modules are reusable, self-contained configurations. You create a module by organizing Terraform files and calling the module from other configurations.

#### **Real-Life Example**: Creating a Module for an EC2 Instance
```hcl
module "ec2" {
  source = "./modules/ec2_instance"
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}
```

---

### **9. What is the `terraform output` command?**
**Answer**: The `terraform output` command shows the values of outputs after `apply`, useful for passing data between modules or displaying information like instance IPs.

#### **Real-Life Example**: Outputting an EC2 Instance Public IP
```hcl
output "instance_ip" {
  value = aws_instance.web.public_ip
}
```

---

Here are the answers for the remaining questions starting from **30** with real-life examples and Terraform `tf` files where applicable:

---

### **10. How does Terraform interact with the cloud provider's API?**
**Answer**: Terraform interacts with cloud provider APIs via **provider plugins**. When a provider is specified (e.g., AWS, Azure, GCP), Terraform uses the provider's API to create, modify, and destroy resources. Providers use authentication (like access keys or tokens) to connect to the cloud provider.

#### **Real-Life Example**: Using the AWS Provider to Launch EC2 Instances
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}
```
In this example, Terraform uses the AWS provider plugin to interact with AWS's EC2 API and create an instance.

---

### **11. How do you manage state in a multi-user environment in Terraform?**
**Answer**: To manage state in a multi-user environment, you use **remote backends** (such as S3 for AWS, or Terraform Cloud) to store the state file. This prevents local conflicts, allows locking, and ensures that the most recent state is always available to all users.

#### **Real-Life Example**: Using S3 for Remote State Storage
```hcl
terraform {
  backend "s3" {
    bucket         = "my-terraform-state-bucket"
    key            = "path/to/my/terraform.tfstate"
    region         = "us-east-1"
    encrypt        = true
    dynamodb_table = "terraform-lock"
  }
}
```

In this example, the state file is stored in an S3 bucket, and a DynamoDB table is used to lock the state, preventing multiple users from applying changes simultaneously.

---

### **12. How do you handle secrets in Terraform configurations?**
**Answer**: Sensitive data like passwords, API keys, and tokens should not be hardcoded in Terraform configurations. Instead, they should be handled using:
- **Environment variables** (e.g., `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`)
- **Secrets managers** like AWS Secrets Manager or HashiCorp Vault
- **Terraform `sensitive` variable attribute** to mask sensitive output

#### **Real-Life Example**: Storing Secrets in AWS Secrets Manager
```hcl
resource "aws_secretsmanager_secret" "db_password" {
  name        = "db_password"
  description = "The RDS database password"
}

resource "aws_secretsmanager_secret_version" "db_password_version" {
  secret_id     = aws_secretsmanager_secret.db_password.id
  secret_string = var.db_password
}

output "db_password" {
  value     = aws_secretsmanager_secret_version.db_password_version.secret_string
  sensitive = true
}
```

In this example, the password is stored in AWS Secrets Manager, and Terraform marks it as sensitive.

---

### **13. Explain the use of Terraform workspaces for managing multiple environments.**
**Answer**: **Terraform workspaces** allow you to manage multiple environments (such as dev, staging, and production) using the same configuration. Each workspace maintains its own state file, enabling different environments to have isolated state.

#### **Real-Life Example**: Using Workspaces for Dev and Prod Environments
```bash
# Create new workspaces
terraform workspace new dev
terraform workspace new prod

# Switch between workspaces
terraform workspace select dev
```

In this example, the same Terraform code is used for both development and production environments, but the state is isolated by using different workspaces.

---

### **14. How would you use dynamic blocks in Terraform for reusable code?**
**Answer**: **Dynamic blocks** are used to generate multiple instances of nested blocks (like `ingress`, `egress`, etc.) based on dynamic values. This is useful when creating resources with a variable number of settings.

#### **Real-Life Example**: Dynamic Security Group Rules
```hcl
resource "aws_security_group" "web_sg" {
  name = "web_sg"

  dynamic "ingress" {
    for_each = var.ingress_rules
    content {
      from_port   = ingress.value.from_port
      to_port     = ingress.value.to_port
      protocol    = "tcp"
      cidr_blocks = ingress.value.cidr_blocks
    }
  }
}

variable "ingress_rules" {
  type = list(object({
    from_port   = number
    to_port     = number
    cidr_blocks = list(string)
  }))
  default = [
    { from_port = 80, to_port = 80, cidr_blocks = ["0.0.0.0/0"] },
    { from_port = 443, to_port = 443, cidr_blocks = ["0.0.0.0/0"] }
  ]
}
```

In this example, dynamic blocks are used to create multiple ingress rules for an AWS security group based on the provided input.

---

### **15. Explain the use of data sources in Terraform.**
**Answer**: **Data sources** in Terraform allow you to query information from cloud providers or other systems, rather than creating new resources. This can be useful for retrieving information such as VPC IDs, AMI IDs, or other existing infrastructure details.

#### **Real-Life Example**: Querying the Latest Amazon Linux AMI
```hcl
data "aws_ami" "latest_amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["amzn2-ami-hvm-*-x86_64-gp2"]
  }
}

resource "aws_instance" "web" {
  ami           = data.aws_ami.latest_amazon_linux.id
  instance_type = "t2.micro"
}
```

In this example, Terraform queries the latest Amazon Linux 2 AMI ID from AWS and uses it to launch an EC2 instance.

---
