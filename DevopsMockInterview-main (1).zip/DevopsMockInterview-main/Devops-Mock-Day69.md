

#### **1. How to create a new user?**
```bash
sudo useradd -m new_user
```

#### **2. How to set a password for a user?**
```bash
sudo passwd new_user
```

#### **3. How to delete a user?**
```bash
sudo userdel -r user_name
```

#### **4. How to switch to another user?**
```bash
su - user_name
```

#### **5. How to list all users on the system?**
```bash
cut -d: -f1 /etc/passwd
```

#### **6. How to lock a user account?**
```bash
sudo usermod -L user_name
```

#### **7. How to unlock a user account?**
```bash
sudo usermod -U user_name
```

#### **8. How to check the last login of a user?**
```bash
last user_name
```

#### **9. How to list users currently logged in?**
```bash
who
```

#### **10. How to add a user to a group?**
```bash
sudo usermod -aG group_name user_name
```


#### **11. How to ping a server?**
```bash
ping -c 4 server_address
```

#### **12. How to check listening ports?**
```bash
sudo netstat -tuln
```

#### **13. How to check the IP address of a server?**
```bash
ip addr show
```

#### **14. How to check network connectivity to a specific port?**
```bash
nc -zv server_address port
```

#### **15. How to trace the route to a server?**
```bash
traceroute server_address
```

#### **16. How to configure a static IP?**
Edit `/etc/network/interfaces` or `/etc/netplan/*.yaml` depending on your Linux distribution.

#### **17. How to test DNS resolution?**
```bash
nslookup domain_name
```

#### **18. How to view current ARP entries?**
```bash
arp -a
```

#### **19. How to flush DNS cache?**
```bash
sudo systemd-resolve --flush-caches
```

#### **20. How to check bandwidth usage?**
Use the `iftop` tool:
```bash
sudo iftop
```

