
1. **What is Docker, and why is it used?**  
   - **Answer**: Docker is a platform for developing, shipping, and running applications in lightweight containers. It ensures consistency across environments.  
   - **Use Case**: Developers can package an application and its dependencies into a container to run reliably in different environments.

---

2. **Explain the difference between an image and a container.**  
   - **Answer**:  
     - **Image**: A template for creating containers, like a snapshot.  
     - **Container**: A running instance of an image.  
   - **Example**:  
     ```bash
     docker pull nginx         # Pulls the Nginx image
     docker run nginx          # Runs a container from the Nginx image
     ```

---

3. **How do you create a Docker image?**  
   - **Answer**: Use a Dockerfile to define the build process and `docker build` to create the image.  
   - **Example**:  
     ```dockerfile
     FROM ubuntu:latest
     RUN apt-get update && apt-get install -y curl
     CMD ["echo", "Hello, Docker!"]
     ```
     ```bash
     docker build -t myimage .
     ```

---

4. **What is the difference between `docker run` and `docker start`?**  
   - **Answer**:  
     - `docker run`: Creates and starts a new container.  
     - `docker start`: Starts an existing stopped container.  
   - **Example**:  
     ```bash
     docker run -d nginx       # Creates and starts a new container
     docker start <container_id>  # Starts an existing container
     ```

---

5. **How do you check running Docker containers?**  
   - **Answer**: Use `docker ps`.  
   - **Example**:  
     ```bash
     docker ps
     ```

---

6. **What is the purpose of `docker-compose`?**  
   - **Answer**: It simplifies multi-container application deployment using a YAML file.  
   - **Example**:  
     ```yaml
     version: "3"
     services:
       web:
         image: nginx
         ports:
           - "8080:80"
     ```

---

7. **How do you delete unused Docker images?**  
   - **Answer**: Use `docker image prune`.  
   - **Example**:  
     ```bash
     docker image prune -f
     ```

---

8. **What is the difference between `COPY` and `ADD` in Dockerfile?**  
   - **Answer**: Both copy files to the image, but `ADD` supports additional features like extracting archives.  
   - **Example**:  
     ```dockerfile
     COPY source /app/source
     ADD archive.tar.gz /app/archive
     ```

---

9. **How do you expose a port in a Docker container?**  
   - **Answer**: Use the `EXPOSE` keyword in the Dockerfile or `-p` in the `docker run` command.  
   - **Example**:  
     ```dockerfile
     EXPOSE 80
     ```
     ```bash
     docker run -p 8080:80 nginx
     ```

---

10. **How do you log into a running Docker container?**  
    - **Answer**: Use `docker exec` or `docker attach`.  
    - **Example**:  
      ```bash
      docker exec -it <container_id> /bin/bash
      ```

