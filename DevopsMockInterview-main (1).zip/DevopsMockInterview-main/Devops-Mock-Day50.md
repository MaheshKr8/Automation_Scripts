
1. **How do you configure Ansible to manage large inventories efficiently?**
    - **Answer**: Use dynamic inventory scripts for large-scale environments like AWS, Azure, or Kubernetes. Also, group hosts into logical categories using host groups.

2. **What is the difference between `include_tasks` and `import_tasks`?**
    - **Answer**: `include_tasks` is dynamic and will be included during runtime, while `import_tasks` is static and gets included during playbook parsing.

3. **How do you ensure that a task is only run once on a host, even if the playbook is run multiple times?**
    - **Answer**: Use `creates` with tasks like `command` or `shell`. If the file exists, the task will be skipped.
    - **Example**:
      ```yaml
      - name: Run command if file does not exist
        command: /usr/bin/do_something
        args:
          creates: /path/to/file
      ```

4. **How would you set environment variables in Ansible?**
    - **Answer**: Use the `environment` keyword to set environment variables for tasks.
    - **Script Example**:
      ```yaml
      tasks:
        - name: Run script with custom environment
          command: /usr/bin/my_script
          environment:
            PATH: "/usr/local/bin:/bin"
            HOME: "/home/user"
      ```

5. **What is the purpose of the `delegate_to` keyword in Ansible?**
    - **Answer**: `delegate_to` allows you to run a task on a different host than the one specified in the play.
    - **Example**:
      ```yaml
      tasks:
        - name: Run task on control machine
          command: /usr/bin/do_something
          delegate_to: localhost
      ```

6. **How do you handle task execution failure in Ansible?**
    - **Answer**: Use `ignore_errors: yes` to allow the playbook to continue even if a task fails. Additionally, you can define `failed_when` to explicitly set when a task is considered failed.

7. **How do you add a delay between tasks in Ansible?**
    - **Answer**: Use the `pause` module to introduce delays between tasks.
    - **Script Example**:
      ```yaml
      tasks:
        - name: Pause for 10 seconds
          pause:
            seconds: 10
      ```

8. **How do you store the result of a command in a variable in Ansible?**
    - **Answer**: Use `register` to store the output of a task in a variable.
    - **Example**:
      ```yaml
      tasks:
        - name: Run command and store result
          command: /usr/bin/uptime
          register: result

        - debug:
            var: result.stdout
      ```

9. **How do you skip a task for certain hosts in Ansible?**
    - **Answer**: Use the `when` clause to conditionally skip tasks.
    - **Example**:
      ```yaml
      tasks:
        - name: Install NGINX on Ubuntu
          apt:
            name: nginx
            state: present
          when: ansible_os_family == "Debian"
      ```

10. **How do you perform a task only if a file exists?**
    - **Answer**: Use the `stat` module to check if

 a file exists, then use `when` to perform the task based on the result.
    - **Script Example**:
      ```yaml
      tasks:
        - name: Check if file exists
          stat:
            path: /path/to/file
          register: file_exists

        - name: Run task if file exists
          command: echo "File exists"
          when: file_exists.stat.exists
      ```



### 11. **How would you orchestrate a zero-downtime deployment for a web application using Ansible on a cluster of servers behind a load balancer?**

   - **Answer**: You would achieve a zero-downtime deployment by following a blue-green deployment or rolling update strategy using Ansible's `serial`, `notify`, and `delegate_to` keywords. Here's the basic flow:
     1. Remove the target server from the load balancer.
     2. Deploy the new version of the application to the target server.
     3. Verify the deployment.
     4. Add the target server back to the load balancer.

   - **Example**:
     ```yaml
     - hosts: web_servers
       serial: 1
       tasks:
         - name: Remove from load balancer
           command: /usr/local/bin/remove_from_lb {{ inventory_hostname }}
           delegate_to: load_balancer

         - name: Deploy application
           git:
             repo: 'https://github.com/myrepo/app.git'
             dest: /var/www/myapp

         - name: Check service status
           command: /usr/local/bin/check_service {{ inventory_hostname }}
           register: service_check
           until: service_check.rc == 0
           retries: 5
           delay: 10

         - name: Add back to load balancer
           command: /usr/local/bin/add_to_lb {{ inventory_hostname }}
           delegate_to: load_balancer
     ```

   **Explanation**: This playbook ensures that only one server is updated at a time, and it validates that the service is up and running before re-adding the server to the load balancer, thus ensuring zero downtime.

---

### 12. **How would you implement configuration drift detection and automatic correction in a large infrastructure using Ansible?**

   - **Answer**: You can implement configuration drift detection by using Ansible's `check_mode` to simulate the execution of a playbook without making changes. Combine this with a cron job or a scheduled Ansible Tower/AWX job to detect changes periodically. If drift is detected, Ansible can automatically enforce the desired state.

   - **Example**:
     ```yaml
     - hosts: all
       tasks:
         - name: Detect configuration drift
           command: ansible-playbook site.yml --check
           register: drift_check

         - name: Enforce configuration if drift detected
           command: ansible-playbook site.yml
           when: drift_check.changed
     ```

   **Explanation**: `--check` mode runs the playbook without making any changes, and if any drift is detected, the playbook will be re-run in normal mode to correct the drift. This can be automated via Ansible Tower or a cron job.

---

### 13. **How do you manage Ansible deployments in a multi-environment setup (e.g., dev, stage, prod) with shared and environment-specific configurations?**

   - **Answer**: You would use Ansible's `group_vars`, `host_vars`, and `inventory` directories to manage shared and environment-specific configurations. Use separate inventory files for each environment and roles for common configurations.

   - **Example Directory Structure**:
     ```
     inventory/
       dev/
         hosts
         group_vars/
           all.yml
           webservers.yml
       stage/
         hosts
         group_vars/
           all.yml
           webservers.yml
       prod/
         hosts
         group_vars/
           all.yml
           webservers.yml
     roles/
       common/
         tasks/
         templates/
       webserver/
         tasks/
         templates/
     ```

   - **Playbook Example**:
     ```yaml
     - hosts: webservers
       roles:
         - common
         - webserver
     ```

   **Explanation**: By separating the environments into their own directories, each with environment-specific variables and configurations, you can reuse the same playbooks across multiple environments while maintaining different settings for each.

---

### 14. **How would you handle sensitive information (passwords, API keys) in playbooks, ensuring both security and ease of use in a CI/CD pipeline?**

   - **Answer**: The best way to handle sensitive data in Ansible is to use **Ansible Vault** to encrypt passwords, API keys, and other sensitive information. In a CI/CD pipeline, you can securely store and decrypt these secrets when needed during the playbook run using environment variables or secure vault passwords.

   - **Example**:
     1. Encrypt sensitive variables:
        ```bash
        ansible-vault encrypt secrets.yml
        ```
     2. Use the encrypted file in your playbook:
        ```yaml
        - hosts: all
          vars_files:
            - secrets.yml
          tasks:
            - name: Deploy API key
              template:
                src: templates/config.j2
                dest: /etc/app/config.yml
        ```
     3. In a CI/CD pipeline (Jenkins, GitLab CI), use a vault password file or environment variable:
        ```bash
        ansible-playbook playbook.yml --vault-password-file /path/to/vault-password
        ```

   **Explanation**: Ansible Vault ensures that sensitive data is encrypted at rest, and the vault password can be securely passed to the pipeline as an environment variable, maintaining security and ease of use in automated workflows.

---

### 15. **You need to run different playbooks based on the type of host (e.g., database server, web server) dynamically during runtime. How would you implement this in Ansible?**

   - **Answer**: You can use the `host_vars` or `group_vars` directories to assign variables to hosts or groups, and then use `include_tasks` or `import_tasks` to dynamically include the appropriate playbook based on the host type.

   - **Example**:
     ```yaml
     - hosts: all
       tasks:
         - name: Include playbook for webservers
           include_tasks: webserver.yml
           when: "'webserver' in group_names"

         - name: Include playbook for databases
           include_tasks: db.yml
           when: "'db' in group_names"
     ```

   **Explanation**: This approach allows you to have different tasks for different server types, and only the relevant tasks will be executed based on the group a host belongs to. It's a scalable method to manage heterogeneous infrastructures.

---
