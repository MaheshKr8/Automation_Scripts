
---

### ✅ **1. Scenario: Your Jenkins build fails because of a missing dependency or tool on the build agent. How do you make builds reliable across agents?**

**Solution:**

* Containerize your build environment using **Docker**:

  * Create a custom image with all required tools (Maven, Node, etc.).
  * Use it in Jenkins pipelines:

    ```groovy
    agent {
      docker { image 'my-custom-build-env:latest' }
    }
    ```
* Alternatively, use **Jenkins shared libraries** and **pre-configured Docker agent templates**.

---

### ✅ **2. Scenario: A developer force-pushed to the `main` branch and broke the production pipeline. How do you prevent this?**

**Solution:**

* Enable **branch protection rules** in GitHub/GitLab:

  * Disallow force push.
  * Require pull request reviews and status checks (CI must pass).
* Use **Git hooks or CI pipeline rules** to enforce code review policies.
* Enable audit logging for change traceability.

---

### ✅ **3. Scenario: One of your EC2-based applications shows intermittent high CPU usage, and users report slowness. How do you identify the root cause?**

**Solution:**

* Use **CloudWatch metrics** (CPU, memory, disk, network).
* Set up **CloudWatch Agent** to collect OS-level metrics and logs.
* Correlate **application logs** (from CloudWatch Logs or ELK) to CPU spikes.
* Use **top**, **pidstat**, or **iostat** from EC2 instance to monitor real-time resource consumption.
* Use **X-Ray** or **Dynatrace** for application-level tracing.

---

### ✅ **4. Scenario: Your Kubernetes pod connects to an external database and fails with intermittent timeouts. How do you troubleshoot this?**

**Solution:**

* Check **network policies**, **DNS resolution**, and **outbound security groups**.
* Use `kubectl exec` to `curl` or `ping` the DB from within the pod.
* Validate pod has correct **service account** and **secrets**.
* If external DB uses IP whitelisting, ensure cluster nodes' IPs are whitelisted.

---

### ✅ **5. Scenario: A Docker container keeps restarting in a loop. What’s your troubleshooting approach?**

**Solution:**

* Check logs:

  ```bash
  docker logs <container_id>
  ```
* Look at container exit code:

  ```bash
  docker inspect --format='{{.State.ExitCode}}' <container_id>
  ```
* Common causes:

  * Missing environment variable.
  * Crash due to application error.
  * Not detaching in daemon mode when required.

Fix the container issue or rewrite Dockerfile/entrypoint logic as needed.

---

### ✅ **6. Scenario: Your GitLab CI/CD job fails due to “out of memory” error during a build. How do you address it?**

**Solution:**

* Optimize the build process:

  * Increase runner memory.
  * Use build tools with `--max-old-space-size` (NodeJS, Java).
* Enable **caching** for dependencies.
* Split the job into smaller stages using the **multi-stage pipeline** concept.
* Use `resource_group` or `concurrency control` to avoid overlapping memory-hungry jobs.

---

### ✅ **7. Scenario: A Terraform apply command deleted a critical resource accidentally. How do you prevent this in future?**

**Solution:**

* Use `prevent_destroy = true` in resource blocks.
* Enable **Terraform plan approvals** in CI/CD.
* Lock production state using `DynamoDB` + `S3 backend`.
* Use `terraform plan -detailed-exitcode` to gate destructive changes in pipelines.

---

### ✅ **8. Scenario: Application users in Asia report high latency, but US users are unaffected. What AWS services can you use to fix this?**

**Solution:**

* Use **Amazon CloudFront** to cache content globally.
* If it's a dynamic app, consider **Global Accelerator** for TCP acceleration.
* Deploy replicas of the app in **Asia regions** using **Route 53 latency-based routing**.

---

### ✅ **9. Scenario: Your Kubernetes deployment works fine in staging but fails in production with image pull errors. What could be wrong?**

**Solution:**

* Check image tag or registry path differences between environments.
* Check if the **imagePullSecret** is present in the production namespace:

  ```bash
  kubectl get secret -n prod
  ```
* Confirm correct access credentials to private registry.
* Validate image existence and permissions.

---

### ✅ **10. Scenario: During blue/green deployment, the green environment isn’t serving traffic after switch. How do you verify and fix it?**

**Solution:**

* Check if **readiness probes** are failing — pods may not be marked ready.
* Verify **Ingress or Service routing rules** are updated correctly.
* Use `kubectl describe service` and `get endpoints` to ensure pods are correctly attached.
* Rollback if necessary and analyze logs before retrying.

---
