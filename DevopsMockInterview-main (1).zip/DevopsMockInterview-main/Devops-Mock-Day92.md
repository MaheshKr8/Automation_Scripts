
---

### **1. How do you manage secrets securely in Terraform?**

#### **Answer:**
- Use **AWS Secrets Manager, HashiCorp Vault, or SSM Parameter Store**.
- Avoid hardcoding secrets in `.tf` files.
- Use Terraform's `sensitive` argument:
  ```hcl
  variable "db_password" {
    type      = string
    sensitive = true
  }
  ```
- Store secrets in a remote backend and retrieve them dynamically.

#### **Example:**
Fetching secrets from AWS SSM Parameter Store:
```hcl
data "aws_ssm_parameter" "db_password" {
  name = "/prod/db_password"
}
```

---

### **2. How do you handle Terraform state locking in a team environment?**

#### **Answer:**
- Use **AWS S3 backend with DynamoDB for locking** to prevent simultaneous modifications.

#### **Example:**
```hcl
terraform {
  backend "s3" {
    bucket         = "terraform-state-bucket"
    key            = "prod/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-lock"
  }
}
```

---

### **3. What happens if a Terraform apply fails in the middle of execution?**

#### **Answer:**
- Terraform follows a **partial state update** approach.
- Some resources may be created while others remain pending.
- Use `terraform state list` to inspect the current state.
- Use `terraform apply` to retry or `terraform destroy` to clean up resources.

---

### **4. How do you dynamically create multiple similar resources in Terraform?**

#### **Answer:**
- Use `count` or `for_each`.

#### **Example using count:**
```hcl
resource "aws_instance" "web" {
  count         = 3
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}
```

#### **Example using for_each:**
```hcl
variable "instances" {
  default = {
    web1 = "t2.micro"
    web2 = "t3.micro"
  }
}

resource "aws_instance" "web" {
  for_each      = var.instances
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = each.value
}
```

---

### **5. How do you deploy different environments (dev, prod) using Terraform?**

#### **Answer:**
- Use **workspaces** or **separate state files**.

#### **Using workspaces:**
```bash
terraform workspace new dev
terraform workspace select dev
terraform apply
```

#### **Using separate state files:**
```hcl
terraform {
  backend "s3" {
    key = "env/${terraform.workspace}/terraform.tfstate"
  }
}
```

---

### **6. What are Terraform Provisioners, and when should you use them?**

#### **Answer:**
- **Provisioners execute scripts on local or remote machines**.
- Used for configuration after resource creation.
- Not recommended for infrastructure management.

#### **Example (remote-exec provisioner to run a script on an EC2 instance):**
```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  provisioner "remote-exec" {
    inline = [
      "sudo apt update",
      "sudo apt install nginx -y"
    ]
  }
}
```

---

### **7. How do you handle drift detection in Terraform?**

#### **Answer:**
- Run `terraform plan` regularly to detect differences.
- Use `terraform apply` to reconcile changes.
- Integrate Terraform drift detection into a **CI/CD pipeline**.

#### **Example (GitHub Actions for drift detection):**
```yaml
- name: Terraform Plan
  run: terraform plan -out=tfplan
```

---

### **8. How do you optimize Terraform execution time?**

#### **Answer:**
- Use **parallelism** (`terraform apply -parallelism=10`).
- Avoid unnecessary dependencies (`depends_on` only where needed).
- Use **data sources** to fetch existing resources instead of creating new ones.

---

### **9. How do you perform a rollback in Terraform?**

#### **Answer:**
1. Use **Terraform state snapshots**:
   ```bash
   terraform state pull > backup.tfstate
   ```

2. If needed, restore:
   ```bash
   terraform state push backup.tfstate
   ```

3. Roll back using version control:
   ```bash
   git checkout previous_version
   terraform apply
   ```

---

### **10. How do you enforce compliance policies in Terraform?**

#### **Answer:**
- Use **Sentinel policies** (for HashiCorp Terraform Cloud).
- Use **OPA (Open Policy Agent)** with Terraform Cloud or CI/CD pipelines.
- Define required tags and security settings in policies.

#### **Example (Deny EC2 without tags using Sentinel Policy):**
```hcl
policy "require_tags" {
  enforcement_level = "hard-mandatory"
  rule {
    all tfplan.resources.aws_instance[*].tags {
      exists value["Environment"]
    }
  }
}
```

---
