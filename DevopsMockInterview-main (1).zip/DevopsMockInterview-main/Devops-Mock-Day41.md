1. **How do you debug DNS issues in Kubernetes?**
    - **Explanation**: DNS issues can be debugged by checking CoreDNS logs, ensuring DNS policies are correct, and using tools like `nslookup` or `dig` within a Pod.
    - **Real-life example**: A Pod cannot resolve the service name due to a DNS misconfiguration.
    - **Command**:
      ```bash
      kubectl exec -it <pod-name> -- nslookup <service-name>
      ```

2. **What is kube-proxy, and how does it manage networking in Kubernetes?**
    - **Explanation**: Kube-proxy manages network rules and load balancing for Services in Kubernetes.
    - **Real-life example**: Forwarding traffic from an external service to the correct backend Pods.
    - **Command**:
      ```bash
      # Check kube-proxy logs
      kubectl logs -n kube-system <kube-proxy-pod>
      ```

3. **How do you handle network congestion or performance issues in Kubernetes?**
    - **Explanation**: Network policies, pod resource limits, and quality of service (QoS) settings can help alleviate congestion.
    - **Real-life example**: Throttling resource usage in Pods that consume excessive network bandwidth.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Pod
      metadata:
        name: throttled-pod
      spec:
        containers:
        - name: nginx
          image: nginx
          resources:
            limits:
              memory: "256Mi"
              cpu: "500m"
      ```



4. **How do you perform an in-place upgrade of Kubernetes clusters?**
    - **Explanation**: Upgrading clusters usually involves upgrading the control plane components first, followed by the worker nodes.
    - **Real-life example**: Upgrading a Kubernetes cluster from version 1.20 to 1.21 using a managed service like EKS.
    - **Command**:
      ```bash
      # Upgrade control plane in a managed Kubernetes service (e.g., EKS)
      eksctl upgrade cluster --name my-cluster --version 1.21
      ```

5. **How do you handle large-scale application deployments across multiple clusters?**
    - **Explanation**: Multi-cluster deployment strategies, such as Federation or GitOps, help manage large-scale applications across different clusters.
    - **Real-life example**: Deploying a global application with services distributed across clusters in different regions.
    - **Command**:
      ```bash
      # Use GitOps for multi-cluster deployments
      flux create source git multi-cluster-repo --url=https://github.com/my-org/multi-cluster-deployments.git
      ```

6. **What is the difference between vertical scaling and horizontal scaling in Kubernetes?**
    - **Explanation**: Horizontal scaling increases or decreases the number of Pods, while vertical scaling adjusts the resources (CPU, memory) allocated to a single Pod.
    - **Real-life example**: Using Horizontal Pod Autoscaler (HPA) to scale the number of Pods during high traffic.
    - **Command**:
      ```bash
      kubectl autoscale deployment my-app --cpu-percent=80 --min=2 --max=10
      ```


7. **What is a blue-green deployment in Kubernetes?**
    - **Explanation**: A blue-green deployment creates two environments (blue and green) where traffic is gradually switched from one to another.
    - **Real-life example**: Deploying a new version of an application with zero downtime by switching from blue to green.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: Deployment
      metadata:
        name: blue-deployment
      spec:
        replicas: 3
        selector:
          matchLabels:
            app: my-app
        template:
          metadata:
            labels:
              app: my-app
              version: blue
          spec:
            containers:
            - name: my-app-container
              image: my-app:v1
      ```

8. **How do you implement canary deployments in Kubernetes?**
    - **Explanation**: Canary deployments gradually introduce a new version of an application to a small subset of users before rolling out to the entire user base.
    - **Real-life example**: Deploying version 2 of an app to 10% of users, and if successful, scaling it to all users.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: Deployment
      metadata:
        name: canary-deployment
      spec:
        replicas: 1
        selector:
          matchLabels:
            app: my-app
            version: canary
        template:
          metadata:
            labels:
              app: my-app
              version: canary
          spec:
            containers:
            - name: my-app-container
              image: my-app:v2
      ```

9. **What are shadow deployments in Kubernetes?**
    - **Explanation**: Shadow deployments send real user traffic to both the old and new versions without the users being aware, allowing you to test the new version without affecting user experience.
    - **Real-life example**: Sending mirrored traffic to a new microservice version for load testing.
    - **Command**:
      ```yaml
      apiVersion: networking.istio.io/v1alpha3
      kind: VirtualService
      metadata:
        name: my-app
      spec:
        hosts:
        - "my-app.com"
        http:
        - match:
          - uri:
              prefix: "/"
          route:
          - destination:
              host: my-app
              subset: v1
          mirror:
            host: my-app
            subset: v2
      ```

10. **How do you deal with failed rollouts in Kubernetes?**
    - **Explanation**: Use `kubectl rollout undo` to revert to a previous version if a deployment fails.
    - **Real-life example**: A new release causes errors, and you roll back to the previous stable version.
    - **Command**:
      ```bash
      kubectl rollout undo deployment/my-app
      ```
