
---

### **1. What is Kubernetes and why is it used?**

**Answer:**
Kubernetes is an open-source container orchestration platform that automates deployment, scaling, load balancing, and management of containerized applications.
It is used to:

* Run apps across clusters for high availability.
* Auto-scale workloads based on demand.
* Provide self-healing (restart failed pods automatically).

---

### **2. What are the main components of a Kubernetes cluster?**

**Answer:**

* **Control Plane (Master Node):**

  * API Server: Manages cluster communication.
  * etcd: Stores cluster state.
  * Scheduler: Assigns Pods to Nodes.
  * Controller Manager: Ensures desired state.
* **Worker Node:**

  * Kubelet: Manages Pods on the node.
  * Kube-proxy: Handles networking and load balancing.
  * Container runtime (Docker/containerd).

---

### **3. What is a Pod in Kubernetes?**

**Answer:**
A Pod is the smallest deployable unit in Kubernetes.
It can contain **one or more containers** that share the same network and storage space.
Pods are ephemeral and usually managed by higher-level controllers like Deployments.

---

### **4. What is a Deployment in Kubernetes?**

**Answer:**
A Deployment is a controller that:

* Manages ReplicaSets.
* Ensures desired number of Pods.
* Enables rolling updates and rollbacks.

Command to create:

```bash
kubectl create deployment myapp --image=nginx
```

---

### **5. What is the difference between a ReplicaSet and a Deployment?**

**Answer:**

* **ReplicaSet:** Ensures a specific number of identical Pods are running.
* **Deployment:** Manages ReplicaSets, adds features like rolling updates and rollbacks.

---

### **6. How does Kubernetes handle scaling?**

**Answer:**

* **Manual Scaling:**

  ```bash
  kubectl scale deployment myapp --replicas=5
  ```
* **Automatic Scaling (HPA):**

  ```bash
  kubectl autoscale deployment myapp --cpu-percent=70 --min=2 --max=10
  ```

Requires **Metrics Server** to monitor resource usage.

---

### **7. What is a Service in Kubernetes and why is it needed?**

**Answer:**
A Service exposes Pods internally or externally and provides:

* A **stable DNS name**.
* **Load balancing** across Pod replicas.

Types:

* ClusterIP (default, internal only)
* NodePort (external access via node IP)
* LoadBalancer (cloud-based)
* ExternalName (DNS alias)

---

### **8. What is a ConfigMap and Secret in Kubernetes?**

**Answer:**

* **ConfigMap:** Stores non-sensitive config data (e.g., app settings).
* **Secret:** Stores sensitive data (e.g., passwords, certificates).
  Both can be mounted as environment variables or files inside Pods.

---

### **9. How do you expose a Deployment to the outside world?**

**Answer:**

* Use a **Service** of type **NodePort** or **LoadBalancer**.
* Or use an **Ingress** with a controller (NGINX, Traefik) for HTTP/HTTPS routing.

Example:

```bash
kubectl expose deployment myapp --type=LoadBalancer --port=80 --target-port=8080
```

---

### **10. How do you debug a failing Pod?**

**Answer:**

1. Check Pod status:

   ```bash
   kubectl get pods
   ```
2. Describe for events:

   ```bash
   kubectl describe pod <pod-name>
   ```
3. Check logs:

   ```bash
   kubectl logs <pod-name>
   ```
4. Open shell inside Pod:

   ```bash
   kubectl exec -it <pod-name> -- /bin/sh
   ```

---

