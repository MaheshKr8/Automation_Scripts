Here are some **real-time Git interview questions** that focus on practical scenarios encountered in a DevOps or software development environment:

---

### **1. Scenario:** You accidentally committed sensitive information (e.g., passwords, API keys) to a Git repository. How do you remove it from history?  

**Answer:**  
- First, remove the sensitive file locally:  
  ```bash
  git rm --cached <file>
  ```
- If it was already committed, use `git filter-branch` or `BFG Repo-Cleaner` to rewrite history:  
  ```bash
  git filter-branch --force --index-filter 'git rm --cached --ignore-unmatch <file>' --prune-empty --tag-name-filter cat -- --all
  ```
- Force push to remove the file from remote history:  
  ```bash
  git push origin --force --all
  ```
- Rotate credentials immediately, as they may have been exposed.

---

### **2. Scenario:** You made several commits on your branch but want to combine them into a single commit before merging. How do you do this?  

**Answer:**  
Use interactive rebase:  
```bash
git rebase -i HEAD~<number_of_commits>
```
- Mark the first commit as `pick` and the others as `squash (s)`.  
- Save and exit the editor.  
- Amend the commit message if necessary.  
- Push with force if changes were already pushed:  
  ```bash
  git push origin <branch> --force
  ```

---

### **3. Scenario:** A teammate force-pushed to the main branch, causing conflicts. How do you recover?  

**Answer:**  
- First, fetch the latest changes:  
  ```bash
  git fetch origin
  ```
- Check the logs to compare your local changes:  
  ```bash
  git log --oneline --graph --decorate --all
  ```
- If necessary, reset your branch:  
  ```bash
  git reset --hard origin/main
  ```
- If you have local changes you need to save, stash them before resetting:  
  ```bash
  git stash
  git reset --hard origin/main
  git stash pop
  ```

---

### **4. Scenario:** You need to push a commit to a remote branch but don’t want to trigger a CI/CD pipeline. How do you do it?  

**Answer:**  
Use an **empty commit** or **skip CI keywords**:  
- Create an empty commit:  
  ```bash
  git commit --allow-empty -m "Trigger rebuild [skip ci]"
  git push origin <branch>
  ```
- Some CI/CD tools respect commit messages like `[skip ci]` or `[ci skip]`, preventing a pipeline run.

---

### **5. Scenario:** You need to find and revert a specific commit that introduced a bug. How do you do it?  

**Answer:**  
- Identify the commit:  
  ```bash
  git log --oneline
  ```
- Revert it:  
  ```bash
  git revert <commit-hash>
  ```
- If reverting multiple commits:  
  ```bash
  git revert HEAD~2..HEAD
  ```
- Push the changes:  
  ```bash
  git push origin <branch>
  ```

---

### **6. Scenario:** You accidentally deleted an important local branch. How do you recover it?  

**Answer:**  
- Check the reflog to find the last known commit:  
  ```bash
  git reflog
  ```
- Restore the branch:  
  ```bash
  git checkout -b <branch> <commit-hash>
  ```

---

### **7. Scenario:** Your merge request (MR) was rejected because the commit history was messy. How do you clean it up?  

**Answer:**  
- Use interactive rebase:  
  ```bash
  git rebase -i main
  ```
- Squash, edit, or drop commits as needed.  
- Force push the cleaned branch:  
  ```bash
  git push origin <branch> --force
  ```

---

### **8. Scenario:** Your team follows a Git workflow with feature branches, but a teammate accidentally committed directly to `main`. How do you fix this?  

**Answer:**  
- Create a new branch from the commit:  
  ```bash
  git branch feature-fix <commit-hash>
  ```
- Reset `main` to the last correct commit:  
  ```bash
  git reset --hard <previous-commit-hash>
  git push origin main --force
  ```
- Merge the feature branch properly via a pull request.

---

### **9. Scenario:** You need to share changes with a teammate before pushing them to the remote repository. How do you do it?  

**Answer:**  
Use `git bundle` or a local patch:  
- Create a patch:  
  ```bash
  git format-patch -1 <commit-hash>
  ```
- Apply the patch on the teammate’s machine:  
  ```bash
  git apply <patch-file>
  ```
Alternatively, use `git bundle` to create a portable repository file.

---

### **10. Scenario:** You are working on a feature branch, but you need the latest changes from `main`. How do you update your branch safely?  

**Answer:**  
- Fetch the latest changes:  
  ```bash
  git fetch origin
  ```
- Option 1: **Merge (Safe, keeps history)**  
  ```bash
  git checkout feature-branch
  git merge main
  ```
- Option 2: **Rebase (Cleaner history, may require conflict resolution)**  
  ```bash
  git checkout feature-branch
  git rebase main
  ```
- If conflicts occur, resolve them and continue the rebase:  
  ```bash
  git rebase --continue
  ```

---

### **Bonus Tips for Git Interviews**
- Know when to use `merge` vs. `rebase`  
- Understand Git branching strategies (GitFlow, Trunk-based development)  
- Be comfortable with troubleshooting commands like `git reflog`, `git reset`, `git revert`  
- Explain best practices for handling large repositories  

