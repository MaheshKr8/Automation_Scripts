## Devops Real-Time Interview Questions
### 1. Scenario: I have one GitHub repository and I have a set of jobs in Jenkins. It is integrated with pollSCM. Now, whenever a commit happens, in general, the build will be automatically triggered. I don't want the build to be triggered for every commit; I want it to trigger only when a particular file is changed. How will you configure that?

* Certainly! Below are the steps for configuring Jenkins to trigger a build only when specific files change, followed by practical examples using both Declarative Pipeline and Freestyle Project configurations.

### Prerequisites
* 1. A Jenkins server set up and running.
* 2. A Jenkins job configured to poll SCM (GitHub repository in this case).

### Steps to Configure

* 1. **Navigate to Your Jenkins Job:**
   - Open Jenkins and navigate to the job you want to configure.

* 2. **Configure the Job:**
   - Click on `Configure`.

* 3. **Source Code Management:**
   - Ensure your repository URL and credentials are correctly set under the "Source Code Management" section.

* 4. **Build Triggers:**
   - Ensure that `Poll SCM` is checked.

* 5. **Polling Schedule:**
   - In the Poll SCM schedule, you can set the frequency at which Jenkins should check for changes. For example, `H/5 * * * *` will check every 5 minutes.

* 6. **Configure the Jenkinsfile:**
   - Create or update the `Jenkinsfile` in your repository with the appropriate pipeline script.

### Declarative Pipeline Example

```groovy
pipeline {
    agent any

    triggers {
        pollSCM('H/5 * * * *')
    }

    environment {
        TRIGGER_FILES = 'config/settings.yml,src/main/resources/application.properties'
    }

    stages {
        stage('Check Changes') {
            when {
                changeset includes: "${env.TRIGGER_FILES}"
            }
            steps {
                script {
                    echo 'Relevant files have changed. Proceeding with the build...'
                }
            }
        }
        stage('Build') {
            steps {
                echo 'Running the build...'
                // Add your build steps here
            }
        }
    }

    post {
        always {
            echo 'Cleaning up...'
            // Add cleanup steps if necessary
        }
    }
}
```

### Explanation for Declarative Pipeline

* 1. **Poll SCM:** Polls the SCM every 5 minutes (`H/5 * * * *`).
* 2. **Environment Variable:** `TRIGGER_FILES` is a comma-separated list of the files you want to monitor.
* 3. **`when` Directive:** Checks if the specified files have changed using the `changeset` condition.
* 4. **Stages:** If the specified files have changed, the pipeline proceeds with the build.

### Freestyle Project Example

* Here is how to set up a Jenkins Freestyle project to trigger a build only when specific files change.

* 1. **Navigate to Your Jenkins Job:**
   - Open Jenkins and navigate to the job you want to configure.

* 2. **Configure the Job:**
   - Click on `Configure`.

* 3. **Source Code Management:**
   - Ensure your repository URL and credentials are correctly set under the "Source Code Management" section.

* 4. **Build Triggers:**
   - Ensure that `Poll SCM` is checked.

* 5. **Polling Schedule:**
   - In the Poll SCM schedule, you can set the frequency at which Jenkins should check for changes. For example, `H/5 * * * *` will check every 5 minutes.

* 6. **Add a Build Step to Check for Changes:**
   - In the `Build` section, add a build step to execute a shell script.

#### Shell Script

```sh
#!/bin/bash

# List of files to monitor
trigger_files=("config/settings.yml" "src/main/resources/application.properties")

# Get the list of changed files in the last commit
changed_files=$(git diff-tree --no-commit-id --name-only -r HEAD)

# Check if any of the trigger files have changed
build_triggered=false
for trigger_file in "${trigger_files[@]}"; do
  if echo "$changed_files" | grep -q "$trigger_file"; then
    build_triggered=true
    break
  fi
done

# If no relevant changes detected, exit with a non-zero status to abort the build
if [ "$build_triggered" = false ]; then
  echo "No relevant changes detected. Aborting build."
  exit 1
else
  echo "Relevant changes detected. Proceeding with the build..."
fi
```

### Steps to Use the Shell Script

* 1. **Navigate to the `Build` Section:**
   - In the project configuration, navigate to the `Build` section.
   - Click on `Add build step` and select `Execute shell`.

* 2. **Add the Shell Script:**
   - Copy and paste the provided shell script into the `Command` text box.

* 3. **Save the Configuration:**
   - Click `Save` to apply the changes.

### Explanation for Freestyle Project

* 1. **Poll SCM:** Jenkins will still check the repository at the specified intervals.
* 2. **Shell Script:**
   - Retrieves the list of files changed in the last commit.
   - Compares the changed files against the list of files you want to monitor (`trigger_files`).
   - If none of the specified files were changed, the script exits with a non-zero status, causing Jenkins to abort the build.
   - If any of the specified files were changed, the script allows the build to proceed.

### Example Files

- If you want to trigger a build only when `config/settings.yml` or `src/main/resources/application.properties` changes, update the `trigger_files` array in the shell script like this:

```sh
trigger_files=("config/settings.yml" "src/main/resources/application.properties")
```

* This setup ensures that your Jenkins Freestyle project triggers a build only when specific files in your GitHub repository change.

### 2) How do you perform backup and restore using Jenkins?

* Performing backup and restore in Jenkins is crucial for maintaining the integrity and continuity of your Jenkins setup. Here’s a step-by-step guide on how to back up and restore Jenkins:

### Backing Up Jenkins

#### 1. Manual Backup

* To manually back up Jenkins, you need to back up the JENKINS_HOME directory. This directory contains all the configuration files, job configurations, plugins, and other essential data.

**Steps:**

* 1. **Stop Jenkins:**
   - It’s recommended to stop Jenkins before taking a backup to ensure data consistency.
   - You can stop Jenkins using the following commands based on your operating system:
     - **Linux:**
       ```sh
       sudo service jenkins stop
       ```
     - **Windows:**
       Stop the Jenkins service from the Services management console or by using the command:
       ```sh
       net stop jenkins
       ```

* 2. **Locate JENKINS_HOME:**
   - The location of JENKINS_HOME can vary. Common locations include `/var/lib/jenkins`, `/usr/share/jenkins`, or specified in your Jenkins configuration file.

* 3. **Copy JENKINS_HOME:**
   - Copy the entire JENKINS_HOME directory to your backup location.
   - Use the following command:
     - **Linux:**
       ```sh
       cp -r /var/lib/jenkins /path/to/backup/location
       ```
     - **Windows:**
       Copy the Jenkins directory to your backup location using File Explorer or the command:
       ```sh
       xcopy C:\ProgramData\Jenkins D:\backup\Jenkins /E /H /C /I
       ```

* 4. **Restart Jenkins:**
   - After the backup is complete, restart Jenkins.
     - **Linux:**
       ```sh
       sudo service jenkins start
       ```
     - **Windows:**
       Start the Jenkins service from the Services management console or by using the command:
       ```sh
       net start jenkins
       ```

#### 2. Automated Backup Using a Plugin

* You can use the ThinBackup plugin to automate the backup process.

**Steps:**

* 1. **Install ThinBackup Plugin:**
   - Go to `Manage Jenkins` > `Manage Plugins`.
   - Under the `Available` tab, search for `ThinBackup`.
   - Install the plugin and restart Jenkins if necessary.

* 2. **Configure ThinBackup:**
   - Go to `Manage Jenkins` > `ThinBackup`.
   - Configure the backup settings, such as backup schedule, backup location, and what to include in the backup.
   - Save the configuration.

* 3. **Perform Backup:**
   - You can perform a manual backup by clicking `Backup Now` in the ThinBackup configuration page.
   - ThinBackup will also perform backups according to the schedule you configured.

### Restoring Jenkins

#### 1. Manual Restore

* To manually restore Jenkins from a backup, you need to replace the current JENKINS_HOME directory with your backup.

**Steps:**

* 1. **Stop Jenkins:**
   - Stop Jenkins to ensure data consistency during the restore process.
     - **Linux:**
       ```sh
       sudo service jenkins stop
       ```
     - **Windows:**
       Stop the Jenkins service from the Services management console or by using the command:
       ```sh
       net stop jenkins
       ```

* 2. **Replace JENKINS_HOME:**
   - Replace the current JENKINS_HOME directory with your backup.
     - **Linux:**
       ```sh
       rm -rf /var/lib/jenkins
       cp -r /path/to/backup/location/jenkins /var/lib/jenkins
       ```
     - **Windows:**
       Delete the current Jenkins directory and replace it with the backup using File Explorer or the command:
       ```sh
       rmdir /S /Q C:\ProgramData\Jenkins
       xcopy D:\backup\Jenkins C:\ProgramData\Jenkins /E /H /C /I
       ```

* 3. **Restart Jenkins:**
   - After the restore is complete, restart Jenkins.
     - **Linux:**
       ```sh
       sudo service jenkins start
       ```
     - **Windows:**
       Start the Jenkins service from the Services management console or by using the command:
       ```sh
       net start jenkins
       ```

#### 2. Restore Using ThinBackup

* If you used ThinBackup for your backup, you can restore using the plugin as well.

**Steps:**

* 1. **Go to ThinBackup Restore:**
   - Go to `Manage Jenkins` > `ThinBackup`.

* 2. **Select Backup to Restore:**
   - Click on `Restore` and select the backup you want to restore from the list of available backups.

* 3. **Start the Restore:**
   - Click `Restore Now`. ThinBackup will replace the current JENKINS_HOME with the selected backup.

* 4. **Restart Jenkins:**
   - Restart Jenkins after the restore process is complete to ensure all changes take effect.

* By following these steps, you can effectively back up and restore your Jenkins setup to ensure data safety and quick recovery in case of any issues.

* Certainly! Here’s how to use credentials within a Groovy script in a Jenkins Declarative Pipeline.


### 3) How can you mention the credentials within the Groovy?

* Steps to Manage Credentials
* 1. **Add Credentials to Jenkins:**
   - Go to `Jenkins Dashboard` > `Manage Jenkins` > `Manage Credentials`.
   - Select the appropriate domain (e.g., `Global`).
   - Click on `Add Credentials`.
   - Choose the type of credentials (e.g., `Username with password`, `Secret text`, `SSH Username with private key`).
   - Fill in the details and save the credentials.
   - Note the ID of the credentials you just created. This ID will be used in the Groovy script.

### Using Credentials in a Declarative Pipeline

#### Example 1: Username and Password

* Here’s an example of how to use `Username with password` credentials within a Declarative Pipeline:

```groovy
pipeline {
    agent any

    environment {
        DB_CREDENTIALS = credentials('db-credentials-id')
    }

    stages {
        stage('Example') {
            steps {
                script {
                    def dbUsername = env.DB_CREDENTIALS_USR
                    def dbPassword = env.DB_CREDENTIALS_PSW

                    echo "Database Username: ${dbUsername}"
                    // Do not echo the password in a real script for security reasons
                    // echo "Database Password: ${dbPassword}"
                }
            }
        }
    }
}
```

* In this example:
- The `credentials` method is used to fetch the credentials by their ID and store them in environment variables.
- The `credentials('db-credentials-id')` method will automatically create environment variables like `DB_CREDENTIALS_USR` and `DB_CREDENTIALS_PSW` for `Username with password` credentials.

#### Example 2: Secret Text

* Here’s an example of how to use `Secret text` credentials within a Declarative Pipeline:

```groovy
pipeline {
    agent any

    environment {
        SECRET_TEXT = credentials('secret-text-id')
    }

    stages {
        stage('Example') {
            steps {
                script {
                    def secret = env.SECRET_TEXT

                    echo "Secret Text: ${secret}"
                }
            }
        }
    }
}
```

In this example:
- The `credentials` method is used to fetch the secret text by its ID and store it in an environment variable.

#### Example 3: SSH Private Key

* Here’s an example of how to use an `SSH Username with private key` credentials within a Declarative Pipeline:

```groovy
pipeline {
    agent any

    stages {
        stage('Checkout') {
            steps {
                script {
                    def sshCredentialsId = 'ssh-credentials-id'
                    
                    withCredentials([sshUserPrivateKey(credentialsId: sshCredentialsId, keyFileVariable: 'SSH_KEY', usernameVariable: 'SSH_USER')]) {
                        sh '''
                            echo "Using SSH Key"
                            ssh -i $SSH_KEY $SSH_USER@hostname
                        '''
                    }
                }
            }
        }
    }
}
```

* In this example:
- The `withCredentials` block is used to wrap the code that needs access to the SSH credentials.
- Environment variables like `SSH_KEY` and `SSH_USER` are used within the script.

* These examples show how to securely handle different types of credentials in a Jenkins Declarative Pipeline using Groovy.

### 4) How will you enable role access for the users in Jenkins?


* Enabling role-based access control (RBAC) for users in Jenkins typically involves using the "Role-based Authorization Strategy" plugin. This plugin allows you to define roles with specific permissions and assign these roles to users or groups. Here's a step-by-step guide to enable and configure role-based access in Jenkins:

### Steps to Enable Role-Based Access Control

#### 1. Install the Role-based Authorization Strategy Plugin

* 1. **Navigate to Manage Plugins:**
   - Go to `Jenkins Dashboard` > `Manage Jenkins` > `Manage Plugins`.

* 2. **Install the Plugin:**
   - Click on the `Available` tab.
   - Search for `Role-based Authorization Strategy`.
   - Check the box next to the plugin and click `Install without restart`.

#### 2. Configure Role-based Authorization Strategy

* 1. **Navigate to Configure Global Security:**
   - Go to `Jenkins Dashboard` > `Manage Jenkins` > `Configure Global Security`.

* 2. **Select Role-based Authorization Strategy:**
   - Under the `Authorization` section, select `Role-based Authorization Strategy`.
   - Click `Save`.

#### 3. Define Roles

* 1. **Navigate to Manage and Assign Roles:**
   - Go to `Jenkins Dashboard` > `Manage Jenkins` > `Manage and Assign Roles` > `Manage Roles`.

* 2. **Create New Roles:**
   - Under `Manage Roles`, you can create new roles and define their permissions.
   - Define roles for both `Global roles` and `Project roles` as needed.
     - **Global roles**: Roles with permissions that apply across the entire Jenkins instance.
     - **Project roles**: Roles with permissions specific to certain jobs or folders.

* 3. **Set Permissions:**
   - For each role, select the permissions it should have by checking the appropriate boxes.
   - Click `Save` to apply the changes.

#### 4. Assign Roles to Users

* 1. **Navigate to Assign Roles:**
   - Go to `Jenkins Dashboard` > `Manage Jenkins` > `Manage and Assign Roles` > `Assign Roles`.

* 2. **Assign Global Roles:**
   - Under the `Global roles` section, enter the username or group name in the appropriate field and assign the desired roles.

* 3. **Assign Project Roles:**
   - Under the `Project roles` section, specify the project name pattern and assign roles to users or groups for those projects.

* 4. **Save Assignments:**
   - Click `Save` to apply the changes.

### Example Configuration

#### Define Roles

* 1. **Create Admin Role:**
   - Role name: `admin`
   - Permissions: All permissions checked.

* 2. **Create Developer Role:**
   - Role name: `developer`
   - Permissions: Job (read, build, workspace), SCM (tag), View (read), and other permissions as needed.

* 3. **Create Viewer Role:**
   - Role name: `viewer`
   - Permissions: Job (read), View (read).

#### Assign Roles to Users

* 1. **Assign Admin Role:**
   - Under `Global roles`, enter the username `admin_user` and check the `admin` role.

* 2. **Assign Developer Role:**
   - Under `Global roles`, enter the username `dev_user` and check the `developer` role.

* 3. **Assign Viewer Role:**
   - Under `Global roles`, enter the username `view_user` and check the `viewer` role.

* 4. **Assign Project-specific Role:**
   - Under `Project roles`, specify the project name pattern (e.g., `my-project-*`), enter the username `proj_user`, and assign the `developer` role.

### Additional Tips

- **LDAP/AD Integration:** If your Jenkins instance is integrated with LDAP or Active Directory, you can assign roles to LDAP groups instead of individual users.
- **Regular Review:** Regularly review and update roles and permissions to ensure they align with your organization's security policies.
- **Role Hierarchy:** Consider creating a role hierarchy where roles inherit permissions from other roles to simplify management.

* By following these steps, you can effectively manage user access and permissions in Jenkins using role-based access control.


## 5. Scenario: When there are code conflicts while merging, what is your approach and how will you recover that using command-based methods?

* When code conflicts occur during a merge, it's important to handle them carefully to ensure that the final codebase remains stable and functional. Here’s a step-by-step guide to resolving merge conflicts using Git commands:

### Steps to Resolve Merge Conflicts

#### 1. Identify the Conflict

- When you attempt to merge a branch and conflicts occur, Git will inform you of the files that have conflicts.
- Example command that leads to a conflict:
  ```sh
  git merge feature-branch
  ```
- Git output indicating conflicts:
  ```
  Auto-merging file1.txt
  CONFLICT (content): Merge conflict in file1.txt
  Automatic merge failed; fix conflicts and then commit the result.
  ```

#### 2. Check the Status

- Use the `git status` command to see which files have conflicts.
  ```sh
  git status
  ```
- Example output:
  ```
  On branch master
  You have unmerged paths.
    (fix conflicts and run "git commit")

  Unmerged paths:
    (use "git add <file>..." to mark resolution)

    both modified:   file1.txt

  no changes added to commit (use "git add" and/or "git commit -a")
  ```

#### 3. Open and Resolve Conflicts

- Open the conflicted files in a text editor. You will see conflict markers indicating the conflicting sections.
  ```sh
  <<<<<<< HEAD
  Current change in the master branch
  =======
  Change from the feature-branch
  >>>>>>> feature-branch
  ```
- Manually edit the file to resolve the conflicts. Choose the changes you want to keep or combine them as necessary.

#### 4. Mark the Conflict as Resolved

- After resolving the conflicts, use the `git add` command to mark the files as resolved.
  ```sh
  git add file1.txt
  ```

#### 5. Complete the Merge

- Once all conflicts are resolved and added, commit the changes to complete the merge.
  ```sh
  git commit -m "Resolved merge conflicts"
  ```

### Example Commands to Resolve Merge Conflicts

Here’s a practical example of resolving conflicts step-by-step:

* 1. **Start the Merge:**
   ```sh
   git merge feature-branch
   ```

* 2. **Identify Conflicts:**
   ```sh
   git status
   ```

* 3. **Open and Edit Conflicted Files:**
   ```sh
   nano file1.txt
   ```
   - Resolve the conflicts manually in the editor.

* 4. **Mark as Resolved:**
   ```sh
   git add file1.txt
   ```

* 5. **Commit the Merge:**
   ```sh
   git commit -m "Resolved merge conflicts"
   ```

### Advanced Techniques

#### Using `git mergetool`

- You can use `git mergetool` to open a graphical or command-line merge tool to help resolve conflicts.
  ```sh
  git mergetool
  ```

#### Aborting a Merge

- If you decide not to proceed with the merge, you can abort it.
  ```sh
  git merge --abort
  ```

#### Creating a New Branch for Conflict Resolution

- Sometimes, it's useful to create a new branch to resolve conflicts, allowing you to isolate the work.
  ```sh
  git checkout -b conflict-resolution
  # Resolve conflicts here
  git add file1.txt
  git commit -m "Resolved conflicts"
  git checkout master
  git merge conflict-resolution
  ```

### Summary

* Resolving merge conflicts involves:
* 1. Attempting the merge and identifying the conflicts.
* 2. Reviewing the conflicted files and manually resolving the conflicts.
* 3. Marking the resolved files as resolved with `git add`.
* 4. Committing the resolved merge.

* By following these steps, you can effectively handle and recover from merge conflicts using Git commands.
