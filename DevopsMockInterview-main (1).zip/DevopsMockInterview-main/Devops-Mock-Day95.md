
---

## **🔍 10 Real-Time Docker Interview Questions**  

### **1. Your application inside a Docker container is failing to start. How would you debug and fix it?**  
✅ **Answer:**  
1. **Check container logs**  
   ```bash
   docker logs <container-id>
   ```
2. **Run the container in interactive mode** to inspect:  
   ```bash
   docker run -it --rm <image-name> /bin/sh
   ```
3. **Check exit status**  
   ```bash
   docker inspect <container-id> --format='{{.State.ExitCode}}'
   ```
📌 **Identifies issues like missing dependencies or incorrect configurations.**  

---

### **2. A containerized application works on your local machine but fails when deployed on another server. How do you troubleshoot this?**  
✅ **Answer:**  
1. **Check image compatibility**  
   ```bash
   docker image inspect <image-name>
   ```
2. **Check environment variables** using `docker inspect`.  
3. **Ensure dependencies exist** (e.g., correct Python or Node.js version).  
4. **Verify network settings** with `docker network ls`.  
📌 **Fixes deployment issues due to system differences.**  

---

### **3. How do you optimize the size of a Docker image?**  
✅ **Answer:**  
1. Use **multi-stage builds**  
   ```dockerfile
   FROM node:18 AS builder
   WORKDIR /app
   COPY . .
   RUN npm install && npm run build

   FROM node:18
   WORKDIR /app
   COPY --from=builder /app/dist /app/dist
   CMD ["node", "app/dist/server.js"]
   ```
2. **Use smaller base images (e.g., Alpine Linux)**  
   ```dockerfile
   FROM python:3.9-alpine
   ```
3. **Remove unnecessary files** with `.dockerignore`  
📌 **Reduces image size, improving build and deployment speed.**  

---

### **4. Your Docker container is running out of disk space. How do you analyze and resolve it?**  
✅ **Answer:**  
1. **Check Docker disk usage:**  
   ```bash
   docker system df
   ```
2. **Remove unused images, containers, and volumes:**  
   ```bash
   docker system prune -a
   ```
3. **Use bind mounts instead of storing data inside containers.**  
📌 **Prevents unnecessary disk usage and improves performance.**  

---

### **5. How do you securely store and manage environment variables in Docker?**  
✅ **Answer:**  
1. **Use Docker Secrets (Swarm mode)**  
   ```bash
   echo "my_secret_value" | docker secret create my_secret -
   ```
2. **Use a `.env` file and load it securely**  
   ```bash
   docker run --env-file .env my-app
   ```
📌 **Prevents secrets from being exposed in logs and images.**  

---

### **6. Your containerized application cannot communicate with another container on the same network. How do you resolve this?**  
✅ **Answer:**  
1. **Check if both containers are on the same network:**  
   ```bash
   docker network inspect <network-name>
   ```
2. **Manually connect containers:**  
   ```bash
   docker network connect my-network container1
   ```
3. **Use `docker-compose` with a shared network:**  
   ```yaml
   version: '3'
   services:
     web:
       image: nginx
       networks:
         - my-network
     db:
       image: postgres
       networks:
         - my-network
   networks:
     my-network:
   ```
📌 **Ensures inter-container communication via user-defined networks.**  

---

### **7. A Docker container needs to expose multiple ports for different services. How do you configure this?**  
✅ **Answer:**  
1. **Expose multiple ports in `docker run`:**  
   ```bash
   docker run -p 8080:80 -p 443:443 nginx
   ```
2. **Define multiple ports in `docker-compose.yml`:**  
   ```yaml
   services:
     web:
       image: nginx
       ports:
         - "8080:80"
         - "8443:443"
   ```
📌 **Allows multiple services (e.g., HTTP & HTTPS) to be accessible.**  

---

### **8. Your application running in a container needs to communicate with an external database server. How do you configure networking to allow this?**  
✅ **Answer:**  
1. **Use the host network mode (Linux only):**  
   ```bash
   docker run --network host my-app
   ```
2. **Specify an external database host via environment variables:**  
   ```bash
   docker run -e DB_HOST=my-database.example.com my-app
   ```
3. **Ensure firewall rules allow external access to the DB server.**  
📌 **Prevents network connectivity issues with external services.**  

---

### **9. A service running in Docker Compose cannot reach another service by hostname. What steps would you take to fix this?**  
✅ **Answer:**  
1. **Ensure services are on the same network in `docker-compose.yml`:**  
   ```yaml
   services:
     web:
       image: nginx
       networks:
         - my-network
     db:
       image: postgres
       networks:
         - my-network
   networks:
     my-network:
   ```
2. **Ping the service from inside a running container:**  
   ```bash
   docker exec -it <container-id> ping db
   ```
📌 **Ensures proper service discovery within Docker Compose networks.**  

---

### **10. Your CI/CD pipeline needs to build and push Docker images efficiently. What optimizations would you apply?**  
✅ **Answer:**  
1. **Use build cache optimizations in Dockerfile:**  
   ```dockerfile
   FROM node:18
   WORKDIR /app
   COPY package.json package-lock.json ./
   RUN npm install
   COPY . .
   CMD ["node", "server.js"]
   ```
2. **Use BuildKit for parallelized builds:**  
   ```bash
   DOCKER_BUILDKIT=1 docker build -t my-app .
   ```
3. **Use a container registry like AWS ECR, Docker Hub, or GitHub Packages:**  
   ```bash
   docker tag my-app:latest my-registry/my-app:latest
   docker push my-registry/my-app:latest
   ```
📌 **Reduces build times and ensures optimized image storage.**  

---
