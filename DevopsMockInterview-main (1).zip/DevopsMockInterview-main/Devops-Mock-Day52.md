
1. **How would you implement a rolling update with zero downtime using Ansible?**
    - **Answer**: Use `serial` in your playbook to update a few servers at a time, ensuring some servers remain online while others are being updated. Use tasks to remove the server from the load balancer, perform the update, and re-add the server once it's confirmed working.

2. **How would you detect and fix configuration drift in a production environment?**
    - **Answer**: Use `check_mode` to detect drift by running playbooks in dry-run mode (`--check`), then apply the changes if drift is detected. You can also schedule this check periodically using cron jobs or Ansible Tower/AWX.

3. **How would you use Ansible to deploy a web application across multiple servers with different configurations?**
    - **Answer**: Use host variables and group variables in `group_vars` and `host_vars` to define specific configurations for different servers. Roles can be used to apply common settings across servers.

4. **How do you manage error handling in Ansible playbooks?**
    - **Answer**: Use `ignore_errors`, `failed_when`, and `block-rescue-always` for error handling. For example, you can use `block` for tasks, `rescue` for fallback actions, and `always` to run cleanup tasks.

5. **How would you automate patch management across a fleet of servers with Ansible?**
    - **Answer**: Create a playbook that checks for updates, applies the patches, and reboots the system if necessary. Use `serial` to patch servers in batches, ensuring availability.
    - **Example**:
      ```yaml
      - name: Apply patches
        hosts: all
        tasks:
          - name: Check for updates
            apt:
              update_cache: yes
          - name: Apply upgrades
            apt:
              upgrade: dist
          - name: Reboot server
            reboot:
              msg: "Rebooting after patching"
      ```

---


6. **How would you integrate Ansible with Jenkins for CI/CD pipelines?**
    - **Answer**: You can call Ansible playbooks from Jenkins pipelines by using the `ansible-playbook` command in a Jenkinsfile or using the Ansible plugin for Jenkins. Ensure proper vault password management and SSH key usage in the pipeline.

7. **How do you manage secret keys in a CI/CD pipeline when using Ansible?**
    - **Answer**: Use `ansible-vault` to encrypt secrets and pass the vault password securely through environment variables in Jenkins, GitLab CI, or any CI tool.

8. **What are the advantages of using Ansible Tower in an enterprise environment?**
    - **Answer**: Ansible Tower provides a web-based interface, role-based access control, job scheduling, real-time job output, auditing, and notifications, making it more suitable for large-scale enterprise environments.

9. **How would you handle scaling Ansible in a large infrastructure?**
    - **Answer**: Use dynamic inventories for cloud environments (AWS, Azure, etc.), delegate tasks to jump hosts using `delegate_to`, and increase parallelism by adjusting the `forks` parameter in `ansible.cfg`.



10. **How would you implement multi-tenancy with Ansible Tower?**
    - **Answer**: Create separate organizations, teams, and role-based access control (RBAC) within Ansible Tower. Define different inventories, projects, and playbooks for each tenant and assign permissions accordingly.

11. **How do you implement a CI/CD pipeline with Ansible for continuous deployment?**
    - **Answer**: In the CI/CD pipeline, trigger Ansible playbooks after every code commit or merge to deploy the application automatically. Ensure that each stage (build, test, deploy) runs seamlessly in different environments (dev, stage, prod).

12. **How would you troubleshoot an Ansible playbook that is failing?**
    - **Answer**: Run the playbook in verbose mode (`-vvv`) to get detailed output, check SSH connectivity, review the Ansible logs, and validate the syntax with `ansible-lint` or `ansible-playbook --syntax-check`.

13. **What is the use of `async` and `poll` in Ansible, and when would you use them?**
    - **Answer**: `async` allows you to run long-running tasks in the background, and `poll` can be used to periodically check the task’s status. This is useful when you don’t want to block other tasks while waiting for a process to complete.
    - **Example**:


      ```yaml
      - name: Run task asynchronously
        command: long_running_task.sh
        async: 1800
        poll: 0
      ```

14. **How do you handle multiple SSH keys or different users for connecting to managed nodes in Ansible?**
    - **Answer**: You can define different SSH keys or users in the inventory file or use `ansible_user` and `ansible_ssh_private_key_file` to specify per-host authentication settings.

15. **How would you configure Ansible to run tasks in parallel?**
    - **Answer**: Increase the `forks` value in `ansible.cfg` to control the number of parallel tasks. By default, Ansible runs tasks on 5 hosts at a time, but you can scale this based on the infrastructure size.
