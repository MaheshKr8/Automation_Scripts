
### **1. How do you set a temporary environment variable in Linux?**
**Solution:**
```bash
export VAR_NAME=value
```
**Real-World Use Case:**  
Used in **temporary configurations and debugging**.

---

### **2. How do you search for a pattern in multiple files recursively?**
**Solution:**
```bash
grep -r "pattern" /path/to/dir
```
**Real-World Use Case:**  
Common for **log analysis and debugging**.

---

### **3. How do you redirect both stdout and stderr to the same file?**
**Solution:**
```bash
command > output.log 2>&1
```
**Real-World Use Case:**  
Useful when **logging script executions**.

---

### **4. How do you create a new user with sudo access?**
**Solution:**
```bash
sudo useradd -m -G sudo newuser
sudo passwd newuser
```
**Real-World Use Case:**  
Used for **onboarding new DevOps engineers**.

---

### **5. How do you remove all stopped Docker containers?**
**Solution:**
```bash
docker rm $(docker ps -a -q)
```
**Real-World Use Case:**  
Frees up **unused Docker resources**.

---

### **6. How do you check if a service is enabled at boot?**
**Solution:**
```bash
systemctl is-enabled service_name
```
**Real-World Use Case:**  
Ensures **critical services start after reboot**.

---

### **7. How do you monitor a system in real-time for CPU, memory, and processes?**
**Solution:**
```bash
htop
```
**Real-World Use Case:**  
Essential for **live system monitoring**.

---

### **8. How do you remove all files older than 7 days from a directory?**
**Solution:**
```bash
find /path/to/dir -type f -mtime +7 -exec rm -f {} \;
```
**Real-World Use Case:**  
Prevents **log file buildup**.

---

### **9. How do you check the default DNS servers being used?**
**Solution:**
```bash
cat /etc/resolv.conf
```
**Real-World Use Case:**  
Used in **network troubleshooting**.

---

### **10. How do you identify zombie processes on a Linux system?**
**Solution:**
```bash
ps aux | awk '{ if ($8 == "Z") print $2 }'
```
**Real-World Use Case:**  
Helps in **debugging orphaned processes**.

---

