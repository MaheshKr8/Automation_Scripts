* Here are the some 5 Docker interview questions, now enhanced with practical scripts and examples:

* 1. **What is Docker and how does it work?**
   - Docker is an open-source platform designed to automate the deployment, scaling, and management of applications in lightweight containers. Containers are isolated from each other and bundle their own software, libraries, and configuration files; they can communicate with each other through well-defined channels.

   **Example Script:**
   ```sh
   # To install Docker on a Linux system
   sudo apt-get update
   sudo apt-get install -y docker.io

   # Check Docker version
   docker --version
   ```

* 2. **What is the difference between a Docker image and a Docker container?**
   - A Docker image is a lightweight, standalone, and executable package that includes everything needed to run a piece of software, including the code, runtime, libraries, environment variables, and configuration files. A Docker container is a running instance of a Docker image.

   **Example Script:**
   ```sh
   # List Docker images
   docker images

   # Run a Docker container from an image
   docker run -d --name my_container nginx
   ```

* 3. **How do you create a Dockerfile and what is its purpose?**
   - A Dockerfile is a text document that contains all the commands to assemble an image. The purpose of a Dockerfile is to automate the image creation process.

   **Example Dockerfile:**
   ```dockerfile
   # Use the official Node.js image as a base
   FROM node:16

   # Set the working directory
   WORKDIR /usr/src/app

   # Copy package.json and package-lock.json
   COPY package*.json ./

   # Install dependencies
   RUN npm install

   # Copy the rest of the application files
   COPY . .

   # Expose the port the app runs on
   EXPOSE 3000

   # Command to run the app
   CMD ["node", "app.js"]
   ```

   **Building and Running the Docker Image:**
   ```sh
   docker build -t my-node-app .
   docker run -p 3000:3000 my-node-app
   ```

* 4. **What is Docker Compose and how is it used?**
   - Docker Compose is a tool for defining and running multi-container Docker applications. With Compose, you use a YAML file to configure your application’s services.

   **Example docker-compose.yml:**
   ```yaml
   version: '3'
   services:
     web:
       image: nginx
       ports:
         - "80:80"
     app:
       build: .
       ports:
         - "3000:3000"
       depends_on:
         - web
   ```

   **Running Docker Compose:**
   ```sh
   docker-compose up
   ```

* 5. **How can you persist data in Docker containers?**
   - Data can be persisted in Docker containers using Docker volumes or bind mounts.

   **Example Script:**
   ```sh
   # Creating a volume
   docker volume create my_volume

   # Running a container with a volume
   docker run -d -v my_volume:/data --name my_container nginx
   ```


* These scripts and examples should help reinforce the practical understanding of Docker concepts.
