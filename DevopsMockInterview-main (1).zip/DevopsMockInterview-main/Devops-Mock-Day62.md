


1. **What is Git, and why is it used?**
   - **Answer**: Git is a version control system that tracks changes in source code during development. It allows multiple developers to collaborate, track versions, and revert to previous versions if needed.

2. **Explain the difference between `git init` and `git clone`.**
   - **Answer**: `git init` initializes a new Git repository in the current directory. `git clone` copies an existing repository to your local machine.

3. **How do you check the current status of your repository?**
   - **Answer**: `git status` shows the current state of the repository, including changes to files in the working directory and the staging area.

4. **How can you see the history of commits in a repository?**
   - **Answer**: Use `git log` to see a list of all commits, along with details like commit IDs, authors, and timestamps.

5. **What is the purpose of the `.gitignore` file?**
   - **Answer**: `.gitignore` specifies files and directories that Git should ignore, such as build artifacts or environment files, to prevent unnecessary tracking.


6. **How do you create a new branch in Git?**
   - **Answer**: Use `git branch <branch_name>` to create a branch. For example, `git branch feature-xyz` creates a branch for a new feature.

7. **How do you switch to another branch?**
   - **Answer**: `git checkout <branch_name>` switches to a specified branch, allowing you to work on changes independently.

8. **Explain `git merge` with an example.**
   - **Answer**: `git merge` combines the changes from another branch into the current branch. For example, `git merge feature-xyz` merges the changes from `feature-xyz` into the current branch.

9. **What is a "merge conflict" and how do you resolve it?**
   - **Answer**: A merge conflict occurs when changes in different branches conflict. Git marks the conflicting code, and you need to manually edit the file to resolve it.

10. **What is a "fast-forward" merge?**
    - **Answer**: In a fast-forward merge, Git simply moves the current branch pointer to the target branch if there are no other commits between them.




