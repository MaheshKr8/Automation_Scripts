

---

# **GIT Real-Time Scenario-Based Questions**

### **1. Scenario:** You committed a change but forgot to include a file. How do you fix this?  

**Solution:**  
- Stage the missing file and amend the commit:  
  ```bash
  git add <missing-file>
  git commit --amend --no-edit
  ```
- If already pushed, force push:  
  ```bash
  git push origin <branch> --force
  ```

---

### **2. Scenario:** You accidentally committed credentials to Git. How do you remove it from history?  

**Solution:**  
- Remove the file and rewrite history:  
  ```bash
  git filter-branch --force --index-filter 'git rm --cached --ignore-unmatch <file>' --prune-empty --tag-name-filter cat -- --all
  ```
- Push forcefully:  
  ```bash
  git push origin --force --all
  ```
- **Best Practice**: Use `.gitignore` to prevent sensitive files from being committed.

---

### **3. Scenario:** You need to delete a branch locally and remotely. How do you do it?  

**Solution:**  
- Delete locally:  
  ```bash
  git branch -d <branch>
  ```
- If unmerged, force delete:  
  ```bash
  git branch -D <branch>
  ```
- Delete remotely:  
  ```bash
  git push origin --delete <branch>
  ```

---

### **4. Scenario:** A teammate force-pushed to `main`, overwriting your commits. How do you recover your work?  

**Solution:**  
- Find lost commits using:  
  ```bash
  git reflog
  ```
- Restore to a safe state:  
  ```bash
  git reset --hard <commit-hash>
  ```
- Push the recovered branch:  
  ```bash
  git push origin main --force
  ```

---

### **5. Scenario:** You want to undo a merge commit but keep the changes. How do you do it?  

**Solution:**  
- Reset while keeping changes staged:  
  ```bash
  git reset --soft HEAD~1
  ```
- If you want to remove changes:  
  ```bash
  git reset --hard HEAD~1
  ```

---

### **6. Scenario:** You need to find which commit introduced a bug. What’s the best approach?  

**Solution:**  
Use **Git Bisect** to find the faulty commit:  
```bash
git bisect start
git bisect bad   # Mark current commit as bad
git bisect good <commit-hash>  # Mark last known good commit
```
Git will guide you through checking commits until the faulty one is found.

---

### **7. Scenario:** Your branch is behind `main`, and you want to update it without merge conflicts. How?  

**Solution:**  
Use **rebase** to keep a clean history:  
```bash
git checkout feature-branch
git fetch origin
git rebase origin/main
```
If conflicts occur:  
```bash
git rebase --continue
```

---

### **8. Scenario:** You need to clone a specific branch of a large repository. How?  

**Solution:**  
```bash
git clone --branch <branch-name> --single-branch <repo-url>
```

---

### **9. Scenario:** You want to see who changed a specific line of a file. What command do you use?  

**Solution:**  
```bash
git blame <file>
```
This shows the commit, author, and timestamp for each line.

---

### **10. Scenario:** You made multiple commits but want to combine them into one before pushing. How?  

**Solution:**  
Use interactive rebase:  
```bash
git rebase -i HEAD~<number-of-commits>
```
Mark all but the first commit as `squash` (`s`), then edit the commit message.

---

# **JENKINS Real-Time Scenario-Based Questions**

### **11. Scenario:** A Jenkins job fails due to a missing dependency. How do you debug this?  

**Solution:**  
- Check logs in **Build Console Output**.  
- Ensure the dependency is installed:  
  ```bash
  mvn clean install
  ```
- Use a **Jenkins agent** with required dependencies.

---

### **12. Scenario:** Your Jenkins job is running slower than expected. How do you optimize it?  

**Solution:**  
- Enable **parallel execution**.  
- Use **caching mechanisms** (e.g., Docker image caching, Maven repository caching).  
- Distribute builds across multiple Jenkins nodes.

---

### **13. Scenario:** You need to trigger a Jenkins job from GitHub automatically. How do you do it?  

**Solution:**  
- **Enable Webhooks** in GitHub under repository settings:  
  ```
  Payload URL: http://<jenkins-url>/github-webhook/
  ```
- In Jenkins, enable **Build Triggers → GitHub hook trigger for GITScm polling**.

---

### **14. Scenario:** Your Jenkins build fails due to workspace issues. How do you fix it?  

**Solution:**  
- Clean the workspace before each build:  
  ```bash
  rm -rf $WORKSPACE/*
  ```
- Configure **"Discard old builds"** in Jenkins.

---

### **15. Scenario:** You need to deploy an application automatically after a successful Jenkins build. How do you do it?  

**Solution:**  
- Use **Post-Build Actions**:  
  - **Deploy to a remote server** using SSH:  
    ```bash
    ssh user@server 'bash deploy-script.sh'
    ```
  - Use **Jenkins Pipeline**:
    ```groovy
    pipeline {
        agent any
        stages {
            stage('Deploy') {
                steps {
                    sh 'scp -r build/* user@server:/var/www/html'
                }
            }
        }
    }
    ```

---

# **Summary**
| **Tool**   | **Scenario**                                        | **Solution**  |
|------------|------------------------------------------------------|---------------|
| **Git**   | Undo last commit but keep changes | `git reset --soft HEAD~1` |
| **Git**   | Find a bug's origin | `git bisect` |
| **Git**   | Remove sensitive data | `git filter-branch`, `BFG` |
| **Jenkins** | Slow builds | Parallel execution, caching |
| **Jenkins** | Automatic deployment | Post-build actions, pipelines |
| **Jenkins** | GitHub triggers | Webhooks |

