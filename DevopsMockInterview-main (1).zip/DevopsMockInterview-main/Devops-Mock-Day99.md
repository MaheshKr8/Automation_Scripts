
---

### **1. How do you ensure Terraform state is not corrupted when multiple team members apply changes?**

#### **Solution:**
- Use a **remote backend** with state locking.
- **Example using AWS S3 + DynamoDB:**
  ```hcl
  terraform {
    backend "s3" {
      bucket         = "terraform-state-bucket"
      key            = "prod/terraform.tfstate"
      region         = "us-east-1"
      dynamodb_table = "terraform-lock"
    }
  }
  ```

- DynamoDB ensures **state locking**, preventing conflicts.

---

### **2. How do you manage secrets securely in Terraform?**

#### **Solution:**
- Avoid hardcoding secrets in `.tf` files.
- Use **AWS Secrets Manager**, **SSM Parameter Store**, or **Vault**.
- Mark variables as sensitive:
  ```hcl
  variable "db_password" {
    type      = string
    sensitive = true
  }
  ```

- Fetch secrets dynamically:
  ```hcl
  data "aws_secretsmanager_secret_version" "db_password" {
    secret_id = "my-db-password"
  }
  ```

---

### **3. How do you create multiple similar resources dynamically?**

#### **Solution:**
- Use `count` or `for_each`.

**Using `count`:**
```hcl
resource "aws_instance" "web" {
  count         = 3
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
}
```

**Using `for_each`:**
```hcl
variable "instances" {
  default = {
    web1 = "t2.micro"
    web2 = "t3.micro"
  }
}

resource "aws_instance" "web" {
  for_each      = var.instances
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = each.value
}
```

---

### **4. How do you manage different environments (dev, test, prod) in Terraform?**

#### **Solution:**
1. **Use Workspaces**:
   ```bash
   terraform workspace new dev
   terraform workspace select dev
   terraform apply
   ```

2. **Use separate state files**:
   ```hcl
   terraform {
     backend "s3" {
       key = "env/${terraform.workspace}/terraform.tfstate"
     }
   }
   ```

---

### **5. What happens if a Terraform apply fails midway?**

#### **Solution:**
- Terraform keeps a **partial state**.
- Use `terraform state list` to inspect.
- Use `terraform apply` again to retry.
- If needed, manually remove a corrupt resource:
  ```bash
  terraform state rm aws_instance.web
  ```

---

### **6. How do you ensure a resource is never accidentally destroyed?**

#### **Solution:**
- Use `prevent_destroy` in lifecycle settings:
  ```hcl
  resource "aws_s3_bucket" "important" {
    lifecycle {
      prevent_destroy = true
    }
  }
  ```

---

### **7. How do you reference an existing resource in Terraform instead of creating a new one?**

#### **Solution:**
- Use **Data Sources**:
  ```hcl
  data "aws_vpc" "existing" {
    filter {
      name   = "tag:Name"
      values = ["my-vpc"]
    }
  }
  ```

- Use it in a resource:
  ```hcl
  resource "aws_subnet" "example" {
    vpc_id = data.aws_vpc.existing.id
  }
  ```

---

### **8. How do you detect and fix drift in Terraform?**

#### **Solution:**
1. **Detect drift**:
   ```bash
   terraform plan
   ```
2. **Manually update Terraform files** OR apply the planned changes:
   ```bash
   terraform apply
   ```

---

### **9. How do you enforce compliance policies in Terraform?**

#### **Solution:**
- Use **Sentinel (Terraform Cloud)** or **OPA (Open Policy Agent)**.
- Example Sentinel policy:
  ```hcl
  policy "require_tags" {
    enforcement_level = "hard-mandatory"
    rule {
      all tfplan.resources.aws_instance[*].tags {
        exists value["Environment"]
      }
    }
  }
  ```

---

### **10. How do you perform a rollback in Terraform?**

#### **Solution:**
- Rollback using a previous commit:
  ```bash
  git checkout previous_version
  terraform apply
  ```

- Restore from a backup state:
  ```bash
  terraform state push backup.tfstate
  ```

---

### **11. How do you run Terraform in a CI/CD pipeline?**

#### **Solution:**
- Use GitHub Actions, GitLab CI, or Jenkins.
- Example GitHub Actions pipeline:
  ```yaml
  - name: Terraform Init
    run: terraform init
  - name: Terraform Plan
    run: terraform plan -out=tfplan
  - name: Terraform Apply
    run: terraform apply tfplan
  ```

---

### **12. How do you ensure Terraform code reusability?**

#### **Solution:**
- Use **Terraform modules**.

**Example Module (`modules/vpc/main.tf`):**
```hcl
resource "aws_vpc" "main" {
  cidr_block = var.cidr
}
```

**Call the module:**
```hcl
module "vpc" {
  source = "./modules/vpc"
  cidr   = "10.0.0.0/16"
}
```

---

### **13. How do you conditionally create resources in Terraform?**

#### **Solution:**
- Use `count`:
  ```hcl
  resource "aws_instance" "web" {
    count = var.create_instance ? 1 : 0
    ami   = "ami-0c55b159cbfafe1f0"
  }
  ```

---

### **14. How do you provision software after launching an EC2 instance?**

#### **Solution:**
- Use **remote-exec**:
  ```hcl
  resource "aws_instance" "web" {
    ami           = "ami-0c55b159cbfafe1f0"
    instance_type = "t2.micro"

    provisioner "remote-exec" {
      inline = [
        "sudo apt update",
        "sudo apt install nginx -y"
      ]
    }
  }
  ```

---

### **15. How do you migrate a local Terraform state to a remote backend?**

#### **Solution:**
1. Update backend configuration:
   ```hcl
   terraform {
     backend "s3" {
       bucket = "terraform-state-bucket"
       key    = "prod/terraform.tfstate"
     }
   }
   ```
2. Migrate state:
   ```bash
   terraform init -migrate-state
   ```

---
