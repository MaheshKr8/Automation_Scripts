
---

### ✅ 1. **Scenario:** Jenkins pipeline is running slow. What do you do?

**Answer:**

* Analyze pipeline stage timings with `Blue Ocean` or logs
* Use parallel stages where possible
* Use Docker agents for lightweight builds
* Cache dependencies (Maven, NPM, etc.)
* Scale Jenkins agents or switch to ephemeral agents (Kubernetes)

---

### ✅ 2. **Scenario:** Docker container works locally but fails in Kubernetes. Why?

**Answer:**

* Image may be using local resources or files missing in container
* Environment variables or configmaps/secrets not mounted
* Port or health probe misconfiguration
* Missing `entrypoint` or volume mounts in deployment YAML

---

### ✅ 3. **Scenario:** Ansible playbook fails on one host but works on others. What’s your strategy?

**Answer:**

* Check `ansible-playbook -vvv` output
* Confirm host-specific variables or facts
* Validate SSH connectivity
* Compare OS versions or package availability

---

### ✅ 4. **Scenario:** Your Terraform apply fails with “resource already exists.” What do you do?

**Answer:**

* Use `terraform import` to bring the resource into the state
* Confirm no manual changes happened
* Avoid using `create_before_destroy` unless necessary
* Use lifecycle blocks like `prevent_destroy = true`

---

### ✅ 5. **Scenario:** Argo CD is not syncing the application correctly. What’s the issue?

**Answer:**

* Check Argo CD UI for sync status and errors
* Validate manifests and values.yaml changes
* Ensure Argo CD has access to the Git repository
* Fix Git tag or branch mismatch

---

### ✅ 6. **Scenario:** Disk usage is 100% on a production server. What immediate steps do you take?

**Answer:**

* Run `du -sh /*` or `ncdu` to identify large files
* Clear Docker logs, unused containers/images (`docker system prune`)
* Rotate log files or increase log retention policy
* Mount new disk or increase volume size

---

### ✅ 7. **Scenario:** How do you perform zero-downtime database migrations?

**Answer:**

* Use **feature flags** to hide new changes
* Run **non-breaking changes first** (e.g., adding columns)
* Use **online schema migration tools** (e.g., gh-ost, pt-online-schema-change)
* Back up DB before migration

---

### ✅ 8. **Scenario:** Team wants to deploy new microservice quickly. What’s your onboarding flow?

**Answer:**

* Create Helm chart or Kustomize templates
* Use CI/CD template (Jenkinsfile or GitHub Actions YAML)
* Add secrets/configs to Vault or Kubernetes
* Monitor with Prometheus/Grafana dashboards

---

### ✅ 9. **Scenario:** Cloud cost has suddenly spiked. How do you investigate?

**Answer:**

* Use AWS Cost Explorer or GCP Billing
* Check EBS volume snapshots, idle EC2, large data transfers
* Review autoscaling misconfigurations or new instance types
* Apply budget alerts and cost governance

---

### ✅ 10. **Scenario:** GitHub Actions pipeline fails only on main branch. Why?

**Answer:**

* Check branch-specific workflow conditions (`on:` config)
* Secrets might be restricted to main
* Branch protection rules blocking deployment
* Main branch has latest features not merged to develop

---

### ✅ 11. **Scenario:** SonarQube is flagging false positives. What can be done?

**Answer:**

* Suppress specific rules using annotations
* Tune quality gate thresholds
* Configure custom rule sets for specific languages
* Exclude directories using `sonar.exclusions`

---

### ✅ 12. **Scenario:** Your team wants to implement GitOps. How do you approach it?

**Answer:**

* Use Argo CD or Flux to sync manifests from Git
* Maintain separate Git branches or repos per environment
* Enforce PR review before merges
* Store secrets as Sealed Secrets or SOPS encrypted files

---

### ✅ 13. **Scenario:** Load testing fails with high 5xx errors. How do you fix?

**Answer:**

* Check backend service logs (timeouts, DB connections)
* Tune auto-scaling or increase pod replicas
* Check Ingress controller rate limits or NGINX timeouts
* Profile app with APM tools under load

---

### ✅ 14. **Scenario:** You want to roll back a Kubernetes deployment quickly. How?

**Answer:**

```bash
kubectl rollout undo deployment <deployment-name>
```

* Or roll back using Argo CD or Helm:

```bash
helm rollback <release> <revision>
```

---

### ✅ 15. **Scenario:** Git merge conflict happens during CI. What should be done?

**Answer:**

* CI should run only after PR is updated with latest base branch
* Enforce fast-forward or squash merges
* Add rebase step or use GitHub merge queue feature

---

### ✅ 16. **Scenario:** Secrets in Kubernetes are in plain text. How do you secure them?

**Answer:**

* Use tools like **Sealed Secrets**, **External Secrets**, or **Vault Injector**
* Avoid hardcoding base64 secrets in manifests
* Enable RBAC restrictions and audit logging

---

### ✅ 17. **Scenario:** Developer wants to test a feature branch on Kubernetes. What’s your approach?

**Answer:**

* Enable **preview environments** using ephemeral namespaces
* Use dynamic Helm values or Kustomize overlays
* Deploy using pipeline triggered on branch push
* Clean up automatically after a timeout or PR close

---

### ✅ 18. **Scenario:** Your CI/CD pipeline needs to deploy across multiple cloud providers. What’s your strategy?

**Answer:**

* Use Terraform with provider aliasing (e.g., AWS + Azure)
* Separate backend configurations per cloud
* Use abstraction layers like Pulumi or Crossplane
* Centralize secrets and config via Vault

---

### ✅ 19. **Scenario:** How do you ensure auditability of all infra changes?

**Answer:**

* Use Git-based workflows (pull requests) for all infra changes
* Enable logging in Terraform backend (S3 + CloudTrail)
* Use tools like Atlantis to trigger Terraform via PRs
* Maintain CI/CD logs with commit ID mapping

---

### ✅ 20. **Scenario:** You’re asked to introduce chaos testing. How would you do it?

**Answer:**

* Use tools like **Litmus**, **Gremlin**, or **Chaos Mesh**
* Simulate pod/node failures, latency, resource exhaustion
* Run experiments during non-peak hours
* Monitor impact and define recovery SLAs

---

