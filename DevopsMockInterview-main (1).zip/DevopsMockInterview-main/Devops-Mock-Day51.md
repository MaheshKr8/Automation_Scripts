

1. **What is Ansible, and how does it work?**
   - **Answer**: Ansible is an open-source automation tool for configuration management, application deployment, and task automation. It works by connecting to nodes via SSH (Linux) or WinRM (Windows), pushing out small programs called "modules" to execute tasks on remote servers. Ansible doesn’t require a client agent on remote hosts.

2. **What is an Ansible Playbook?**
   - **Answer**: An Ansible playbook is a YAML file that defines a set of tasks to be executed on managed hosts. Playbooks are used to automate tasks, such as installing software or managing configurations.

3. **Explain the difference between `ad-hoc` commands and playbooks in Ansible.**
   - **Answer**: `ad-hoc` commands are one-liners executed directly on the terminal for quick tasks. Playbooks are structured YAML scripts used for complex, multi-step tasks and are reusable.

4. **What are Ansible modules?**
   - **Answer**: Ansible modules are reusable units of code that perform actions like installing packages, managing files, or restarting services. Examples include `apt`, `yum`, `service`, `copy`, `file`, etc.

5. **What is the inventory file in Ansible?**
   - **Answer**: The inventory file lists all the managed hosts and their groupings. It can be static (INI or YAML format) or dynamic (AWS, Azure).

---


6. **How do you manage different environments in Ansible (e.g., dev, stage, prod)?**
   - **Answer**: By creating different inventory files for each environment (e.g., `inventory/dev`, `inventory/prod`) and using `group_vars` and `host_vars` directories for environment-specific variables.

7. **How does `ansible-vault` help in managing sensitive data?**
   - **Answer**: `ansible-vault` allows you to encrypt sensitive data (passwords, API keys) in playbooks. You can encrypt entire files or variables and decrypt them during runtime using a vault password or environment variable.

8. **What is `handlers` in Ansible?**
   - **Answer**: `handlers` are special tasks that are triggered by the `notify` directive in other tasks. Handlers are executed only once after the tasks that notified them have been executed.

9. **What is `gather_facts` in Ansible?**
   - **Answer**: `gather_facts` is a default action in Ansible that collects information (facts) about the managed hosts, such as IP addresses, OS details, etc. It is used to make tasks conditional or to make decisions based on host attributes.

10. **What is the purpose of `roles` in Ansible?**
    - **Answer**: Roles allow you to organize playbooks and reuse code by grouping tasks, variables, files, handlers, and templates into separate directories. This makes playbooks more modular and maintainable.

---


11. **How does Ansible handle idempotency?**
    - **Answer**: Idempotency ensures that running a playbook multiple times results in the same outcome. Ansible modules are designed to check if a change is needed, and if not, they don’t apply the change, maintaining the system state.

12. **Explain how `with_items`, `with_dict`, and `with_fileglob` are used for looping in Ansible.**
    - **Answer**: These loops allow tasks to iterate over lists, dictionaries, or file patterns:
      - `with_items` iterates over a list.
      - `with_dict` loops over dictionary keys and values.
      - `with_fileglob` loops over files matching a pattern.

13. **How do you manage task dependencies in Ansible?**
    - **Answer**: Task dependencies can be managed using the `notify` directive to trigger handlers, or using the `when` clause to conditionally run tasks based on the results of previous tasks.

14. **What is a `block` in Ansible, and how is it useful?**
    - **Answer**: `block` groups tasks together and allows you to apply common directives such as `when`, `become`, or error handling (`rescue`, `always`). This is useful for organizing related tasks and handling errors gracefully.

15. **Explain the difference between `include` and `import` in Ansible.**
    - **Answer**: `include` is dynamic and evaluated at runtime, while `import` is static and evaluated when the playbook is parsed. `include_tasks` is useful for conditional task inclusion.

---


