
1. **What is a Git tag, and why is it used?**
    - **Answer**: Git tags mark specific points in the repository’s history, often used for version releases. For example, `git tag v1.0` tags the current commit as version 1.0.

2. **How do you push a tag to a remote repository?**
    - **Answer**: Use `git push origin <tag_name>` to push a tag to the remote repository.

3. **How do you delete a tag locally and remotely?**
    - **Answer**: `git tag -d <tag_name>` deletes a local tag, and `git push origin --delete <tag_name>` deletes it from the remote.

4. **Explain lightweight vs. annotated tags.**
    - **Answer**: Lightweight tags are just pointers to a commit, while annotated tags store additional metadata like a message, author, and date.

5. **How can you list all tags in a repository?**
    - **Answer**: Use `git tag` to list all tags.



6. **How do you revert a commit?**
    - **Answer**: `git revert <commit_id>` creates a new commit that undoes the changes of the specified commit, preserving history.

7. **What is the difference between `git reset` and `git revert`?**
    - **Answer**: `git reset` moves the HEAD pointer to a previous commit, modifying history, while `git revert` creates a new commit to undo changes without altering history.

8. **Explain `git reset --hard` vs. `git reset --soft`.**
    - **Answer**: `git reset --hard` resets the working directory and staging area to a specific commit, erasing changes, while `git reset --soft` only resets the commit history, keeping changes staged.

9. **How can you undo a staged file?**
    - **Answer**: `git reset <file>` unstages the file, keeping changes in the working directory.

10. **How do you undo changes to a specific file in the working directory?**
    - **Answer**: `git checkout -- <file>` reverts a file in the working directory to the last committed version.



