## Let's dive into each question with practical, real-time scenario-based answers.

1. **How can we change the permissions for a file under Linux?**

   * To change the permissions of a file in Linux, use the `chmod` command. For example, if you have a file called `example.txt` and you want to give read and write permissions to the owner, read permissions to the group, and no permissions to others, you would use:

   ```bash
   chmod 640 example.txt
   ```
   * In a real scenario, if you are a developer who needs to modify a script but want to restrict others from doing so, you would adjust the permissions accordingly.

2. **How can we list the partitions in Linux?**

   * To list the partitions in Linux, you can use the `lsblk` or `fdisk -l` commands. For instance:

   ```bash
   lsblk
   ```
   or

   ```bash
   sudo fdisk -l
   ```
   * This is useful when setting up a new disk or troubleshooting storage issues on your server.

3. **What is the command to find the current load average in the system?**

   * The `uptime` or `top` commands can be used to find the current load average:
   ```bash
   uptime
   ```
   or

   ```bash
   top
   ```
   * This is typically checked when you notice the system is sluggish and you want to see if high load might be the cause.

4. **What is the command to check all the running processes?**

   * To check all running processes, use the `ps` command with the `aux` options:
   ```bash
   ps aux
   ```
   or

   ```bash
   top
   ```
   * This is often used by system administrators to identify resource-intensive processes.

5. **What is a workspace in Jenkins?**

   * In Jenkins, a workspace is the directory where Jenkins builds and stores files for a particular project. Each job has its own workspace. For example, if you are running a job to compile code, the source code and build artifacts will be stored in the workspace.

6. **If we want to take a backup of a post Jenkins server, what would be the process?**

   * To backup a Jenkins server, you should backup the Jenkins home directory, which contains all the configurations, plugins, and job information. You can do this by:
   ```bash
   cp -r /var/lib/jenkins /path/to/backup/location
   ```
   * Automating this with a cron job and ensuring backups are stored securely is a good practice.

7. **I want to give access to some instance, which is in a private subnet to a developer, how can we give access?**

   * You can provide access to the instance using SSH with a bastion host or VPN. For example, set up a bastion host in a public subnet that the developer can SSH into, and from there, they can SSH into the private instance.

8. **Difference between private and public subnets?**

   - **Public Subnet**: Has a route to the internet through an Internet Gateway. Resources in a public subnet can directly access the internet.
   - **Private Subnet**: Does not have a direct route to the internet. Resources in a private subnet typically access the internet through a NAT Gateway.

   * For instance, web servers are often placed in public subnets, while databases are placed in private subnets for security.

9. **If I want to deny one IP address access to my infrastructure, how can I do this in AWS?**

  * You can use security groups or network ACLs. For example, to deny access using a security group:
   - Go to the security group in the AWS console.
   - Add an inbound rule with the IP address to deny.
   - Set the action to deny.

   * Using Network ACLs, you would add a deny rule for the specific IP address.

10. **What are the restrictions for Lambda service?**

    - Execution timeout: Maximum 15 minutes.
    - Memory allocation: Between 128 MB to 10,240 MB.
    - Disk space in /tmp: 512 MB.
    - Environment variables: Maximum of 4 KB.

   * For instance, if you have a function that processes images, you need to ensure it completes within 15 minutes and uses less than the allocated memory.

11. **I want to expose my app which is running in the EC2 instance to the outside, how can I do that?**

    * You need to:
    - Attach an Elastic IP to your EC2 instance.
    - Configure the security group to allow inbound traffic on the necessary ports (e.g., port 80 for HTTP).
    - Update your route tables to allow traffic to the instance.

12. **Difference between roles and policies?**

    - **Policies**: Documents that define permissions. They specify what actions are allowed or denied for which resources.
    - **Roles**: Entities that AWS services or applications assume to obtain temporary security credentials. Roles have policies attached to define what actions they can perform.

    * For example, you might have a policy that allows S3 access and attach it to a role that an EC2 instance assumes.

13. **What is the Dockerfile and what are some instructions?**

    * A Dockerfile is a script containing a series of instructions on how to build a Docker image. Key instructions include:
    - `FROM`: Specifies the base image.
    - `RUN`: Executes commands in the container.
    - `COPY`: Copies files from the host to the container.
    - `CMD`: Specifies the default command to run.

    * Example:
    ```Dockerfile
    FROM ubuntu:latest
    COPY . /app
    RUN make /app
    CMD ["./app/start.sh"]
    ```

14. **Difference between ENV and ARG in Docker?**

    - **ARG**: Defines a variable that users can pass at build-time.
    - **ENV**: Sets an environment variable in the container at run-time.

    * Example:
    ```Dockerfile
    ARG build_version
    ENV APP_VERSION $build_version
    ```

15. **Difference between StatefulSet and Deployment?**

    - **Deployment**: Manages stateless applications, ensuring a specified number of pod replicas are running.
    - **StatefulSet**: Manages stateful applications, providing guarantees about the ordering and uniqueness of pods.

   *  For example, a web server would use a Deployment, while a database that requires stable storage would use a StatefulSet.
