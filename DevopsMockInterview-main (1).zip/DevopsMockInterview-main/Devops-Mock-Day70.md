### Top 20 Linux Interview Questions for DevOps Engineers

---

### **1. What are the runlevels in Linux, and how do you change them?**

**Answer:**
- Runlevels define the state of the Linux system (e.g., single-user mode, multi-user mode, graphical interface).
  - **0**: Halt (shutdown)
  - **1**: Single-user mode
  - **2**: Multi-user mode without networking
  - **3**: Multi-user mode with networking
  - **5**: Multi-user mode with GUI
  - **6**: Reboot

**Command to change the runlevel:**
```bash
sudo systemctl isolate runlevelX.target  # Replace X with the desired runlevel.
```

**Relevance for DevOps:**  
Understanding runlevels helps in managing services during system boots, especially when automating server configurations.

---

### **2. How do you secure SSH access on a Linux server?**

**Answer:**
- **Key Steps:**
  1. Disable root login:  
     ```bash
     sudo nano /etc/ssh/sshd_config
     ```
     Set `PermitRootLogin no`.
  2. Use key-based authentication instead of passwords.
  3. Change the default port (e.g., `22` → `2222`).
  4. Restrict access using `AllowUsers` in `sshd_config`.

**Relevance for DevOps:**  
SSH security is critical for preventing unauthorized server access, especially in production environments.

---

### **3. How do you check CPU and memory usage on a Linux server?**

**Answer:**
- **CPU Usage:**  
  ```bash
  top
  htop
  ```
- **Memory Usage:**  
  ```bash
  free -h
  ```

**Relevance for DevOps:**  
Performance monitoring is essential to ensure smooth CI/CD pipeline execution and application performance.

---

### **4. How do you find and kill a process by its name or PID?**

**Answer:**
- **Find a process:**
  ```bash
  ps aux | grep process_name
  ```
- **Kill by PID:**
  ```bash
  kill -9 PID
  ```
- **Kill by name:**
  ```bash
  pkill -f process_name
  ```

**Relevance for DevOps:**  
Essential for managing misbehaving or stuck processes in application environments.

---

### **5. How do you monitor logs in real-time?**

**Answer:**
```bash
tail -f /var/log/application.log
```

**Relevance for DevOps:**  
Monitoring logs is vital for troubleshooting application issues during deployment or runtime.

---

### **6. How do you configure a static IP address on a Linux server?**

**Answer:**
1. Edit the configuration file:
   ```bash
   sudo nano /etc/netplan/01-netcfg.yaml
   ```
2. Example configuration:
   ```yaml
   network:
     version: 2
     ethernets:
       eth0:
         dhcp4: no
         addresses: [192.168.1.100/24]
         gateway4: 192.168.1.1
         nameservers:
           addresses: [8.8.8.8, 8.8.4.4]
   ```
3. Apply changes:
   ```bash
   sudo netplan apply
   ```

**Relevance for DevOps:**  
Required when setting up servers with permanent addresses for consistent network configurations.

---

### **7. What is a symbolic link, and how do you create one?**

**Answer:**
- A symbolic link is a pointer to another file or directory.
- **Command:**
  ```bash
  ln -s /path/to/target /path/to/link_name
  ```

**Relevance for DevOps:**  
Used for managing configuration files and shared resources efficiently.

---

### **8. How do you set environment variables in Linux?**

**Answer:**
1. Temporarily:
   ```bash
   export VAR_NAME=value
   ```
2. Permanently (e.g., in `.bashrc` or `/etc/environment`):
   ```bash
   echo "VAR_NAME=value" >> ~/.bashrc
   source ~/.bashrc
   ```

**Relevance for DevOps:**  
Environment variables are crucial for managing application configurations across environments.

---

### **9. What is SELinux, and how do you manage its state?**

**Answer:**
- SELinux (Security-Enhanced Linux) is a security module to control access based on policies.
- **Check status:**
  ```bash
  sestatus
  ```
- **Disable temporarily:**
  ```bash
  sudo setenforce 0
  ```
- **Permanently:**
  Edit `/etc/selinux/config` and set `SELINUX=disabled`.

**Relevance for DevOps:**  
SELinux can block applications unintentionally. Understanding it ensures seamless deployments.

---

### **10. How do you find which process is using a specific port?**

**Answer:**
```bash
sudo netstat -tuln | grep :port
sudo lsof -i :port
```

**Relevance for DevOps:**  
Diagnosing port conflicts during application deployment.

---

### **11. What is the purpose of crontab, and how do you use it?**

**Answer:**
- **Crontab** schedules periodic tasks.
- **Example:**
  ```bash
  crontab -e
  ```
  Add:
  ```bash
  0 2 * * * /path/to/script.sh
  ```
  (Runs the script daily at 2 AM.)

**Relevance for DevOps:**  
Automates tasks like backups, log rotation, and health checks.

---

### **12. How do you check the DNS configuration on Linux?**

**Answer:**
```bash
cat /etc/resolv.conf
```

**Relevance for DevOps:**  
DNS is critical for resolving service endpoints in distributed architectures.

---

### **13. How do you mount a disk partition in Linux?**

**Answer:**
```bash
sudo mount /dev/sdX /mnt
```
To make it permanent:
1. Add to `/etc/fstab`:
   ```bash
   /dev/sdX  /mnt  ext4  defaults  0  0
   ```

**Relevance for DevOps:**  
Mounting disks is essential for managing persistent storage.

---

### **14. How do you troubleshoot connectivity issues in Linux?**

**Answer:**
1. Ping test:
   ```bash
   ping -c 4 example.com
   ```
2. Check routes:
   ```bash
   ip route
   ```
3. Check DNS resolution:
   ```bash
   nslookup example.com
   ```

**Relevance for DevOps:**  
Network troubleshooting is key for diagnosing service outages.

---

### **15. How do you manage firewalls in Linux?**

**Answer:**
- Using `iptables`:
  ```bash
  sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT
  ```
- Using `ufw`:
  ```bash
  sudo ufw allow 22
  ```

**Relevance for DevOps:**  
Firewalls are critical for securing servers in production environments.

---

### **16. What is `rsync`, and how is it used?**

**Answer:**
- **Command:**
  ```bash
  rsync -avz /source/dir/ user@destination:/target/dir/
  ```
- **Explanation:**  
  Syncs files and directories over SSH.

**Relevance for DevOps:**  
Efficiently backups and syncs files during deployments.

---

### **17. How do you check system uptime?**

**Answer:**
```bash
uptime
```

**Relevance for DevOps:**  
Useful for monitoring server reliability and performance.

---

### **18. How do you view system resource usage?**

**Answer:**
```bash
top
htop
vmstat
```

**Relevance for DevOps:**  
Resource usage monitoring ensures the stability of CI/CD pipelines.

---

### **19. How do you configure a Linux server as a NAT gateway?**

**Answer:**
1. Enable IP forwarding:
   ```bash
   echo 1 > /proc/sys/net/ipv4/ip_forward
   ```
2. Configure NAT using `iptables`:
   ```bash
   iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
   ```

**Relevance for DevOps:**  
Used in hybrid cloud setups for routing traffic between private and public networks.

---

### **20. How do you check system boot logs?**

**Answer:**
```bash
journalctl -b
```

**Relevance for DevOps:**  
Boot logs help troubleshoot startup issues in production servers.

---

### Conclusion:
These questions cover key Linux concepts relevant to DevOps workflows, focusing on server management, automation, networking, and security. Practice these topics to excel in interviews and real-world scenarios!
