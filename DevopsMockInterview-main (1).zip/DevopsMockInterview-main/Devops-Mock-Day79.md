
---

### **1. Scenario: State File Corruption**
**Question**: If your Terraform state file becomes corrupted or is accidentally deleted, how would you recover it and ensure the infrastructure remains consistent?

**Expected Answer**:
- If a **remote backend** is configured, restore the state file from the backend or a backup.
- If no remote backend is used:
  - Attempt to manually fix the state file.
  - Use `terraform refresh` to reconcile the state with the actual resources.
  - Use `terraform import` to re-import unmanaged resources into the state file.

---

### **2. Scenario: Dependency Issues**
**Question**: You are creating an infrastructure with multiple resources. One resource depends on another, but Terraform fails because it doesn't recognize the dependency. How would you resolve this?

**Expected Answer**:
- Terraform automatically handles dependencies using references.
- If implicit dependencies are not recognized:
  - Use the `depends_on` argument to explicitly define dependencies.
- Example:
  ```hcl
  resource "aws_instance" "web" {
    depends_on = [aws_security_group.web_sg]
    # Other attributes...
  }
  ```

---

### **3. Scenario: Managing Multi-Environment Setups**
**Question**: How would you manage different environments (e.g., dev, staging, prod) using Terraform with minimal code duplication?

**Expected Answer**:
- Use **workspaces**:
  ```bash
  terraform workspace new dev
  terraform workspace select prod
  ```
- Use **input variables** for environment-specific configurations.
- Separate environment-specific `.tfvars` files (e.g., `dev.tfvars`, `prod.tfvars`) to override default variable values.

---

### **4. Scenario: Sensitive Data Handling**
**Question**: A colleague accidentally hardcoded sensitive data (like AWS access keys) in the Terraform configuration files. What steps would you take to resolve this?

**Expected Answer**:
- Immediately remove sensitive data from the configuration and commit history.
- Use **environment variables** to store secrets securely:
  ```bash
  export AWS_ACCESS_KEY_ID=your_access_key
  export AWS_SECRET_ACCESS_KEY=your_secret_key
  ```
- Use tools like **Terraform Cloud** or **Vault** for secrets management.
- Mark sensitive outputs:
  ```hcl
  output "db_password" {
    value     = var.db_password
    sensitive = true
  }
  ```

---

### **5. Scenario: Drift Detection**
**Question**: After deploying infrastructure with Terraform, some resources are modified manually outside of Terraform. How would you detect and reconcile these changes?

**Expected Answer**:
- Use `terraform plan` to identify any drift between the actual infrastructure and the Terraform state.
- Use `terraform apply` to reconcile the state and enforce the desired configuration.
- Optionally, use `terraform refresh` to update the state file with the actual state of the infrastructure.

---

### **6. Scenario: Module Version Updates**
**Question**: A module used in your Terraform configuration is updated to a new version. How would you safely test and apply these changes?

**Expected Answer**:
- Update the module version in the configuration:
  ```hcl
  module "vpc" {
    source  = "terraform-aws-modules/vpc/aws"
    version = "2.0.0"
  }
  ```
- Run `terraform init -upgrade` to fetch the new module version.
- Use `terraform plan` to preview the changes and ensure they align with expectations.
- Apply changes in a test environment before deploying to production.

---

### **7. Scenario: Remote Backend Locking**
**Question**: What would you do if you encounter a locking issue while using a remote backend (e.g., S3 with DynamoDB)?

**Expected Answer**:
- Use `terraform force-unlock <LOCK_ID>` to release the lock manually.
- Investigate the root cause of the locking issue:
  - Check for concurrent `terraform apply` or `terraform plan` runs.
  - Ensure the locking table (e.g., DynamoDB) is properly configured.

---

### **8. Scenario: Scaling Resources**
**Question**: How would you scale resources, such as EC2 instances, dynamically using Terraform?

**Expected Answer**:
- Use the `count` argument to create multiple instances:
  ```hcl
  resource "aws_instance" "web" {
    count         = 3
    ami           = "ami-0c55b159cbfafe1f0"
    instance_type = "t2.micro"
  }
  ```
- For more control, use `for_each` to scale resources based on a map or set of variables.

---

### **9. Scenario: Importing Existing Infrastructure**
**Question**: You are tasked with bringing existing AWS resources (e.g., S3 buckets) under Terraform management without re-creating them. How would you do this?

**Expected Answer**:
- Use the `terraform import` command:
  ```bash
  terraform import aws_s3_bucket.my_bucket my-bucket-name
  ```
- Define the resource in the Terraform configuration to match the imported resource.
- Run `terraform plan` to ensure the configuration matches the actual resource.

---

### **10. Scenario: Handling Large State Files**
**Question**: Your Terraform state file has grown significantly in size, leading to performance issues. How would you optimize it?

**Expected Answer**:
- Use **Terraform modules** to split the configuration into smaller, logical components, each with its own state file.
- Configure a **remote backend** (e.g., S3) to manage state efficiently and enable locking.
- Use the `terraform state rm` command to remove unmanaged resources from the state file if they are no longer required:
  ```bash
  terraform state rm <resource_id>
  ```

---

### **Bonus: Follow-up Tips**
- Provide examples when answering scenario-based questions.
- Demonstrate familiarity with advanced Terraform commands like `terraform graph`, `terraform taint`, and `terraform state mv`.
- Highlight best practices like modularization, state locking, and infrastructure-as-code principles.
