
---

### 🔥 **1. Production deployment failed. How do you debug and recover quickly?**

**Answer:**

* **Step 1**: Check pipeline logs (Jenkins/GitHub Actions).
* **Step 2**: Validate last successful deployment version.
* **Step 3**: Check app logs (`kubectl logs`, `docker logs`).
* **Step 4**: Use health checks (liveness/readiness) and monitoring (Grafana/ELK).
* **Step 5**: If issue confirmed, **rollback** to previous stable release.
* **Step 6**: Patch and test hotfix in staging → redeploy.

---

### 🔥 **2. Application pod is crashing repeatedly. What’s your approach?**

**Answer:**

* Use:

  ```bash
  kubectl describe pod <pod>
  kubectl logs <pod>
  ```
* Check for:

  * CrashLoopBackOff?
  * ImagePull errors?
  * Env/config issues?
  * Resource limits (OOMKilled)?
* Actions:

  * Fix config/secret/env.
  * Increase resource limits if needed.
  * Validate container entrypoint/command.

---

### 🔥 **3. Jenkins job is stuck in the queue. What could be wrong?**

**Answer:**

* Possible causes:

  * No agents available.
  * Label mismatch in node config.
  * Node offline or disk full.
* Fix:

  * Check node status under `Manage Jenkins > Nodes`.
  * Reconnect agent or clean workspace.
  * Check for executor occupancy.

---

### 🔥 **4. How would you recover Terraform state after accidental deletion or corruption?**

**Answer:**

* If using **remote backend** (S3), restore from:

  * S3 versioning.
  * Terraform Cloud state history.
* If local:

  * Try from `.terraform/` backup.
* Reconstruct resources using `terraform import`.

---

### 🔥 **5. Application is working fine but metrics are not visible in Grafana. What will you do?**

**Answer:**

* Check Prometheus:

  * `targets` status.
  * PromQL expression.
* Verify:

  * Exporter is running (`node_exporter`, `app_exporter`).
  * Network/Firewall not blocking scrape port.
* Fix data source config in Grafana.

---

### 🔥 **6. Your Docker container is running but the app is not accessible. How do you fix it?**

**Answer:**

* Check Dockerfile:

  * App listening on correct port?
  * `EXPOSE` used?
* Check container logs:

  ```bash
  docker logs <container>
  ```
* Ensure port is published:

  ```bash
  docker run -p 8080:8080 ...
  ```

---

### 🔥 **7. A developer pushed a secret into Git. How do you remediate this securely?**

**Answer:**

* Revoke exposed credentials immediately.
* Remove secrets from history:

  ```bash
  git filter-branch --force ...
  ```

  Or use [`BFG Repo-Cleaner`](https://rtyley.github.io/bfg-repo-cleaner/)
* Push changes and **force update remote**.
* Add secrets scanning in pipeline (e.g., GitLeaks, TruffleHog).

---

### 🔥 **8. Jenkins job fails only on one node but works on others. What would you check?**

**Answer:**

* Check node-specific issues:

  * Disk space, JVM memory.
  * Tool versions (e.g., Java, Docker).
  * Network connectivity.
* Re-run with verbose logging:

  ```bash
  sh 'bash -x script.sh'
  ```

---

### 🔥 **9. You are getting 502 Bad Gateway in a Kubernetes ingress. How do you troubleshoot?**

**Answer:**

* Check ingress logs:

  ```bash
  kubectl logs -n ingress-nginx <nginx-pod>
  ```
* Verify:

  * Backend service is running.
  * Target pod is healthy.
  * Correct service port in ingress definition.
* Confirm DNS resolution inside cluster (`nslookup` or `curl` service).

---

### 🔥 **10. After a Helm upgrade, app fails. What steps will you take to identify the issue?**

**Answer:**

* Use:

  ```bash
  helm history <release>
  helm rollback <release> <revision>
  ```
* Compare changed values using:

  ```bash
  helm get values --revision=X
  ```
* Validate pod events:

  ```bash
  kubectl describe pod
  ```
* Fix `values.yaml` and redeploy.

---


### 🔥 **11. Your Terraform plan shows unexpected changes even though nothing was modified. Why?**

**Answer:**

* Causes:

  * **Drift** in manually modified resources.
  * Dynamic values (e.g., `timestamp()`, `random_id`) recalculated.
  * Provider upgrade causing change in defaults.
* Solutions:

  * Use `terraform refresh` to sync state.
  * Add `lifecycle { ignore_changes = [...] }` where needed.
  * Investigate actual infra vs. state using cloud console.

---

### 🔥 **12. A pipeline suddenly started failing due to a `docker pull` error. What might be wrong?**

**Answer:**

* Possible issues:

  * Docker Hub or registry rate limit.
  * Network/DNS resolution failure.
  * Expired authentication token.
* Fix:

  * Add registry credentials.
  * Retry with a delay or mirror registry.
  * Check `.docker/config.json` for valid creds.

---

### 🔥 **13. After enabling autoscaling in Kubernetes, your app goes down. Why might that happen?**

**Answer:**

* Common causes:

  * Insufficient cluster resources → pods stay in `Pending`.
  * Incorrect HPA settings or low resource limits.
  * Readiness probe failing → pods not added to service.
* Fix:

  * Check `kubectl get events`.
  * Increase cluster node size or count.
  * Adjust autoscaler thresholds.

---

### 🔥 **14. Developer reports that a recent change is not reflected in the deployed application. What would you check?**

**Answer:**

* Ensure:

  * Latest code is merged into main.
  * CI/CD triggered successfully.
  * Image tag isn’t static (e.g., avoid using `latest` blindly).
  * Deployment used correct image tag.
* Tip: Use `kubectl describe deployment` and `kubectl get pods -o wide`.

---

### 🔥 **15. Your SSL certificate expired in production. What’s your response plan?**

**Answer:**

* Immediate:

  * Renew cert manually or via automation (Let’s Encrypt, ACM).
  * Restart web server or ingress controller.
* Preventive:

  * Monitor cert expiry using tools like Certbot or Prometheus alerts.
  * Use auto-renewal scripts or managed certs in cloud platforms.

---

### 🔥 **16. How do you debug a slow build in Jenkins or GitHub Actions?**

**Answer:**

* Use:

  * Timestamps to identify slow stages.
  * Parallel stages for test/build split.
  * Caching layers (e.g., Docker cache, Maven/NPM cache).
* Reduce I/O operations and external dependencies (e.g., avoid downloading in every build).

---

### 🔥 **17. You updated a ConfigMap but the pods are still using the old config. What went wrong?**

**Answer:**

* ConfigMap updates **don't reflect in existing pods** unless:

  * Volume mounted with `subPath` is not used (as it won’t auto-refresh).
  * Pods are restarted/redeployed.
* Fix:

  * Trigger rollout:

    ```bash
    kubectl rollout restart deployment <name>
    ```

---

### 🔥 **18. CI/CD pipeline cannot clone from Git. What might be wrong?**

**Answer:**

* Possible issues:

  * SSH key or PAT (Personal Access Token) expired or missing.
  * Git server unreachable or down.
  * Wrong repo URL (HTTPS vs. SSH).
* Fix:

  * Add credentials in Jenkins/GitHub Actions secrets.
  * Use correct protocol (e.g., `git@github.com:` for SSH).
  * Test manually using the same key/token.

---

### 🔥 **19. One microservice is failing but others work fine. What’s your debugging process?**

**Answer:**

* Steps:

  * Check pod logs: `kubectl logs <pod-name>`
  * Ensure dependencies are available (e.g., DB, APIs).
  * Validate service discovery and DNS (`nslookup`, `dig`, `curl`).
  * Review resource usage (`kubectl top`).
  * Check if config/env vars are misconfigured.

---

### 🔥 **20. Kubernetes pods keep restarting due to OOMKilled. What’s your fix?**

**Answer:**

* Causes:

  * Pod exceeds memory limit → killed by Kubelet.
* Fix:

  * Increase memory limits/requests:

    ```yaml
    resources:
      limits:
        memory: "512Mi"
      requests:
        memory: "256Mi"
    ```
  * Optimize app memory usage.
  * Monitor with Prometheus + Grafana dashboards.

---


