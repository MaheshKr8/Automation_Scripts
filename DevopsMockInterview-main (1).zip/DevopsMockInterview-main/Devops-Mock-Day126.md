
---

### 🔹 **1. How do you perform zero-downtime deployments in Kubernetes?**

**Answer:**
Use the **RollingUpdate** strategy in Deployments. It gradually replaces old Pods with new ones, ensuring at least one Pod is always running.

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1
    maxUnavailable: 0
```

---

### 🔹 **2. How do you troubleshoot a failing Docker container?**

**Answer:**
Check logs:

```bash
docker logs <container_id>
```

Use `docker inspect` for config issues.
Run interactive shell to debug:

```bash
docker exec -it <container_id> /bin/bash
```

---

### 🔹 **3. How do you implement auto-healing in Kubernetes?**

**Answer:**
Kubernetes auto-heals failed Pods using the **ReplicaSet**. If a Pod dies, the ReplicaSet automatically replaces it.

---

### 🔹 **4. How do you securely inject credentials into a CI/CD pipeline?**

**Answer:**

* Use Jenkins credentials plugin / GitHub Actions secrets.
* Avoid hardcoding secrets.
* Store in vault tools (AWS Secrets Manager, HashiCorp Vault).

---

### 🔹 **5. How do you rollback a Kubernetes deployment?**

**Answer:**

```bash
kubectl rollout undo deployment my-deployment
```

Use `kubectl rollout history` to check versions.

---

### 🔹 **6. How do microservices communicate securely in Kubernetes?**

**Answer:**
Use:

* **Service Mesh** like Istio/Linkerd for mTLS.
* Kubernetes **Network Policies** to restrict communication.

---

### 🔹 **7. How do you scale a Dockerized application for high traffic?**

**Answer:**

* Use `docker-compose scale` (legacy) or Docker Swarm/Kubernetes.
* Prefer Kubernetes `HorizontalPodAutoscaler` for auto-scaling.

---

### 🔹 **8. How do you set up monitoring in Kubernetes?**

**Answer:**

* **Prometheus** for metrics scraping.
* **Grafana** for visualization.
* **Node Exporter**, **kube-state-metrics** for additional data.

---

### 🔹 **9. How do you prevent configuration drift in infrastructure?**

**Answer:**
Use **Infrastructure as Code** tools like **Terraform**, version control configs, and run automated compliance checks.

---

### 🔹 **10. How do you debug a failed `kubectl apply` command?**

**Answer:**

* Use `kubectl describe` to get details.
* Check YAML syntax.
* Validate object kinds and versions.
* Use `kubectl apply -f <file> --dry-run=client -o yaml`.

---

### 🔹 **11. How do you reduce Docker image size?**

**Answer:**

* Use Alpine base images.
* Multi-stage builds.
* Remove unnecessary layers/files.

```Dockerfile
FROM node:alpine
WORKDIR /app
COPY . .
RUN npm ci
CMD ["npm", "start"]
```

---

### 🔹 **12. What is your strategy for handling stateful apps in Kubernetes?**

**Answer:**
Use:

* **StatefulSets**
* **PersistentVolumeClaims (PVCs)**
* Dedicated **StorageClasses**

---

### 🔹 **13. How do you handle secrets securely in Kubernetes?**

**Answer:**

* Use `Secret` objects.
* Encrypt secrets at rest.
* Access via environment variables or mounted volumes.
* Integrate with Vault or Sealed Secrets.

---

### 🔹 **14. How do you handle log aggregation in a containerized environment?**

**Answer:**
Use **EFK (Elasticsearch, Fluentd, Kibana)** or **Loki + Grafana** for centralized logging.

---

### 🔹 **15. How do you troubleshoot pod communication issues in Kubernetes?**

**Answer:**

* Use `kubectl exec` to ping services.
* Validate service names and ports.
* Check `NetworkPolicy` restrictions.
* Verify CNI plugin (Calico, Flannel) is working.

---

### 🔹 **16. How do you implement blue-green deployment in Kubernetes?**

**Answer:**

* Create two deployments: blue (live) and green (new).
* Use a **Service** to switch traffic between them.
* Rollback by switching the Service selector.

---

### 🔹 **17. How do you manage environment-specific configurations in Kubernetes?**

**Answer:**

* Use **ConfigMaps** for each environment.
* Inject using volume mounts or environment variables.
* Use tools like **Helm** or **Kustomize** for templating.

---

### 🔹 **18. How do you configure health checks in Docker and Kubernetes?**

**Answer:**
**Docker**:

```Dockerfile
HEALTHCHECK CMD curl --fail http://localhost:8080/health || exit 1
```

**Kubernetes**:

```yaml
livenessProbe:
  httpGet:
    path: /health
    port: 8080
```

---

### 🔹 **19. How do you handle service-to-service authentication in Kubernetes?**

**Answer:**

* Use **mTLS** via Istio/Linkerd.
* Validate JWT tokens.
* Use **service accounts** with RBAC roles.

---

### 🔹 **20. How do you clean up unused Docker resources in CI/CD pipelines?**

**Answer:**
Use:

```bash
docker system prune -af
```

Schedule cleanup scripts periodically to free space.

---

