Here are **20 real-time DevOps interview questions with practical answers**, tailored for someone attending an interview soon. These reflect common use cases involving Jenkins, Terraform, Kubernetes, Ansible, CI/CD, and Cloud infrastructure.

---

### ✅ **1. Explain your CI/CD pipeline setup and tools used in your project.**

**Answer:**
We use **Jenkins** as our main CI/CD tool. Developers push code to **GitHub**, which triggers a Jenkins job via **webhook**. The pipeline performs **SonarQube code analysis**, **Trivy image scanning**, builds a **Docker image**, pushes it to **ECR**, and deploys to **EKS** using Helm. Notifications are sent via **Slack**.

---

### ✅ **2. How do you manage Terraform state across different environments?**

**Answer:**
We use **remote backend** in **AWS S3**, with **separate folders/buckets per environment** (e.g., dev/prod). **DynamoDB** is used for **state locking** to prevent race conditions in concurrent deployments.

---

### ✅ **3. What’s your strategy for zero-downtime deployment in Kubernetes?**

**Answer:**
We use **rolling updates** in the deployment spec with `maxUnavailable: 0`. For critical apps, we use **blue-green or canary deployment** strategies using **Argo Rollouts or Istio**.

---

### ✅ **4. How do you troubleshoot a failed Jenkins pipeline?**

**Answer:**
I check the **Jenkins console output**, inspect **individual stage logs**, verify **environment variables**, and check **Docker build logs** or **kubectl describe pod** if the deployment fails. If needed, I re-run the job with debug flags.

---

### ✅ **5. How do you integrate SonarQube and Trivy into your Jenkins pipeline?**

**Answer:**
For **SonarQube**, I use the `withSonarQubeEnv()` block and the Maven scanner. For **Trivy**, I run a shell command like:

```bash
trivy image myapp:latest --exit-code 1 --severity CRITICAL
```

and fail the build if vulnerabilities are found.

---

### ✅ **6. Have you implemented Infrastructure as Code? Give an example.**

**Answer:**
Yes. I used **Terraform** to provision VPCs, subnets, EKS clusters, RDS, and S3. For example, our entire staging environment (network + compute + DB) is codified in a Terraform module.

---

### ✅ **7. How do you handle secrets management in your infrastructure?**

**Answer:**
We use **AWS Secrets Manager** or **HashiCorp Vault** to store secrets. In Kubernetes, secrets are mounted via volumes or environment variables and encrypted at rest. For Ansible, we use **Ansible Vault**.

---

### ✅ **8. Describe how you monitor applications and infrastructure.**

**Answer:**
We use **Prometheus** for metrics, **Grafana** for visualization, and **Alertmanager** for notifications. **Fluentd** or **ELK stack** is used for logs. Infrastructure health is monitored via **CloudWatch** and **custom dashboards**.

---

### ✅ **9. What is your disaster recovery strategy in the cloud?**

**Answer:**
We replicate data across **multiple regions** using **RDS cross-region replication** and regular **S3 backups**. EKS clusters are backed up via **Velero**. DNS failover is configured in **Route 53** using health checks.

---

### ✅ **10. How do you scale an application running in Kubernetes?**

**Answer:**
We configure **Horizontal Pod Autoscalers (HPA)** based on CPU/memory. For large-scale apps, **Cluster Autoscaler** scales nodes. Additionally, we use **load testing** tools to simulate traffic before scaling.

---

### ✅ **11. What is your approach to patch management and OS updates?**

**Answer:**
We use **Ansible** for patch automation. In cloud, **AWS SSM Patch Manager** helps patch EC2 instances. For containers, we rebuild base images regularly using CI pipelines.

---

### ✅ **12. How do you roll back a faulty deployment in Kubernetes or Jenkins?**

**Answer:**
In Kubernetes:

```bash
kubectl rollout undo deployment <app-name>
```

In Jenkins, I maintain build artifacts and use the previous tag to redeploy. Helm also supports rollback via `helm rollback`.

---

### ✅ **13. How do you use Ansible in production?**

**Answer:**
We use Ansible for **config management**, **package installation**, **user creation**, **application deployment**, and **server provisioning**. Inventories are dynamic, sourced from **AWS EC2** or **CMDB**.

---

### ✅ **14. What are best practices for writing Dockerfiles?**

**Answer:**

* Use small base images like `alpine`
* Avoid installing unnecessary packages
* Use multi-stage builds
* Minimize layers
* Always pin versions
* Don't store secrets in images

---

### ✅ **15. How do you implement blue-green or canary deployments in Kubernetes?**

**Answer:**
Using **Argo Rollouts** or **Flagger** with **Istio**, we split traffic gradually between old and new versions. We use metrics to validate new versions before full rollout.

---

### ✅ **16. How do you manage IAM roles and policies using Terraform?**

**Answer:**
We define IAM roles as Terraform resources like `aws_iam_role`, `aws_iam_policy`, and use `aws_iam_role_policy_attachment` for binding. Each environment gets its own role with limited privileges (least privilege principle).

---

### ✅ **17. What security practices do you follow while deploying apps in the cloud?**

**Answer:**

* Use **IAM roles** with least privilege
* Enable **encryption at rest and transit**
* Use **security groups**, **NACLs**
* Scan Docker images
* Enable **CloudTrail**, **GuardDuty**

---

### ✅ **18. How do you handle log aggregation and centralized logging?**

**Answer:**
We use the **EFK (Elasticsearch, Fluentd, Kibana)** or **Loki + Grafana** stack. Logs are collected via **Fluent Bit** or **Filebeat**, enriched with metadata, and shipped to a central store.

---

### ✅ **19. Explain how DNS resolution works inside Kubernetes.**

**Answer:**
K8s uses **CoreDNS**. Services are registered with names like `service.namespace.svc.cluster.local`. Pods use `kube-dns` as a nameserver and CoreDNS resolves internal and external names.

---

### ✅ **20. Have you ever performed cloud migration? What were the challenges and solutions?**

**Answer:**
Yes, we migrated from on-prem to AWS. Challenges included **data synchronization**, **network latency**, and **legacy app compatibility**. We used **AWS DMS**, **Snowball**, and containerized legacy apps for cloud readiness.

---
