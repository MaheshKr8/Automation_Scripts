### 1. **How do you configure Jenkins to integrate with GitHub?**

**Answer:**
1. **Install Git Plugin:**
   - Go to **Manage Jenkins** > **Manage Plugins** and install the Git plugin.
   
2. **Create a New Job:**
   - Create a new job in Jenkins, select **Freestyle Project** or **Pipeline**.
   
3. **Set GitHub as the Source Control:**
   - Under the **Source Code Management** section, select Git and provide the repository URL.
   
4. **Set Up Webhooks:**
   - In the GitHub repository settings, go to **Webhooks** and add the Jenkins URL to trigger builds automatically when changes are pushed.

**Example Webhook URL:**
```bash
http://<Jenkins-URL>/github-webhook/
```

### 2. **How do you secure Jenkins?**

**Answer:**
1. **Use Role-Based Access Control (RBAC):**
   - Install the **Role-Based Authorization Strategy Plugin** to set roles and restrict access.
   
2. **Enable Security Settings:**
   - Go to **Manage Jenkins** > **Configure Global Security** and enable **Security Realm** and **Authorization**.
   
3. **Use SSL:**
   - Configure Jenkins to run behind HTTPS for secure communication.
   
4. **Backup and Audit Logs:**
   - Regularly back up Jenkins configurations and enable auditing for tracking user actions.

### 3. **What is the purpose of a Jenkinsfile, and where is it stored?**

**Answer:**
A Jenkinsfile is a text file that contains the definition of a Jenkins pipeline. It is typically stored in the root of the source control repository (e.g., GitHub, GitLab) and provides version control for the CI/CD pipeline.

**Types of Jenkinsfiles:**
- **Declarative Pipeline**
- **Scripted Pipeline**

### 4. **What is Blue Ocean in Jenkins?**

**Answer:**
Blue Ocean is a modern, visual alternative to the Jenkins classic UI that simplifies pipeline creation and visualization. It provides a graphical interface to create and view Jenkins pipelines, making it easier to see pipeline statuses, logs, and job details in a user-friendly format.

### 5. **What is the difference between a Freestyle project and a Pipeline in Jenkins?**

**Answer:**
- **Freestyle Project:** A simple, predefined build job that allows you to perform basic tasks like building code and running scripts. It has a limited set of features and doesn't support complex automation.
  
- **Pipeline:** A more flexible, code-defined process that supports complex workflows, parallel tasks, conditionals, and is defined in a Jenkinsfile. It allows for CI/CD with full control over the build, test, and deployment phases.

