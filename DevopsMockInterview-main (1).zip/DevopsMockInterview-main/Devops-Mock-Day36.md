
1. **Explain how Docker multi-stage builds work.**
    - **Answer**: Multi-stage builds allow you to use multiple `FROM` statements in a Dockerfile, where each stage can copy artifacts from previous stages. This helps in reducing the final image size by copying only necessary files to the final image.

2. **How do you handle application updates in a Dockerized environment without downtime?**
    - **Answer**: Use strategies like blue-green deployments, rolling updates (via Docker Swarm or Kubernetes), or A/B testing to update applications with zero downtime.

3. **What is a Docker overlay network, and when would you use it?**
    - **Answer**: An overlay network allows containers on different Docker hosts to communicate securely. It is used in Swarm mode or multi-host environments where services need to communicate across different physical or virtual machines.

4. **How do you troubleshoot networking issues in Docker containers?**
    - **Answer**: Use commands like `docker network inspect`, `docker exec <container_id> ping <ip>`, and `docker logs` to diagnose network connectivity, DNS resolution, or configuration issues.

5. **Explain how Docker manages resource limits for CPU and memory.**
    - **Answer**: Docker allows you to set resource constraints using flags like `--memory` and `--cpus` in the `docker run` command, which limits the container's usage of memory and CPU resources to prevent it from overwhelming the host.


6. **How do you integrate Docker into a CI/CD pipeline?**
    - **Answer**: Integrate Docker by building images in the CI/CD pipeline using tools like Jenkins, GitLab CI, or CircleCI. Use `docker build` to create images, `docker push` to publish them to a registry, and deploy them using orchestration tools.

7. **Explain how you would use Docker for local development and testing.**
    - **Answer**: Use Docker to create consistent development environments by defining services, dependencies, and configurations in Dockerfiles and Docker Compose files. This ensures that developers and CI pipelines use the same environment.

8. **How do you manage different environments (dev, staging, prod) with Docker?**
    - **Answer**: Use different Docker Compose files for each environment or use Docker Swarm/Kubernetes to manage different stacks. Environment-specific configurations can be managed with environment variables, secrets, and config maps.

9. **What are the advantages of using a private Docker registry, and how do you set it up?**
    - **Answer**: A private Docker registry allows you to securely store and share Docker images within an organization. Set it up using Docker's `registry` image, configure authentication, and optionally use TLS for secure access.

10. **How would you automate the deployment of Docker containers in a production environment?**
    - **Answer**: Automate deployments using CI/CD tools, along with orchestration platforms like Docker Swarm or Kubernetes. Use Infrastructure as Code (IaC) tools like Terraform or Ansible to define and manage infrastructure and container deployments.



11. **What is the difference between Docker Swarm and Kubernetes, and when would you choose one over the other?**
    - **Answer**: Docker Swarm is simpler to set up and use, ideal for smaller clusters, while Kubernetes is more feature-rich and scalable, suitable for large, complex environments. Kubernetes offers more flexibility and ecosystem integrations.

12. **How do you perform a rolling update in Docker Swarm?**
    - **Answer**: Use `docker service update` with the `--update-parallelism` and `--update-delay` options to control the rolling update process for a Sw

arm service.

13. **Explain how service discovery works in Docker Swarm.**
    - **Answer**: Docker Swarm provides built-in service discovery, allowing containers to communicate using service names. DNS entries for services are automatically created and updated as services scale or change.

14. **How do you handle node failures in a Docker Swarm cluster?**
    - **Answer**: Docker Swarm automatically re-schedules containers from failed nodes to healthy ones, as long as there are sufficient resources. Swarm managers should be set up in a high-availability configuration to avoid single points of failure.

15. **How do you migrate a Dockerized application from Docker Swarm to Kubernetes?**
    - **Answer**: Migrate by converting Swarm service definitions to Kubernetes resources like Deployments, Services, and ConfigMaps. Use tools like Kompose to assist with the conversion, and update CI/CD pipelines accordingly.

