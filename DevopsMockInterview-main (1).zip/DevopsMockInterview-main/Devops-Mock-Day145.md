
---

### ✅ **1. Scenario: Your Jenkins pipeline is failing randomly during the build stage. How do you troubleshoot and ensure build stability?**

**Answer:**

* Check Jenkins build logs for exact failure point.
* Confirm consistent build environment using **Docker agents**.
* Add retries in flaky stages using `retry(n)` block.
* Ensure dependencies are installed and version-locked (Maven, npm, etc.).
* Run the build locally in a container to reproduce the issue.

---

### ✅ **2. Scenario: You deployed a new version of a service to Kubernetes and now it's returning 500 errors. What’s your debugging approach?**

**Answer:**

* Check the pod logs:

  ```bash
  kubectl logs <pod-name>
  ```
* Describe the pod for events (e.g., crash, readiness probe failure):

  ```bash
  kubectl describe pod <pod-name>
  ```
* Roll back the deployment:

  ```bash
  kubectl rollout undo deployment <name>
  ```
* Verify service routing and config maps/secrets.

---

### ✅ **3. Scenario: A developer pushed a bad change directly to `main` branch. How do you prevent this and enforce best practices?**

**Answer:**

* Set **branch protection rules**:

  * Require pull request approval.
  * Disallow force pushes.
  * Require CI checks to pass before merging.
* Use GitHub/GitLab policies or pre-receive hooks.

---

### ✅ **4. Scenario: Your Terraform apply command unexpectedly deletes a resource. How can you prevent this?**

**Answer:**

* Add lifecycle rules to sensitive resources:

  ```hcl
  lifecycle {
    prevent_destroy = true
  }
  ```
* Always review `terraform plan` before apply.
* Use `terraform plan -out=tfplan` and manual approvals.
* Store state remotely in **S3 with locking via DynamoDB**.

---

### ✅ **5. Scenario: Your EC2 instance cannot connect to the internet. What do you check?**

**Answer:**

* Is the instance in a **public subnet** with an **Internet Gateway**?
* Does it have a **public IP** assigned?
* Check **security groups** and **NACLs** for outbound rules.
* Use `curl` or `ping` from the instance for verification.

---

### ✅ **6. Scenario: A Docker container crashes immediately after starting. What steps do you take?**

**Answer:**

* Check container logs:

  ```bash
  docker logs <container_id>
  ```
* Check exit code with:

  ```bash
  docker inspect --format='{{.State.ExitCode}}' <container_id>
  ```
* Common issues:

  * Incorrect `CMD` or `ENTRYPOINT`.
  * Missing environment variables.
  * Dependency service not reachable.

---

### ✅ **7. Scenario: Two Kubernetes pods in different namespaces should not talk to each other. How do you enforce this?**

**Answer:**

* Use **NetworkPolicies** with a default deny-all policy:

  ```yaml
  kind: NetworkPolicy
  spec:
    podSelector: {}
    ingress: []
  ```
* Whitelist only allowed traffic using `namespaceSelector`.

---

### ✅ **8. Scenario: You want to reduce latency for users accessing your S3-hosted app from different continents. What do you do?**

**Answer:**

* Use **Amazon CloudFront** as a CDN in front of the S3 bucket.
* Enable **Geo-replication** if users are uploading data.
* Enable **HTTP/2** and caching for static content.

---

### ✅ **9. Scenario: During deployment, you realize the app isn’t connecting to the RDS database. What checks do you perform?**

**Answer:**

* Check **security groups** for DB access.
* Verify DB credentials (check secrets or environment variables).
* Confirm the app is deployed in the **same VPC/subnet** or has **VPC peering** if separate.
* Use `telnet <db-host> 5432` from app pod/instance.

---

### ✅ **10. Scenario: You need to scan container images for vulnerabilities before pushing to ECR. How do you set this up?**

**Answer:**

* Use **Trivy** or **Grype**:

  ```bash
  trivy image myapp:latest
  ```
* Integrate scan step into your CI/CD pipeline.
* Fail builds if critical vulnerabilities are found.
* Optionally, enable **ECR image scanning** (basic or enhanced).

---
