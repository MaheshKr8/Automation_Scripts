### **Advanced Jenkins Real-Time Interview Questions and Scenarios**  
Here are some additional **tough real-time Jenkins scenarios** covering **troubleshooting, Jenkins + Terraform integration, and advanced CI/CD workflows.**  

---

## **🔹 Troubleshooting and Debugging Jenkins Issues**  

### **1️⃣ Scenario: Jenkins Build Fails Due to Disk Space Issues**  
#### **Question:**  
Your Jenkins jobs are failing with an error:  
> "No space left on device"  

How do you resolve this issue?  

#### **Answer:**  
- **Check disk usage** on the Jenkins server:  
  ```sh
  df -h
  du -sh /var/lib/jenkins
  ```
- **Clear old builds and logs:**  
  ```sh
  rm -rf /var/lib/jenkins/workspace/*
  ```
- **Configure Jenkins to delete old builds automatically:**  
  - In Jenkins UI → **Job Configuration → Discard Old Builds**  
  - Retain the last **10 builds** to save space.

- **Move Jenkins home directory to a larger disk:**  
  ```sh
  mv /var/lib/jenkins /mnt/bigger-disk/jenkins
  ln -s /mnt/bigger-disk/jenkins /var/lib/jenkins
  ```

---

### **2️⃣ Scenario: Jenkins Agent Fails to Connect to the Master Node**  
#### **Question:**  
Your Jenkins agent is not connecting to the master. How do you debug this?  

#### **Answer:**  
- Check **Jenkins Master Logs:**  
  ```sh
  cat /var/log/jenkins/jenkins.log
  ```
- Check **Jenkins Agent Logs:**  
  ```sh
  tail -f /var/log/jenkins-agent.log
  ```
- Ensure **firewall rules allow port 50000** (default for agents):  
  ```sh
  sudo ufw allow 50000/tcp
  ```

- **Restart Jenkins agent:**  
  ```sh
  java -jar agent.jar -jnlpUrl http://jenkins-master:8080/computer/agent-node/slave-agent.jnlp -secret <SECRET>
  ```

---

### **3️⃣ Scenario: Jenkins Job Stuck at "Waiting for Executor"**  
#### **Question:**  
A job is stuck in the queue with "Waiting for Executor." How do you resolve this?  

#### **Answer:**  
- **Check Available Executors:**  
  - Go to **Jenkins UI → Manage Jenkins → Nodes**
  - Ensure at least **one executor is online**.

- **Manually Add an Executor:**  
  ```sh
  sudo systemctl restart jenkins
  ```

- **Check if the node is offline:**  
  ```sh
  tail -f /var/log/jenkins/jenkins.log
  ```

---

## **🔹 Jenkins + Terraform Integration Questions**  

### **4️⃣ Scenario: Running Terraform in a Jenkins Pipeline**  
#### **Question:**  
How do you integrate Terraform with Jenkins to deploy infrastructure?  

#### **Answer:**  
1. **Install Terraform Plugin in Jenkins**  
   - **Manage Jenkins → Plugins → Terraform Plugin**  

2. **Use a Jenkinsfile to Execute Terraform**  

#### **Jenkinsfile Example:**  
```groovy
pipeline {
    agent any
    environment {
        AWS_ACCESS_KEY_ID = credentials('aws-key')
        AWS_SECRET_ACCESS_KEY = credentials('aws-secret')
    }
    stages {
        stage('Terraform Init') {
            steps {
                sh 'terraform init'
            }
        }
        stage('Terraform Plan') {
            steps {
                sh 'terraform plan -out=tfplan'
            }
        }
        stage('Terraform Apply') {
            steps {
                sh 'terraform apply tfplan'
            }
        }
    }
}
```

---

### **5️⃣ Scenario: Terraform Apply Fails Due to Locked State File**  
#### **Question:**  
Your Jenkins pipeline fails during `terraform apply` with:  
> "Error: Error acquiring the state lock"  

How do you fix it?  

#### **Answer:**  
- **Check active Terraform state locks:**  
  ```sh
  aws dynamodb scan --table-name terraform-locks
  ```
- **Manually unlock the state:**  
  ```sh
  terraform force-unlock <LOCK_ID>
  ```
- **Fix Terraform Backend Config in `Jenkinsfile`:**  
  ```groovy
  terraform {
      backend "s3" {
          bucket         = "my-terraform-bucket"
          key            = "terraform.tfstate"
          region         = "us-west-2"
          dynamodb_table = "terraform-locks"
      }
  }
  ```

---

## **🔹 Advanced Jenkins CI/CD Scenarios**  

### **6️⃣ Scenario: Canary Deployment Using Jenkins and Kubernetes**  
#### **Question:**  
How do you perform a **canary deployment** using Jenkins?  

#### **Answer:**  
1. **Deploy a new version to 10% of users:**  
2. **Gradually shift traffic from old to new deployment.**  

#### **Jenkinsfile Example:**  
```groovy
pipeline {
    agent any
    stages {
        stage('Deploy Canary') {
            steps {
                sh 'kubectl apply -f k8s/deployment-canary.yaml'
            }
        }
        stage('Monitor Traffic') {
            steps {
                sh 'kubectl get pods -o wide'
            }
        }
        stage('Shift 100% Traffic to New Version') {
            steps {
                sh 'kubectl apply -f k8s/service-new.yaml'
            }
        }
    }
}
```

---

### **7️⃣ Scenario: Running Selenium UI Tests in a Jenkins Pipeline**  
#### **Question:**  
How do you integrate **Selenium UI tests** into a Jenkins pipeline?  

#### **Answer:**  
- **Install Selenium in Jenkins Server:**  
  ```sh
  sudo apt-get install -y xvfb
  ```
- **Run Selenium Tests in Pipeline:**  

#### **Jenkinsfile Example:**  
```groovy
pipeline {
    agent any
    stages {
        stage('Run Selenium Tests') {
            steps {
                sh 'xvfb-run --server-args="-screen 0 1024x768x24" mvn test -Dtest=UITests'
            }
        }
    }
}
```

---

### **8️⃣ Scenario: Auto-Scaling Jenkins Agents on Kubernetes**  
#### **Question:**  
How do you configure Jenkins to automatically **scale agents on Kubernetes?**  

#### **Answer:**  
1. **Install Kubernetes Plugin** in Jenkins  
2. **Define a Kubernetes Pod Template:**  

#### **Jenkinsfile Example:**  
```groovy
pipeline {
    agent {
        kubernetes {
            yaml """
            apiVersion: v1
            kind: Pod
            spec:
              containers:
              - name: jnlp
                image: jenkins/jnlp-slave
                args: ['$(JENKINS_SECRET)', '$(JENKINS_NAME)']
            """
        }
    }
    stages {
        stage('Run Build on Kubernetes') {
            steps {
                sh 'mvn clean package'
            }
        }
    }
}
```

---

### **9️⃣ Scenario: Running Jenkins with Trivy for Security Scanning**  
#### **Question:**  
How do you **scan Docker images for vulnerabilities** in Jenkins using Trivy?  

#### **Answer:**  
1. **Install Trivy Plugin in Jenkins**  
2. **Run Trivy Security Scan in Jenkinsfile**  

#### **Jenkinsfile Example:**  
```groovy
pipeline {
    agent any
    stages {
        stage('Build Docker Image') {
            steps {
                sh 'docker build -t my-app:latest .'
            }
        }
        stage('Run Security Scan') {
            steps {
                sh 'trivy image --exit-code 1 my-app:latest'
            }
        }
    }
}
```

---

### **🔟 Scenario: Jenkins Pipeline Fails Due to Permission Issues**  
#### **Question:**  
Jenkins jobs fail with **permission denied errors.** How do you resolve it?  

#### **Answer:**  
- **Fix file ownership in Jenkins Home:**  
  ```sh
  sudo chown -R jenkins:jenkins /var/lib/jenkins
  ```
- **Run jobs as Jenkins user:**  
  ```sh
  sudo su - jenkins
  ```

---
