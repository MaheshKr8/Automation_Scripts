Here are 50 real-time scenario-based Kubernetes interview questions and answers with real-life examples and explanations:



1. **What is a Kubernetes Pod, and how does it work?**
    - **Explanation**: A Pod is the smallest deployable unit in Kubernetes, consisting of one or more containers sharing the same storage and network.
    - **Real-life example**: Running a multi-container app where one container is a web server, and another container acts as a logger.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Pod
      metadata:
        name: multi-container-pod
      spec:
        containers:
          - name: web-server
            image: nginx
          - name: logger
            image: busybox
            args: ["sh", "-c", "while true; do echo 'logging'; sleep 5; done"]
      ```

2. **How do you handle Pod restarts when they crash?**
    - **Explanation**: Kubernetes automatically restarts Pods using the `restartPolicy` in the Pod specification.
    - **Real-life example**: A web server container crashes due to out-of-memory issues, and Kubernetes restarts it.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Pod
      metadata:
        name: restart-pod
      spec:
        containers:
          - name: web-server
            image: nginx
        restartPolicy: Always
      ```

3. **What happens when you scale a Deployment from 3 to 5 replicas?**
    - **Explanation**: Kubernetes creates 2 additional Pods to match the desired replica count.
    - **Real-life example**: Scaling a web application to handle increased traffic.
    - **Command**:
      ```bash
      kubectl scale deployment my-web-app --replicas=5
      ```

4. **How do you ensure a Pod is rescheduled in case a node fails?**
    - **Explanation**: Kubernetes ensures Pods are rescheduled on another available node.
    - **Real-life example**: If a node running a critical database crashes, the Pod will be rescheduled.
    - **Command**:
      ```bash
      kubectl get pods -o wide
      ```

5. **What is a ReplicaSet, and how is it different from a Deployment?**
    - **Explanation**: A ReplicaSet ensures a specified number of Pods are running, while a Deployment offers features like rolling updates.
    - **Real-life example**: Running stateless applications where Pods need constant replication.
    - **Command**:
      ```yaml
      apiVersion: apps/v1
      kind: ReplicaSet
      metadata:
        name: my-replicaset
      spec:
        replicas: 3
        selector:
          matchLabels:
            app: my-app
        template:
          metadata:
            labels:
              app: my-app
          spec:
            containers:
              - name: nginx
                image: nginx
      ```



6. **How does a Service provide access to Pods?**
    - **Explanation**: A Service provides a stable IP and load balances traffic across the Pods.
    - **Real-life example**: Exposing a web app with multiple backend Pods.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Service
      metadata:
        name: my-service
      spec:
        selector:
          app: my-app
        ports:
          - protocol: TCP
            port: 80
            targetPort: 80
      ```

7. **What is the difference between ClusterIP, NodePort, and LoadBalancer Services?**
    - **Explanation**: ClusterIP exposes the service only within the cluster, NodePort exposes it on a node's IP, and LoadBalancer uses cloud providers to balance traffic.
    - **Real-life example**: Exposing a service externally using `LoadBalancer` in a cloud environment.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Service
      metadata:
        name: my-loadbalancer-service
      spec:
        type: LoadBalancer
        selector:
          app: my-app
        ports:
          - protocol: TCP
            port: 80
            targetPort: 80
      ```

8. **How does Kubernetes manage DNS for Services?**
    - **Explanation**: Kubernetes automatically assigns DNS names to services, allowing them to be accessed by name within the cluster.
    - **Real-life example**: Connecting a backend service to a database service using DNS.
    - **Command**:
      ```bash
      curl http://my-database-service.default.svc.cluster.local
      ```

9. **How does the network flow work when a client hits a ClusterIP service?**
    - **Explanation**: The request flows through kube-proxy, which forwards the request to a backend Pod.
    - **Real-life example**: A web application where the frontend sends requests to a backend service exposed using ClusterIP.
    - **Command**:
      ```bash
      kubectl get service my-clusterip-service
      ```

10. **How do you expose a Kubernetes Service using Ingress?**
    - **Explanation**: Ingress allows external HTTP and HTTPS traffic to access the services.
    - **Real-life example**: Exposing a web application with multiple paths using Ingress.
    - **Command**:
      ```yaml
      apiVersion: networking.k8s.io/v1
      kind: Ingress
      metadata:
        name: my-ingress
      spec:
        rules:
          - host: my-app.example.com
            http:
              paths:
                - path: /
                  pathType: Prefix
                  backend:
                    service:
                      name: my-service
                      port:
                        number: 80
      ```



11. **What happens if there are not enough resources to schedule a Pod?**
    - **Explanation**: The Pod stays in the pending state until resources become available.
    - **Real-life example**: A resource-intensive application can't be scheduled until a node with more memory is available.
    - **Command**:
      ```bash
      kubectl describe pod <pod-name>
      ```

12. **How do you use node affinity to schedule Pods on specific nodes?**
    - **Explanation**: Node affinity ensures Pods are scheduled on nodes with specific labels.
    - **Real-life example**: Running a Pod on a node with SSD storage.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Pod
      metadata:
        name: affinity-pod
      spec:
        affinity:
          nodeAffinity:
            requiredDuringSchedulingIgnoredDuringExecution:
              nodeSelectorTerms:
                - matchExpressions:
                    - key: storage
                      operator: In
                      values:
                        - ssd
        containers:
          - name: nginx
            image: nginx
      ```

13. **How do taints and tolerations work in Kubernetes?**
    - **Explanation**: Taints prevent Pods from being scheduled on specific nodes unless the Pods have tolerations.
    - **Real-life example**: Preventing non-critical workloads from being scheduled on production nodes.
    - **Command**:
      ```bash
      # Add a taint to a node
      kubectl taint nodes <node-name> key=value:NoSchedule

      # Pod toleration example
      apiVersion: v1
      kind: Pod
      metadata:
        name: tolerant-pod
      spec:
        tolerations:
          - key: "key"
            operator: "Equal"
            value: "value"
            effect: "NoSchedule"
        containers:
          - name: nginx
            image: nginx
      ```

14. **How do you schedule Pods using Kubernetes Jobs?**
    - **Explanation**: Jobs are used for batch processing, running a Pod to completion.
    - **Real-life example**: Running a database backup script as a Kubernetes Job.
    - **Command**:
      ```yaml
      apiVersion: batch/v1
      kind: Job
      metadata:
        name: backup-job
      spec:
        template:
          spec:
            containers:
              - name: backup
                image: my-backup-image
                args: ["sh", "-c", "backup.sh"]
            restartPolicy: OnFailure
      ```

15. **What is a CronJob, and how do you schedule it?**
    - **Explanation**: A CronJob runs a Job periodically based on a cron schedule.
    - **Real-life example**: Scheduling a data cleanup script to run every night.
    - **Command**:
      ```yaml
      apiVersion: batch/v1
      kind: CronJob
      metadata:
        name: cleanup-cronjob
      spec:
        schedule: "0 0 * * *"
        jobTemplate:
          spec:
            template:
              spec:
                containers:
                  - name: cleanup
                    image: my-cleanup-image
                    args: ["sh", "-c", "cleanup.sh"]
                restartPolicy: OnFailure
      ```


