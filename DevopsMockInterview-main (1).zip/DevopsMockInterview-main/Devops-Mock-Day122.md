
---

### ✅ 1. **Scenario:** A production deployment failed. How do you troubleshoot?

**Answer:**

* Check Jenkins pipeline logs
* Rollback to previous stable build
* Check application logs using `kubectl logs` or ELK stack
* Verify if environment variables/secrets changed
* Use monitoring tools like Prometheus/Grafana for resource bottlenecks

---

### ✅ 2. **Scenario:** A pod in Kubernetes is crash looping. What do you do?

**Answer:**

* Run `kubectl describe pod <pod-name>` to check events
* Use `kubectl logs <pod-name>` for container logs
* Check health probes, resource limits, or missing config/secrets
* Run a debug pod using `kubectl debug` or `kubectl exec`

---

### ✅ 3. **Scenario:** Terraform state file is accidentally deleted. What are your next steps?

**Answer:**

* Recover state file from versioned S3 backup
* Run `terraform refresh` to sync with actual infrastructure
* Use `terraform import` to recreate state if backup is not available
* Always configure versioning and state locking (DynamoDB)

---

### ✅ 4. **Scenario:** A new Docker image was pushed with a critical vulnerability. How do you prevent this?

**Answer:**

* Use Trivy to scan images in Jenkins
* Fail the build if vulnerabilities are found
* Integrate policy engines like OPA/Gatekeeper or Harbor image signing
* Enable image allowlisting in Kubernetes admission controller

---

### ✅ 5. **Scenario:** Developers pushed code that broke production. How do you handle this?

**Answer:**

* Roll back to last stable version using Helm/Kubernetes
* Use Git tags or versioned deployments
* Improve pipeline with automated tests and canary deployments
* Add approval stage in Jenkins before production

---

### ✅ 6. **Scenario:** Jenkins master is down. What’s your recovery strategy?

**Answer:**

* Restore Jenkins from a backup (usually via persistent volume)
* Use Jenkins Configuration as Code (JCasC) for fast bootstrapping
* Consider Jenkins in HA setup or migration to GitHub Actions/GitLab CI

---

### ✅ 7. **Scenario:** You need to deploy infrastructure to multiple environments. How do you manage this in Terraform?

**Answer:**

* Use **workspaces** or **directory-based environment separation**
* Store state files in remote S3 backend with per-environment prefix
* Use input variables and override files for environment-specific configs

---

### ✅ 8. **Scenario:** How do you ensure secrets aren’t leaked in CI/CD pipelines?

**Answer:**

* Use Jenkins credentials store
* Avoid printing secrets in pipeline logs
* Use tools like Vault, AWS Secrets Manager
* Enable scanning tools like GitLeaks in pre-commit or CI steps

---

### ✅ 9. **Scenario:** Your application needs to scale during high traffic. What’s your approach?

**Answer:**

* Enable **Horizontal Pod Autoscaler** in Kubernetes
* Set `cpu` and `memory` requests/limits
* Use cloud-native load balancers (ALB/ELB)
* Monitor and tune based on Prometheus/Grafana metrics

---

### ✅ 10. **Scenario:** Deployment to production must have zero downtime. How do you achieve this?

**Answer:**

* Use **rolling updates** or **blue-green deployments**
* Implement readiness probes to ensure traffic goes only to healthy pods
* Use feature flags to control release visibility
* Test in staging environment using canary strategy

---

### ✅ 11. **Scenario:** A region in AWS goes down. What would you do?

**Answer:**

* Use multi-region active-passive setup
* Route 53 with failover policy
* Backup critical services using snapshots or replication
* Automate infra recovery using Terraform or CloudFormation

---

### ✅ 12. **Scenario:** A new developer needs access to deploy code. How do you manage it securely?

**Answer:**

* Use RBAC policies (GitHub/GitLab/Jenkins)
* Role-based IAM policies in cloud
* Set up SSO with least privilege access
* Audit logs for accountability

---

### ✅ 13. **Scenario:** App performance is degrading. What’s your debugging flow?

**Answer:**

* Check CPU/memory usage in Grafana
* Review application logs
* Profile latency with APM tools (New Relic, Datadog)
* Check DB connections, external API delays

---

### ✅ 14. **Scenario:** How do you manage code and infra changes in sync?

**Answer:**

* Use **monorepo or GitOps** practices
* Terraform modules live alongside app code
* Use Argo CD or Flux to sync Kubernetes manifests from Git

---

### ✅ 15. **Scenario:** Someone accidentally committed credentials to Git. What do you do?

**Answer:**

* Revoke the exposed secrets immediately
* Use tools like BFG or `git filter-branch` to remove secrets
* Rotate credentials and enforce scanning pre-commit
* Integrate secret scanners in CI

---

### ✅ 16. **Scenario:** You need to migrate workloads from on-prem to cloud. How would you do it?

**Answer:**

* Assess current infrastructure
* Containerize legacy applications (Docker)
* Recreate infra using Terraform
* Use VPN or Direct Connect for hybrid connectivity

---

### ✅ 17. **Scenario:** A pipeline gets stuck randomly. How do you debug?

**Answer:**

* Review Jenkins agent logs
* Check executor availability and resource exhaustion
* Enable pipeline debug mode (`-X` or `set -x`)
* Rotate agents or run on a clean node

---

### ✅ 18. **Scenario:** What’s your approach to logging in a distributed environment?

**Answer:**

* Centralize logs using Fluentd or Filebeat
* Ship logs to Elasticsearch or Loki
* Tag logs with pod/service metadata
* Set log retention and alerting on anomalies

---

### ✅ 19. **Scenario:** You need to roll out a config change to hundreds of servers. How?

**Answer:**

* Use Ansible with inventory and parallel execution
* Use dynamic inventory (e.g., AWS EC2 tags)
* Run in dry-run (`--check`) mode before real change
* Validate with log/metric collection post-deployment

---

### ✅ 20. **Scenario:** Production has an outage at midnight. What steps do you follow?

**Answer:**

* Trigger on-call using PagerDuty
* Gather logs, metrics, and error reports
* Restore service, apply hotfix if needed
* Run postmortem, RCA, and improve monitoring/alerts

---
