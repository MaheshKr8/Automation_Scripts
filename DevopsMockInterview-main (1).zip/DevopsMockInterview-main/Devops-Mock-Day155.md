
---

### ✅ 1. **How do you prevent accidental deletion or update of critical infrastructure using Terraform?**

**Answer:**
Use `lifecycle` blocks to protect critical resources:

```hcl
resource "aws_instance" "db" {
  ...
  lifecycle {
    prevent_destroy = true
  }
}
```

Also:

* Use **workspaces** to separate environments.
* Apply **RBAC** via IAM to limit `apply` access.
* Review `terraform plan` in code reviews before approval.

---

### ✅ 2. **A Kubernetes pod in production is using 100% CPU and restarting frequently. What steps do you take to fix it?**

**Answer:**

1. Use `kubectl top pod` to confirm CPU spikes.
2. Use `kubectl logs` to inspect errors.
3. Check if **resource limits/requests** are defined.
4. Analyze container behavior using **liveness/readiness probes**.
5. Consider **auto-scaling** or optimizing code inside the container.

---

### ✅ 3. **Your EC2 instance terminated unexpectedly. What could be the causes, and how do you troubleshoot it?**

**Answer:**
Possible causes:

* Spot instance reclamation.
* Auto Scaling policy.
* EBS volume issues.
* Startup script failure.

Steps:

* Check **CloudTrail**, **CloudWatch Logs**, and **Termination Notice**.
* Review **auto-scaling group** or manual user actions.
* Use **EBS snapshot** to restore data if needed.

---

### ✅ 4. **How do you detect and prevent configuration drift in your infrastructure?**

**Answer:**

* Use **Terraform plan/apply** regularly in CI/CD.
* Integrate **Driftctl** or **Terraform Cloud Drift Detection**.
* For Kubernetes, use **Argo CD** or **Flux** to detect drift from Git.

---

### ✅ 5. **How do you ensure secrets like API keys and DB passwords are securely managed in CI/CD pipelines?**

**Answer:**

* Store secrets in:

  * **AWS Secrets Manager / Parameter Store**
  * **HashiCorp Vault**
  * **Kubernetes Secrets**
* In Jenkins/GitHub Actions:

  * Use credentials plugin or GitHub secrets.
  * Never hardcode in code or logs.
  * Mask secrets in pipeline output.

---

### ✅ 6. **Your CI/CD deployment to production failed. What is your rollback strategy?**

**Answer:**

* Use:

  * **Blue-Green Deployments** or
  * **Canary Deployments**
* If using GitOps (ArgoCD):

  * Roll back using previous Git commit or Helm revision.
* Maintain **immutable infrastructure** where rollback = redeploy previous version.

---

### ✅ 7. **How do you manage a situation where a developer bypassed the CI/CD and directly deployed to production?**

**Answer:**

* Implement **strict RBAC** to restrict direct access.
* Enforce **audit trails** via CloudTrail or audit logs.
* Use **infrastructure as code** with GitOps — no direct kubectl/docker commands allowed.
* Implement **change management approvals**.

---

### ✅ 8. **What is the best way to scale Kubernetes workloads during traffic spikes without manual intervention?**

**Answer:**

* Use **Horizontal Pod Autoscaler** (HPA):

  ```yaml
  apiVersion: autoscaling/v2
  kind: HorizontalPodAutoscaler
  ...
  ```
* Combine with:

  * **Cluster Autoscaler** for node-level scaling.
  * **Prometheus Adapter** for custom metrics.
  * Ensure proper `requests/limits` are defined.

---

### ✅ 9. **Your ECR image is failing during `docker pull`. What could be the issue?**

**Answer:**

* Token expired – re-authenticate using:

  ```bash
  aws ecr get-login-password | docker login ...
  ```
* IAM permissions missing.
* Image deleted or incorrect tag.
* Network/VPC endpoint issue if pulling from private subnet.

---

### ✅ 10. **How do you design a fault-tolerant, highly available architecture for a web application in AWS?**

**Answer:**

* Use **multi-AZ** and **multi-region** deployment.
* Load balancer in front (ALB/NLB).
* Use **Auto Scaling Groups**.
* Store state in **RDS with Multi-AZ** or **DynamoDB**.
* Distribute static assets via **CloudFront**.
* Use **Route53 failover** routing policy.

---

