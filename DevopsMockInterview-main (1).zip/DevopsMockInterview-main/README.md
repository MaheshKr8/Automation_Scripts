# DevopsMockInterview
This repository mainly deals with real-time interviews
