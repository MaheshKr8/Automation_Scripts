

---

### ✅ **1. Task: Clone a Git repository and push a new feature branch**

**Answer:**

```bash
git clone https://github.com/org/repo.git
cd repo
git checkout -b feature/new-feature
# make changes
git add .
git commit -m "New feature added"
git push origin feature/new-feature
```

---

### ✅ **2. Task: Write a Dockerfile to serve a Python Flask app**

**Answer:**

```dockerfile
FROM python:3.10
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
CMD ["python", "app.py"]
```

---

### ✅ **3. Task: Build and run a Docker container**

**Answer:**

```bash
docker build -t myflaskapp:1.0 .
docker run -d -p 5000:5000 myflaskapp:1.0
```

---

### ✅ **4. Task: Create a Jenkins pipeline that builds and pushes Docker image**

**Answer (Jenkinsfile):**

```groovy
pipeline {
  agent any
  stages {
    stage('Build') {
      steps {
        sh 'docker build -t myimage:latest .'
      }
    }
    stage('Push') {
      steps {
        withCredentials([usernamePassword(credentialsId: 'dockerhub-creds', usernameVariable: 'USER', passwordVariable: 'PASS')]) {
          sh 'docker login -u $USER -p $PASS'
          sh 'docker push myimage:latest'
        }
      }
    }
  }
}
```

---

### ✅ **5. Task: Create an EC2 instance using Terraform**

**Answer:**

```hcl
resource "aws_instance" "example" {
  ami           = "ami-0abcdef1234567890"
  instance_type = "t2.micro"
  tags = {
    Name = "MyInstance"
  }
}
```

---

### ✅ **6. Task: Configure NGINX as a reverse proxy using Ansible**

**Answer (Playbook):**

```yaml
- name: Configure NGINX
  hosts: web
  become: yes
  tasks:
    - name: Install NGINX
      apt: name=nginx state=present
    - name: Copy config file
      copy:
        src: nginx.conf
        dest: /etc/nginx/nginx.conf
    - name: Restart NGINX
      service:
        name: nginx
        state: restarted
```

---

### ✅ **7. Task: Auto-scale pods in Kubernetes using HPA**

**Answer:**

```bash
kubectl autoscale deployment myapp --cpu-percent=75 --min=2 --max=10
```

---

### ✅ **8. Task: Store Terraform remote state in S3**

**Answer:**

```hcl
terraform {
  backend "s3" {
    bucket = "my-tf-state-bucket"
    key    = "env/dev/terraform.tfstate"
    region = "us-west-2"
  }
}
```

---

### ✅ **9. Task: Mount a ConfigMap into a Kubernetes pod**

**Answer:**

```bash
kubectl create configmap app-config --from-literal=ENV=dev
```

Pod YAML snippet:

```yaml
env:
- name: ENV
  valueFrom:
    configMapKeyRef:
      name: app-config
      key: ENV
```

---

### ✅ **10. Task: Set up Prometheus and Grafana using Helm**

**Answer:**

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install monitoring prometheus-community/kube-prometheus-stack
```

---

### ✅ **11. Task: Run vulnerability scan on a Docker image using Trivy**

**Answer:**

```bash
trivy image myapp:latest
```

---

### ✅ **12. Task: Deploy a Helm chart**

**Answer:**

```bash
helm install myapp ./myapp-chart
```

---

### ✅ **13. Task: Create a GitHub Actions workflow to test a Node app**

**Answer (.github/workflows/test.yml):**

```yaml
name: CI

on: [push]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - run: npm install
      - run: npm test
```

---

### ✅ **14. Task: Roll back a Kubernetes deployment**

**Answer:**

```bash
kubectl rollout undo deployment myapp-deployment
```

---

### ✅ **15. Task: Archive old logs and delete files older than 7 days**

**Answer:**

```bash
find /var/log/myapp -type f -mtime +7 -exec rm {} \;
```

---

### ✅ **16. Task: Backup and restore a MySQL DB in a Kubernetes pod**

**Backup:**

```bash
kubectl exec mysql-pod -- mysqldump -u root -pmy_pass mydb > backup.sql
```

**Restore:**

```bash
cat backup.sql | kubectl exec -i mysql-pod -- mysql -u root -pmy_pass mydb
```

---

### ✅ **17. Task: Connect to a container inside a Kubernetes pod**

**Answer:**

```bash
kubectl exec -it mypod -- /bin/bash
```

---

### ✅ **18. Task: Set environment variables in a Jenkins pipeline**

**Answer (Declarative pipeline):**

```groovy
environment {
  ENV = 'production'
  API_KEY = credentials('api-key-id')
}
```

---

### ✅ **19. Task: Set up ingress for a service using NGINX**

**Answer (Ingress YAML):**

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: myapp-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: myapp-service
            port:
              number: 80
```

---

### ✅ **20. Task: Create an AWS IAM user with CLI access**

**Answer:**

```bash
aws iam create-user --user-name devops-user
aws iam create-access-key --user-name devops-user
aws iam attach-user-policy --user-name devops-user --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
```

---
