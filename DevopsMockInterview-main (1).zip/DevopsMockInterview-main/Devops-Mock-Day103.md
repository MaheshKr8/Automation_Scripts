
 

---

### **1. How do you write a shell script to check if a file exists and is readable?**  
#### **Solution:**
```bash
#!/bin/bash
file="/path/to/file"
if [[ -f "$file" && -r "$file" ]]; then
    echo "File exists and is readable."
else
    echo "File is missing or not readable."
fi
```
**Use Case:**  
Useful for **validating file existence before processing logs or configuration files**.

---

### **2. How do you write a script to monitor CPU usage and alert if it exceeds 80%?**  
#### **Solution:**  
```bash
#!/bin/bash
cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
threshold=80

if (( $(echo "$cpu_usage > $threshold" | bc -l) )); then
    echo "Alert: CPU usage is above $threshold%!"
fi
```
**Use Case:**  
Automates **CPU monitoring for production servers**.

---

### **3. How do you automate log rotation using a shell script?**  
#### **Solution:**  
```bash
#!/bin/bash
logfile="/var/log/app.log"
backup_dir="/var/log/archive"

mkdir -p "$backup_dir"
mv "$logfile" "$backup_dir/app_$(date +%F).log"
touch "$logfile"
```
**Use Case:**  
Prevents **log file growth issues** in applications.

---

### **4. How do you schedule a shell script using cron to run every 15 minutes?**  
#### **Solution:**  
Add this line to `crontab -e`:  
```bash
*/15 * * * * /path/to/script.sh
```
**Use Case:**  
Used in **DevOps pipelines for scheduled tasks** like backups or sync jobs.

---

### **5. How do you count the number of lines in a file using a shell script?**  
#### **Solution:**  
```bash
#!/bin/bash
file="/var/log/syslog"
echo "Total lines: $(wc -l < "$file")"
```
**Use Case:**  
Used for **log file analysis and monitoring**.

---

### **6. How do you write a script to check if a service is running and restart it if down?**  
#### **Solution:**  
```bash
#!/bin/bash
service="nginx"

if ! systemctl is-active --quiet "$service"; then
    echo "$service is down. Restarting..."
    sudo systemctl restart "$service"
fi
```
**Use Case:**  
Ensures **critical services remain operational**.

---

### **7. How do you automate user creation with a shell script?**  
#### **Solution:**  
```bash
#!/bin/bash
read -p "Enter username: " username
sudo useradd "$username" && echo "User $username created."
```
**Use Case:**  
Speeds up **bulk user creation in organizations**.

---

### **8. How do you find and delete files older than 30 days using a script?**  
#### **Solution:**  
```bash
#!/bin/bash
find /var/log -type f -mtime +30 -exec rm -f {} \;
```
**Use Case:**  
Automates **disk cleanup in production servers**.

---

### **9. How do you rename all `.txt` files in a directory by adding `_backup`?**  
#### **Solution:**  
```bash
#!/bin/bash
for file in *.txt; do
    mv "$file" "${file%.txt}_backup.txt"
done
```
**Use Case:**  
Batch renaming files during **data migrations or backups**.

---

### **10. How do you create a menu-driven script for basic operations?**  
#### **Solution:**  
```bash
#!/bin/bash
echo "1. Show date"
echo "2. Show uptime"
echo "3. Show logged-in users"
read -p "Enter choice: " choice

case $choice in
    1) date ;;
    2) uptime ;;
    3) who ;;
    *) echo "Invalid choice!" ;;
esac
```
**Use Case:**  
Used for **interactive automation scripts**.

---

### **11. How do you monitor disk usage and send an email alert if usage exceeds 90%?**  
#### **Solution:**  
```bash
#!/bin/bash
usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ "$usage" -gt 90 ]; then
    echo "Warning: Disk usage is above 90%" | mail -s "Disk Alert" admin@example.com
fi
```
**Use Case:**  
Prevents **server crashes due to full disk space**.

---

### **12. How do you write a script to check internet connectivity?**  
#### **Solution:**  
```bash
#!/bin/bash
ping -c 1 google.com &> /dev/null && echo "Online" || echo "Offline"
```
**Use Case:**  
Helps in **network troubleshooting**.

---

### **13. How do you find all running processes of a specific user?**  
#### **Solution:**  
```bash
ps -u username
```
**Use Case:**  
Monitors **user-specific resource consumption**.

---

### **14. How do you read and process a file line by line?**  
#### **Solution:**  
```bash
#!/bin/bash
while IFS= read -r line; do
    echo "Processing: $line"
done < file.txt
```
**Use Case:**  
Used for **batch processing logs, configs, or data files**.

---

### **15. How do you check if a process is running and kill it if necessary?**  
#### **Solution:**  
```bash
#!/bin/bash
process="apache2"
if pgrep -x "$process" > /dev/null; then
    echo "Stopping $process..."
    pkill "$process"
fi
```
**Use Case:**  
Prevents **hung processes affecting performance**.

---

### **16. How do you find files larger than 1GB?**  
#### **Solution:**  
```bash
find / -type f -size +1G
```
**Use Case:**  
Helps in **identifying large files consuming storage**.

---

### **17. How do you extract only IP addresses from a log file?**  
#### **Solution:**  
```bash
grep -oE '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+' /var/log/nginx/access.log
```
**Use Case:**  
Used for **analyzing traffic sources**.

---

### **18. How do you check memory usage in real time?**  
#### **Solution:**  
```bash
free -h
```
**Use Case:**  
Helps in **performance tuning**.

---

### **19. How do you find the 10 most memory-consuming processes?**  
#### **Solution:**  
```bash
ps aux --sort=-%mem | head -10
```
**Use Case:**  
Useful for **identifying memory leaks**.

---

### **20. How do you automatically restart a process if it crashes?**  
#### **Solution:**  
```bash
#!/bin/bash
process="nginx"
if ! pgrep -x "$process" > /dev/null; then
    sudo systemctl restart "$process"
fi
```
**Use Case:**  
Ensures **high availability of critical services**.

---

### **21. How do you set up a loop to retry a failed command?**  
#### **Solution:**  
```bash
#!/bin/bash
for i in {1..5}; do
    some_command && break
    sleep 5
done
```
**Use Case:**  
Handles **temporary network failures**.

---

### **22. How do you compare two files and show the differences?**  
#### **Solution:**  
```bash
diff file1.txt file2.txt
```
**Use Case:**  
Used in **configuration management**.

---

### **23. How do you encrypt and decrypt a file using OpenSSL?**  
#### **Solution:**  
```bash
openssl enc -aes-256-cbc -salt -in file.txt -out file.enc
openssl enc -aes-256-cbc -d -in file.enc -out file.txt
```
**Use Case:**  
Ensures **secure file storage**.

---

### **24. How do you monitor a log file in real time?**  
#### **Solution:**  
```bash
tail -f /var/log/syslog
```
**Use Case:**  
Useful for **real-time debugging**.

---

### **25. How do you extract a specific column from a CSV file?**  
#### **Solution:**  
```bash
cut -d',' -f2 file.csv
```
**Use Case:**  
Automates **data processing tasks**.
