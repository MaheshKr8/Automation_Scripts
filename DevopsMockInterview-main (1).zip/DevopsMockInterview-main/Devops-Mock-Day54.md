
---

### **1. Git**

#### **Q1: How would you handle sensitive data (e.g., API keys, passwords) in a Git repository, ensuring they don’t get committed accidentally?**
- **Scenario**: During code reviews, you discover that sensitive information such as API keys and passwords has been accidentally committed to the Git repository. How do you handle this securely?
- **Answer**: 
   1. Remove the sensitive data from the history using **BFG Repo-Cleaner** or `git filter-branch`.
      ```bash
      bfg --delete-files 'keys.json'
      ```
   2. Rotate the exposed credentials immediately.
   3. Add sensitive files (like `.env`) to `.gitignore` to avoid future mistakes.
   4. Use secret scanning tools such as **GitGuardian** to prevent further leaks.

#### **Q2: How would you handle a situation where you need to force-push changes to a shared branch (e.g., `master`), but the team relies on the branch?**
- **Scenario**: Due to an urgent bug fix, you must rewrite commit history on the `master` branch, but the team has already pulled the latest changes. How do you mitigate the disruption?
- **Answer**:
   1. Notify the team to hold off on pulling changes until you complete the force-push.
   2. Rewrite the branch history and force-push it.
      ```bash
      git rebase -i HEAD~3
      git push origin master --force
      ```
   3. Ask the team to fetch the branch and reset their local repository to avoid conflicts:
      ```bash
      git fetch origin
      git reset --hard origin/master
      ```

---

### **2. Jenkins**

#### **Q3: How do you implement zero-downtime deployment for a high-traffic web application using Jenkins and Blue-Green deployment?**
- **Scenario**: You need to ensure that deploying new features does not lead to downtime or service disruption in a high-traffic environment. How do you implement Blue-Green deployment in Jenkins?
- **Answer**:
   1. Set up two environments, Blue (current live version) and Green (new version).
   2. Deploy the new version to the Green environment using Jenkins.
      - Example Jenkins pipeline:
        ```groovy
        pipeline {
          agent any
          stages {
            stage('Deploy to Green') {
              steps {
                sh 'kubectl apply -f green-deployment.yaml'
              }
            }
          }
        }
        ```
   3. Once the deployment to Green is successful, switch the traffic from Blue to Green (e.g., via load balancer or DNS update).
      ```bash
      kubectl patch service my-app-service -p '{"spec":{"selector":{"version":"green"}}}'
      ```

#### **Q4: How would you set up Jenkins to trigger a build automatically when there is a new commit in a Git repository?**
- **Scenario**: You want Jenkins to start a build whenever new code is pushed to a Git repository, without manual intervention. How do you configure this?
- **Answer**:
   1. Enable **Git hooks** or use **GitHub Webhooks** to notify Jenkins when a new commit is pushed.
   2. In Jenkins, configure the job to poll the repository:
      - In **Build Triggers**, select **Poll SCM** and set the schedule to `* * * * *` for continuous polling.
      - Alternatively, configure a webhook in your Git repository to trigger Jenkins builds.
      ```bash
      curl -X POST http://jenkins-server/job/my-job/build?token=YOUR_TOKEN
      ```

---

### **3. Docker**

#### **Q5: How would you handle a situation where your Docker containers are running out of disk space due to unused images and stopped containers?**
- **Scenario**: On your production servers, Docker containers are running out of disk space because old images and stopped containers are not being cleaned up. How do you resolve and automate the cleanup process?
- **Answer**:
   1. Run the following command to remove unused images and stopped containers:
      ```bash
      docker system prune -a --volumes
      ```
   2. Automate this cleanup by setting up a cron job:
      ```bash
      0 2 * * * docker system prune -a --volumes -f
      ```
   3. Monitor disk space usage regularly using tools like **Prometheus** or **Datadog**.

#### **Q6: How do you optimize Docker container startup time for a Node.js application in production?**
- **Scenario**: Your Node.js Docker container is slow to start, impacting deployment speed in production. How do you optimize the container’s startup time?
- **Answer**:
   1. Use a **multistage build** in Docker to reduce image size:
      ```Dockerfile
      FROM node:14 AS build
      WORKDIR /app
      COPY package*.json ./
      RUN npm install
      COPY . .
      RUN npm run build

      FROM node:14-alpine
      WORKDIR /app
      COPY --from=build /app/dist /app
      CMD ["node", "server.js"]
      ```
   2. Pre-compile assets during the build process.
   3. Use a lighter base image like `node:alpine` to reduce overhead.

---

### **4. Kubernetes**

#### **Q7: How would you debug and fix a pod that is stuck in `CrashLoopBackOff` in Kubernetes?**
- **Scenario**: You’ve deployed an application in Kubernetes, but one of the pods is stuck in a `CrashLoopBackOff` state. How would you troubleshoot and resolve this issue?
- **Answer**:
   1. Check the logs of the failing pod:
      ```bash
      kubectl logs <pod-name>
      ```
   2. Describe the pod to get detailed event information:
      ```bash
      kubectl describe pod <pod-name>
      ```
   3. Investigate issues like missing configuration files, incorrect container images, or resource limits.
   4. If the issue is with the application, fix it and restart the pod:
      ```bash
      kubectl delete pod <pod-name>
      ```

#### **Q8: How would you manage environment-specific configurations (e.g., dev, prod) in Kubernetes without changing the YAML files?**
- **Scenario**: You are deploying applications to multiple environments (e.g., dev, prod), and need to manage environment-specific configurations without modifying the base YAML files for each deployment.
- **Answer**: Use **Kubernetes ConfigMaps** and **Secrets** for environment-specific configurations.
   1. Create ConfigMaps for each environment:
      ```bash
      kubectl create configmap dev-config --from-literal=ENV=dev
      kubectl create configmap prod-config --from-literal=ENV=prod
      ```
   2. Reference these ConfigMaps in your deployment YAML:
      ```yaml
      env:
        - name: ENV
          valueFrom:
            configMapKeyRef:
              name: dev-config
              key: ENV
      ```

---


### **5. Terraform**

#### **Q9: How do you handle state locking in Terraform when multiple engineers are working on the same infrastructure?**
- **Scenario**: Your team of engineers is simultaneously applying changes to the same Terraform-managed infrastructure, causing potential conflicts. How do you ensure that only one engineer can modify the infrastructure at a time?
- **Answer**: Use **state locking** in Terraform to avoid simultaneous changes and conflicts. This can be achieved by storing the Terraform state in a **remote backend** like **Amazon S3** with **DynamoDB** for locking.
   1. Configure the remote backend:
      ```hcl
      terraform {
        backend "s3" {
          bucket         = "my-terraform-state"
          key            = "production/terraform.tfstate"
          region         = "us-east-1"
          dynamodb_table = "terraform-locks"
        }
      }
      ```
   2. DynamoDB ensures that the state file is locked during operations, preventing other engineers from making changes simultaneously.
   3. If you try to apply Terraform while someone else is modifying the infrastructure, Terraform will throw a state lock error, ensuring only one person can modify the state at a time.

#### **Q10: How would you manage infrastructure across multiple AWS accounts using Terraform?**
- **Scenario**: You are responsible for managing resources across multiple AWS accounts for development, staging, and production environments. How do you configure Terraform to handle this efficiently?
- **Answer**: Use **Terraform workspaces** or **multiple provider blocks** with different credentials for each AWS account.
   1. **Using Workspaces**:
      - Set up different workspaces for each account:
        ```bash
        terraform workspace new dev
        terraform workspace new prod
        ```
      - Use workspaces to separate configurations per account.
      - Deploy by switching between workspaces:
        ```bash
        terraform workspace select dev
        terraform apply
        ```
   
   2. **Using Multiple Provider Blocks**:
      - Set up different provider blocks for each account:
        ```hcl
        provider "aws" {
          alias  = "dev"
          region = "us-east-1"
          access_key = "dev-access-key"
          secret_key = "dev-secret-key"
        }

        provider "aws" {
          alias  = "prod"
          region = "us-east-1"
          access_key = "prod-access-key"
          secret_key = "prod-secret-key"
        }
        ```
      - Reference the appropriate provider in your resources:
        ```hcl
        resource "aws_instance" "dev_instance" {
          provider = aws.dev
          # resource configuration for dev
        }

        resource "aws_instance" "prod_instance" {
          provider = aws.prod
          # resource configuration for prod
        }
        ```

---

### **6. Ansible**

#### **Q11: How would you manage configuration drift using Ansible for an infrastructure spread across multiple regions?**
- **Scenario**: Your application is deployed across multiple regions, and you want to ensure that configurations remain consistent across all instances, avoiding any drift caused by manual interventions. How do you ensure configuration consistency?
- **Answer**: Use **Ansible Tower** (or AWX) to schedule regular playbook runs, ensuring configurations are periodically applied to all instances to maintain consistency.
   1. Schedule periodic Ansible playbook executions using Ansible Tower, ensuring configurations are consistently applied across all regions.
   2. Example playbook to enforce consistent configurations:
      ```yaml
      - hosts: all
        tasks:
          - name: Ensure Nginx is installed
            apt:
              name: nginx
              state: present

          - name: Ensure correct config file is deployed
            copy:
              src: /path/to/nginx.conf
              dest: /etc/nginx/nginx.conf
              owner: root
              group: root
              mode: 0644
      ```
   3. If any configuration drift occurs, Ansible will automatically correct it during the next scheduled run, ensuring consistency.

#### **Q12: How do you handle dynamic inventories in Ansible for cloud infrastructure like AWS?**
- **Scenario**: Your infrastructure is dynamic, with instances being spun up and down frequently in AWS. You need to ensure that Ansible is aware of these changes and can dynamically target the correct servers. How do you configure this?
- **Answer**: Use **Ansible dynamic inventory** scripts, specifically for AWS, to ensure that Ansible targets the correct servers dynamically.
   1. Install the **Ansible EC2 inventory plugin**:
      ```bash
      pip install boto boto3
      ```
   2. Configure the dynamic inventory in **ansible.cfg**:
      ```ini
      [defaults]
      inventory = ./ec2.py
      ```
   3. Use the **ec2.py** inventory script, which fetches live information from AWS:
      - Download and configure the script from the official Ansible repo.
      - Run your playbook with the dynamic inventory:
        ```bash
        ansible-playbook -i ec2.py site.yml
        ```
   4. This ensures that Ansible automatically targets the correct instances based on the latest AWS EC2 information, without the need for manually updating static inventory files.

---

