
---

### ✅ **1. How do you trigger a Jenkins pipeline when code is pushed to GitHub?**

**Answer:**

* Configure **GitHub Webhook** in the repository (`Settings > Webhooks`).
* Set payload URL to Jenkins: `http://<jenkins-url>/github-webhook/`.
* In Jenkins, enable "**GitHub hook trigger for GITScm polling**" in the job.

---

### ✅ **2. How do you integrate Maven build into a Jenkins pipeline?**

**Answer:**
Use a `Jenkinsfile` with the following step:

```groovy
stage('Build') {
    steps {
        sh 'mvn clean install'
    }
}
```

* Ensure Jenkins has **Maven installed** or use a Maven Docker agent.
* Can be managed via Jenkins global tools config or inside pipeline.

---

### ✅ **3. How do you run SonarQube analysis in a Jenkins pipeline for a Maven project?**

**Answer:**
You need the **SonarQube plugin** in Jenkins and a Sonar server configured.

```groovy
stage('SonarQube Analysis') {
    steps {
        withSonarQubeEnv('SonarQubeServer') {
            sh 'mvn sonar:sonar -Dsonar.projectKey=my-app -Dsonar.host.url=http://localhost:9000'
        }
    }
}
```

* Replace `SonarQubeServer` with the name of your Sonar installation in Jenkins.

---

### ✅ **4. How do you break the Jenkins build if code quality fails in SonarQube?**

**Answer:**
After analysis, wait for SonarQube’s quality gate result:

```groovy
stage("Quality Gate") {
    steps {
        timeout(time: 1, unit: 'MINUTES') {
            waitForQualityGate abortPipeline: true
        }
    }
}
```

* Requires SonarQube Scanner for Jenkins plugin and background task to be completed.

---

### ✅ **5. How do you scan your Maven-built Docker image using Trivy in Jenkins?**

**Answer:**
After building the Docker image, use Trivy:

```groovy
stage('Trivy Scan') {
    steps {
        sh 'trivy image my-app:latest'
    }
}
```

* Optionally, break the build if high/critical vulnerabilities exist:

```groovy
sh 'trivy image --exit-code 1 --severity HIGH,CRITICAL my-app:latest'
```

---

### ✅ **6. How do you structure a complete Jenkins pipeline with GitHub → Maven → SonarQube → Trivy → Deploy?**

**Answer:**
A simplified declarative `Jenkinsfile`:

```groovy
pipeline {
    agent any

    environment {
        DOCKER_IMAGE = "my-app:${BUILD_NUMBER}"
    }

    stages {
        stage('Checkout') {
            steps {
                git url: 'https://github.com/user/repo.git'
            }
        }

        stage('Build with Maven') {
            steps {
                sh 'mvn clean package'
            }
        }

        stage('SonarQube Analysis') {
            steps {
                withSonarQubeEnv('SonarQubeServer') {
                    sh 'mvn sonar:sonar'
                }
            }
        }

        stage('Quality Gate') {
            steps {
                timeout(time: 1, unit: 'MINUTES') {
                    waitForQualityGate abortPipeline: true
                }
            }
        }

        stage('Docker Build') {
            steps {
                sh 'docker build -t $DOCKER_IMAGE .'
            }
        }

        stage('Trivy Scan') {
            steps {
                sh 'trivy image --exit-code 1 --severity HIGH,CRITICAL $DOCKER_IMAGE'
            }
        }

        stage('Deploy') {
            steps {
                echo "Deploying $DOCKER_IMAGE..."
                // deploy steps here
            }
        }
    }
}
```

---

### ✅ **7. Where do you store Jenkins credentials for GitHub or DockerHub in pipelines?**

**Answer:**
Use **Jenkins Credentials Manager**:

* Store **username/password** or **personal access token**.
* Use it in pipeline with:

```groovy
withCredentials([usernamePassword(credentialsId: 'github-creds', usernameVariable: 'USERNAME', passwordVariable: 'TOKEN')]) {
    sh 'git clone https://$USERNAME:$TOKEN@github.com/user/repo.git'
}
```

---

### ✅ **8. What’s your approach if SonarQube or Trivy fails during the pipeline?**

**Answer:**

* If failure is critical: break the build.
* If optional: mark stage as unstable or proceed with a warning.

```groovy
catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE') {
    sh 'trivy image my-app:latest'
}
```

---

### ✅ **9. How do you manage parallel testing or static analysis in a Jenkins pipeline?**

**Answer:**

```groovy
stage('Parallel Checks') {
    parallel {
        stage('Unit Tests') {
            steps {
                sh 'mvn test'
            }
        }
        stage('Static Code Analysis') {
            steps {
                sh 'mvn checkstyle:check'
            }
        }
    }
}
```

---

### ✅ **10. How do you view and archive test reports/artifacts in Jenkins?**

**Answer:**

* For JUnit test results:

```groovy
post {
    always {
        junit '**/target/surefire-reports/*.xml'
    }
}
```

* To archive build artifacts:

```groovy
post {
    success {
        archiveArtifacts artifacts: '**/target/*.jar', fingerprint: true
    }
}
```

---

### ✅ **11. How do you handle build versioning in a Maven + Jenkins pipeline?**

**Answer:**

* Use Jenkins `BUILD_NUMBER` or a timestamp to tag builds:

```bash
mvn versions:set -DnewVersion=1.0.${BUILD_NUMBER}
```

* Store version in a property file or commit back if needed.

---

### ✅ **12. How do you securely push Docker images to DockerHub or ECR from Jenkins?**

**Answer:**

* Store DockerHub/ECR credentials in Jenkins.
* Use `withCredentials` block:

```groovy
withCredentials([usernamePassword(credentialsId: 'docker-creds', usernameVariable: 'DOCKER_USER', passwordVariable: 'DOCKER_PASS')]) {
    sh """
        echo $DOCKER_PASS | docker login -u $DOCKER_USER --password-stdin
        docker push my-app:${BUILD_NUMBER}
    """
}
```

---

### ✅ **13. How can you speed up a Maven build in Jenkins?**

**Answer:**

* Use `mvn -T 1C` to enable parallel builds.
* Cache `.m2` repository across builds using shared workspace or Docker volume.
* Skip tests for fast builds if not needed: `mvn clean install -DskipTests`.

---

### ✅ **14. How do you prevent breaking changes in GitHub when merging to main branch?**

**Answer:**

* Enable **branch protection rules**.
* Require status checks to pass (e.g., Jenkins CI build).
* Enforce pull request reviews.
* Integrate **Trivy**, **Sonar**, and **unit tests** in PR builds.

---

### ✅ **15. How do you handle multiple environments (dev/staging/prod) in Jenkins pipelines?**

**Answer:**

* Use parameterized pipelines (`choice` or `string` parameters).
* Select environment dynamically:

```groovy
environment {
    DEPLOY_ENV = "${params.ENV}"
}
```

* Use conditionals in deployment stages based on environment.

---

### ✅ **16. How do you make Jenkins pipelines reusable across multiple microservices?**

**Answer:**

* Use **shared libraries** in Jenkins:

  * Define reusable `vars/` functions or `steps`.
* Store pipeline logic in centralized repo.
* Each repo includes a minimal `Jenkinsfile` calling shared logic.

---

### ✅ **17. How do you manage secret scanning in GitHub and CI?**

**Answer:**

* Enable **GitHub secret scanning**.
* Integrate tools like **Gitleaks**, **Detect-Secrets**, or **TruffleHog** in pipeline:

```bash
gitleaks detect --source=. --exit-code 1
```

* Fail build if secrets are found.

---

### ✅ **18. What would you do if SonarQube reports low code coverage?**

**Answer:**

* Identify uncovered areas in Sonar UI.
* Write additional **unit tests** or **integration tests**.
* Integrate coverage tools like **Jacoco** with Maven:

```xml
<plugin>
  <groupId>org.jacoco</groupId>
  <artifactId>jacoco-maven-plugin</artifactId>
</plugin>
```

---

### ✅ **19. How do you test a Jenkins pipeline without committing every time?**

**Answer:**

* Use **Multibranch Pipeline** with a test branch.
* Use **Replay** feature in Jenkins to rerun modified `Jenkinsfile`.
* Locally simulate CI using **Jenkinsfile Runner** or Docker.

---

### ✅ **20. How do you handle failures in multi-stage Jenkins pipelines gracefully?**

**Answer:**

* Use `catchError`, `try-catch`, or `post` blocks:

```groovy
stage('Trivy Scan') {
    steps {
        catchError(buildResult: 'UNSTABLE') {
            sh 'trivy image my-app:latest'
        }
    }
}
```

* Report errors but allow non-critical failures to proceed.

---

