
---

### **1. How do you check which user last modified a file?**  
#### **Solution:**  
```bash
ls -lt /path/to/file
stat /path/to/file
```

**Real-World Use Case:**  
Useful in **auditing and troubleshooting accidental file modifications**.

---

### **2. How do you check if a file is being actively written to?**  
#### **Solution:**  
```bash
lsof /path/to/file
```

**Real-World Use Case:**  
Helpful when troubleshooting **log rotation issues or debugging locked files**.

---

### **3. How do you recover deleted files from a running process?**  
#### **Solution:**  
```bash
lsof -nP | grep deleted
cp /proc/<pid>/fd/<file_descriptor> /path/to/recovery
```

**Real-World Use Case:**  
Used when a **critical log or configuration file is deleted while still being used**.

---

### **4. How do you set limits on user CPU usage?**  
#### **Solution:**  
Modify `/etc/security/limits.conf`:  
```bash
user_name hard cpu 100
```

**Real-World Use Case:**  
Prevents a single user from consuming **all CPU resources**.

---

### **5. How do you change file permissions for all `.sh` files in a directory?**  
#### **Solution:**  
```bash
chmod +x /path/to/directory/*.sh
```

**Real-World Use Case:**  
Useful for **batch updating script execution permissions**.

---

### **6. How do you set up a swap file to increase memory?**  
#### **Solution:**  
```bash
sudo fallocate -l 1G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
```

**Real-World Use Case:**  
Helps in **preventing crashes on low-memory servers**.

---

### **7. How do you check and repair a corrupted filesystem?**  
#### **Solution:**  
```bash
fsck -y /dev/sda1
```

**Real-World Use Case:**  
Fixes **disk corruption issues after an unexpected system crash**.

---

### **8. How do you list all environment variables?**  
#### **Solution:**  
```bash
printenv
```

**Real-World Use Case:**  
Helps in **debugging incorrect environment variable settings in CI/CD pipelines**.

---

### **9. How do you change a default shell for a user?**  
#### **Solution:**  
```bash
chsh -s /bin/zsh username
```

**Real-World Use Case:**  
Used when **migrating to a new shell like Zsh or Fish**.

---

### **10. How do you find all processes owned by a specific user?**  
#### **Solution:**  
```bash
ps -u username
```

**Real-World Use Case:**  
Used in **multi-user environments to track system usage**.

---

### **11. How do you find the location of a command binary?**  
#### **Solution:**  
```bash
which nginx
```

**Real-World Use Case:**  
Useful when dealing with **multiple versions of an installed application**.

---

### **12. How do you increase the maximum number of open files?**  
#### **Solution:**  
Modify `/etc/security/limits.conf`:  
```bash
* hard nofile 65535
```

**Real-World Use Case:**  
Prevents issues in **high-performance applications like Nginx, MySQL, and Kafka**.

---

### **13. How do you display only directories in the current location?**  
#### **Solution:**  
```bash
ls -d */
```

**Real-World Use Case:**  
Useful when dealing with **large directory structures**.

---

### **14. How do you check failed SSH login attempts?**  
#### **Solution:**  
```bash
grep "Failed password" /var/log/auth.log
```

**Real-World Use Case:**  
Essential for **detecting brute force login attempts**.

---

### **15. How do you remove all lines containing a specific word from a file?**  
#### **Solution:**  
```bash
sed -i '/unwantedword/d' file.txt
```

**Real-World Use Case:**  
Useful for **cleaning logs or configuration files**.

---

### **16. How do you extract only email addresses from a file?**  
#### **Solution:**  
```bash
grep -oE "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}" file.txt
```

**Real-World Use Case:**  
Needed for **data processing and automation scripts**.

---

### **17. How do you find all symbolic links in a directory?**  
#### **Solution:**  
```bash
find /path/to/dir -type l
```

**Real-World Use Case:**  
Helps in **troubleshooting broken links in applications**.

---

### **18. How do you find files modified in the last 24 hours?**  
#### **Solution:**  
```bash
find /path/to/directory -mtime -1
```

**Real-World Use Case:**  
Useful in **file system monitoring and backup solutions**.

---

### **19. How do you test network latency between two servers?**  
#### **Solution:**  
```bash
ping -c 5 server_ip
```

**Real-World Use Case:**  
Helps diagnose **network delays in Kubernetes clusters or cloud infrastructure**.

---

### **20. How do you display a list of users currently logged in?**  
#### **Solution:**  
```bash
who
```

**Real-World Use Case:**  
Used for **tracking logged-in users in multi-user systems**.

---

### **21. How do you compress a folder using tar and gzip?**  
#### **Solution:**  
```bash
tar -czvf archive.tar.gz /path/to/folder
```

**Real-World Use Case:**  
Used for **efficient backup and storage**.

---

### **22. How do you rename all `.txt` files in a directory by adding `_backup`?**  
#### **Solution:**  
```bash
for file in *.txt; do mv "$file" "${file%.txt}_backup.txt"; done
```

**Real-World Use Case:**  
Useful when **batch renaming files during maintenance**.

---

### **23. How do you enable a firewall and allow only SSH and HTTP traffic?**  
#### **Solution:**  
```bash
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow http
```

**Real-World Use Case:**  
Used in **server hardening to prevent unauthorized access**.

---

### **24. How do you forcefully terminate all processes of a user?**  
#### **Solution:**  
```bash
pkill -u username
```

**Real-World Use Case:**  
Used when **revoking access for a terminated employee**.

---

### **25. How do you securely delete a file beyond recovery?**  
#### **Solution:**  
```bash
shred -u file.txt
```

**Real-World Use Case:**  
Essential for **securely deleting sensitive data**.

---

