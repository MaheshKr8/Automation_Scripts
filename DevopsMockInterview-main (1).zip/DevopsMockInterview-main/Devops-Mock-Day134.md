
---

### **1. How do you manage Terraform state in a team environment?**

**Answer**:
In a team, store the Terraform state in a **remote backend** like **AWS S3** and use **DynamoDB** for state locking to avoid conflicts.

**Example**:

```hcl
terraform {
  backend "s3" {
    bucket         = "my-tf-state"
    key            = "dev/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "tf-lock"
  }
}
```

---

### **2. How do you import existing resources into Terraform?**

**Answer**:
Use `terraform import` to bring existing infrastructure under Terraform management.

**Example**:

```bash
terraform import aws_instance.web i-0a12b3456cdef7890
```

Then manually write the resource configuration in your `.tf` files to match.

---

### **3. How do you provision software after launching an EC2 instance?**

**Answer**:
Use **remote-exec** provisioner (not recommended for complex setups; prefer Ansible for that).

**Example**:

```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  provisioner "remote-exec" {
    inline = [
      "sudo apt update",
      "sudo apt install -y nginx"
    ]
  }
}
```

---

### **4. How do you manage multiple environments in Terraform (dev, staging, prod)?**

**Answer**:

* Use **workspaces** or
* Separate directories with different state files.

**Example (workspaces)**:

```bash
terraform workspace new staging
terraform apply
```

**Example (directory structure)**:

```
environments/
  ├── dev/
  └── prod/
```

---

### **5. How do you handle secrets in Terraform?**

**Answer**:
Never hardcode secrets. Use:

* **SSM Parameter Store**
* **Secrets Manager**
* Environment variables
* `sensitive = true` to hide output

**Example**:

```hcl
data "aws_ssm_parameter" "db_password" {
  name = "/prod/db_password"
}
```

---

### **6. How do you manage resource dependencies explicitly in Terraform?**

**Answer**:
Use the `depends_on` argument to force dependency when implicit ones are not enough.

**Example**:

```hcl
resource "aws_instance" "web" {
  depends_on = [aws_security_group.allow_ssh]
}
```

---

### **7. How do you handle resource count based on a condition?**

**Answer**:
Use a variable and control the `count` or `for_each`.

**Example**:

```hcl
resource "aws_instance" "web" {
  count = var.create_instance ? 1 : 0
}
```
It means:

* If create_instance = true, then Terraform will create 1 EC2 instance.

* If create_instance = false, then no EC2 instance will be created.

---

### **8. What happens if a Terraform apply fails midway?**

**Answer**:

* Terraform saves **partial state** of applied resources.
* You can:

  * Re-run `terraform apply`
  * Manually fix state using `terraform state` commands
  * Review logs with `TF_LOG=DEBUG`

---

### **9. How do you use modules in Terraform?**

**Answer**:
Modules help **reuse** infrastructure code.

**Example (main.tf)**:

```hcl
module "vpc" {
  source = "./modules/vpc"
  cidr   = "10.0.0.0/16"
}
```

---

### **10. How do you restrict a user from destroying a resource using Terraform?**

**Answer**:
Use the `lifecycle` block with `prevent_destroy`.

**Example**:

```hcl
resource "aws_s3_bucket" "secure_logs" {
  bucket = "my-secure-logs"

  lifecycle {
    prevent_destroy = true
  }
}
```

---


