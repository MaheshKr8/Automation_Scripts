
### **1. How do you use provisioners in Terraform, and when would you use them?**
**Answer**: Provisioners in Terraform are used to execute scripts or commands on resources after they are created or destroyed. They should be used sparingly, mainly for bootstrapping or for resources that don't provide native Terraform support.

#### **Real-Life Example**: Running a Shell Script on an EC2 Instance
```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  provisioner "remote-exec" {
    inline = [
      "sudo apt-get update",
      "sudo apt-get install -y nginx"
    ]

    connection {
      type        = "ssh"
      user        = "ubuntu"
      private_key = file("~/.ssh/id_rsa")
      host        = self.public_ip
    }
  }
}
```

---

### **2. What is the use of the `terraform refresh` command?**
**Answer**: The `terraform refresh` command updates the state file with the actual state of resources, refreshing it to reflect any changes made outside of Terraform.

#### **Real-Life Example**: Running `terraform refresh` to Sync State
- Apply a configuration to create an EC2 instance.
- Manually modify the instance in the AWS console (e.g., change the tag).
- Run `terraform refresh` to update the state file without making changes to the resources.

---

### **3. How do you manage sensitive output values in Terraform?**
**Answer**: You can mark output values as sensitive to prevent them from being displayed in plain text during the Terraform run.

#### **Real-Life Example**: Using Sensitive Outputs
```hcl
output "db_password" {
  value     = aws_db_instance.db.password
  sensitive = true
}
```

**Practice**:
- Check that the sensitive output is masked when running `terraform apply`.

---

### **4. What are Terraform `locals` and how do you use them?**
**Answer**: `locals` allow you to assign expressions to a name for reuse throughout your configuration.

#### **Real-Life Example**: Using `locals` for Reusable Logic
```hcl
locals {
  environment = "dev"
  instance_type = "t2.micro"
}

resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = local.instance_type
  tags = {
    Environment = local.environment
  }
}
```

---

### **5. How do you manage provider versions in Terraform?**
**Answer**: Provider versions can be locked using the `version` argument in the provider block to ensure consistency across environments.

#### **Real-Life Example**: Locking AWS Provider Version
```hcl
provider "aws" {
  region  = "us-east-1"
  version = "~> 3.0"
}
```

---

### **6. How does Terraform handle resource dependencies by default?**
**Answer**: Terraform automatically handles dependencies by analyzing references between resources. Resources with references are created or destroyed in the correct order.

#### **Real-Life Example**: Implicit Dependencies via Interpolation
```hcl
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_subnet" "subnet" {
  vpc_id = aws_vpc.main.id
  cidr_block = "10.0.1.0/24"
}
```

---

### **7. How do you update a Terraform module?**
**Answer**: Terraform modules are updated by modifying the module source and running `terraform get -update` or using `terraform init` to download the latest version.

#### **Real-Life Example**: Updating a Module
- Update the source of a module in your configuration.
```hcl
module "ec2" {
  source = "git::https://github.com/terraform-aws-modules/terraform-aws-ec2-instance.git?ref=v2.0.0"
}
```
- Run `terraform init` to fetch the updated module.

---

### **8. How do you output lists or maps in Terraform?**
**Answer**: Lists and maps can be output using the `output` block and are useful for returning complex data structures from your configuration.

#### **Real-Life Example**: Outputting a List of Instance IDs
```hcl
output "instance_ids" {
  value = aws_instance.web[*].id
}
```

---

### **9. What is the purpose of `terraform apply -auto-approve`?**
**Answer**: The `-auto-approve` flag automatically approves the execution of `terraform apply` without interactive approval, useful in automated pipelines.

#### **Real-Life Example**: Applying Infrastructure Without Approval
```bash
terraform apply -auto-approve
```

---

### **10. What are `terraform` lifecycle hooks?**
**Answer**: Lifecycle hooks like `create_before_destroy` and `prevent_destroy` allow you to control the behavior of resources during creation and destruction.

#### **Real-Life Example**: Prevent Resource Destruction
```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  lifecycle {
    prevent_destroy = true
  }
}
```

