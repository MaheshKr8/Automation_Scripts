
1. **Explain the purpose of `git stash` with an example.**
    - **Answer**: `git stash` saves your uncommitted changes temporarily, allowing you to switch branches without committing them. For example, `git stash save "WIP"` stashes work in progress.

2. **How do you apply stashed changes?**
    - **Answer**: Use `git stash apply` to apply the most recent stash or `git stash apply stash@{n}` to apply a specific stash.

3. **What does `git cherry-pick` do?**
    - **Answer**: `git cherry-pick <commit_id>` applies the changes from a specific commit onto the current branch. It’s useful when you need a single change without merging the entire branch.

4. **How can you view differences between two branches?**
    - **Answer**: `git diff branch1..branch2` shows differences between two branches, making it easy to review changes before merging.

5. **What is the use of `git rebase`?**
    - **Answer**: `git rebase` is used to move or combine a series of commits to a new base commit. This is useful for maintaining a clean commit history.

6. **How do you link a local repository to a remote repository?**
    - **Answer**: `git remote add origin <remote_url>` links a local repository to a remote one, where `origin` is an alias for the remote.

7. **How do you push changes to a remote repository?**
    - **Answer**: Use `git push origin <branch_name>` to push your local changes to the remote repository.

8. **Explain `git pull` with an example.**
    - **Answer**: `git pull` fetches and merges changes from the remote repository into the current branch. For example, `git pull origin main` updates the local main branch with the latest remote changes.

9. **What is `git fetch`?**
    - **Answer**: `git fetch` retrieves updates from a remote repository without merging them into the local branch, allowing you to review changes before merging.

10. **How can you remove a remote repository?**
    - **Answer**: Use `git remote remove <remote_name>` to unlink the local repository from a remote. For example, `git remote remove origin`.



