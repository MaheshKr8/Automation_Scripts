

### **1. How do you handle application configuration across multiple environments in Kubernetes?**  
✅ **Answer:**  
Use **ConfigMaps** and **Secrets** to manage environment-specific configurations.  

✅ **Example ConfigMap for Environment Variables:**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: app-config
data:
  APP_ENV: "production"
  API_URL: "https://api.prod.example.com"
```
✅ **Use it inside a Pod:**  
```yaml
envFrom:
  - configMapRef:
      name: app-config
```
📌 **Keeps configurations modular and secure.**  

---

### **2. How do you implement Pod Disruption Budgets (PDB) to maintain high availability?**  
✅ **Answer:**  
PDB ensures a minimum number of pods remain available during voluntary disruptions (e.g., rolling updates).  

✅ **Example PDB for a Stateful Application:**  
```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: my-app-pdb
spec:
  minAvailable: 2
  selector:
    matchLabels:
      app: my-app
```
📌 **Prevents downtime during deployments or node upgrades.**  

---

### **3. How do you handle log aggregation in Kubernetes?**  
✅ **Answer:**  
Use **Fluentd, ELK Stack, or Loki** to centralize logs.  

✅ **Deploy Fluentd DaemonSet for Log Forwarding:**  
```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluentd-logger
spec:
  selector:
    matchLabels:
      name: fluentd
  template:
    metadata:
      labels:
        name: fluentd
    spec:
      containers:
      - name: fluentd
        image: fluentd:latest
```
📌 **Ensures logs are collected from all nodes efficiently.**  

---

### **4. How do you restrict access to certain Kubernetes namespaces?**  
✅ **Answer:**  
Use **Role-Based Access Control (RBAC)** with Roles & RoleBindings.  

✅ **Example Role to Allow Only Read Access:**  
```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: dev-team
  name: dev-read-only
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "list"]
```
✅ **Bind the Role to a User/Group:**  
```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: dev-read-only-binding
  namespace: dev-team
subjects:
- kind: User
  name: dev-user
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: dev-read-only
  apiGroup: rbac.authorization.k8s.io
```
📌 **Ensures security by restricting user permissions.**  

---

### **5. How do you implement multi-cluster Kubernetes management?**  
✅ **Answer:**  
Use **KubeFed (Kubernetes Federation)** or **ArgoCD** to manage multiple clusters centrally.  

✅ **Example ArgoCD Multi-Cluster Configuration:**  
```bash
argocd cluster add my-cluster-context
```
📌 **Simplifies deployment across multiple Kubernetes clusters.**  

---

### **6. How do you handle Kubernetes node failures gracefully?**  
✅ **Answer:**  
1. **Use Pod Anti-Affinity** to spread workloads across nodes.  
2. **Set up Cluster Autoscaler** to replace failed nodes.  
3. **Use `kubectl cordon` & `kubectl drain` before maintenance.**  

✅ **Example Anti-Affinity to Prevent Single-Node Deployment:**  
```yaml
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
    - labelSelector:
        matchExpressions:
        - key: app
          operator: In
          values:
          - my-app
      topologyKey: "kubernetes.io/hostname"
```
📌 **Ensures fault tolerance in case of node failures.**  

---

### **7. How do you enforce network security in Kubernetes?**  
✅ **Answer:**  
Use **Network Policies** to control pod-to-pod communication.  

✅ **Example Network Policy Allowing Only API Traffic:**  
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-api
  namespace: default
spec:
  podSelector:
    matchLabels:
      app: api
  policyTypes:
  - Ingress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: frontend
    ports:
    - protocol: TCP
      port: 80
```
📌 **Blocks unauthorized access between microservices.**  

---

### **8. How do you perform automated backups for Kubernetes persistent storage?**  
✅ **Answer:**  
Use **Velero** for Kubernetes backups.  

✅ **Install Velero:**  
```bash
velero install --provider aws --bucket my-backup-bucket
```
✅ **Backup All Resources in a Namespace:**  
```bash
velero backup create my-backup --include-namespaces my-namespace
```
📌 **Ensures disaster recovery for critical applications.**  

---

### **9. How do you troubleshoot an application running in a Kubernetes pod?**  
✅ **Answer:**  
1. **Check pod logs:**  
   ```bash
   kubectl logs <pod-name>
   ```
2. **Check live pod status:**  
   ```bash
   kubectl describe pod <pod-name>
   ```
3. **Run a debug shell inside the container:**  
   ```bash
   kubectl exec -it <pod-name> -- /bin/sh
   ```
📌 **Identifies issues like missing dependencies or misconfigured environments.**  

---

### **10. How do you optimize resource allocation in Kubernetes?**  
✅ **Answer:**  
1. **Use Resource Requests & Limits** to prevent resource hogging.  
2. **Use Cluster Autoscaler** to dynamically scale worker nodes.  

✅ **Example Resource Limits for a Pod:**  
```yaml
resources:
  requests:
    cpu: "500m"
    memory: "256Mi"
  limits:
    cpu: "1"
    memory: "512Mi"
```
📌 **Ensures efficient cluster utilization and prevents over-provisioning.**  

---
