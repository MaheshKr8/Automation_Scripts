
1. **How would you set up an Ansible dynamic inventory with AWS?**
   - **Answer**: Ansible can use dynamic inventories by pulling the list of hosts from AWS EC2. You configure the `aws_ec2` plugin in your `ansible.cfg` file.
   - **Example**:
     ```yaml
     plugin: aws_ec2
     regions:
       - us-east-1
     filters:
       tag:Name: web
     ```

2. **How would you configure an Ansible playbook to automatically retry failed tasks?**
   - **Answer**: Use the `retries` and `delay` parameters with the `until` directive.
   - **Example**:
     ```yaml
     - name: Retry until success
       command: /usr/bin/false
       register: result
       until: result.rc == 0
       retries: 5
       delay: 10
     ```

3. **What is the difference between `command` and `shell` modules in Ansible?**
   - **Answer**: The `command` module runs a command without using a shell, whereas the `shell` module runs commands through the shell, allowing for pipes, redirects, etc. The `command` module is safer as it avoids shell injection risks.

4. **How do you define a task that should only run if a previous task has changed?**
   - **Answer**: Use `notify` with a handler that is triggered only when the task changes.
   - **Example**:
     ```yaml
     tasks:
       - name: Install nginx
         apt:
           name: nginx
           state: present
         notify: restart nginx

     handlers:
       - name: restart nginx
         service:
           name: nginx
           state: restarted
     ```

5. **What is the difference between `notify` and `always_run` in Ansible?**
   - **Answer**: `notify` triggers handlers only when a task results in a change, whereas `always_run: yes` (now deprecated and replaced by `check_mode: no`) forces a task to run regardless of conditions.

6. **How would you perform a rolling update with Ansible?**
   - **Answer**: Use the `serial` keyword to update a few servers at a time, ensuring high availability.
   - **Example**:
     ```yaml
     - hosts: app_servers
       serial: 2
       tasks:
         - name: Update application
           command: /update_app.sh
     ```

7. **How do you manage configuration files using templates in Ansible?**
   - **Answer**: Use the `template` module to deploy files with variables replaced dynamically.
   - **Script Example**:
     ```yaml
     - name: Deploy nginx configuration
       template:
         src: templates/nginx.conf.j2
         dest: /etc/nginx/nginx.conf
     ```

8. **How would you install software on a remote machine without root privileges using Ansible?**
   - **Answer**: Use the `become` directive with non-root users who have sudo access.
   - **Script Example**:
     ```yaml
     - hosts: web
       become: yes
       become_user: non_root_user
       tasks:
         - name: Install nginx
           apt:
             name: nginx
             state: present
     ```

9. **Explain how to use the `with_items` loop in Ansible.**
   - **Answer**: `with_items` is used to loop over a list of items in tasks like installing multiple packages or users.
   - **Script Example**:
     ```yaml
     tasks:
       - name: Install multiple packages
         apt:
           name: "{{ item }}"
           state: present
         with_items:
           - nginx
           - git
           - curl
     ```

10. **How do you manage parallelism in Ansible?**
    - **Answer**: You can manage parallelism by using the `forks` directive in the `ansible.cfg` file. By default, Ansible uses 5 forks, but you can increase this for better performance.

11. **How do you use `ansible-vault` to encrypt sensitive data in playbooks?**
    - **Answer**: You can encrypt files using `ansible-vault` and decrypt them on-the-fly when running playbooks.
    - **Example**:
      ```bash
      ansible-vault create secret.yml
      ansible-playbook --ask-vault-pass playbook.yml
      ```

12. **What is the purpose of `become_method` in Ansible?**
    - **Answer**: `become_method` defines which method Ansible should use for privilege escalation, such as `sudo`, `su`, or `pbrun`.

13. **How do you implement a task that should run only on a specific day of the week?**
    - **Answer**: Use the `when` clause with the `ansible_date_time` fact.
    - **Example**:
      ```yaml
      tasks:
        - name: Run this on Monday
          command: echo "Today is Monday"
          when: ansible_date_time.weekday == 'Monday'
      ```

14. **How do you copy multiple files using Ansible?**
    - **Answer**: Use the `with_fileglob` loop to copy multiple files matching a pattern.
    - **Script Example**:
      ```yaml
      tasks:
        - name: Copy multiple files
          copy:
            src: "{{ item }}"
            dest: /destination/folder/
          with_fileglob:
            - "/path/to/files/*.txt"
      ```

15. **How do you manage file ownership and permissions with Ansible?**
    - **Answer**: Use the `file` module to manage file ownership, permissions, and other attributes.
    - **Script Example**:
      ```yaml
      - name: Set file permissions
        file:
          path: /etc/nginx/nginx.conf
          owner: root
          group: root
          mode: '0644'
      ```
