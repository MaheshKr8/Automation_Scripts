Here are **20 Kubernetes real-time scenario-based interview questions and answers**, designed to address practical challenges with real-life examples:

---

### **1. How do you handle a pod that is stuck in a "CrashLoopBackOff" state?**
**Answer:**
- Check pod logs:
  ```bash
  kubectl logs <pod-name>
  ```
- Verify if the container has the necessary configurations or environment variables.
- Investigate the container's `readinessProbe` and `livenessProbe`.
- Example: A database container is failing because it lacks credentials. Updating the Deployment with proper `secrets` fixes the issue.

---

### **2. How do you configure Kubernetes for zero-downtime deployments?**
**Answer:**
- Use RollingUpdate strategy:
  ```yaml
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0
      maxSurge: 1
  ```
- Ensure proper readiness probes to allow new pods to be ready before terminating old ones.

---

### **3. What do you do if a node becomes unreachable?**
**Answer:**
- Check node status:
  ```bash
  kubectl get nodes
  ```
- If it's marked as `NotReady`, check logs using:
  ```bash
  kubectl describe node <node-name>
  ```
- Possible actions:
  - Drain the node: 
    ```bash
    kubectl drain <node-name> --ignore-daemonsets
    ```
  - Investigate the node's kubelet or system logs.

---

### **4. How do you scale a Deployment in Kubernetes?**
**Answer:**
- Manually scale:
  ```bash
  kubectl scale deployment <deployment-name> --replicas=<number>
  ```
- Using Horizontal Pod Autoscaler (HPA):
  ```bash
  kubectl autoscale deployment <deployment-name> --cpu-percent=50 --min=1 --max=10
  ```

---

### **5. How do you troubleshoot DNS issues in Kubernetes?**
**Answer:**
- Verify CoreDNS pods are running:
  ```bash
  kubectl get pods -n kube-system
  ```
- Test DNS resolution:
  ```bash
  kubectl exec -it <pod-name> -- nslookup <service-name>
  ```
- Check `/etc/resolv.conf` inside the pod.

---

### **6. What is the role of `ConfigMap` and `Secret` in Kubernetes?**
**Answer:**
- **ConfigMap**: Stores non-sensitive data, e.g., application configurations.
- **Secret**: Stores sensitive information, e.g., API keys.
- Example:
  ```yaml
  env:
  - name: DB_PASSWORD
    valueFrom:
      secretKeyRef:
        name: db-secret
        key: password
  ```

---

### **7. How do you implement service discovery in Kubernetes?**
**Answer:**
- Kubernetes services (ClusterIP) provide built-in DNS names.
- Example:
  - Service named `my-service` in namespace `default` is accessible at `my-service.default.svc.cluster.local`.

---

### **8. How do you secure your Kubernetes cluster?**
**Answer:**
- Enable Role-Based Access Control (RBAC).
- Use `NetworkPolicy` to restrict traffic.
- Scan images for vulnerabilities before deployment.
- Example NetworkPolicy:
  ```yaml
  kind: NetworkPolicy
  apiVersion: networking.k8s.io/v1
  metadata:
    name: deny-all
  spec:
    podSelector: {}
    policyTypes:
    - Ingress
  ```

---

### **9. How do you persist data in Kubernetes?**
**Answer:**
- Use Persistent Volumes (PVs) and Persistent Volume Claims (PVCs).
- Example:
  ```yaml
  volumeMounts:
  - name: my-pv
    mountPath: /data
  volumes:
  - name: my-pv
    persistentVolumeClaim:
      claimName: my-pvc
  ```

---

### **10. How do you debug a pod that’s not starting?**
**Answer:**
- Inspect the pod's events:
  ```bash
  kubectl describe pod <pod-name>
  ```
- Check logs for errors:
  ```bash
  kubectl logs <pod-name>
  ```
- If it’s an image pull error, verify image availability and credentials.

---

### **11. What is the difference between a Deployment and a StatefulSet?**
**Answer:**
- **Deployment**: For stateless applications, scales pods independently.
- **StatefulSet**: For stateful applications, ensures ordered deployment and unique network identities.

---

### **12. How do you configure HTTPS for a Kubernetes Ingress?**
**Answer:**
- Use a TLS certificate:
  ```yaml
  spec:
    tls:
    - hosts:
      - my-app.example.com
      secretName: tls-secret
  ```

---

### **13. How do you monitor a Kubernetes cluster?**
**Answer:**
- Use Prometheus and Grafana for resource metrics.
- Use `kubectl top` for quick pod and node resource usage:
  ```bash
  kubectl top pods
  kubectl top nodes
  ```

---

### **14. How do you set up a custom namespace?**
**Answer:**
- Create a namespace:
  ```bash
  kubectl create namespace my-namespace
  ```
- Deploy resources in the namespace:
  ```yaml
  metadata:
    namespace: my-namespace
  ```

---

### **15. How do you configure pod affinity and anti-affinity?**
**Answer:**
- Example anti-affinity:
  ```yaml
  affinity:
    podAntiAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchLabels:
            app: my-app
        topologyKey: "kubernetes.io/hostname"
  ```

---

### **16. How do you update a running application in Kubernetes?**
**Answer:**
- Use `kubectl edit` to modify a deployment.
- Apply a new manifest file:
  ```bash
  kubectl apply -f updated-deployment.yaml
  ```

---

### **17. How do you expose an application externally in Kubernetes?**
**Answer:**
- Use a Service of type `LoadBalancer` or configure an Ingress resource.

---

### **18. What is the difference between readiness and liveness probes?**
**Answer:**
- **Readiness Probe**: Determines if a pod is ready to serve traffic.
- **Liveness Probe**: Checks if a pod is still running.

---

### **19. How do you set up a private Docker registry for Kubernetes?**
**Answer:**
- Create a Secret with Docker credentials:
  ```bash
  kubectl create secret docker-registry my-registry-secret --docker-server=<registry> --docker-username=<username> --docker-password=<password>
  ```

---

### **20. How do you configure a `Job` in Kubernetes?**
**Answer:**
- Example Job manifest:
  ```yaml
  apiVersion: batch/v1
  kind: Job
  metadata:
    name: example-job
  spec:
    template:
      spec:
        containers:
        - name: my-job
          image: busybox
          command: ["echo", "Hello Kubernetes!"]
        restartPolicy: Never
  ```

---

These questions and answers are commonly asked in real-time Kubernetes interviews and help demonstrate your hands-on expertise. Let me know if you'd like additional explanation or scripts!
