

---

### ✅ **1. Scenario: You need to deploy a new feature to production with zero downtime. How do you ensure this using Kubernetes?**

**Answer:**
Use **Rolling Updates** in Kubernetes:

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1
    maxUnavailable: 0
```

* This ensures that at least one pod is always running.
* Test readiness using **readinessProbe** so traffic isn’t routed to unready pods.

---

### ✅ **2. Scenario: A developer accidentally deleted an AWS S3 bucket that stores production logs. How do you prevent this in the future?**

**Answer:**

* Enable **Versioning** and **MFA Delete** on the bucket.
* Use **Terraform with `prevent_destroy = true`**:

```hcl
lifecycle {
  prevent_destroy = true
}
```

* Enable S3 **Object Lock** for write-once-read-many (WORM) protection.

---

### ✅ **3. Scenario: An application running in a Docker container is losing logs after container restart. How do you persist logs?**

**Answer:**

* Use **Docker volumes** to persist logs:

```bash
docker run -v /app/logs:/var/logs my-app
```

* Or redirect logs to host via logging driver:

```bash
docker run --log-driver=json-file ...
```

* Use centralized logging: Fluentd → Elasticsearch → Kibana (EFK).

---

### ✅ **4. Scenario: Your Kubernetes pods are in `CrashLoopBackOff`. How do you troubleshoot?**

**Answer:**

1. Check logs:

```bash
kubectl logs <pod-name> --previous
```

2. Describe pod:

```bash
kubectl describe pod <pod-name>
```

3. Common issues:

   * Misconfigured **environment variables**.
   * Failing **liveness/readiness probes**.
   * Not enough **resources** or **secrets** missing.

---

### ✅ **5. Scenario: You need to deploy Terraform modules in a dependent order (e.g., VPC → EC2). How do you handle dependencies?**

**Answer:**
Use **module outputs and inputs**:

```hcl
module "vpc" {
  ...
}

module "ec2" {
  vpc_id = module.vpc.vpc_id
}
```

Terraform automatically builds a dependency graph and deploys in order.

---

### ✅ **6. Scenario: You need to restrict internal Kubernetes traffic between two namespaces. How do you achieve this?**

**Answer:**

* Use **Network Policies**:

```yaml
kind: NetworkPolicy
spec:
  podSelector: {}
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              name: allowed-namespace
```

* Use Calico/Cilium to enforce policies.

---

### ✅ **7. Scenario: A new developer needs access to a specific Jenkins job and not the whole system. How do you handle this?**

**Answer:**

* Enable **Matrix-based Security** or Role Strategy Plugin.
* Assign job-specific permissions (Read/Build) to the developer.
* Optionally, integrate Jenkins with **LDAP** or **OAuth2** for centralized RBAC.

---

### ✅ **8. Scenario: Your EC2 instance is unreachable via SSH. What do you check?**

**Answer:**

1. **Security Group** allows port 22.
2. **Network ACLs** allow inbound/outbound traffic.
3. **Public IP** is assigned (for public access).
4. Use **EC2 Instance Connect** or **AWS SSM** Session Manager if available.

---

### ✅ **9. Scenario: Code pushed to GitHub should trigger Jenkins pipeline automatically. How do you set this up?**

**Answer:**

* Configure **GitHub Webhook** to notify Jenkins:

  * URL: `http://jenkins-url/github-webhook/`
* Use **GitHub plugin** in Jenkins and setup a pipeline job with SCM polling.
* Use a **Jenkinsfile** for declarative pipeline.

---

### ✅ **10. Scenario: Your team needs to scan Docker images for vulnerabilities before pushing to production. What tool do you use and how?**

**Answer:**

* Use **Trivy** or **Grype** to scan images:

```bash
trivy image myapp:latest
```

* Integrate scan step in Jenkins/GitLab pipeline.
* Optionally enforce **policy gates** using tools like **OPA Gatekeeper** or **Harbor** registry with CVE enforcement.

---
