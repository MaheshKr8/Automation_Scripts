
---

### **1. Scenario: You deployed a new application version in Kubernetes and it's crashing. How do you debug?**

**Answer:**
- Run `kubectl get pods` to check the status.
- Use `kubectl describe pod <pod-name>` to see events and reasons.
- Use `kubectl logs <pod-name>` for container logs.
- Check for misconfigurations in ConfigMap/Secrets or missing env vars.
- If `CrashLoopBackOff`, check readiness/liveness probes or image issues.

---

### **2. Scenario: Jenkins job is failing after a pipeline change. How will you troubleshoot?**

**Answer:**
- Check the Jenkins job logs.
- Review recent changes in `Jenkinsfile`.
- Check if credentials/secrets are missing or invalid.
- Ensure plugins and agents are working.
- Re-run the job with debug or echo steps.

---

### **3. Scenario: Your EC2 instance is not accessible via SSH. What do you do?**

**Answer:**
- Check security group rules (port 22).
- Verify NACLs.
- Ensure instance has a public IP and correct key pair.
- Use EC2 Serial Console or Systems Manager Session Manager.
- Check instance status and system logs.

---

### **4. Scenario: A Terraform apply failed. What next?**

**Answer:**
- Read the exact error in the CLI.
- Fix the resource conflict or dependency issue.
- Use `terraform plan` to review expected changes.
- If stuck in partial apply, use `terraform state` to clean up.
- Consider using `-target` or `-replace`.

---

### **5. Scenario: Docker container keeps restarting. How to debug?**

**Answer:**
- Use `docker logs <container-id>` to check errors.
- Use `docker inspect <container-id>` for config details.
- Check entrypoint or CMD in Dockerfile.
- Ensure necessary ports/volumes/env vars are correctly passed.
- Look for permission issues or resource limits.

---

### **6. Scenario: You see a CVE in image scan via Trivy/SonarQube. What actions do you take?**

**Answer:**
- Identify severity (critical/high).
- Look for a patched version of the base image/library.
- Rebuild the image with updated packages.
- Document the exception if fix isn’t available.
- Integrate scan in CI to prevent future issues.

---

### **7. Scenario: How would you roll back a Kubernetes deployment?**

**Answer:**
- Use `kubectl rollout undo deployment <name>`.
- Check previous revision: `kubectl rollout history deployment <name>`.
- Monitor rollback: `kubectl rollout status deployment <name>`.

---

### **8. Scenario: Application is deployed but not accessible. What do you check?**

**Answer:**
- Pod status and logs.
- Service type and selector labels.
- Ingress rules and DNS settings.
- Firewall/Security Groups.
- External IP for LoadBalancer/NodePort services.

---

### **9. Scenario: Jenkins is slow. How do you optimize?**

**Answer:**
- Check number of concurrent jobs.
- Increase executor count on agents.
- Offload artifacts/logs to S3/NFS.
- Use lightweight Docker agents.
- Archive logs and prune old builds.

---

### **10. Scenario: How do you ensure zero-downtime deployment in Kubernetes?**

**Answer:**
- Use rolling updates (default).
- Set proper readiness/liveness probes.
- Use `maxUnavailable` and `maxSurge` in Deployment strategy.
- Validate deployment with `kubectl rollout status`.

---

### **11. Scenario: Git merge conflict in CI/CD pipeline. What do you do?**

**Answer:**
- Reproduce locally using the same branch/PR.
- Resolve conflict manually and re-commit.
- Improve branching strategy (GitFlow/trunk-based).
- Use PR validations and rebase before merge.

---

### **12. Scenario: Your Terraform state file is corrupted. What can you do?**

**Answer:**
- Restore from S3/versioned backup (if remote).
- Use `terraform state pull` and fix syntax manually.
- Use `terraform import` to re-import resources.
- Avoid manual changes to state unless necessary.

---

### **13. Scenario: ArgoCD sync fails. What’s your debugging approach?**

**Answer:**
- Check Application logs in ArgoCD UI or CLI.
- Validate YAML in Git repo (`kubectl apply -f` locally).
- Check K8s resource status via `kubectl`.
- Review RBAC and ArgoCD ServiceAccount permissions.

---

### **14. Scenario: Team needs to access secrets securely. How do you manage it?**

**Answer:**
- Use AWS Secrets Manager or HashiCorp Vault.
- Limit access via IAM policies or Vault policies.
- Integrate secrets injection in CI/CD pipelines.
- Rotate secrets automatically.

---

### **15. Scenario: Application performance is degraded. Where do you start?**

**Answer:**
- Check metrics in Prometheus/Grafana.
- Analyze resource usage (CPU, memory).
- Look for high latency in API/DB.
- Use APM tools like NewRelic/DataDog.
- Investigate any recent deployments.

---

### **16. Scenario: Dockerfile is slow during build. How to optimize?**

**Answer:**
- Use multistage builds.
- Minimize image layers.
- Avoid `apt-get update` without `--no-install-recommends`.
- Cache dependencies intelligently.
- Pin base image versions.

---

### **17. Scenario: You accidentally deleted a Kubernetes namespace. Recovery plan?**

**Answer:**
- If backup exists (Velero), restore it.
- If using GitOps (e.g., ArgoCD), reapply manifests from Git.
- Prevent future issues by enabling RBAC controls.
- Consider setting finalizers to avoid accidental deletions.

---

### **18. Scenario: Jenkins pipeline takes too long. How can you speed it up?**

**Answer:**
- Run steps in parallel (`parallel` block).
- Use Docker layers or cache for builds.
- Move heavy integration tests to scheduled runs.
- Optimize steps by reusing artifacts.

---

### **19. Scenario: Your Kubernetes pod can’t reach an external service. What now?**

**Answer:**
- Check NetworkPolicies and egress rules.
- Ensure DNS resolution works inside the pod.
- Test with curl/ping tools in a debug container.
- Check for egress NAT gateway if private subnet.

---

### **20. Scenario: How would you handle disaster recovery for your infrastructure?**

**Answer:**
- Use Infrastructure as Code (Terraform) for reproducibility.
- Store remote state in versioned and encrypted storage (S3).
- Backup data volumes and databases regularly.
- Use Multi-AZ/Multi-Region deployments.
- Test DR plan quarterly.

---
