
---

### **1. How to find the top 5 CPU-consuming processes in real-time?**

**Command:**
```bash
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6
```

**Explanation:**  
The `ps` (process status) command is used to view information about active processes. The options used here help us sort and display processes based on CPU consumption.

- **`-e`**: Displays all processes.
- **`-o pid,ppid,cmd,%mem,%cpu`**: Specifies the columns to display:
  - `pid`: Process ID.
  - `ppid`: Parent process ID.
  - `cmd`: Command that started the process.
  - `%mem`: Memory usage by the process.
  - `%cpu`: CPU usage by the process.
- **`--sort=-%cpu`**: Sorts the output by CPU usage in descending order (most CPU-consuming processes at the top).
- **`head -n 6`**: Limits the output to the top 5 processes, including the header.

**Why it’s useful:**  
- **Monitoring Performance:** Helps identify which processes are consuming the most CPU resources, useful for troubleshooting performance bottlenecks.
- **System Administration:** Regular monitoring of CPU usage ensures that no process is overloading the system and affecting its performance.

**Example Usage:**
```bash
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6
```

**Example Output:**
```
  PID  PPID CMD                         %MEM %CPU
  1234  5678 /usr/bin/python3 app.py      1.2  30.5
  2345  1234 /usr/bin/node server.js     0.8  20.3
  3456  1234 /usr/bin/java -jar app.jar  1.5  15.2
  4567  2345 /usr/bin/mysql              2.1  8.6
  5678  3456 /usr/bin/nginx              0.5  6.1
```

In this example:
- The top 5 processes are listed along with their CPU and memory usage.
- The `python3` process is using the most CPU (`30.5%`), followed by the `node` process (`20.3%`).

**Real-Life Use Case:**  
You might use this command to quickly identify resource-hogging processes during periods of high server load or in response to a system performance issue. If a single process is consuming too much CPU, you can then decide to optimize, kill, or limit its resource usage.

### **2. How to check disk usage of a specific directory?**

**Command:**
```bash
du -sh /path/to/directory
```

**Explanation:**  
The `du` (disk usage) command provides the size of a directory and its contents. The options used here are:

- **`-s`**: Summarizes the total disk usage of the directory and doesn't list the sizes of individual files or subdirectories.
- **`-h`**: Provides human-readable output, displaying the size in KB, MB, GB, etc.

**Why it’s useful:**  
- **Disk Space Management:** Helps track the amount of space being consumed by a specific directory, especially useful for identifying large directories or files that may be consuming excessive disk space.
- **System Monitoring:** Useful for periodic checks to prevent storage from filling up, which could affect system performance or cause outages.
- **Backup or Migration:** Before moving or backing up a directory, knowing its size ensures proper planning and execution.

**Example Usage:**
```bash
du -sh /var/log
```

**Example Output:**
```
1.5G    /var/log
```

This shows that the `/var/log` directory is using 1.5GB of disk space.

**Real-Life Use Case:**  
Suppose you're running a server with limited disk space, and you want to determine the space usage of log files stored in `/var/log`. Using the command `du -sh /var/log` gives you a quick overview of the total space used by logs, helping you decide whether to archive or delete old log files to free up space.

### Additional Notes:
- **Check Disk Usage of All Subdirectories:** If you want to see the disk usage for all subdirectories inside a directory:
  ```bash
  du -h /path/to/directory
  ```
  This will display the sizes of the directory and all its subdirectories.
  
- **Sort by Size:** To list the directories in descending order of size, you can combine `du` with `sort`:
  ```bash
  du -ah /path/to/directory | sort -rh
  ```
  This will list all files and directories under `/path/to/directory`, sorted by size.

### **3. How to find and delete files larger than 1GB?**

**Command:**
```bash
find /path/to/directory -type f -size +1G -exec rm -i {} \;
```

**Explanation:**  
The `find` command allows you to search for files based on various criteria. Here, we use it to find files larger than 1GB and delete them:

- **`/path/to/directory`**: The directory where you want to search for large files (you can use `/` to search the entire filesystem).
- **`-type f`**: Restricts the search to regular files (not directories or other types).
- **`-size +1G`**: Finds files larger than 1GB. The `+` sign means "greater than" and `1G` represents 1 gigabyte.
- **`-exec rm -i {} \;`**: For each file found, the `rm` command is executed to delete the file. The `-i` option prompts for confirmation before deletion, providing a safeguard to avoid accidental deletion.

**Why it’s useful:**  
- **Disk Space Management:** Helps in clearing up large, unnecessary files that may be consuming valuable disk space.
- **File Cleanup:** Useful when you need to remove old, outdated files or large temporary files.
- **Automated Maintenance:** Can be included in maintenance scripts for automatic cleanup of files exceeding a size threshold.

**Example Usage:**
```bash
find /home/user/Downloads -type f -size +1G -exec rm -i {} \;
```

This command will search for files larger than 1GB in the `/home/user/Downloads` directory and ask for confirmation before deleting each file.

**Real-Life Use Case:**  
You might use this command when cleaning up an old server or filesystem that has accumulated large files over time (e.g., backups, log files, or temporary data). For instance, if the `/var/log` directory contains log files that have grown too large, this command helps to find and remove them.

### Additional Notes:
- **Dry Run (Without Deletion):** To find the files without deleting them (for verification):
  ```bash
  find /path/to/directory -type f -size +1G
  ```
  This lists all files larger than 1GB without deleting them.
  
- **Force Deletion Without Confirmation:** If you're confident about the files being deleted and want to skip the confirmation step, use:
  ```bash
  find /path/to/directory -type f -size +1G -exec rm {} \;
  ```
  This will delete the files without asking for confirmation. Use this with caution.

### **4. How to monitor real-time logs of a service?**

**Command:**
```bash
sudo journalctl -u service_name -f
```

**Explanation:**  
The `journalctl` command is used to query and view logs from the `systemd` journal. The options used here are:

- **`-u service_name`**: Specifies the service whose logs you want to monitor. Replace `service_name` with the name of the service (e.g., `nginx`, `apache2`, `mysql`).
- **`-f`**: Follows the logs in real-time, displaying new log entries as they are written (similar to `tail -f`).

**Why it’s useful:**  
- **Real-Time Monitoring:** This command allows you to actively monitor the logs of a service, which is crucial for debugging, troubleshooting, and observing the behavior of services.
- **Error Detection:** You can quickly spot errors or warnings that occur during runtime (e.g., when a web server like `nginx` fails to start or encounters an issue).
- **System Administration:** Essential for keeping an eye on critical services, especially during system maintenance or troubleshooting.

**Example Usage:**
To monitor the real-time logs of the `nginx` service:
```bash
sudo journalctl -u nginx -f
```

This will continuously display new logs generated by the `nginx` service as they appear in the system's journal.

**Example Output:**
```
-- Logs begin at Tue 2024-11-23 10:00:00 UTC, end at Thu 2024-11-23 12:00:00 UTC. --
Nov 23 12:00:00 server_name nginx[1234]: 2024/11/23 12:00:00 [error] 1234#1234: *1 connect() to unix:/var/run/php/php7.4-fpm.sock failed (2: No such file or directory) while connecting to upstream, client: 192.168.1.1, server: example.com, request: "GET / HTTP/1.1", upstream: "fastcgi://unix:/var/run/php/php7.4-fpm.sock", host: "example.com"
Nov 23 12:00:01 server_name nginx[1234]: 2024/11/23 12:00:01 [error] 1234#1234: *2 connect() to unix:/var/run/php/php7.4-fpm.sock failed (2: No such file or directory) while connecting to upstream, client: 192.168.1.1, server: example.com, request: "GET /about HTTP/1.1", upstream: "fastcgi://unix:/var/run/php/php7.4-fpm.sock", host: "example.com"
```

In this example, you can see that `nginx` is attempting to connect to a PHP-FPM socket but encountering an error due to the socket file missing.

### Real-Life Use Case:  
If you’re troubleshooting a web server (like `nginx`) that isn’t serving pages correctly, monitoring the logs in real-time helps you identify configuration issues, missing files, or errors generated by services like PHP-FPM or databases. This can lead you to a faster resolution of the problem.

### Additional Notes:
- **Monitor Logs for Other Services:** To monitor logs of any other service, simply replace `nginx` with the relevant service name:
  ```bash
  sudo journalctl -u apache2 -f
  ```
- **Display Logs from a Specific Time:** To display logs from a specific time, you can use the `--since` option:
  ```bash
  sudo journalctl -u service_name --since "2024-11-23 10:00:00"
  ```

### **5. How to schedule a cron job to run a script daily at midnight?**

**Command:**
```bash
crontab -e
```

**Explanation:**  
The `crontab` command is used to edit the cron jobs for the current user. The `-e` option opens the user's crontab file for editing.

To schedule a script to run daily at midnight, you need to add a new cron job with the following syntax:

```bash
0 0 * * * /path/to/script.sh
```

- **`0 0 * * *`**: This specifies the schedule:
  - The first `0` refers to the minute of the hour (0th minute).
  - The second `0` refers to the hour (0th hour, which is midnight).
  - The `*` in the day of the month, month, and day of the week fields means "every".
- **`/path/to/script.sh`**: The full path to the script that you want to run at midnight. Ensure the script is executable (`chmod +x /path/to/script.sh`).

**Why it’s useful:**  
- **Automation:** Cron jobs are ideal for automating regular tasks, such as backups, log rotations, database maintenance, etc.
- **Consistency:** Scheduling the script to run at midnight ensures it runs at the same time every day, without requiring manual intervention.

**Example Usage:**
```bash
crontab -e
```

Then, add the following line to schedule the script to run daily at midnight:
```bash
0 0 * * * /home/user/scripts/daily_backup.sh
```

**Real-Life Use Case:**  
Imagine you need to perform a backup of your website every night at midnight. Instead of manually initiating the backup, you can automate it by adding the cron job. The script `/home/user/scripts/daily_backup.sh` will automatically run at midnight every day to back up your website data.

### Additional Notes:
- **Check Existing Cron Jobs:** To list your existing cron jobs, use:
  ```bash
  crontab -l
  ```
- **Cron Logs:** If you want to troubleshoot or verify if your cron job is running as expected, check the cron logs:
  ```bash
  grep CRON /var/log/syslog
  ```
- **Redirect Output to Log File:** If you want the output of the script to be logged for later review, you can redirect it to a log file:
  ```bash
  0 0 * * * /path/to/script.sh >> /path/to/logfile.log 2>&1
  ```

### **6. How to troubleshoot a service that is not starting?**

**Steps:**

1. **Check the Service Status:**
   Use `systemctl` to check the status of the service. This will provide clues if the service failed to start.
   ```bash
   sudo systemctl status service_name
   ```

   **Explanation:**
   - **`status`**: Displays the current status of the service, including whether it's running or failed.
   - The output typically includes the last few log entries related to the service, which can help identify the cause of the failure.

   **Example Output:**
   ```bash
   ● nginx.service - A high performance web server and a reverse proxy server
      Loaded: loaded (/lib/systemd/system/nginx.service; enabled; vendor preset: enabled)
      Active: failed (Result: exit-code) since Thu 2024-11-23 10:00:00 UTC; 2h 10min ago
     Process: 1234 ExecStart=/usr/sbin/nginx -g daemon on; master_process on; (code=exited, status=1/FAILURE)
    ```

2. **View Detailed Logs:**
   To get more detailed logs, use `journalctl` to view logs related to the service:
   ```bash
   sudo journalctl -u service_name
   ```

   **Explanation:**
   - **`-u service_name`**: Limits the logs to those related to the specific service.
   - This will give you detailed logs and any error messages that can pinpoint the problem.

   **Example Usage:**
   ```bash
   sudo journalctl -u nginx
   ```

3. **Check for Configuration Errors:**
   Sometimes, a service fails to start because of incorrect configuration. Review the service's configuration files for errors.
   - For example, for `nginx`, check the configuration file:
     ```bash
     sudo nginx -t
     ```
   - This command checks the syntax of the configuration file and will provide feedback on any errors.

   **Example Output:**
   ```
   nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
   nginx: configuration file /etc/nginx/nginx.conf test is successful
   ```

4. **Check for Port Conflicts:**
   A service may fail to start if the port it’s trying to bind to is already in use. To check if the port is occupied, use:
   ```bash
   sudo lsof -i :port_number
   ```

   **Explanation:**
   - **`lsof`**: Lists open files, including network connections.
   - **`-i :port_number`**: Lists processes using the specified port.

   **Example Usage:**
   ```bash
   sudo lsof -i :80
   ```

   If another service is using the port, you can either stop the conflicting service or change the configuration of the service you're troubleshooting.

5. **Check System Resources:**
   Sometimes, a service fails to start due to insufficient system resources like memory or disk space. Use the following commands to check system usage:
   - **Check free memory:**
     ```bash
     free -h
     ```
   - **Check disk usage:**
     ```bash
     df -h
     ```

6. **Restart the Service:**
   After identifying and fixing any issues, try restarting the service:
   ```bash
   sudo systemctl restart service_name
   ```

   **Explanation:**
   - **`restart`**: Restarts the service after making configuration changes or fixing errors.

7. **Re-enable the Service (if necessary):**
   If the service is disabled, it may not start automatically after a reboot. To enable the service, use:
   ```bash
   sudo systemctl enable service_name
   ```

8. **Check for Missing Dependencies:**
   Some services depend on other services or packages. If dependencies are missing, the service may fail to start. Check if all required packages are installed and running:
   ```bash
   sudo systemctl list-dependencies service_name
   ```

### Real-Life Use Case:
If your `nginx` web server isn’t starting, follow these steps to troubleshoot:
- Run `sudo systemctl status nginx` to check if it failed due to a misconfiguration.
- Use `sudo journalctl -u nginx` to check for detailed error logs.
- If the logs indicate a configuration error, run `sudo nginx -t` to validate the configuration file.
- If a port conflict is mentioned, check if port 80 is already in use using `sudo lsof -i :80`.
- After resolving issues, restart the service with `sudo systemctl restart nginx`.

### Additional Notes:
- **Permissions:** Ensure the service has the necessary permissions to access files or network ports. Sometimes, SELinux or AppArmor might block access.
- **Reboot the System:** If all else fails, reboot the server, especially if there are issues with system resources or if other services are not starting correctly.


### **7. How to set up a password-less SSH login?**

**Steps:**

1. **Generate SSH Key Pair (on the local machine):**
   First, generate an SSH key pair (public and private keys) on the local machine. If you already have an SSH key pair, you can skip this step.

   **Command:**
   ```bash
   ssh-keygen -t rsa -b 2048
   ```

   **Explanation:**
   - **`-t rsa`**: Specifies the type of key to create (RSA).
   - **`-b 2048`**: Specifies the bit size of the key (2048 bits is secure for most uses).
   - The command will prompt you for a location to save the key (`~/.ssh/id_rsa` by default) and a passphrase (optional, but recommended for added security).

   **Example Output:**
   ```
   Generating public/private rsa key pair.
   Enter file in which to save the key (/home/user/.ssh/id_rsa):
   Enter passphrase (empty for no passphrase):
   Enter same passphrase again:
   ```

2. **Copy the Public Key to the Remote Server:**
   Next, copy the public key (`id_rsa.pub`) to the remote server’s `~/.ssh/authorized_keys` file.

   **Command:**
   ```bash
   ssh-copy-id user@remote_server
   ```

   **Explanation:**
   - **`ssh-copy-id`**: A simple command that copies your public key to the remote server.
   - **`user@remote_server`**: Replace with the username and the IP address or hostname of the remote server.
   - It will prompt you for the password of the remote server's user to authenticate the initial connection.

   **Example Output:**
   ```
   /usr/bin/ssh-copy-id: INFO: Source of key(s) to be installed: /home/user/.ssh/id_rsa.pub
   The authenticity of host 'remote_server (192.168.1.1)' can't be established.
   Are you sure you want to continue connecting (yes/no)? yes
   user@remote_server's password:
   ```

3. **Test Password-less Login:**
   Now that the public key is copied to the remote server, try logging in again. This time, SSH will use the private key for authentication, and you won’t be prompted for a password.

   **Command:**
   ```bash
   ssh user@remote_server
   ```

   **Explanation:**
   - If the key was correctly installed, SSH will authenticate you using your private key, and you will not be asked for the password.

   **Example Output:**
   ```
   Welcome to Ubuntu 20.04 LTS!
   user@remote_server:~$
   ```

### Real-Life Use Case:
Setting up password-less SSH login is particularly useful for automating tasks such as:
- **Automating Backups:** If you're writing a script that needs to access a remote server for backups, password-less login ensures the script can run without manual intervention.
- **Managing Multiple Servers:** When managing several servers (e.g., for system administration tasks), password-less SSH login enables easy access to each server, eliminating the need to input passwords each time.
- **CI/CD Pipelines:** In a continuous integration/continuous deployment (CI/CD) environment, setting up password-less SSH access is critical for deploying code from an automated server to remote machines.

### Additional Notes:
- **Security Considerations:** It’s important to secure the private key file (`~/.ssh/id_rsa`). If you use a passphrase when creating the SSH key, it adds an additional layer of security.
  - **Ensure proper file permissions**: The private key should be readable only by the owner:
    ```bash
    chmod 600 ~/.ssh/id_rsa
    ```
- **SSH Agent:** If you used a passphrase for your private key, you might want to use `ssh-agent` to cache your key’s passphrase, so you don’t have to enter it each time.
  ```bash
  eval $(ssh-agent)
  ssh-add ~/.ssh/id_rsa
  ```
- **Disabling Password Authentication (Optional):** Once you've set up password-less SSH, you can increase security by disabling password-based login altogether by editing the SSH configuration file (`/etc/ssh/sshd_config`) on the remote server:
  ```bash
  PasswordAuthentication no
  ```
  Then restart the SSH service:
  ```bash
  sudo systemctl restart sshd
  ```

This setup will ensure that only users with valid SSH keys can log in, making your server more secure.

---

### **8. How to find which process is using a specific port?**

**Command:**
```bash
sudo lsof -i :port_number
```

**Explanation:**
- **`lsof`**: Lists open files, including network connections.
- **`-i :port_number`**: Specifies the port number to search for. Replace `port_number` with the actual port number you're interested in (e.g., `80` for HTTP, `443` for HTTPS).
- **`sudo`**: You may need superuser privileges to view information about processes owned by other users.

This command will display the process that is currently using the specified port.

**Example:**
To find which process is using port 80 (HTTP):
```bash
sudo lsof -i :80
```

**Example Output:**
```
COMMAND  PID   USER   FD   TYPE DEVICE SIZE/OFF NODE NAME
nginx   1234   root   6u  IPv4  123456      0t0  TCP *:http (LISTEN)
```

- **`COMMAND`**: The name of the command (e.g., `nginx`).
- **`PID`**: The Process ID (PID) of the command (e.g., `1234`).
- **`USER`**: The user running the process (e.g., `root`).
- **`NAME`**: The name of the port and protocol (e.g., `*:http`).

This output indicates that `nginx` is listening on port 80 (HTTP).

### Why it’s useful:
- **Troubleshooting Port Conflicts**: This command is helpful when trying to identify which process is occupying a particular port, especially when a new service or application fails to start due to a port conflict.
- **System Monitoring**: Allows you to keep track of network services and applications listening on specific ports.
- **Security Audits**: Helps you check if any unauthorized services are running on unexpected ports.

### Real-Life Use Case:
Imagine you are trying to start a web server on port 80 (HTTP), but it fails. You run the command `sudo lsof -i :80` and discover that `nginx` is already using the port. In this case, you can stop `nginx` or reconfigure your web server to use a different port.

### Additional Notes:
- **Alternative Command (Using `netstat`)**: If `lsof` is not available, you can use `netstat` to get similar information:
  ```bash
  sudo netstat -tuln | grep :port_number
  ```
  - **`-tuln`**: Shows TCP (`t`), UDP (`u`), listening (`l`), and numeric (`n`) connections.
  
- **Checking Multiple Ports**: If you want to check for multiple ports, you can modify the command like this:
  ```bash
  sudo lsof -i :80 -i :443
  ```

This way, you can easily identify which processes are using the specified ports.

### **9. How to compress and archive a directory?**

You can compress and archive a directory in Linux using the `tar` command, which stands for "tape archive." It combines the tasks of compressing files and creating archives.

**Command to Compress and Archive a Directory:**
```bash
tar -czvf archive_name.tar.gz /path/to/directory
```

### Explanation:
- **`tar`**: The command to create and manipulate archive files.
- **`-c`**: Create a new archive.
- **`-z`**: Compress the archive using `gzip` (creates `.tar.gz`).
- **`-v`**: Verbose mode, which displays the files being archived.
- **`-f`**: Specifies the name of the archive file.
- **`archive_name.tar.gz`**: The name of the resulting archive file.
- **`/path/to/directory`**: The path to the directory you want to archive and compress.

**Example Usage:**
To compress and archive a directory named `my_folder` into an archive called `my_folder.tar.gz`:
```bash
tar -czvf my_folder.tar.gz my_folder/
```

### Example Output:
```
my_folder/
my_folder/file1.txt
my_folder/file2.txt
my_folder/subfolder/
my_folder/subfolder/file3.txt
```

This will create a `my_folder.tar.gz` file in the current directory and include the contents of `my_folder` inside it.

### Real-Life Use Case:
- **Backup**: You might want to compress and archive a directory for backup purposes. For example, archiving a project directory before migrating it to another server.
- **Transfer**: Compressing and archiving a directory makes it easier to transfer large directories over the network (e.g., via email or FTP).
- **System Administration**: System administrators often create compressed archives of system configurations, logs, or other directories for storage, transfer, or backup.

### Additional Notes:
- **Compression Alternatives**: You can use different compression formats by changing the options:
  - **`-j`** for `bzip2` compression (`.tar.bz2`):
    ```bash
    tar -cjvf archive_name.tar.bz2 /path/to/directory
    ```
  - **`-J`** for `xz` compression (`.tar.xz`):
    ```bash
    tar -cJvf archive_name.tar.xz /path/to/directory
    ```

- **Extracting the Archive**:
  To extract the contents of a `.tar.gz` archive, use:
  ```bash
  tar -xzvf archive_name.tar.gz
  ```
  - **`-x`**: Extract the archive.

- **List Contents of the Archive**:
  If you want to list the contents of an archive without extracting it, use:
  ```bash
  tar -tzvf archive_name.tar.gz
  ```

This makes the `tar` command a versatile tool for archiving and compressing directories in Linux.

### **10. How to view network statistics and active connections?**

There are several tools available in Linux to view network statistics and active connections. Below are some commonly used commands:

---

#### **1. Using `netstat` to View Network Statistics and Active Connections**

**Command:**
```bash
netstat -tuln
```

**Explanation:**
- **`netstat`**: Network statistics tool that displays various network-related information, including active connections, listening ports, and more.
- **`-t`**: Shows TCP connections.
- **`-u`**: Shows UDP connections.
- **`-l`**: Shows only listening sockets (active ports).
- **`-n`**: Shows numerical addresses instead of resolving hostnames.

This command will display active TCP/UDP connections and their status.

**Example Output:**
```
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address           Foreign Address         State
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN
tcp6       0      0 :::80                   :::*                    LISTEN
```

- **`Local Address`**: The IP address and port the server is listening on.
- **`Foreign Address`**: The IP address and port of the remote connection (for established connections).
- **`State`**: The state of the connection (e.g., LISTEN, ESTABLISHED).

---

#### **2. Using `ss` to View Network Statistics**

**Command:**
```bash
ss -tuln
```

**Explanation:**
- **`ss`**: `ss` (Socket Stat) is a tool that provides more detailed information about network sockets and is considered faster and more efficient than `netstat`.
- The options (`-tuln`) have the same meaning as with `netstat`.

**Example Output:**
```
State      Recv-Q Send-Q   Local Address:Port     Peer Address:Port
LISTEN     0      128              *:22                    *:*   
LISTEN     0      128              *:80                    *:*
```

`ss` provides more detailed and faster results compared to `netstat`.

---

#### **3. Using `ifstat` to View Network Interface Statistics**

**Command:**
```bash
ifstat
```

**Explanation:**
- **`ifstat`**: Displays network interface statistics, showing the amount of data transferred over network interfaces.

**Example Output:**
```
       eth0        lo
 KB in  KB out  KB in  KB out
  4.50     1.30    0.00     0.00
```

- **`eth0`**: Network interface name (can vary depending on your system).
- **`KB in`** and **`KB out`**: Data received and transmitted in kilobytes per second.

---

#### **4. Using `iftop` for Real-Time Network Bandwidth Monitoring**

**Command:**
```bash
sudo iftop
```

**Explanation:**
- **`iftop`**: Displays real-time bandwidth usage on a network interface.
- You can monitor which connections are consuming the most bandwidth.

**Example Output:**
```
  192.168.1.2:80   => 192.168.1.100:53684  1.35 MB    0.00  0.10  1.0%
  192.168.1.100:53684   => 192.168.1.2:80     3.56 MB    0.00  0.10  3.5%
```

- **`Source` and `Destination`**: The local and remote IP addresses.
- **Data Transfer Rate**: The amount of data being transferred.
- **`%`**: Percentage of total bandwidth used.

---

#### **5. Using `nmap` to Scan Open Ports and Active Connections**

**Command:**
```bash
nmap -sT -O localhost
```

**Explanation:**
- **`nmap`**: Network Mapper is a powerful tool to discover hosts and services on a computer network.
- **`-sT`**: Performs a TCP connect scan.
- **`-O`**: Attempts to identify the operating system of the host.
- **`localhost`**: Replace with a target IP or hostname.

**Example Output:**
```
Starting Nmap 7.80 ( https://nmap.org ) at 2024-11-23 10:00 UTC
Nmap scan report for localhost (127.0.0.1)
Host is up (0.00017s latency).
Not shown: 998 closed ports
PORT   STATE SERVICE
22/tcp open  ssh
80/tcp open  http
```

- This shows which ports are open on the target system and what services are running on them.

---

#### **6. Using `ip -s link` to View Network Interface Statistics**

**Command:**
```bash
ip -s link
```

**Explanation:**
- **`ip`**: The `ip` command provides detailed information about networking and interfaces.
- **`-s`**: Provides detailed statistics.
- **`link`**: Refers to network interfaces.

**Example Output:**
```
2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP mode DEFAULT group default qlen 1000
    link/ether 00:1a:2b:3c:4d:5e brd ff:ff:ff:ff:ff:ff
    RX: bytes  packets  errors  dropped missed  mcast
    1000000     1000     0       0       0      0
    TX: bytes  packets  errors  dropped carrier collsns
    2000000     2000     0       0       0      0
```

- **RX/TX Statistics**: Displays received and transmitted bytes, packets, errors, etc.

---

### Real-Life Use Case:
You are a network administrator trying to identify which processes are using specific ports or if there's any unauthorized activity on your server. Using `netstat` or `ss` allows you to check for open ports, active connections, and monitor any unusual or unexpected behavior. For example, if you're seeing high bandwidth usage, you could use `iftop` to see which processes or connections are consuming the most network resources.

### Additional Notes:
- **Monitoring with `netstat` or `ss`**: Both commands are useful for identifying issues like service failures due to port conflicts, unauthorized connections, or even security issues (e.g., unexpected services running on open ports).
- **Real-Time Monitoring**: For real-time bandwidth and traffic monitoring, use tools like `iftop` or `nload`.
- **Firewall Configuration**: If you notice unnecessary open ports, consider securing them with a firewall (e.g., using `ufw` or `iptables`).

These tools help in monitoring network performance, debugging network issues, and ensuring system security.

