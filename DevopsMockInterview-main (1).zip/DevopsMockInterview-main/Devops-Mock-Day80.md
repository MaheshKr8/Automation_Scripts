
---

### **1. Resource Re-creation**

#### **Question**: You want to force the re-creation of a specific resource, but you don’t want to delete and manually reapply it. How would you achieve this in Terraform?

#### **Answer**:
To force re-creation:
1. Use the `terraform taint` command:
   ```bash
   terraform taint aws_instance.web
   ```
   This marks the resource for re-creation during the next `terraform apply`.

2. Run `terraform apply` to destroy and recreate the resource:
   ```bash
   terraform apply
   ```

#### **Example**:
For an EC2 instance:
```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  tags = {
    Name = "RecreatedInstance"
  }
}
```

---

### **2. Managing Multiple Cloud Providers**

#### **Question**: How would you manage infrastructure across multiple cloud providers (e.g., AWS and Azure) using Terraform?

#### **Answer**:
1. Define multiple provider blocks:
   ```hcl
   provider "aws" {
     region = "us-east-1"
   }

   provider "azurerm" {
     features = {}
   }
   ```

2. Use resource blocks for each provider:
   ```hcl
   resource "aws_instance" "web" {
     ami           = "ami-0c55b159cbfafe1f0"
     instance_type = "t2.micro"
   }

   resource "azurerm_resource_group" "example" {
     name     = "example-resource-group"
     location = "East US"
   }
   ```

---

### **3. Outdated Provider Versions**

#### **Question**: While initializing Terraform, you receive an error about using an outdated provider version. How do you resolve this?

#### **Answer**:
1. Update the provider version in `required_providers`:
   ```hcl
   terraform {
     required_providers {
       aws = {
         source  = "hashicorp/aws"
         version = ">= 3.0"
       }
     }
   }
   ```

2. Reinitialize Terraform:
   ```bash
   terraform init -upgrade
   ```

3. Test the changes in a dev environment.

---

### **4. Zero Downtime Deployment**

#### **Question**: How would you achieve zero downtime when deploying updates to a web application using Terraform?

#### **Answer**:
- Use **blue-green deployment**:
  - Deploy new resources (e.g., EC2 instances).
  - Update the load balancer's target group to point to the new instances.
  - Destroy the old resources after the new ones are validated.

#### **Example**:
Using Terraform to update an ALB:
```hcl
resource "aws_lb_target_group" "blue" {
  name     = "blue-target-group"
  protocol = "HTTP"
  port     = 80
  vpc_id   = aws_vpc.main.id
}
```

---

### **5. Debugging Terraform Execution**

#### **Question**: Terraform is throwing errors, but the logs are not providing enough information. How would you debug the issue?

#### **Answer**:
1. Enable debug logs:
   ```bash
   export TF_LOG=DEBUG
   terraform apply
   ```

2. Redirect logs to a file:
   ```bash
   terraform apply 2> debug.log
   ```

3. Review the logs for errors.

---

### **6. Infrastructure Cost Optimization**

#### **Question**: Your organization asks you to optimize infrastructure costs. How would you use Terraform to achieve this?

#### **Answer**:
- Use smaller instance types for non-critical workloads:
  ```hcl
  variable "instance_type" {
    default = "t3.micro"
  }
  ```
- Remove unused resources by reviewing `terraform plan`.
- Use spot instances where appropriate.

---

### **7. Preventing Resource Deletion**

#### **Question**: You need to ensure that a critical resource (e.g., a database) is not accidentally deleted. How would you implement this in Terraform?

#### **Answer**:
- Use the `prevent_destroy` lifecycle setting:
  ```hcl
  resource "aws_rds_instance" "db" {
    lifecycle {
      prevent_destroy = true
    }
  }
  ```

---

### **8. Shared State Management Across Teams**

#### **Question**: How would you share Terraform state between team members while ensuring it’s secure?

#### **Answer**:
- Use a remote backend like S3 with DynamoDB locking:
  ```hcl
  terraform {
    backend "s3" {
      bucket         = "my-terraform-state"
      key            = "state/terraform.tfstate"
      region         = "us-east-1"
      dynamodb_table = "terraform-lock"
    }
  }
  ```

---

### **9. Dynamic Resource Creation**

#### **Question**: You need to create a dynamic number of resources (e.g., subnets) based on input. How would you handle this?

#### **Answer**:
- Use the `for_each` argument:
  ```hcl
  variable "subnet_cidrs" {
    default = ["10.0.1.0/24", "10.0.2.0/24"]
  }

  resource "aws_subnet" "subnet" {
    for_each = toset(var.subnet_cidrs)
    cidr_block = each.value
    vpc_id     = aws_vpc.main.id
  }
  ```

---

### **10. Remote State Migration**

#### **Question**: Your Terraform state file is currently local, but you want to migrate it to an S3 backend. How would you do this?

#### **Answer**:
1. Configure the S3 backend:
   ```hcl
   terraform {
     backend "s3" {
       bucket = "my-terraform-state"
       key    = "state/terraform.tfstate"
       region = "us-east-1"
     }
   }
   ```

2. Run `terraform init` and follow the prompts to migrate the state file.

---

### **11. Handling Terraform Drift in CI/CD Pipelines**

#### **Question**: How would you integrate Terraform into a CI/CD pipeline to automatically detect and fix drift?

#### **Answer**:
- Add a step to run `terraform plan` in the pipeline:
  ```yaml
  - name: Detect Terraform Drift
    run: terraform plan
  ```

---

### **12. Handling Conditional Resource Creation**

#### **Question**: You need to create a resource only if a specific condition is met. How would you handle this?

#### **Answer**:
- Use the `count` argument with a condition:
  ```hcl
  resource "aws_instance" "web" {
    count         = var.create_instance ? 1 : 0
    instance_type = "t2.micro"
    ami           = "ami-0c55b159cbfafe1f0"
  }
  ```

---

### **13. Terraform Code Reusability**

#### **Question**: How would you make your Terraform code reusable across different teams or projects?

#### **Answer**:
- Use **modules** to encapsulate logic and share reusable code:
  ```hcl
  module "vpc" {
    source = "./modules/vpc"
  }
  ```

---

### **14. Using External Data**

#### **Question**: How would you use data from an external source (e.g., a script or API) in your Terraform configuration?

#### **Answer**:
- Use the `external` data source:
  ```hcl
  data "external" "example" {
    program = ["python3", "script.py"]
  }
  ```

---

### **15. Troubleshooting Plan Differences**

#### **Question**: Terraform’s `plan` output shows changes for resources you didn’t modify. How do you troubleshoot this?

#### **Answer**:
- Check for manual changes or drift.
- Use `terraform refresh` to update the state file.
- Ensure variables and attributes are consistent across configurations.

---
