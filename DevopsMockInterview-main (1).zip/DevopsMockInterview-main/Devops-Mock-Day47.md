
1. **What is Ansible, and how does it work?**
   - **Answer**: Ansible is an open-source configuration management, provisioning, and application deployment tool. It uses SSH for communication and executes tasks based on playbooks written in YAML.
   - **Example**: Installing software packages, configuring services, and restarting services.

2. **What is an Ansible Playbook?**
   - **Answer**: A playbook is a YAML file that contains a series of tasks for Ansible to execute on a host.
   - **Script Example**:
     ```yaml
     - hosts: webservers
       tasks:
         - name: Install NGINX
           apt:
             name: nginx
             state: present
     ```

3. **How do you create an inventory file in Ansible?**
   - **Answer**: Inventory files list the hosts where the tasks are to be executed. They can be static or dynamic.
   - **Script Example**:
     ```
     [webservers]
     192.168.1.1
     192.168.1.2
     ```

4. **How do you run a playbook?**
   - **Answer**: Use the command `ansible-playbook <playbook.yml>`.

5. **What are handlers in Ansible?**
   - **Answer**: Handlers are triggered at the end of a task to restart or notify a service if a task changes the system state.
   - **Example**: Restarting Nginx after installation.

6. **How do you use variables in Ansible?**
   - **Answer**: Variables are defined in playbooks or inventory files and can be used to store reusable values.
   - **Script Example**:
     ```yaml
     - hosts: web
       vars:
         nginx_version: "1.18"
       tasks:
         - name: Install NGINX
           apt:
             name: "nginx={{ nginx_version }}"
             state: present
     ```

7. **What are roles in Ansible?**
   - **Answer**: Roles are a way to group related tasks, variables, files, templates, and handlers into reusable components.
   - **Script Example**:
     ```
     ansible-galaxy init my_role
     ```

8. **Explain how Ansible Vault works.**
   - **Answer**: Ansible Vault encrypts sensitive data like passwords and secret keys.
   - **Script Example**:
     ```
     ansible-vault create secret.yml
     ```

9. **How do you handle idempotency in Ansible?**
   - **Answer**: Idempotency ensures that running a task multiple times doesn’t change the system state after the first run.

10. **How do you check syntax in an Ansible playbook?**
    - **Answer**: Run `ansible-playbook --syntax-check <playbook.yml>`.



11. **Explain the difference between `when` and `register`.**
    - **Answer**: `when` applies conditions to tasks; `register` stores the result of a command for later use.

12. **How would you use `ansible-pull`?**
    - **Answer**: `ansible-pull` allows nodes to pull configurations from a central repository.
    - **Script Example**:
      ```
      ansible-pull -U https://github.com/yourrepo.git
      ```

13. **What is `ansible-galaxy`?**
    - **Answer**: `ansible-galaxy` is a tool for downloading and sharing pre-built roles.

14. **What’s the purpose of the `become` directive in Ansible?**
    - **Answer**: It allows privilege escalation for tasks that require root access.
    - **Example**:
      ```yaml
      tasks:
        - name: Install NGINX
          become: yes
          apt:
            name: nginx
            state: present
      ```

15. **How do you use loops in Ansible?**
    - **Answer**: Ansible loops allow you to repeat tasks with different items.
    - **Script Example**:
      ```yaml
      tasks:
        - name: Install multiple packages
          apt:
            name: "{{ item }}"
            state: present
          loop:
            - nginx
            - git
            - curl
      ```
