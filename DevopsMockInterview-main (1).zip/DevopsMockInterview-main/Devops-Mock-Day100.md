
---

## **1. How do you handle circular dependencies in Terraform?**
### **Solution:**
Terraform automatically detects dependencies, but for edge cases:
- Use `depends_on`:
  ```hcl
  resource "aws_instance" "web" {
    depends_on = [aws_security_group.allow_ssh]
  }
  ```
- Avoid referencing a resource inside its own configuration.

---

## **2. How do you create an auto-scaling group with Terraform?**
### **Solution:**
- Use `aws_autoscaling_group`:
  ```hcl
  resource "aws_autoscaling_group" "web" {
    launch_configuration = aws_launch_configuration.web.name
    min_size             = 2
    max_size             = 5
  }
  ```

---

## **3. How do you handle resource drift if someone manually changes infrastructure outside Terraform?**
### **Solution:**
- Run:
  ```bash
  terraform plan
  ```
- Use **`terraform refresh`** to update the state.
- Reapply:
  ```bash
  terraform apply
  ```

---

## **4. How do you roll back a failed Terraform deployment?**
### **Solution:**
1. Restore from previous Git commit:
   ```bash
   git checkout previous_version
   terraform apply
   ```
2. If state is corrupted, manually restore:
   ```bash
   terraform state push backup.tfstate
   ```

---

## **5. How do you create and attach an IAM policy to an AWS user dynamically?**
### **Solution:**
```hcl
resource "aws_iam_policy" "example" {
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action   = "s3:ListBucket"
      Effect   = "Allow"
      Resource = "arn:aws:s3:::example-bucket"
    }]
  })
}

resource "aws_iam_user_policy_attachment" "attach" {
  user       = aws_iam_user.example.name
  policy_arn = aws_iam_policy.example.arn
}
```

---

## **6. How do you ensure Terraform only creates a resource if a specific condition is met?**
### **Solution:**
- Use `count` or `for_each`:
  ```hcl
  resource "aws_instance" "web" {
    count = var.enable_instance ? 1 : 0
  }
  ```

---

## **7. How do you use Terraform to manage Kubernetes resources?**
### **Solution:**
- Use the **Kubernetes provider**:
  ```hcl
  provider "kubernetes" {
    config_path = "~/.kube/config"
  }

  resource "kubernetes_deployment" "nginx" {
    metadata {
      name = "nginx"
    }
    spec {
      replicas = 3
    }
  }
  ```

---

## **8. How do you pass outputs from one Terraform module to another?**
### **Solution:**
1. **Inside module**:
   ```hcl
   output "vpc_id" {
     value = aws_vpc.main.id
   }
   ```
2. **Use it in another module**:
   ```hcl
   module "network" {
     source = "./network"
   }

   resource "aws_instance" "web" {
     vpc_id = module.network.vpc_id
   }
   ```

---

## **9. How do you restrict Terraform execution to a specific AWS region?**
### **Solution:**
```hcl
provider "aws" {
  region = var.allowed_region
}

variable "allowed_region" {
  default = "us-east-1"
  validation {
    condition     = contains(["us-east-1", "us-west-2"], var.allowed_region)
    error_message = "Invalid AWS region"
  }
}
```

---

## **10. How do you handle Terraform state file locking in a CI/CD pipeline?**
### **Solution:**
- Use **S3 with DynamoDB** for state locking.
- In Jenkins/GitHub Actions, use:
  ```bash
  terraform init
  terraform plan
  terraform apply -auto-approve
  ```

---

## **11. How do you import an existing AWS resource into Terraform?**
### **Solution:**
1. Run:
   ```bash
   terraform import aws_instance.example i-1234567890abcdef0
   ```
2. Update the Terraform file manually.

---

## **12. How do you handle Terraform provider versioning?**
### **Solution:**
```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}
```

---

## **13. How do you automatically clean up resources that are no longer needed?**
### **Solution:**
- Use `terraform destroy`:
  ```bash
  terraform destroy -auto-approve
  ```
- For auto-deletion:
  ```hcl
  lifecycle {
    create_before_destroy = true
  }
  ```

---

## **14. How do you deploy a Terraform project across multiple AWS accounts?**
### **Solution:**
- Use different provider blocks:
  ```hcl
  provider "aws" {
    alias  = "dev"
    region = "us-east-1"
  }

  provider "aws" {
    alias  = "prod"
    region = "us-west-2"
  }
  ```

---

## **15. How do you handle dependencies between modules?**
### **Solution:**
- Use outputs from one module in another:
  ```hcl
  output "vpc_id" {
    value = aws_vpc.main.id
  }
  ```

---

## **16. How do you execute only a specific resource in Terraform?**
### **Solution:**
```bash
terraform apply -target=aws_instance.example
```

---

## **17. How do you ensure Terraform always applies a specific sequence of resources?**
### **Solution:**
- Use `depends_on`:
  ```hcl
  resource "aws_instance" "web" {
    depends_on = [aws_s3_bucket.example]
  }
  ```

---

## **18. How do you rotate secrets in Terraform?**
### **Solution:**
1. Store secrets in **AWS Secrets Manager**.
2. Rotate them using Terraform + Lambda function.

---

## **19. How do you deploy a Terraform project across multiple cloud providers?**
### **Solution:**
- Use multiple providers:
  ```hcl
  provider "aws" {
    region = "us-east-1"
  }

  provider "google" {
    project = "my-gcp-project"
  }
  ```

---

## **20. How do you dynamically create different types of resources based on user input?**
### **Solution:**
- Use `for_each`:
  ```hcl
  variable "instances" {
    type = map(string)
    default = {
      "web"  = "t2.micro"
      "db"   = "t3.micro"
    }
  }

  resource "aws_instance" "example" {
    for_each      = var.instances
    instance_type = each.value
  }
  ```

---
