### **Linux Real-Time Scenario-Based Interview Questions for DevOps Engineers**

Here are **20 real-time Linux scenario-based interview questions** with solutions and real-world explanations. These cover system troubleshooting, process management, networking, automation, and security, all crucial for a **DevOps Engineer**.

---

### **1. A critical production server is running slow. How do you identify the issue?**
**Solution:**
1. Check CPU usage:
   ```bash
   top
   ```
2. Check memory usage:
   ```bash
   free -m
   ```
3. Check disk usage:
   ```bash
   df -h
   ```
4. Check I/O wait (disk bottleneck):
   ```bash
   iostat -x 1 5
   ```
5. Check if any process is consuming excessive resources:
   ```bash
   ps aux --sort=-%cpu | head -5
   ```

**Real-World Use Case:**  
Your application suddenly slows down, impacting users. You must quickly diagnose the problem (CPU, memory, disk I/O) before applying fixes.

---

### **2. A process is unresponsive but must not be abruptly killed. How do you handle it?**
**Solution:**
1. First, try a graceful stop:
   ```bash
   kill PID
   ```
2. If the process doesn’t stop, send a termination signal:
   ```bash
   kill -15 PID
   ```
3. If it's still running, force kill it:
   ```bash
   kill -9 PID
   ```

**Real-World Use Case:**  
If a database or application server is hung, a **graceful stop** prevents data corruption, unlike an abrupt kill.

---

### **3. You need to find and delete files larger than 5GB in `/var/log`. How would you do it?**
**Solution:**
```bash
find /var/log -type f -size +5G -exec rm -f {} \;
```

**Real-World Use Case:**  
Log files consuming excessive disk space can cause application crashes. Automating cleanup prevents downtime.

---

### **4. A developer says their app can't connect to the database. How do you debug?**
**Solution:**
1. Check if the database is running:
   ```bash
   systemctl status mysql  # or postgresql, etc.
   ```
2. Check if the port is open:
   ```bash
   netstat -tulnp | grep 3306
   ```
3. Check firewall rules:
   ```bash
   sudo ufw status
   ```
4. Verify DB connectivity:
   ```bash
   mysql -h database_host -u user -p
   ```

**Real-World Use Case:**  
Network, firewall, or database failures can prevent app connectivity. This approach pinpoints the cause.

---

### **5. You must automatically restart a crashed service. How would you do it?**
**Solution:**
Using **systemd**, enable automatic restart:
```bash
sudo systemctl edit myservice
```
Add:
```
[Service]
Restart=always
RestartSec=5
```
Apply changes:
```bash
sudo systemctl daemon-reload
sudo systemctl restart myservice
```

**Real-World Use Case:**  
If an application crashes (e.g., **Nginx, Tomcat, or PostgreSQL**), this ensures it restarts automatically.

---

### **6. A script needs to run every day at 2 AM. How do you set it up?**
**Solution:**
Edit cron jobs:
```bash
crontab -e
```
Add:
```bash
0 2 * * * /path/to/script.sh
```

**Real-World Use Case:**  
Useful for **backups, log rotations, or automated reporting** in production.

---

### **7. You need to find which process is using port 8080. What command do you use?**
**Solution:**
```bash
sudo netstat -tulnp | grep 8080
```
or
```bash
sudo lsof -i :8080
```

**Real-World Use Case:**  
Commonly used when debugging **Nginx, Apache, or Tomcat** conflicts.

---

### **8. How do you check which user executed a specific command on the server?**
**Solution:**
Check shell history:
```bash
cat ~/.bash_history
```
For global auditing, use:
```bash
sudo cat /var/log/auth.log | grep 'sudo'
```

**Real-World Use Case:**  
Helpful when troubleshooting **unauthorized changes** in production.

---

### **9. A Linux server reboots unexpectedly. How do you find the cause?**
**Solution:**
1. Check the last reboot:
   ```bash
   last reboot
   ```
2. Analyze system logs:
   ```bash
   sudo journalctl -b -1
   ```
3. Check kernel logs:
   ```bash
   dmesg | tail -50
   ```

**Real-World Use Case:**  
Diagnoses **hardware failures, kernel panics, or power outages**.

---

### **10. How do you block a specific IP from accessing the server?**
**Solution:**
```bash
sudo iptables -A INPUT -s <IP> -j DROP
```

**Real-World Use Case:**  
Prevents **DDoS attacks, brute-force login attempts, or malicious traffic**.

---

### **11. You need to sync files between two servers securely. How do you do it?**
**Solution:**
```bash
rsync -avz -e ssh /source/dir/ user@destination:/target/dir/
```

**Real-World Use Case:**  
Used for **backups, deployments, and failover servers**.

---

### **12. A user accidentally deleted a critical file. Can you recover it?**
**Solution:**
Check if it's open in memory:
```bash
lsof | grep deleted
```
If using ext3/ext4, try:
```bash
extundelete /dev/sdX --restore-all
```

**Real-World Use Case:**  
Accidental file deletion is common. Quick recovery prevents outages.

---

### **13. You need to find all files modified in the last 24 hours. How?**
**Solution:**
```bash
find /path/to/dir -type f -mtime -1
```

**Real-World Use Case:**  
Used for **troubleshooting recent deployments or configuration changes**.

---

### **14. A developer reports that a container isn't starting. How do you debug?**
**Solution:**
1. Check container logs:
   ```bash
   docker logs container_id
   ```
2. Check container status:
   ```bash
   docker ps -a
   ```
3. Inspect why it failed:
   ```bash
   docker inspect container_id
   ```

**Real-World Use Case:**  
Critical for managing **Dockerized microservices**.

---

### **15. You need to add 50 users to a server quickly. How would you do it?**
**Solution:**
```bash
for i in {1..50}; do sudo useradd user$i; done
```

**Real-World Use Case:**  
Used in **onboarding teams or scaling infrastructure**.

---

### **16. How do you check the last login of all users?**
**Solution:**
```bash
lastlog
```

---

### **17. How do you see which users are currently logged in?**
**Solution:**
```bash
who
w
```

---

### **18. How do you find the 5 largest files on the system?**
**Solution:**
```bash
du -ah / | sort -rh | head -5
```

---

### **19. You need to monitor a log file in real-time. How?**
**Solution:**
```bash
tail -f /var/log/syslog
```

---

### **20. How do you check which services failed to start at boot?**
**Solution:**
```bash
systemctl --failed
```

---
