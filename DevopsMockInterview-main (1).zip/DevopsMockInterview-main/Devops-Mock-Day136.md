
---

### ✅ **1. Explain how you’d implement end-to-end CI/CD for a microservices architecture.**

**Answer:**

* Use GitHub for version control → Jenkins/GitLab CI for CI/CD → Docker for packaging → Kubernetes for orchestration.
* Each microservice has its own pipeline (lint → test → build → scan → deploy).
* Use Helm charts for deployment and ArgoCD for GitOps-based delivery.
* Trivy/SonarQube integrated for code and image quality.

---

### ✅ **2. How do you handle Terraform drift in a multi-team environment?**

**Answer:**

* Use remote backend with state locking (S3 + DynamoDB).
* Regularly run `terraform plan` in CI to detect drift.
* Use `terraform import` or `terraform state` to correct issues.
* Limit manual changes; enforce Infra-as-Code practices via PR reviews.

---

### ✅ **3. What’s your strategy for high availability and disaster recovery in Kubernetes?**

**Answer:**

* Use multiple master nodes (HA control plane).
* Distribute workloads across availability zones.
* Backup etcd using Velero or snapshot automation.
* Replicate persistent volumes using storage classes that support replication (like EBS, Ceph).

---

### ✅ **4. How do you manage blue/green or canary deployments in production Kubernetes?**

**Answer:**

* **Blue/Green**: Deploy a new version to a separate namespace or replica set → switch traffic using Ingress.
* **Canary**: Route partial traffic using Istio/NGINX with weight-based routing → analyze metrics → promote or rollback.

---

### ✅ **5. How would you secure a Kubernetes cluster from both internal and external threats?**

**Answer:**

* Use RBAC with least privilege.
* Enable audit logging.
* Isolate namespaces with NetworkPolicies.
* Secure API Server via OIDC or mTLS.
* Image scanning, pod security policies (or PodSecurity admission), and runtime protection via tools like Falco.

---

### ✅ **6. How do you ensure traceability and auditability across your DevOps pipelines?**

**Answer:**

* Version control all infra and app code.
* Use audit logs (GitHub, Jenkins, Terraform, AWS CloudTrail).
* Tag artifacts and deployments with Git commit SHA.
* Use metadata in build systems to trace every change.

---

### ✅ **7. What are common pitfalls when using Docker in production and how do you avoid them?**

**Answer:**

* Not setting resource limits (fix with `--memory`, `--cpus` or K8s resource limits).
* Running containers as root (use non-root USER in Dockerfile).
* Large images (optimize with multi-stage builds and minimal base images).
* Unmanaged logs (route logs to ELK, Fluentd, or sidecar).

---

### ✅ **8. How do you implement zero-downtime deployments in Jenkins + Kubernetes setup?**

**Answer:**

* Use rolling updates with `readinessProbes` in Deployment.
* Keep old pods until new ones are ready.
* Use health checks in pipeline before `kubectl apply`.
* Canary new version to a subset of users.

---

### ✅ **9. Explain how GitOps improves deployment workflows.**

**Answer:**

* All deployments are managed from Git repo → acts as a single source of truth.
* Tools like ArgoCD or FluxCD sync manifests from Git to cluster.
* Enables version-controlled, auditable, and auto-healing deployments.

---

### ✅ **10. Your application is leaking memory in production. What’s your approach?**

**Answer:**

* Monitor memory usage using Prometheus + Grafana.
* Set memory limits to trigger OOMKill and get logs.
* Use `kubectl exec` with `top`, `heapdump`, or APM tools (Datadog/New Relic) for analysis.
* Reproduce and profile locally using tools like `jmap`, `valgrind`, etc.

---

### ✅ **11. How do you scale Jenkins for a large development team?**

**Answer:**

* Use **Jenkins Master-Agent architecture**.
* Offload builds to **Docker/Kubernetes-based dynamic agents**.
* Configure **resource quotas** and use **shared libraries** to avoid duplication.
* Use separate Jenkins controllers per team if scale requires it.

---

### ✅ **12. How do you design a secure and auditable CI/CD pipeline?**

**Answer:**

* Store secrets in Vault, AWS Secrets Manager, or Jenkins credentials plugin.
* Sign artifacts and verify integrity before deploy.
* Require PR review, linting, and static analysis.
* Maintain CI/CD audit logs and restrict access by RBAC.

---

### ✅ **13. What is your approach to integrating infrastructure testing into CI/CD?**

**Answer:**

* Use **Terraform validate**, **tflint**, **checkov** in pre-plan stage.
* Use **kubeval**, **kube-score**, or **conftest** for Kubernetes manifests.
* Use integration tests post-deployment in staging.

---

### ✅ **14. How do you optimize cost in a large Kubernetes cluster?**

**Answer:**

* Use **Cluster Autoscaler** to scale down unused nodes.
* Enforce requests/limits to avoid overprovisioning.
* Use **spot/preemptible** instances with fallback.
* Auto-delete unused volumes and images.

---

### ✅ **15. How do you detect and prevent secret leaks in Git repositories and CI?**

**Answer:**

* Use **Gitleaks**, **TruffleHog**, or **GitGuardian** in CI.
* Use GitHub secret scanning.
* Enforce pre-commit hooks to reject secrets locally.
* Rotate secrets immediately if leaks are found.

---

### ✅ **16. Describe how you handle rollback in CI/CD pipelines.**

**Answer:**

* Maintain versioned artifacts in S3 or Nexus.
* Roll back by re-deploying previous artifact via Jenkins or ArgoCD.
* Keep `kubectl rollout undo` or Helm rollback handy.
* Test rollback process in staging.

---

### ✅ **17. How do you implement and enforce policies in your cloud infrastructure?**

**Answer:**

* Use **OPA (Open Policy Agent)** with Terraform or Kubernetes.
* AWS: Use **Service Control Policies (SCPs)** and IAM Policies.
* Run `checkov`/`tfsec` scans in CI pipelines.
* Use drift detection alerts.

---

### ✅ **18. How do you reduce MTTR (Mean Time to Recovery) in production failures?**

**Answer:**

* Use **centralized logging** and **metrics dashboards**.
* Alert on symptom, not just outage.
* Automate rollbacks or failover.
* Run **postmortems** and update playbooks after every incident.

---

### ✅ **19. What is the difference between `stateful` and `stateless` services? How does this affect DevOps strategy?**

**Answer:**

* **Stateless**: Easier to scale, no persistent data, ideal for containers.
* **Stateful**: Requires persistent volume and data recovery strategy.
* Use StatefulSets and backup strategies for stateful apps.
* Treat infra (DBs, PVs) differently from app deployments.

---

### ✅ **20. How would you implement security gates in your CI/CD process?**

**Answer:**

* Enforce branch protections and signed commits.
* Integrate tools like SonarQube, Trivy, and Checkov.
* Fail pipeline on CVEs, low code coverage, or policy violations.
* Require manual approvals for high-risk environments.

---

