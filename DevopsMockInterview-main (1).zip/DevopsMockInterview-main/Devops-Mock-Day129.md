

---

### ✅ **1. What is the difference between continuous integration, continuous delivery, and continuous deployment?**

**Answer:**

* **CI**: Automates code integration and testing.
* **CD (Delivery)**: Automates packaging and readiness for deployment (manual approval).
* **CD (Deployment)**: Fully automated deployment to production.

---

### ✅ **2. What are some common challenges in CI/CD pipelines and how do you handle them?**

**Answer:**

* Flaky tests → Add retries or stabilize tests.
* Long build time → Cache dependencies, parallel builds.
* Security issues → Use scanners like Trivy, Snyk.
* Broken builds → Use pre-merge checks and approvals.

---

### ✅ **3. What’s the difference between Docker Swarm and Kubernetes?**

**Answer:**

* **Docker Swarm**: Simple, easy to set up, native to Docker.
* **Kubernetes**: Feature-rich, supports complex deployments, widely adopted in production.

---

### ✅ **4. How do you implement infrastructure as code (IaC) in your projects?**

**Answer:**

* Use **Terraform** or **CloudFormation** for provisioning.
* Version control IaC.
* Use modules, variables, and remote state for reusability and scalability.

---

### ✅ **5. How would you handle a security breach in a CI/CD pipeline?**

**Answer:**

* Revoke credentials/secrets.
* Audit logs.
* Rotate keys and reset tokens.
* Run security scans and patch vulnerable images.

---

### ✅ **6. Explain the difference between Ansible and Terraform.**

**Answer:**

* **Terraform**: Declarative, used for provisioning infra.
* **Ansible**: Procedural, used for configuration management.
* Use **Terraform first**, then Ansible for config.

---

### ✅ **7. What is Blue-Green deployment and why is it useful?**

**Answer:**

* Two environments: blue (old), green (new).
* Switch traffic from blue → green post-validation.
* Enables rollback and zero-downtime deployments.

---

### ✅ **8. What is Immutable Infrastructure?**

**Answer:**

* Servers are **not updated**, they're **replaced** with new versions.
* Ensures consistency, avoids drift.
* Tools: Terraform, Packer, Docker.

---

### ✅ **9. How do you implement RBAC in Kubernetes?**

**Answer:**

* Create `Role`/`ClusterRole`, `RoleBinding`/`ClusterRoleBinding`.

```yaml
kind: Role
rules:
- apiGroups: [""]
  resources: ["pods"]
  verbs: ["get", "list"]
```

---

### ✅ **10. How do you debug a stuck Jenkins job?**

**Answer:**

* Check console logs.
* Enable verbose `sh` output.
* Kill zombie jobs with `ps` or `kill`.
* Clear workspace if corrupted.

---

### ✅ **11. How do you handle drift detection in Terraform?**

**Answer:**

* Run `terraform plan` regularly.
* Use CI/CD to compare state with reality.
* Enforce policies using Sentinel or OPA.

---

### ✅ **12. What are readiness and liveness probes in Kubernetes?**

**Answer:**

* **Liveness**: Restarts container if it's unhealthy.
* **Readiness**: Ensures traffic is routed only when ready.
* Prevents serving broken apps to users.

---

### ✅ **13. How do you monitor deployments in production?**

**Answer:**

* Use tools like **Prometheus, Grafana, ELK, New Relic**.
* Monitor:

  * Latency, Errors, Traffic, Saturation (Google's 4 golden signals).
  * Application logs and metrics.

---

### ✅ **14. How would you migrate an app from on-prem to AWS?**

**Answer:**

* Assess & plan infra.
* Recreate using Terraform.
* Use VPN or DirectConnect.
* Transfer data via S3, RDS, or Snowball.
* Use Route 53 for DNS cutover.

---

### ✅ **15. How do you secure your Kubernetes cluster?**

**Answer:**

* RBAC and NetworkPolicies.
* Turn off unused services.
* Scan images for vulnerabilities.
* Restrict access to kube-apiserver.

---

### ✅ **16. Explain a situation where a deployment broke production and how you handled it.**

**Answer (Example):**

* Bad Helm config led to 500 errors.
* Rolled back Helm release.
* Patched values.yaml.
* Added pre-deployment checks and smoke tests to prevent recurrence.

---

### ✅ **17. How would you handle config differences between environments (dev, staging, prod)?**

**Answer:**

* Use environment-specific `.tfvars`, `values.yaml`, or secrets.
* Separate namespaces or accounts.
* CI/CD uses the right config per env.

---

### ✅ **18. What’s the purpose of using a service mesh like Istio?**

**Answer:**

* Manages traffic, observability, security at service-to-service level.
* Features: mTLS, retries, A/B testing, traffic shifting.

---

### ✅ **19. How do you manage multi-cloud environments?**

**Answer:**

* Use tools like Terraform with provider blocks.
* Use abstracted monitoring/logging tools (e.g., Datadog, Prometheus).
* Ensure identity management is unified (e.g., via Okta, IAM federation).

---

### ✅ **20. What is the role of GitOps in modern DevOps?**

**Answer:**

* Use Git as the single source of truth.
* Tools like **Argo CD** or **Flux** sync changes automatically from Git → cluster.
* Ensures auditability, rollback, and control.

---

