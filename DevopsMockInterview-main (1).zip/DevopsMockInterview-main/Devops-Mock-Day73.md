  
### **1. Explain the Role of `docker-compose` in Microservices Architecture**  

#### **Answer**:  
`docker-compose` simplifies the deployment and management of multi-container applications in microservices architecture by using a YAML configuration file. It enables:  
1. **Service Definition**: Each microservice is defined as a service in the YAML file, including its dependencies.  
2. **Networking**: Automatically creates a shared network for communication between services.  
3. **Portability**: Ensures consistent multi-container setups across environments.  

#### **Example**: Deploying a microservice architecture with an API, database, and frontend:  
```yaml
version: '3.8'
services:
  api:
    image: myapi:latest
    ports:
      - "5000:5000"
    depends_on:
      - db
  db:
    image: postgres:latest
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
  frontend:
    image: myfrontend:latest
    ports:
      - "3000:3000"
    depends_on:
      - api
```

**Command**:  
```bash
docker-compose up
```

---

### **2. What Is the Difference Between `docker stack` and `docker-compose`?**

#### **Answer**:  

| **Aspect**            | **`docker stack`**                     | **`docker-compose`**               |
|------------------------|----------------------------------------|-------------------------------------|
| **Purpose**            | Orchestrates services in Swarm mode.   | Manages local multi-container apps. |
| **Environment**        | Requires Docker Swarm.                | Works on a standalone Docker host. |
| **Scaling**            | Supports dynamic scaling of services. | Limited to scaling on a single host. |
| **Command Example**    | `docker stack deploy -c stack.yml app` | `docker-compose up`                |
| **Use Case**           | Production deployment.                | Local development and testing.     |

---

### **3. How Do You Set Up Docker for a CI/CD Pipeline?**

#### **Answer**:  
1. **Install Docker in the CI/CD environment**:  
   Use Docker to build, test, and deploy containers.  

2. **Build Docker Images**:  
   Create images as part of the pipeline.  
   ```bash
   docker build -t myapp:ci .
   ```

3. **Run Unit Tests Inside Containers**:  
   ```bash
   docker run --rm myapp:ci pytest tests/
   ```

4. **Push Images to a Registry**:  
   ```bash
   docker tag myapp:ci myregistry/myapp:ci
   docker push myregistry/myapp:ci
   ```

5. **Deploy Images**:  
   Use Docker Compose or Docker Swarm in the pipeline for deployment.

#### **Real-World Example with Jenkins**:  
A Jenkins pipeline for Dockerized app:  
```groovy
pipeline {
    agent any
    stages {
        stage('Build') {
            steps {
                sh 'docker build -t myapp:latest .'
            }
        }
        stage('Test') {
            steps {
                sh 'docker run --rm myapp:latest pytest tests/'
            }
        }
        stage('Deploy') {
            steps {
                sh 'docker-compose up -d'
            }
        }
    }
}
```

---

### **4. Explain `docker inspect` and Its Use Cases**

#### **Answer**:  
`docker inspect` retrieves detailed information about Docker objects such as containers, images, or networks in JSON format.  

#### **Example**: Inspect a running container:  
```bash
docker inspect <container_id>
```

#### **Use Cases**:  
1. Check container environment variables.  
2. Inspect network configurations.  
3. Debug issues by checking the container state.  

**Example Output**:  
```json
"NetworkSettings": {
    "IPAddress": "172.17.0.2",
    "Ports": {
        "80/tcp": [
            {
                "HostIp": "0.0.0.0",
                "HostPort": "8080"
            }
        ]
    }
}
```

---

### **5. How Do You Configure Auto-Restart Policies for Containers?**

#### **Answer**:  
Use the `--restart` option in `docker run` or in a Docker Compose file to specify restart policies.  

#### **Options**:  
- **no**: Do not restart.  
- **on-failure**: Restart only on non-zero exit codes.  
- **always**: Restart always.  
- **unless-stopped**: Restart unless manually stopped.

#### **Example**:  
```bash
docker run --restart=always nginx
```

**Docker Compose Example**:  
```yaml
version: '3.8'
services:
  web:
    image: nginx
    restart: always
```

---

### **6. How Do You Monitor Docker Containers in Real-Time?**

#### **Answer**:  
1. **Resource Monitoring with `docker stats`**:  
   ```bash
   docker stats
   ```
   Displays real-time CPU, memory, network, and I/O stats.

2. **Logging with `docker logs`**:  
   ```bash
   docker logs -f <container_id>
   ```

3. **Third-Party Tools**:  
   Use tools like **Prometheus**, **Grafana**, or **ELK Stack** for comprehensive monitoring.

---

### **7. What Is the Role of `HEALTHCHECK` in Dockerfile?**

#### **Answer**:  
`HEALTHCHECK` specifies how Docker determines the health of a container.  

#### **Syntax**:  
```dockerfile
HEALTHCHECK --interval=30s --timeout=5s --retries=3 CMD curl -f http://localhost:8080/health || exit 1
```

- **Parameters**:
  - `interval`: Time between health checks.
  - `timeout`: Time before a health check is considered failed.
  - `retries`: Number of retries before marking the container as unhealthy.

---

### **8. How Do You Troubleshoot Docker Networking Issues?**

#### **Answer**:  
1. **Check Network Configuration**:  
   ```bash
   docker network ls
   docker inspect <network_name>
   ```

2. **Ping Between Containers**:  
   ```bash
   docker exec -it <container_id> ping <target_container>
   ```

3. **Test Port Mappings**:  
   Use tools like `curl` or `telnet` to test connections.

4. **Debug with Logs**:  
   ```bash
   docker logs <container_id>
   ```

5. **Restart Docker Network Services**:  
   ```bash
   docker network rm <network_name>
   docker network create <network_name>
   ```

#### **Example Issue**: Containers on a custom network cannot communicate.  
**Solution**: Ensure they are on the same network or troubleshoot firewall rules.  

--- 


### **9. How Do You Deploy a Multi-Container Application Using Docker Compose?**

#### **Answer**:  
Docker Compose enables the deployment of multi-container applications using a single YAML file.  

#### **Steps**:  
1. **Create a `docker-compose.yml` file**:  
   Define services and their configurations.  

   **Example**: Deploying a Node.js app with MongoDB.  
   ```yaml
   version: '3.8'
   services:
     app:
       image: node:latest
       ports:
         - "3000:3000"
       volumes:
         - "./app:/usr/src/app"
       depends_on:
         - db
     db:
       image: mongo:latest
       ports:
         - "27017:27017"
   ```

2. **Deploy the Application**:  
   ```bash
   docker-compose up -d
   ```

3. **Verify Services**:  
   ```bash
   docker-compose ps
   ```

---

### **10. How Do You Scale Containers Using Docker Swarm?**

#### **Answer**:  
Docker Swarm simplifies scaling services across nodes.

#### **Steps**:  
1. **Create a Service**:  
   ```bash
   docker service create --name web --replicas 2 -p 8080:80 nginx
   ```

2. **Scale the Service**:  
   ```bash
   docker service scale web=5
   ```

3. **Verify Scaling**:  
   ```bash
   docker service ps web
   ```

---

### **11. What Is the Process of Migrating Legacy Applications to Docker?**

#### **Answer**:  

1. **Analyze the Application**:  
   Identify dependencies, configurations, and networking requirements.  

2. **Containerize the Application**:  
   - Write a `Dockerfile`.  
   - Use multi-stage builds if necessary to optimize image size.

   **Example**:  
   ```dockerfile
   FROM openjdk:8-jdk-alpine
   COPY app.jar /app.jar
   ENTRYPOINT ["java", "-jar", "/app.jar"]
   ```

3. **Run and Test Locally**:  
   ```bash
   docker build -t legacy-app .
   docker run -p 8080:8080 legacy-app
   ```

4. **Orchestrate Deployment**:  
   Use Docker Compose or Kubernetes to deploy the containerized app.

---

### **12. Explain Zero-Downtime Deployment Using Docker**

#### **Answer**:  
Zero-downtime deployment ensures no service interruptions during application updates.  

#### **Steps**:  
1. **Use a Load Balancer**:  
   Direct traffic to healthy instances only.

2. **Update Services Gradually** (Rolling Updates):  
   - In Docker Swarm:  
     ```bash
     docker service update --image new_image:tag my_service
     ```

   - In Kubernetes:  
     ```yaml
     spec:
       strategy:
         type: RollingUpdate
         rollingUpdate:
           maxUnavailable: 1
           maxSurge: 1
     ```

3. **Monitor Health**:  
   Use health checks to ensure instances are ready before traffic is routed.

---

### **13. How Do You Integrate Docker with Kubernetes?**

#### **Answer**:  
1. **Build and Push Docker Images**:  
   ```bash
   docker build -t myapp:latest .
   docker tag myapp:latest myregistry/myapp:latest
   docker push myregistry/myapp:latest
   ```

2. **Create Kubernetes Deployment Files**:  
   ```yaml
   apiVersion: apps/v1
   kind: Deployment
   metadata:
     name: myapp
   spec:
     replicas: 3
     template:
       spec:
         containers:
         - name: myapp
           image: myregistry/myapp:latest
   ```

3. **Deploy Using kubectl**:  
   ```bash
   kubectl apply -f deployment.yml
   ```

---

### **14. What Are the Challenges of Running Stateful Applications in Docker?**

#### **Answer**:  

1. **Data Persistence**:  
   Containers are ephemeral, so external volumes or persistent storage are needed.

2. **Scaling**:  
   Ensuring consistent data access in a distributed setup can be complex.

3. **Orchestration**:  
   Stateful apps require specialized orchestration (e.g., StatefulSets in Kubernetes).

---

### **15. How Do You Set Up a Private Docker Registry?**

#### **Answer**:  

1. **Run the Docker Registry Image**:  
   ```bash
   docker run -d -p 5000:5000 --name registry registry:2
   ```

2. **Push Images to the Registry**:  
   ```bash
   docker tag myapp:latest localhost:5000/myapp
   docker push localhost:5000/myapp
   ```

3. **Access the Registry**:  
   Use the image: `localhost:5000/myapp`.  

4. **Secure the Registry**:  
   Use HTTPS with a certificate or authentication.

---
