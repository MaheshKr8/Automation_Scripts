Here are **15 Ansible real-time scenario-based interview questions** for a DevOps Engineer:

---

### **1. Ansible Tower vs. Ansible CLI**
**Question:**  
You are managing a large-scale infrastructure and using Ansible. When would you choose Ansible Tower over Ansible CLI? Provide a real-time example.

**Answer:**  
- Use **Ansible Tower** for managing large inventories, scheduling playbooks, RBAC (Role-Based Access Control), and visualizing job runs.  
- Example: In an organization, multiple teams need to run Ansible playbooks. Tower can restrict user access to only specific tasks, schedule periodic runs for compliance, and provide detailed logs.

---

### **2. Handling Variable Precedence**
**Question:**  
A playbook is not picking up variables correctly. How would you debug this issue?  
Explain the order of variable precedence in Ansible with an example.

**Answer:**  
- Debug using `ansible-playbook --extra-vars "debug_mode=true"`.  
- Variable precedence (highest to lowest): `extra_vars` > `task vars` > `block vars` > `role vars` > `inventory vars` > `group_vars` > `host_vars`.  
- Example: If a variable `app_version` is defined in `group_vars` and overridden by `extra_vars`, the latter will take precedence.

---

### **3. Ansible and Dynamic Inventory**  
**Question:**  
How do you manage an AWS infrastructure dynamically in Ansible?  

**Answer:**  
Use a **dynamic inventory script** to pull AWS instances.  
- Example: Using `aws_ec2` inventory plugin, dynamically gather EC2 instances:
```yaml
plugin: aws_ec2
regions:
  - us-east-1
filters:
  instance-state-name: running
```
Run the playbook with the dynamic inventory:  
```bash
ansible-playbook -i aws_ec2.yml site.yml
```

---

### **4. Rolling Updates for Web Servers**
**Question:**  
You are tasked with updating a web application on 100 servers without downtime. How would you handle this in Ansible?

**Answer:**  
Use **serial** to perform rolling updates:  
```yaml
- name: Rolling update of web servers
  hosts: web_servers
  serial: 10
  tasks:
    - name: Update application
      ansible.builtin.command: "/usr/bin/update_app"
```
This ensures 10 servers are updated at a time, maintaining service availability.

---

### **5. Ansible with Secret Management**  
**Question:**  
How do you manage sensitive data like passwords or API keys securely in Ansible?  

**Answer:**  
Use **Ansible Vault** for encrypting secrets.  
Steps:  
1. Create a vault file:  
   ```bash
   ansible-vault create secrets.yml
   ```
2. Encrypt sensitive data like:  
   ```yaml
   db_password: mysecurepassword
   ```
3. Use it in playbooks:  
   ```yaml
   vars_files:
     - secrets.yml
   ```

---

### **6. Debugging a Failing Playbook**
**Question:**  
A playbook fails on certain hosts but works on others. How would you debug this issue?

**Answer:**  
- Run the playbook in **check mode**:  
   ```bash
   ansible-playbook site.yml --check
   ```
- Use `--limit` to target specific hosts:  
   ```bash
   ansible-playbook site.yml --limit 'hostname'
   ```
- Debug task outputs with the `debug` module:  
   ```yaml
   - name: Debug facts
     debug: var=ansible_facts
   ```

---

### **7. Ensuring Idempotency**
**Question:**  
You notice your playbooks are not idempotent. How would you ensure idempotency in tasks?  

**Answer:**  
- Use state-based modules (`ansible.builtin.*`) like `file`, `yum`, or `apt`.  
- Example: To create a directory:  
   ```yaml
   - name: Ensure directory exists
     ansible.builtin.file:
       path: /mydir
       state: directory
   ```

---

### **8. Integrating Ansible with Jenkins**  
**Question:**  
How would you integrate Ansible with Jenkins to automate CI/CD?  

**Answer:**  
- Add Ansible in Jenkins pipeline as a build step using `ansible-playbook`.  
- Example Jenkins pipeline script:  
   ```groovy
   pipeline {
     stages {
       stage('Deploy') {
         steps {
           sh 'ansible-playbook -i inventory site.yml'
         }
       }
     }
   }
   ```

---

### **9. Configuration Drift in Servers**
**Question:**  
How would you use Ansible to detect and correct configuration drift?

**Answer:**  
- Use `check_mode` to detect drift without applying changes:  
   ```bash
   ansible-playbook site.yml --check
   ```
- Run the playbook periodically using a cron job to fix drift.

---

### **10. Ansible with Kubernetes**
**Question:**  
How would you deploy a Kubernetes application using Ansible?  

**Answer:**  
- Use the `k8s` module to manage Kubernetes resources.  
- Example: Deploy an application in a namespace:  
   ```yaml
   - name: Deploy app to Kubernetes
     k8s:
       state: present
       definition:
         apiVersion: apps/v1
         kind: Deployment
         metadata:
           name: my-app
           namespace: default
         spec:
           replicas: 3
           selector:
             matchLabels:
               app: my-app
           template:
             metadata:
               labels:
                 app: my-app
             spec:
               containers:
               - name: my-container
                 image: nginx:latest
   ```

---
  

### **11. Scenario: Rolling Updates with Minimal Downtime**
**Question:**  
You are tasked to perform a rolling update of a web application hosted on multiple servers using Ansible. How would you ensure that at least one server remains active during the update process?  

**Answer:**  
- Use the `serial` keyword in the playbook to define the batch size for the update.  
- Example:  
```yaml
- name: Rolling update of web application
  hosts: web_servers
  serial: 1
  tasks:
    - name: Update application
      ansible.builtin.shell: "sudo apt update && sudo apt upgrade -y"
    - name: Restart web service
      ansible.builtin.service:
        name: apache2
        state: restarted
```  
This ensures only one server is updated at a time, while others remain active.

---

### **12. Scenario: Dynamic Inventory for Multi-Cloud Deployment**
**Question:**  
How would you manage a dynamic inventory in Ansible for a multi-cloud environment (e.g., AWS and Azure)?  

**Answer:**  
- Use dynamic inventory plugins for both AWS and Azure.
- Create inventory scripts or configuration files for each provider.  
- Example: Use the `ec2.py` script for AWS and `azure_rm` plugin for Azure. Combine them in your playbook.  
- Sample command:  
```bash
ansible-playbook -i aws_ec2.yml,azure_rm.yml playbook.yml
```

---

### **13. Scenario: Handling Secret Variables Securely**
**Question:**  
You need to manage sensitive information (like database credentials) in Ansible playbooks. How will you achieve this securely?  

**Answer:**  
- Use **Ansible Vault** to encrypt sensitive variables.  
- Encrypt the file:  
  ```bash
  ansible-vault encrypt secrets.yml
  ```  
- Access the secrets in playbooks:  
  ```yaml
  - name: Securely access secrets
    vars_files:
      - secrets.yml
    tasks:
      - name: Use credentials
        ansible.builtin.debug:
          msg: "Database username is {{ db_username }}"
  ```
- Decrypt during execution:  
  ```bash
  ansible-playbook playbook.yml --ask-vault-pass
  ```

---

### **14. Scenario: Automated Backup Using Ansible**
**Question:**  
How would you configure an automated backup of application logs to an S3 bucket using Ansible?  

**Answer:**  
- Use `s3` module to upload files to S3.  
- Example playbook:  
```yaml
- name: Backup application logs
  hosts: all
  tasks:
    - name: Upload logs to S3
      community.aws.s3:
        bucket: app-logs-backup
        object: logs/{{ inventory_hostname }}.tar.gz
        src: /var/log/app_logs.tar.gz
        mode: put
        aws_access_key: "{{ aws_key }}"
        aws_secret_key: "{{ aws_secret }}"
```

---

### **15. Scenario: Zero Downtime Deployment for a Blue-Green Setup**
**Question:**  
Your organization wants to implement a zero-downtime deployment using a Blue-Green deployment strategy. How would you implement it using Ansible?  

**Answer:**  
- Use Ansible to set up two environments (blue and green). Update one while keeping the other active.  
- Example:  
```yaml
- name: Deploy to green environment
  hosts: green_servers
  tasks:
    - name: Deploy application
      ansible.builtin.copy:
        src: /path/to/app
        dest: /var/www/html
    - name: Switch traffic to green
      ansible.builtin.command: "route_traffic green"

- name: Verify green deployment
  hosts: green_servers
  tasks:
    - name: Check application health
      ansible.builtin.uri:
        url: "http://{{ inventory_hostname }}/health"
        status_code: 200
```
Switch traffic back to blue if health checks fail.

---  
