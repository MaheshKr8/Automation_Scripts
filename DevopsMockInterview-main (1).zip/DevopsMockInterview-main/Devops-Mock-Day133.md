
---

### ☸️ **1. A Pod is stuck in `CrashLoopBackOff`. How do you troubleshoot it?**

**Answer:**

1. View logs:

   ```bash
   kubectl logs <pod-name>
   ```
2. Describe pod for events:

   ```bash
   kubectl describe pod <pod-name>
   ```
3. Common issues:

   * Incorrect command/entrypoint
   * Missing env vars/configs
   * Failing readiness/liveness probes

**Fix:**
Adjust the pod spec, fix the app config, or increase initial delay.

---

### ☸️ **2. How do you perform a zero-downtime update of a production application in Kubernetes?**

**Answer:**

Use a **Deployment** with `RollingUpdate` strategy:

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 1
    maxUnavailable: 0
```

**Command:**

```bash
kubectl set image deployment/myapp myapp=myapp:v2
```

---

### ☸️ **3. Your service is not accessible via ClusterIP. How do you debug it?**

**Answer:**

1. Verify service:

   ```bash
   kubectl get svc
   ```
2. Check endpoints:

   ```bash
   kubectl get endpoints
   ```
3. Test DNS:

   ```bash
   kubectl exec -it <pod> -- nslookup <service-name>
   ```
4. Use `curl` from within another pod to test connectivity.

---

### ☸️ **4. A Pod cannot connect to another Pod in the same namespace. What would you check?**

**Answer:**

* NetworkPolicy blocking traffic?
* CNI plugin (e.g., Calico, Flannel) is properly configured?
* DNS resolution (try `nslookup`, `dig`)?
* Verify the service exists and endpoints are populated.

---

### ☸️ **5. How do you store application logs for a Kubernetes cluster?**

**Answer:**

* Kubernetes itself doesn’t store logs.
* Use:

  * **EFK** (Elasticsearch, Fluentd, Kibana)
  * **Loki** (Grafana)
  * **Promtail** agents on nodes to push logs.

**Real-time Tip:**
Mount `/var/log/containers/` from nodes using DaemonSets.

---

### ☸️ **6. You need to restrict Pod scheduling on specific nodes. How would you do that?**

**Answer:**

Use:

* **Node Selectors**:

  ```yaml
  nodeSelector:
    disktype: ssd
  ```
* **Affinity/Anti-Affinity**
* **Taints and Tolerations**

**Scenario:**
Schedule DB pods on high-performance SSD nodes only.

---

### ☸️ **7. How do you handle dynamic environment configurations in Kubernetes?**

**Answer:**

* Use **ConfigMaps** for non-sensitive data.
* Use **Secrets** for sensitive values.
* Mount as volumes or use environment variables.

```yaml
envFrom:
  - configMapRef:
      name: app-config
```

**Bonus Tip:**
Use Helm or Kustomize to template environment-specific values.

---

### ☸️ **8. How do you automatically scale Pods based on CPU/memory usage?**

**Answer:**

Use **Horizontal Pod Autoscaler (HPA):**

```bash
kubectl autoscale deployment myapp --cpu-percent=80 --min=2 --max=10
```

Make sure metrics server is installed and running:

```bash
kubectl top pod
```

---

### ☸️ **9. How do you expose a service to the internet securely?**

**Answer:**

* Use **Ingress** with **TLS termination**.
* Apply HTTPS certificates using cert-manager and Let’s Encrypt.
* Use `IngressClass: nginx` or another ingress controller.

**Example Ingress:**

```yaml
tls:
  - hosts:
      - myapp.example.com
    secretName: tls-secret
```

---

### ☸️ **10. How do you troubleshoot an unresponsive application in a pod?**

**Answer:**

1. Check container logs:

   ```bash
   kubectl logs <pod>
   ```

2. Check pod health:

   ```bash
   kubectl describe pod <pod>
   ```

3. Check probe configuration:

   ```yaml
   livenessProbe:
     httpGet:
       path: /health
       port: 8080
   ```

4. Exec into pod:

   ```bash
   kubectl exec -it <pod> -- /bin/sh
   ```

---

