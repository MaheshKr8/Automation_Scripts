
---

### **1. Git**

#### **Q1: How do you manage code reviews and ensure that only approved changes are merged into the main branch?**
- **Scenario**: Your team follows strict code review policies. You want to ensure that no code is merged into the `main` branch without being reviewed by at least one other developer. How do you enforce this using Git?
- **Answer**: Use **GitHub/GitLab branch protection rules** to enforce pull requests and code reviews.
   1. Enable branch protection in GitHub/GitLab to require pull requests and reviews before merging.
   2. You can also use status checks to ensure tests pass before merging.

#### **Q2: How would you handle a situation where a large number of merge conflicts occur during a release?**
- **Scenario**: You are releasing a feature branch into the `main` branch, but there are many merge conflicts. What steps would you take to resolve them?
- **Answer**: Resolve merge conflicts manually by rebasing or merging the conflicting branches locally.
   1. Fetch and merge `main` into your feature branch:
      ```bash
      git fetch origin
      git merge origin/main
      ```
   2. Manually resolve conflicts in the code, commit the changes, and push the branch for review.

---

### **2. Jenkins**

#### **Q3: How would you implement a Jenkins pipeline that handles different environments (e.g., development, staging, production)?**
- **Scenario**: You need to deploy applications to different environments using Jenkins. How do you configure the pipeline to handle different environments automatically?
- **Answer**: Use **parameters** in the Jenkins pipeline to dynamically deploy to different environments.
   - **Example Jenkinsfile**:
     ```groovy
     pipeline {
       agent any
       parameters {
         choice(name: 'ENV', choices: ['dev', 'staging', 'prod'], description: 'Select environment')
       }
       stages {
         stage('Deploy') {
           steps {
             script {
               if (params.ENV == 'prod') {
                 sh 'kubectl apply -f deployment-prod.yaml'
               } else if (params.ENV == 'staging') {
                 sh 'kubectl apply -f deployment-staging.yaml'
               } else {
                 sh 'kubectl apply -f deployment-dev.yaml'
               }
             }
           }
         }
       }
     }
     ```

#### **Q4: How do you ensure a Jenkins build pipeline only triggers when changes are made to specific files in a repository?**
- **Scenario**: You want to limit your build pipeline to trigger only when changes are made to certain files (e.g., only when `Dockerfile` or `build.gradle` is updated). How would you implement this in Jenkins?
- **Answer**: Use **Jenkins pipeline file change triggers**.
   1. Use the `when` directive in the Jenkins pipeline to check for file changes:
      ```groovy
      pipeline {
        agent any
        stages {
          stage('Build') {
            when {
              changeset "**/Dockerfile,**/build.gradle"
            }
            steps {
              sh 'docker build .'
            }
          }
        }
      }
      ```

---

### **3. Docker**

#### **Q5: How would you persist data in a Docker container running a database like MySQL?**
- **Scenario**: You are running MySQL in a Docker container, but the data is lost when the container is stopped or removed. How would you persist the data?
- **Answer**: Use **Docker volumes** to persist data.
   1. Create a Docker volume and mount it to the MySQL container:
      ```bash
      docker volume create mysql-data
      docker run -d --name mysql -v mysql-data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=root mysql:latest
      ```
   2. The volume ensures that even if the container is removed, the data is stored.

#### **Q6: How do you monitor resource usage (CPU, memory) of running Docker containers?**
- **Scenario**: You want to monitor the CPU and memory usage of containers to optimize performance. How would you achieve this?
- **Answer**: Use **Docker Stats** for real-time monitoring.
   1. Run the following command to get real-time metrics:
      ```bash
      docker stats
      ```
   2. This provides details on CPU, memory, network, and I/O for each running container.

---

### **4. Kubernetes**

#### **Q7: How do you ensure that a Kubernetes pod can only communicate with another pod in the same namespace?**
- **Scenario**: You want to restrict communication between pods so that only pods within the same namespace can talk to each other. How would you implement this?
- **Answer**: Use **Kubernetes Network Policies**.
   - **Example Network Policy**:
     ```yaml
     apiVersion: networking.k8s.io/v1
     kind: NetworkPolicy
     metadata:
       name: allow-same-namespace
     spec:
       podSelector: {}
       policyTypes:
       - Ingress
       ingress:
       - from:
         - podSelector: {}
     ```
   1. This policy restricts incoming traffic to pods in the same namespace.

#### **Q8: How would you debug a failing Kubernetes deployment where the pod immediately restarts after running?**
- **Scenario**: Your Kubernetes pod fails to stay up and keeps restarting. How would you troubleshoot this?
- **Answer**: Use the following steps:
   1. Check the pod logs:
      ```bash
      kubectl logs <pod-name>
      ```
   2. Use `kubectl describe pod` to check events and error messages, and then debug based on the specific issue (e.g., image pull errors, crash loop).

---

### **5. Terraform**

#### **Q9: How would you handle sensitive information such as passwords or API keys in Terraform configuration files?**
- **Scenario**: You need to use sensitive credentials (like passwords or API keys) in your Terraform code, but you want to ensure they aren’t hard-coded in plain text. How do you manage this securely?
- **Answer**: Use **Terraform variables** with **environment variables** or **secrets management systems** like AWS Secrets Manager.
   1. Define sensitive variables in a `.tfvars` file:
      ```hcl
      variable "db_password" {
        type      = string
        sensitive = true
      }
      ```
   2. Load the values securely from environment variables:
      ```bash
      export TF_VAR_db_password=supersecretpassword
      ```

#### **Q10: How do you manage Terraform code across multiple teams, ensuring that each team has control over specific parts of the infrastructure?**
- **Scenario**: You have multiple teams managing different parts of the infrastructure. How would you structure your Terraform code to maintain team autonomy while managing dependencies between resources?
- **Answer**: Use **Terraform modules** to divide the infrastructure into manageable, reusable components.
   1. Create separate modules for each team (e.g., VPC, RDS, S3) and manage dependencies using **outputs** and **data sources**.
   2. Example of referencing a VPC module in an RDS module:
      ```hcl
      module "vpc" {
        source = "./modules/vpc"
      }

      module "rds" {
        source = "./modules/rds"
        vpc_id = module.vpc.vpc_id
      }
      ```

---

### **6. Ansible**

#### **Q11: How do you run an Ansible playbook against specific tags to only run a subset of tasks?**
- **Scenario**: Your playbook has multiple tasks, but you only want to run a specific set of tasks related to deploying an application, not setting up infrastructure. How do you achieve this?
- **Answer**: Use **tags** to isolate tasks and run only the relevant parts of the playbook.
   - Example Playbook with Tags:
     ```yaml
     - name: Deploy Application
       hosts: all
       tasks:
         - name: Install dependencies
           apt:
             name: nginx
           tags: install

         - name: Deploy app
           copy:
             src: /path/to/app
             dest: /var/www/html
           tags: deploy
     ```
   1. Run the playbook with the `--tags` flag:
      ```bash
      ansible-playbook site.yml --tags deploy
      ```

#### **Q12: How do you handle situations where Ansible must use different users or SSH keys for different hosts?**
- **Scenario**: You need to run tasks on multiple servers, but they use different SSH keys or users. How do you manage this in Ansible?
- **Answer**: Use **Ansible inventory** to define user and SSH keys for different hosts.
   - Example Inventory File:
     ```ini
     [webservers]
     web1 ansible_user=ubuntu ansible_ssh_private_key_file=~/.ssh/web1.pem
     web2 ansible_user=admin ansible_ssh_private_key_file=~/.ssh/web2.pem
     ```
   1. Ansible will automatically use the specified user and SSH key for each host.

---

### **7. Trivy**

#### **Q13: How do you integrate Trivy scans into your Kubernetes pipeline to ensure containers are scanned before deployment?**
- **Scenario**: You need to ensure that all Docker containers are scanned for vulnerabilities before being deployed to Kubernetes.

 How would you set up this pipeline?
- **Answer**: Add a **Trivy scanning step** to the CI pipeline before deployment.
   - Example in GitLab CI:
     ```yaml
     stages:
       - test
       - deploy

     scan:
       stage: test
       script:
         - trivy image my-app:latest
     ```

#### **Q14: How do you automatically generate and store Trivy scan reports in a CI/CD pipeline for auditing purposes?**
- **Scenario**: You want to generate a Trivy vulnerability report and store it as an artifact for auditing purposes in your CI/CD pipeline.
- **Answer**: Save the scan output as a report.
   - Example:
     ```bash
     trivy image --format json --output trivy-report.json my-app:latest
     ```
   1. Store the report as an artifact in Jenkins/GitLab for future reference.

---

### **8. AWS**

#### **Q15: How would you implement auto-scaling based on custom CloudWatch metrics in AWS?**
- **Scenario**: You need to automatically scale EC2 instances based on a custom application metric, such as request latency, rather than CPU usage. How do you achieve this?
- **Answer**: Use **CloudWatch Alarms** with custom metrics and **Auto Scaling Groups**.
   1. Create a custom metric for request latency in CloudWatch.
   2. Set up a scaling policy to add/remove instances based on that metric:
      ```bash
      aws autoscaling put-scaling-policy --policy-name ScaleUp --auto-scaling-group-name my-asg --scaling-adjustment 1 --metric-name Latency
      ```

#### **Q16: How do you ensure high availability and fault tolerance for an application hosted in AWS?**
- **Scenario**: You need to design a high-availability solution for an application that must remain available even during regional outages. How do you architect this?
- **Answer**: Use **AWS services** such as **Auto Scaling, Elastic Load Balancing, Multi-AZ RDS**, and **S3 Cross-Region Replication**.
   1. Deploy the application across multiple availability zones using an **Auto Scaling group** and **ELB**.
   2. Store critical data in **Multi-AZ RDS** and enable **S3 replication** for redundancy.

---

These questions cover more advanced and practical use cases, providing a comprehensive overview of common DevOps challenges, solutions, and best practices for key tools.
