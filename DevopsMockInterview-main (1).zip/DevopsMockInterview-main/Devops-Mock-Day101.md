
These scenario-based Linux questions will help you tackle real-world DevOps problems efficiently.  

---

### **1. A web application running on your server is suddenly unresponsive. How do you troubleshoot?**  
#### **Solution:**  
- **Check if the service is running:**  
  ```bash
  systemctl status nginx  # Replace nginx with your web server
  ```
- **Check open ports:**  
  ```bash
  netstat -tulnp | grep LISTEN
  ```
- **Check resource usage:**  
  ```bash
  top or htop
  ```
- **Check logs for errors:**  
  ```bash
  journalctl -u nginx --since "10 minutes ago"
  tail -f /var/log/nginx/error.log
  ```

**Real-World Use Case:**  
If a web service stops responding, these steps help identify **crashes, high CPU usage, or port conflicts**.

---

### **2. How do you find which process is consuming the most memory on a server?**  
#### **Solution:**  
```bash
ps aux --sort=-%mem | head -5
```

**Real-World Use Case:**  
Useful for diagnosing **memory leaks** in applications.

---

### **3. A server is running out of disk space. How do you find and clean up large files?**  
#### **Solution:**  
- **Find the largest directories:**  
  ```bash
  du -ah / | sort -rh | head -10
  ```
- **Delete logs older than 7 days:**  
  ```bash
  find /var/log -type f -mtime +7 -exec rm -f {} \;
  ```
- **Clear system cache:**  
  ```bash
  sync; echo 3 > /proc/sys/vm/drop_caches
  ```

**Real-World Use Case:**  
Helps free up disk space and prevents system crashes due to **disk exhaustion**.

---

### **4. How do you find which process is using a specific port?**  
#### **Solution:**  
```bash
netstat -tulnp | grep :80  # Check for port 80
lsof -i :80
```

**Real-World Use Case:**  
Useful when troubleshooting **port conflicts in Docker, Apache, Nginx, or other applications**.

---

### **5. How do you set up passwordless SSH login for automation scripts?**  
#### **Solution:**  
```bash
ssh-keygen -t rsa
ssh-copy-id user@remote_host
```

**Real-World Use Case:**  
Essential for **CI/CD pipelines, automated deployments, and Ansible playbooks**.

---

### **6. Your server is experiencing high CPU usage. How do you investigate?**  
#### **Solution:**  
- **Check top processes:**  
  ```bash
  top -o %CPU
  ```
- **Find which process is using the CPU:**  
  ```bash
  ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head
  ```

**Real-World Use Case:**  
Identifies performance bottlenecks caused by **misconfigured applications or infinite loops**.

---

### **7. How do you monitor real-time logs of a running service?**  
#### **Solution:**  
```bash
journalctl -fu nginx  # Replace with your service name
tail -f /var/log/nginx/access.log
```

**Real-World Use Case:**  
Used for **troubleshooting errors in live environments**.

---

### **8. How do you check the last 10 successful logins on a Linux system?**  
#### **Solution:**  
```bash
last -n 10
```

**Real-World Use Case:**  
Useful for **security auditing and unauthorized access detection**.

---

### **9. How do you block an IP from accessing your server?**  
#### **Solution:**  
```bash
sudo iptables -A INPUT -s <IP_ADDRESS> -j DROP
```
or using UFW:  
```bash
sudo ufw deny from <IP_ADDRESS>
```

**Real-World Use Case:**  
Blocks **malicious bots or DDoS attacks**.

---

### **10. How do you check the public IP of your Linux server?**  
#### **Solution:**  
```bash
curl -s ifconfig.me
```

**Real-World Use Case:**  
Needed for **troubleshooting and firewall configurations**.

---

### **11. How do you list all open connections on a Linux server?**  
#### **Solution:**  
```bash
netstat -antp
ss -tulnp
```

**Real-World Use Case:**  
Detects **unauthorized connections**.

---

### **12. How do you schedule a cron job to run every Monday at 2 AM?**  
#### **Solution:**  
```bash
crontab -e
```
Add the following line:  
```bash
0 2 * * 1 /path/to/script.sh
```

**Real-World Use Case:**  
Automates **backup jobs, log rotation, or application restarts**.

---

### **13. How do you change the hostname of a Linux server?**  
#### **Solution:**  
```bash
sudo hostnamectl set-hostname new-hostname
```

**Real-World Use Case:**  
Useful when configuring **cloud VMs or Kubernetes nodes**.

---

### **14. How do you enable and disable a service at boot?**  
#### **Solution:**  
Enable:  
```bash
sudo systemctl enable nginx
```
Disable:  
```bash
sudo systemctl disable nginx
```

**Real-World Use Case:**  
Ensures **critical services start automatically after a reboot**.

---

### **15. How do you check the system load average?**  
#### **Solution:**  
```bash
uptime
cat /proc/loadavg
```

**Real-World Use Case:**  
Helps in **capacity planning and load balancing**.

---

### **16. How do you find and kill a process by its name?**  
#### **Solution:**  
```bash
pkill -f process_name
```

**Real-World Use Case:**  
Used to **stop runaway processes**.

---

### **17. How do you check if a server can reach Google’s DNS?**  
#### **Solution:**  
```bash
ping -c 4 8.8.8.8
```

**Real-World Use Case:**  
Troubleshooting **network connectivity issues**.

---

### **18. How do you check which DNS server is being used?**  
#### **Solution:**  
```bash
cat /etc/resolv.conf
```

**Real-World Use Case:**  
Helps in **network performance optimization**.

---

### **19. How do you find and delete all empty files in a directory?**  
#### **Solution:**  
```bash
find /path/to/dir -type f -empty -delete
```

**Real-World Use Case:**  
Useful for **cleaning up unnecessary files in log directories**.

---

### **20. How do you force unmount a busy NFS share?**  
#### **Solution:**  
```bash
sudo umount -l /mnt/nfs
```

**Real-World Use Case:**  
Prevents **server hangs caused by unresponsive NFS mounts**.

---
