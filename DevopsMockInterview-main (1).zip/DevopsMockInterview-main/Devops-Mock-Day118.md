
---

### **1. What is Docker and how is it different from a virtual machine?**

**Answer**: Docker is a containerization platform that packages applications with dependencies in isolated environments. Unlike VMs, Docker containers share the host OS kernel, making them lightweight and faster to start.

---

### **2. How do you check running Docker containers?**

**Answer**:

```bash
docker ps
```

---

### **3. How do you persist data in Docker containers?**

**Answer**: Use **volumes** or **bind mounts**:

```bash
docker run -v /host/data:/container/data myapp
```

---

### **4. How do you create a Docker image from a Dockerfile?**

**Answer**:

```bash
docker build -t myimage:latest .
```

---

### **5. How do you reduce Docker image size?**

**Answer**:

* Use multi-stage builds.
* Use lightweight base images (like `alpine`).
* Combine `RUN` statements to reduce layers.

---

### **6. How do you troubleshoot a container that exits immediately?**

**Answer**:

* Check logs: `docker logs <container_id>`
* Run with interactive mode:

  ```bash
  docker run -it myapp /bin/sh
  ```

---

### **7. How do you connect containers in the same network?**

**Answer**:

```bash
docker network create mynet
docker run --network=mynet --name app1 myapp
docker run --network=mynet --name app2 myapp
```

---

### **8. What is the difference between CMD and ENTRYPOINT in Dockerfile?**

**Answer**:

* `CMD` sets default arguments.
* `ENTRYPOINT` defines the executable.
  They can be combined.

---

### **9. How do you remove all stopped containers and unused images?**

**Answer**:

```bash
docker system prune -a
```

---

### **10. How do you expose a container port to the host?**

**Answer**:

```bash
docker run -p 8080:80 myapp
```

---

### **11. What is the use of `.dockerignore`?**

**Answer**:
To exclude files and directories from the Docker build context, improving build performance and security.

---

### **12. How do you scale containers using Docker Compose?**

**Answer**:

```bash
docker-compose up --scale web=3
```

---

### **13. How do you handle secrets in Docker?**

**Answer**:

* In Swarm: `docker secret`
* Or inject via environment variables or mounted files (with caution).

---

### **14. What is a multi-stage Docker build?**

**Answer**:
A technique to use multiple `FROM` statements to copy only required artifacts to the final image. Helps reduce image size.

---

### **15. How can you debug a running Docker container?**

**Answer**:

```bash
docker exec -it <container_id> /bin/bash
```

---

### **16. How do you pass environment variables to a Docker container?**

**Answer**:

```bash
docker run -e ENV_VAR=value myapp
```

---

### **17. What are the best practices for writing Dockerfiles?**

**Answer**:

* Use minimal base images.
* Avoid installing unnecessary packages.
* Use `.dockerignore`.
* Pin image versions.
* Minimize layers.

---

### **18. What’s the difference between COPY and ADD in Dockerfile?**

**Answer**:

* `COPY` is for simple file copy.
* `ADD` can extract archives and fetch URLs, but is less explicit and generally avoided unless needed.

---

### **19. How do you push a Docker image to Docker Hub?**

**Answer**:

```bash
docker tag myimage username/myimage
docker push username/myimage
```

---

### **20. How do you ensure containers restart automatically on failure or host reboot?**

**Answer**:
Use `--restart` policy:

```bash
docker run --restart=always myapp
```

---
