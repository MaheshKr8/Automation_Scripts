
---

### 🚀 **1. Your containerized application is not starting. How do you troubleshoot it?**

**Answer:**

Steps:

* Check logs:

  ```bash
  docker logs <container_id>
  ```
* Verify the Dockerfile ENTRYPOINT/CMD.
* Run interactively:

  ```bash
  docker run -it <image> /bin/bash
  ```
* Check image base, environment variables, mounted volumes.

**Example Issue:**
The `CMD` in Dockerfile points to a script that has no execute permission.

---

### 🚀 **2. A Docker image runs on your machine but fails in production. What would you check?**

**Answer:**

* Environment differences (OS, volumes, ports).
* Verify `.env` or environment-specific configs.
* Check for hardcoded paths in Dockerfile.
* Compare Docker versions.

**Fix:**
Use **multi-stage builds** and minimal base images to avoid dependency mismatches.

---

### 🚀 **3. How would you ensure data persists when the container stops or is recreated?**

**Answer:**

Use Docker **volumes** or **bind mounts**:

```bash
docker run -v mydata:/app/data myimage
```

**Real Use Case:**
Persisting MySQL database data in `/var/lib/mysql` across container restarts.

---

### 🚀 **4. You're seeing frequent restarts of a container. What could be the issue?**

**Answer:**

* Use `docker inspect <container_id>` → Check `RestartCount`.
* Container crashes due to app error or missing config.
* Use:

  ```bash
  docker logs <container_id>
  ```
* Check `HEALTHCHECK` or startup scripts.

**Fix:**
Add robust entrypoint logic or update restart policy:

```bash
--restart=on-failure:5
```

---

### 🚀 **5. How do you optimize Docker image size in production?**

**Answer:**

* Use minimal base images like `alpine`.
* Use `.dockerignore` to exclude unnecessary files.
* Use **multi-stage builds**:

```Dockerfile
FROM golang AS builder
WORKDIR /app
COPY . .
RUN go build -o app

FROM alpine
COPY --from=builder /app/app /app
ENTRYPOINT ["/app"]
```

---

### 🚀 **6. Your Dockerized app can't access another container on the same network. What do you do?**

**Answer:**

* Ensure both containers are on the same **Docker network**:

```bash
docker network create mynet
docker run --network=mynet --name app1 ...
docker run --network=mynet --name db ...
```

* Ping by container name, not localhost.

---

### 🚀 **7. How do you troubleshoot container networking issues?**

**Answer:**

* Use:

  ```bash
  docker exec -it <container> ping <other-container>
  ```
* Check Docker bridge network:

  ```bash
  docker network inspect bridge
  ```
* Use `curl` or `telnet` for port testing.

**Use Case:**
App container can’t reach database due to missing network config.

---

### 🚀 **8. You need to secure Docker secrets (passwords, API keys). How?**

**Answer:**

* Don’t hardcode in Dockerfile.
* Use runtime environment variables or Docker secrets (Swarm):

```bash
docker secret create db_pass password.txt
```

* Mount secrets as files inside container.

---

### 🚀 **9. How do you handle container logs in production?**

**Answer:**

* Use logging drivers like:

  ```bash
  --log-driver=json-file (default)
  --log-driver=fluentd
  ```
* Aggregate logs using ELK stack or Loki.

**Script Example:**

```bash
docker run --log-driver=syslog nginx
```

---

### 🚀 **10. How do you update a running container without downtime?**

**Answer:**

* Use **Docker Swarm** or **Kubernetes** for orchestration.
* Blue-green deployment:

  * Run new container on different port.
  * Test, then switch traffic.
* Or recreate with zero-downtime tools like `docker-compose up -d --build`.

---

