
# DevOps Real-Time Task-Based Interview Questions and Answers

## 1. How do you create a Jenkins job to build a Maven project from a GitHub repository?

### Answer:
1. **Open Jenkins and click on "New Item."**
2. **Enter a name for the job and select "Freestyle project," then click "OK."**
3. **In the "Source Code Management" section, select "Git" and enter the repository URL.**
4. **In the "Build Triggers" section, choose "GitHub hook trigger for GITScm polling."**
5. **In the "Build" section, click "Add build step" and select "Invoke top-level Maven targets."**
6. **In the "Goals" field, enter `clean install`.**
7. **Save the job and click "Build Now" to test it.**

## 2. Write a script to automate the deployment of a Docker container for a simple web application.

### Answer:
```bash
#!/bin/bash

# Variables
IMAGE_NAME="mywebapp"
CONTAINER_NAME="mywebapp_container"
PORT=8080

# Build Docker image
docker build -t $IMAGE_NAME .

# Stop and remove any existing container
docker stop $CONTAINER_NAME && docker rm $CONTAINER_NAME

# Run Docker container
docker run -d -p $PORT:80 --name $CONTAINER_NAME $IMAGE_NAME
```

## 3. How would you create and configure an S3 bucket using AWS CLI for storing application logs?

### Answer:
1. **Create the bucket**
    ```bash
    aws s3 mb s3://my-app-logs
    ```
2. **Apply a bucket policy to allow public read access (if needed)**
    ```bash
    aws s3api put-bucket-policy --bucket my-app-logs --policy file://policy.json
    ```
    Where `policy.json` contains the necessary JSON policy.
3. **Enable versioning on the bucket**
    ```bash
    aws s3api put-bucket-versioning --bucket my-app-logs --versioning-configuration Status=Enabled
    ```
4. **Enable server-side encryption**
    ```bash
    aws s3api put-bucket-encryption --bucket my-app-logs --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
    ```

## 4. Write an Ansible playbook to install NGINX on a remote server.

### Answer:
```yaml
---
- name: Install NGINX
  hosts: webservers
  become: yes
  tasks:
    - name: Update apt cache
      apt:
        update_cache: yes

    - name: Install NGINX
      apt:
        name: nginx
        state: present

    - name: Ensure NGINX is running
      service:
        name: nginx
        state: started
        enabled: yes
```

## 5. How would you set up Prometheus to monitor a Kubernetes cluster?

### Answer:
1. **Create a namespace for monitoring**
    ```bash
    kubectl create namespace monitoring
    ```
2. **Use Helm to install Prometheus**
    ```bash
    helm install prometheus stable/prometheus --namespace monitoring
    ```
3. **Verify the installation**
    ```bash
    kubectl get pods --namespace monitoring
    ```
4. **Access the Prometheus dashboard**
    ```bash
    kubectl port-forward -n monitoring deploy/prometheus-server 9090
    ```
    Open `http://localhost:9090` in a browser.

## 6. Write a script to back up a MySQL database and store the backup in an S3 bucket.

### Answer:
```bash
#!/bin/bash

# Variables
DB_NAME="mydatabase"
DB_USER="myuser"
DB_PASS="mypassword"
BACKUP_NAME="backup_$(date +%F).sql"
S3_BUCKET="s3://mydatabase-backups"

# Create backup
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME > /tmp/$BACKUP_NAME

# Upload to S3
aws s3 cp /tmp/$BACKUP_NAME $S3_BUCKET

# Remove local backup
rm /tmp/$BACKUP_NAME
```

## 7. How would you configure GitLab CI/CD to deploy a Node.js application?

### Answer:
1. **Create `.gitlab-ci.yml` in the root of your project**
    ```yaml
    stages:
      - install
      - test
      - deploy

    install:
      stage: install
      script:
        - npm install

    test:
      stage: test
      script:
        - npm test

    deploy:
      stage: deploy
      script:
        - npm run deploy
      only:
        - main
    ```
2. **Push the `.gitlab-ci.yml` file to your repository and observe the pipeline execution in GitLab.**

## 8. Describe the steps to set up a reverse proxy with NGINX for a web application running on port 3000.

### Answer:
1. **Install NGINX**
    ```bash
    sudo apt update
    sudo apt install nginx
    ```
2. **Configure NGINX**
    - Edit the default configuration file `/etc/nginx/sites-available/default`
      ```nginx
      server {
          listen 80;

          server_name your_domain.com;

          location / {
              proxy_pass http://localhost:3000;
              proxy_http_version 1.1;
              proxy_set_header Upgrade $http_upgrade;
              proxy_set_header Connection 'upgrade';
              proxy_set_header Host $host;
              proxy_cache_bypass $http_upgrade;
          }
      }
      ```
3. **Test and reload NGINX**
    ```bash
    sudo nginx -t
    sudo systemctl restart nginx
    ```

## 9. How do you automate the creation of an EC2 instance and install Apache on it using a user data script?

### Answer:
1. **Create a user data script**
    ```bash
    #!/bin/bash
    sudo apt update
    sudo apt install -y apache2
    sudo systemctl start apache2
    sudo systemctl enable apache2
    ```
2. **Use AWS CLI to launch an EC2 instance with the user data script**
    ```bash
    aws ec2 run-instances --image-id ami-0abcdef1234567890 --count 1 --instance-type t2.micro --key-name MyKeyPair --security-group-ids sg-903004f8 --subnet-id subnet-6e7f829e --user-data file://user-data.sh
    ```

## 10. Write a Kubernetes manifest file to deploy a simple NGINX application with 3 replicas.

### Answer:
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:latest
        ports:
        - containerPort: 80
```
**Apply the manifest file using:**
```bash
kubectl apply -f nginx-deployment.yaml
```
