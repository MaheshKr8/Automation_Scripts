
---

## **1. How would you design a CI/CD pipeline that integrates GitHub, Jenkins, Maven, SonarQube, Trivy, and Kubernetes?**

**Answer:**

* **GitHub** → source code repository, triggers Jenkins on push/PR.
* **Jenkins** → pipeline with stages: Build (Maven), Unit Test, Static Code Analysis (SonarQube), Security Scan (Trivy), Package Docker image, Push to Registry, Deploy to Kubernetes.
* **Kubernetes** → deployment manifests or Helm charts applied using kubectl/Helm.
* **Secrets** → stored in Jenkins Credentials, Kubernetes Secrets, or Vault.

---

## **2. How do you implement Canary deployments in Kubernetes?**

**Answer:**

* Use two deployments: **stable** and **canary**.
* Route a percentage of traffic to canary using **Ingress NGINX** annotations or **Service Mesh** (Istio, Linkerd).
* Gradually increase canary percentage after validation.
* Rollback if metrics fail thresholds.

---

## **3. How do you handle Terraform drift when resources are changed outside Terraform?**

**Answer:**

* Run `terraform plan` to detect drift.
* If needed, import using `terraform import` or reapply state with `terraform apply`.
* Implement **state locking** with S3 + DynamoDB (for AWS) to prevent concurrent changes.

---

## **4. How do you connect on-premises data center to AWS for hybrid cloud workloads?**

**Answer:**

* **Options**:

  * **AWS Direct Connect** (dedicated line, low latency)
  * **AWS Site-to-Site VPN** (IPSec over internet)
* Ensure VPC routing tables, security groups, and NACLs are updated.
* For Kubernetes workloads, use **EKS + VPC peering** or **Transit Gateway**.

---

## **5. How do you handle secrets across multiple environments in Kubernetes?**

**Answer:**

* Use **Kubernetes Secrets** encrypted with KMS.
* Or external secret managers like **HashiCorp Vault**, **AWS Secrets Manager**, **SealedSecrets**.
* Inject into pods using **environment variables** or **mounted volumes**.

---

## **6. How do you roll back a failed deployment in ArgoCD?**

**Answer:**

* ArgoCD stores history of sync operations.
* UI: Select previous revision → Sync.
* CLI:

  ```bash
  argocd app history <app-name>
  argocd app rollback <app-name> <revision>
  ```
* Rollbacks restore manifests from Git repo state.

---

## **7. How do you ensure zero-downtime deployment for a database schema change?**

**Answer:**

* Use **Blue-Green DB Migration** or **Expand and Contract** method:

  1. Add new columns/tables without removing old ones.
  2. Deploy application that writes to both old and new schema.
  3. Migrate data gradually.
  4. Switch application fully to new schema.
  5. Remove old schema after verification.

---

## **8. How do you debug a pod in Kubernetes that keeps crashing?**

**Answer:**

* Check logs: `kubectl logs <pod> --previous`.
* Describe pod: `kubectl describe pod <pod>`.
* Run debug container: `kubectl exec -it <pod> -- /bin/sh`.
* Check **liveness/readiness probes**, resource limits, and dependencies (DNS, config, secrets).

---

## **9. How would you optimize an EC2 cost for workloads with predictable spikes?**

**Answer:**

* Use **Auto Scaling Groups** with scheduled scaling.
* Use **Reserved Instances** for base load and **Spot Instances** for spikes.
* Implement **Elastic Load Balancer** to distribute traffic.

---

## **10. How do you secure a Docker container in production?**

**Answer:**

* Use **minimal base images** (Alpine).
* Run as **non-root**.
* Scan images with **Trivy/Clair**.
* Enable **read-only root filesystem**.
* Restrict capabilities via `docker run --cap-drop`.

---

## **11. How do you handle inter-pod communication between namespaces securely?**

**Answer:**

* Use **Network Policies** to explicitly allow required traffic.
* Example: Allow Pod A in Namespace X to connect only to Pod B in Namespace Y.
* Enforce policies with **Calico** or **Cilium** CNI.

---

## **12. How do you implement blue-green deployment for Kubernetes services?**

**Answer:**

* Two versions (blue, green) deployed.
* Service selector updated to point to green after verification.
* Rollback by pointing service back to blue.

---

## **13. How do you provide temporary access to pull images from a private ECR to another AWS account?**

**Answer:**

* Share via **ECR Repository Policy** or cross-account IAM roles.
* Temporary access via `aws ecr get-login-password` with STS tokens.

---

## **14. How do you debug slow Git operations in a large monorepo?**

**Answer:**

* Use **shallow cloning**: `git clone --depth=1`.
* Use **Git sparse checkout** to fetch only needed directories.
* Optimize by **splitting monorepo** or using Git LFS for large binaries.

---

## **15. How do you ensure Terraform applies happen in the right order when modules depend on each other?**

**Answer:**

* Pass outputs from one module to another via `module.vpc.vpc_id`.
* Use `depends_on` for explicit ordering when dependencies are not obvious.

---
