Here are five more advanced real-time Kubernetes interview questions:

### 1. **How do you manage storage in Kubernetes, and what is the difference between PersistentVolume (PV) and PersistentVolumeClaim (PVC)?**

**Explanation**:
In Kubernetes, storage management is essential for stateful applications. 

- **PersistentVolume (PV)**:
  - A **PersistentVolume** is a storage resource in the cluster that administrators provision.
  - It is independent of any specific pod and is abstracted from the underlying storage systems (e.g., NFS, cloud-based block storage).

- **PersistentVolumeClaim (PVC)**:
  - A **PersistentVolumeClaim** is a request by a user for storage. It binds to a specific PersistentVolume that matches the storage criteria (size, access modes).
  
- **Key Difference**: 
  - The **PV** is the actual storage resource, while the **PVC** is a claim for that resource. Once a PVC is bound to a PV, the pod can use that storage.

### 2. **How does Kubernetes handle multi-container pods, and when would you use sidecar containers?**

**Explanation**:
In Kubernetes, a pod can run multiple containers. These containers share the same network and storage resources, but each container runs independently.

- **Multi-container Pods**: 
  Multiple containers in a pod are usually tightly coupled and need to share resources or communicate closely. An example could be a logging agent container (sidecar) running alongside an application container.

- **Sidecar Containers**: 
  A sidecar container is a secondary container that enhances or supports the primary application container. Use cases include:
  - **Logging**: A sidecar container can collect logs from the primary container and send them to a log aggregator.
  - **Proxies**: Sidecar containers can act as reverse proxies, such as in the **service mesh** pattern (e.g., Istio, Linkerd).

### 3. **How do you handle config changes in a live Kubernetes environment without downtime?**

**Explanation**:
Handling configuration changes without downtime is critical for ensuring high availability. Here are a few strategies:

1. **ConfigMaps and Secrets**:
   - Store application configurations in **ConfigMaps** or **Secrets**.
   - When you update a ConfigMap or Secret, Kubernetes automatically mounts the updated data into the pod, though not all applications reload them dynamically.
   
2. **Rolling Updates**:
   - For applications that do not dynamically reload configs, perform a **rolling update** by updating the Deployment with the new config values.
   - Use the command:
     ```bash
     kubectl rollout restart deployment/<deployment-name>
     ```
     This will gradually replace pods with the updated configuration without downtime.

3. **Graceful Shutdown**:
   - Use **preStop hooks** and **liveness probes** to gracefully terminate the old pods while the new pods are being rolled out.

### 4. **Explain how Kubernetes handles scaling pods based on custom metrics (other than CPU or memory)?**

**Explanation**:
Kubernetes supports scaling pods based on custom metrics using the **Horizontal Pod Autoscaler (HPA)**. Here’s how it works:

1. **Custom Metrics**:
   - In addition to CPU and memory, you can define custom metrics such as request rates, queue length, or response times to trigger autoscaling.
   
2. **Metrics Server and Custom Metrics Adapter**:
   - The **Metrics Server** provides basic resource metrics like CPU and memory.
   - To use custom metrics, you need to deploy a **Custom Metrics Adapter** (e.g., Prometheus Adapter) that allows HPA to query custom metrics from external monitoring systems (e.g., Prometheus).

3. **HPA for Custom Metrics**:
   You configure the HPA with custom metrics like this:
   ```yaml
   apiVersion: autoscaling/v2beta2
   kind: HorizontalPodAutoscaler
   metadata:
     name: custom-hpa
   spec:
     scaleTargetRef:
       apiVersion: apps/v1
       kind: Deployment
       name: my-app
     minReplicas: 1
     maxReplicas: 10
     metrics:
     - type: External
       external:
         metric:
           name: http_requests_per_second
         target:
           type: Value
           value: "500"
   ```

4. **External Metrics**:
   - Metrics can come from external systems like Prometheus, Datadog, etc., which collect application-specific metrics, and these are used for scaling decisions.

### 5. **What happens if a Kubernetes master node fails, and how do you design a resilient control plane?**

**Explanation**:
Kubernetes relies on the control plane (master nodes) to manage the state of the cluster. If a master node fails, the cluster’s ability to schedule new pods and process changes is impacted.

1. **Master Node Failures**:
   - If a single master node fails, the cluster may become read-only. Existing workloads will continue to run, but new deployments, scaling, and configuration changes will be blocked until the master node is restored.

2. **High Availability (HA) Design**:
   - **Multi-master setup**: To avoid downtime and single points of failure, you can run multiple master nodes (etcd, API server, controller manager, scheduler) in an HA configuration.
   - **etcd Quorum**: Ensure **etcd** (the data store) has a quorum (more than half of etcd nodes must be running) to ensure consistent state across the control plane.

3. **Backup and Recovery**:
   - Regularly backup etcd, which stores the cluster state. In case of a failure, restoring the etcd backup can help recover the cluster.

4. **Load Balancing**:
   - Use a load balancer in front of the API servers to ensure requests are balanced across healthy master nodes. This allows the cluster to continue serving API requests even if one master node is down.

### Summary

These advanced questions cover complex aspects of Kubernetes like storage management, handling stateful workloads, managing configurations without downtime, working with custom metrics for autoscaling, and designing highly available control planes. Answering these questions requires in-depth knowledge of Kubernetes internals and real-world troubleshooting and architectural design experience.
