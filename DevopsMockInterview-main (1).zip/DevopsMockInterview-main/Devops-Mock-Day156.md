
---

### ✅ **1. Your containerized application is not starting. How do you troubleshoot it?**

**Answer:**

* Check logs using:

  ```bash
  docker logs <container_id>
  ```
* Use interactive debugging:

  ```bash
  docker run -it <container_name> /bin/bash
  ```
* Validate `ENTRYPOINT`, `CMD`, and base image.
* Ensure required ports/volumes/environment variables are correctly configured.

---

### ✅ **2. A Docker container works locally but fails on the server. What could be the cause?**

**Answer:**

* Check for missing environment variables.
* Ensure external services (DB, APIs) are accessible from server.
* Confirm Docker version compatibility.
* Inspect `docker run` parameters like volume paths or network modes.

---

### ✅ **3. How do you reduce the size of a Docker image?**

**Answer:**

* Use **multi-stage builds**.
* Choose minimal base images (`alpine`, `scratch`).
* Clean up package cache in the same layer:

  ```dockerfile
  RUN apt-get update && apt-get install -y <pkg> && apt-get clean
  ```
* Remove unnecessary dependencies and files.

---

### ✅ **4. How do you persist data in Docker containers?**

**Answer:**

* Use **volumes**:

  ```bash
  docker volume create mydata
  docker run -v mydata:/data <image>
  ```
* Or use **bind mounts**:

  ```bash
  docker run -v /host/path:/container/path <image>
  ```

---

### ✅ **5. How do you debug high CPU usage in a Docker container?**

**Answer:**

* Use `docker stats` to identify problematic containers.
* SSH into container:

  ```bash
  docker exec -it <container_id> bash
  top
  ```
* Use monitoring tools like **cAdvisor**, **Prometheus**, **Grafana**.

---

### ✅ **6. How do you manage secrets in Docker?**

**Answer:**

* Use Docker Secrets with Swarm for production:

  ```bash
  docker secret create my_secret secret.txt
  ```
* For local/dev, use environment variables with caution or mount secret files securely:

  ```bash
  docker run -e DB_PASSWORD=$(cat secret.txt) <image>
  ```

---

### ✅ **7. A container needs to expose multiple ports. How do you do this?**

**Answer:**

```bash
docker run -p 80:80 -p 443:443 <image>
```

* Also ensure the application listens on both ports.

---

### ✅ **8. How do you ensure environment-specific configurations inside Docker?**

**Answer:**

* Use environment variables or `.env` files:

  ```bash
  docker run --env ENV=production <image>
  ```
* Or mount different config files using volumes:

  ```bash
  docker run -v ./prod-config.json:/app/config.json <image>
  ```

---

### ✅ **9. Your container is running but the app is not responding. How do you troubleshoot?**

**Answer:**

* Check container logs.
* Use `docker exec` to test inside the container.
* Check if app is binding to `0.0.0.0` not `localhost`.
* Ensure the exposed port is correct in Dockerfile and `docker run`.

---

### ✅ **10. How do you handle multi-container applications with Docker?**

**Answer:**

* Use **Docker Compose**:

  ```yaml
  version: "3"
  services:
    web:
      image: my-web-app
      ports:
        - "80:80"
    db:
      image: postgres
      volumes:
        - pgdata:/var/lib/postgresql/data
  volumes:
    pgdata:
  ```
* Use `docker-compose up -d` to bring up all containers.

---
