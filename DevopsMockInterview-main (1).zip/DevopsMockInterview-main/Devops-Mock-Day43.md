Here's a detailed list of 10 real-time **Terraform interview questions**, along with **answers** and **real-life Terraform examples** to practice. The goal is to provide you with an end-to-end understanding of the most common Terraform tasks and challenges a DevOps engineer might face.

---

### **1. What is Terraform State, and how do you manage it?**
**Answer**: Terraform state is used to map real-world resources to your configuration, track metadata, and improve performance for large infrastructures. It stores information about the resources created by Terraform, allowing it to track changes between infrastructure deployments.

#### **Real-Life Example**: Store Terraform State in AWS S3
In this example, you will configure Terraform to store state files remotely in an S3 bucket and use DynamoDB for state locking to prevent race conditions during simultaneous updates.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"

  tags = {
    Name = "WebServer"
  }
}

terraform {
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "global/s3/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-lock"
  }
}
```

**Practice**:
- Configure your AWS credentials.
- Apply the configuration and check if the state file is saved in S3.
- Use `terraform plan` to see how the state file tracks changes.

---

### **2. How do you manage multiple environments (dev, staging, prod) in Terraform?**
**Answer**: Terraform can manage multiple environments using workspaces or by creating separate configurations with different variable files. Workspaces allow you to manage different environments with the same configuration by maintaining multiple state files.

#### **Real-Life Example**: Managing Multiple Environments with Workspaces
In this example, you'll create and switch between workspaces for dev, staging, and prod environments.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  tags = {
    Name = "${terraform.workspace}-web-server"
  }
}

output "instance_id" {
  value = aws_instance.web_server.id
}
```

**Practice**:
1. Create a new workspace: `terraform workspace new dev`.
2. Apply the configuration in the dev workspace: `terraform apply`.
3. Switch to another environment: `terraform workspace new prod` and apply the configuration again.
4. Verify that the instance in each workspace is independent.

---

### **3. What are Terraform modules, and how do they help manage large infrastructure?**
**Answer**: Terraform modules are reusable components that group related resources together. They help manage large infrastructures by breaking configurations into smaller, manageable parts that can be reused across different projects or environments.

#### **Real-Life Example**: Create and Use a Simple Terraform Module
In this example, you’ll create a module to provision an EC2 instance and reuse it in multiple environments.

#### **Module Structure**:
```
modules/
└── ec2_instance/
    ├── main.tf
    ├── outputs.tf
    └── variables.tf
```

#### `modules/ec2_instance/main.tf`
```hcl
resource "aws_instance" "app_server" {
  ami           = var.ami
  instance_type = var.instance_type

  tags = {
    Name = var.name
  }
}
```

#### `modules/ec2_instance/variables.tf`
```hcl
variable "ami" {}
variable "instance_type" {}
variable "name" {}
```

#### `modules/ec2_instance/outputs.tf`
```hcl
output "instance_id" {
  value = aws_instance.app_server.id
}
```

#### **Using the Module**:
```hcl
module "app_server" {
  source        = "./modules/ec2_instance"
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  name          = "AppServer"
}
```

**Practice**:
- Create a module for an EC2 instance.
- Use the module to deploy EC2 instances in different environments by changing variables.
- Validate that the module works in both staging and production environments.

---

### **4. How do you handle secrets in Terraform?**
**Answer**: Secrets should be stored securely using environment variables, secrets management tools like AWS Secrets Manager, or encrypted backends. Terraform supports sensitive variables to prevent the leakage of sensitive information in logs or outputs.

#### **Real-Life Example**: Handling Sensitive Variables for Database Credentials
In this example, you will use sensitive variables for managing sensitive data like database passwords.

#### `variables.tf`
```hcl
variable "db_password" {
  description = "The password for the database"
  type        = string
  sensitive   = true
}

variable "db_username" {
  description = "The username for the database"
  type        = string
  default     = "admin"
}
```

#### `main.tf`
```hcl
provider "aws" {
  region = "us-west-2"
}

resource "aws_rds_instance" "db_instance" {
  allocated_storage    = 20
  engine               = "mysql"
  instance_class       = "db.t2.micro"
  name                 = "mydb"
  username             = var.db_username
  password             = var.db_password
  skip_final_snapshot  = true
}
```

#### `terraform.tfvars`
```hcl
db_password = "mysecurepassword"
```

**Practice**:
- Apply the configuration and note how sensitive variables are not exposed in logs.
- Use `terraform output` to verify that sensitive outputs are masked.

---

### **5. How do you define dependencies between resources in Terraform?**
**Answer**: Terraform automatically determines dependencies between resources based on resource attributes. However, explicit dependencies can be defined using the `depends_on` argument.

#### **Real-Life Example**: Defining Dependencies between EC2 and Security Groups
In this example, you’ll create an EC2 instance that depends on a security group.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_security_group" "web_sg" {
  name        = "web_sg"
  description = "Allow web traffic"
  
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  vpc_security_group_ids = [aws_security_group.web_sg.id]

  depends_on = [aws_security_group.web_sg]

  tags = {
    Name = "WebServer"
  }
}
```

**Practice**:
- Apply the configuration and observe the order of resource creation.
- Remove `depends_on` and check how Terraform handles implicit dependencies.

---

### **6. How do you import existing infrastructure into Terraform?**
**Answer**: Terraform can import existing infrastructure into its state file without needing to destroy and re-create resources. The `terraform import` command is used to bring external resources under Terraform management.

#### **Real-Life Example**: Import an Existing AWS S3 Bucket into Terraform
In this example, you will import an existing S3 bucket into your Terraform configuration.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_s3_bucket" "example_bucket" {
  bucket = "my-existing-bucket"
}
```

**Practice**:
1. Use `terraform import aws_s3_bucket.example_bucket my-existing-bucket` to import the existing bucket.
2. Run `terraform plan` to verify the bucket is now managed by Terraform.

---

### **7. How do you handle resource drift in Terraform?**
**Answer**: Resource drift occurs when the actual state of resources diverges from Terraform’s state file, usually due to manual changes. Terraform detects drift using `terraform plan`, and you can reconcile it by running `terraform apply` to bring the state in sync.

#### **Real-Life Example**: Detecting and Correcting Resource Drift
In this example, you'll manually modify an AWS resource and use Terraform to detect and correct the drift.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  tags = {
    Name = "WebServer"
  }
}
```

**Practice**:
- Apply the configuration to create an EC2 instance.
- Manually change the instance type in the AWS console.
- Run `terraform plan` to detect the drift and `terraform apply` to correct it.

---

### **8. How do you use data sources in Terraform?**
**Answer**: Data sources allow Terraform to query information about resources that are not managed by Terraform, but still needed

 in your configuration.

#### **Real-Life Example**: Query an Existing VPC and Create a Subnet
In this example, you will use a data source to fetch an existing VPC’s ID and create a new subnet within it.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-west-2"
}

data "aws_vpc" "default" {
  default = true
}

resource "aws_subnet" "default_subnet" {
  vpc_id     = data.aws_vpc.default.id
  cidr_block = "10.0.1.0/24"
  availability_zone = "us-west-2a"
}
```

**Practice**:
- Apply the configuration and observe how Terraform queries the existing VPC.
- Modify the CIDR block and reapply to create a new subnet.

---

### **9. How do you create reusable infrastructure components in Terraform?**
**Answer**: Terraform modules allow you to create reusable infrastructure components by grouping related resources into a single configuration that can be reused across environments or projects.

#### **Real-Life Example**: Reusing a Security Group Module
In this example, you'll create a reusable module for an AWS security group.

#### `modules/security_group/main.tf`
```hcl
resource "aws_security_group" "sg" {
  name        = var.name
  description = var.description

  ingress {
    from_port   = var.ingress_from_port
    to_port     = var.ingress_to_port
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

#### `modules/security_group/variables.tf`
```hcl
variable "name" {}
variable "description" {}
variable "ingress_from_port" {}
variable "ingress_to_port" {}
```

#### `main.tf`
```hcl
module "web_sg" {
  source            = "./modules/security_group"
  name              = "web_sg"
  description       = "Allow web traffic"
  ingress_from_port = 80
  ingress_to_port   = 80
}
```

**Practice**:
- Apply the configuration to create the security group.
- Modify the module to handle different ingress ports and reuse it for multiple environments.

---

### **10. What is the `terraform taint` command, and when would you use it?**
**Answer**: The `terraform taint` command marks a resource as needing to be destroyed and recreated during the next `terraform apply`. It's used when you suspect that a resource is in an unhealthy state or needs to be replaced.

#### **Real-Life Example**: Tainting an AWS EC2 Instance
In this example, you’ll taint an EC2 instance to force its recreation.

#### `main.tf`
```hcl
provider "aws" {
  region = "us-east-1"
}

resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t2.micro"
  tags = {
    Name = "WebServer"
  }
}
```

**Practice**:
1. Use `terraform taint aws_instance.web_server` to mark the instance for replacement.
2. Run `terraform apply` to destroy and recreate the instance.

