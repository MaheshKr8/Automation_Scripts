
---

### **1. Scenario: Jenkins Pipeline Fails Only on Production**

**Question:** Your Jenkins pipeline runs successfully in staging but fails in production. How would you debug and resolve this?

**Answer:**

* Check differences in **credentials/secrets** between staging and production.
* Validate **environment variables** and configurations.
* Compare the **Jenkinsfile** logic (some may have conditional stages).
* Check if the production has **approval gates** or **restricted IAM permissions**.
* Inspect logs using `BlueOcean` or Jenkins console output.
* Re-run with debug flags: `set -x` (for shell) or `mvn -X`.

---

### **2. Scenario: Kubernetes Pod Not Starting**

**Question:** A pod is stuck in `CrashLoopBackOff`. How do you fix it?

**Answer:**

* Run: `kubectl describe pod <pod-name>` – check for events (e.g., failed mounts, permission issues).
* Check logs: `kubectl logs <pod-name>` – reveals application-level error.
* Common fixes:

  * Incorrect command in `command` or `entrypoint`.
  * Missing config/env variable.
  * Insufficient memory causing OOM kills.
* Use `liveness` and `readiness` probes carefully to avoid restarts on transient issues.

---

### **3. Scenario: Docker Container Cannot Access the Internet**

**Question:** A container can’t reach the internet. How do you troubleshoot?

**Answer:**

* Confirm container is using the **bridge network** (check with `docker inspect`).
* Verify host’s internet access.
* Check firewall rules (iptables or cloud security groups).
* DNS inside container may be misconfigured. Use:

  ```bash
  docker run --dns 8.8.8.8 busybox ping google.com
  ```

---

### **4. Scenario: S3 Bucket Sync Between Accounts**

**Question:** How do you sync data between S3 buckets in two AWS accounts?

**Answer:**

* Configure **bucket policy** on destination bucket to allow writes from source account.
* Use `aws s3 sync` with appropriate credentials:

  ```bash
  aws s3 sync s3://source-bucket s3://dest-bucket --profile dest-account
  ```
* Automate with **Lambda + S3 event** to trigger on object creation.

---

### **5. Scenario: Terraform Dependency Between Modules**

**Question:** You have two Terraform modules — VPC and EC2. EC2 needs the VPC ID. How do you pass it?

**Answer:**
In VPC module (`vpc/outputs.tf`):

```hcl
output "vpc_id" {
  value = aws_vpc.main.id
}
```

In root module:

```hcl
module "vpc" { ... }

module "ec2" {
  source  = "./ec2"
  vpc_id  = module.vpc.vpc_id
}
```

---

### **6. Scenario: Restrict Pod Communication Across Namespaces**

**Question:** You want to block traffic from Pod A in namespace `frontend` to Pod B in namespace `backend`. How?

**Answer:**

* Enable **NetworkPolicy** in your Kubernetes cluster (requires CNI plugin support).
* Create a deny-all policy in `backend`:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: deny-external
  namespace: backend
spec:
  podSelector: {}
  ingress: []
```

---

### **7. Scenario: Application Can’t Pull from Private ECR**

**Question:** Kubernetes pods can’t pull images from private Amazon ECR. Fix?

**Answer:**

* Create IAM role with ECR read permissions.
* Create Kubernetes service account with IAM role (IRSA).
* Attach image pull secret to the pod or service account:

```yaml
imagePullSecrets:
- name: ecr-secret
```

---

### **8. Scenario: Git Merge Conflict in CI Pipeline**

**Question:** A merge conflict occurs when multiple PRs are merged simultaneously. How do you ensure clean merges?

**Answer:**

* Use **“Rebase and merge”** strategy for cleaner history.
* Add a **merge check** stage in Jenkins/GitHub Actions:

  ```bash
  git fetch origin main
  git rebase origin/main
  ```
* Automate pull + rebase before final merge.

---

### **9. Scenario: Rollback a Faulty Deployment**

**Question:** A new deployment breaks production. What’s the quickest rollback strategy?

**Answer:**

* **Kubernetes:**

  ```bash
  kubectl rollout undo deployment myapp
  ```
* **GitOps (ArgoCD):** Revert to previous commit.
* **Jenkins:** Re-deploy last successful build.
* Ensure you always tag and archive each deployment artifact.

---

### **10. Scenario: Memory Leak in Java App Running in Container**

**Question:** A Java container crashes after a few hours. How do you detect and fix memory leak?

**Answer:**

* Enable `-XX:+HeapDumpOnOutOfMemoryError` in JVM options.
* Use `docker stats` to monitor memory usage.
* Set memory limits in `Dockerfile` or `K8s`:

  ```yaml
  resources:
    limits:
      memory: "512Mi"
  ```
* Analyze heap dump with tools like Eclipse MAT.
* Use tools like **Prometheus + Grafana** or **New Relic** for metrics.

---

