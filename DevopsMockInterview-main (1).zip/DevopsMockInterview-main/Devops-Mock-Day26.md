* Certainly! Here are the 15 real-time scenario-based Terraform interview questions, along with examples, expected answers, and real-time commands/scripts for better understanding.

### 1. How do you manage sensitive information such as passwords and API keys in Terraform?

**Expected Answer:**  
Sensitive information should be managed using Terraform’s `sensitive` attribute, environment variables, or secret management services like HashiCorp Vault, AWS Secrets Manager, or Azure Key Vault. Avoid hardcoding secrets in Terraform files.

**Example: Using environment variables and the `sensitive` attribute.**

**Code:**

```hcl
variable "db_password" {
  type      = string
  sensitive = true
}

resource "aws_db_instance" "example" {
  identifier = "example-db"
  engine     = "mysql"
  username   = "admin"
  password   = var.db_password
}
```

**Command:**

```sh
export TF_VAR_db_password=my-secret-password
terraform apply
```

---

### 2. Describe a situation where you had to roll back a Terraform deployment. How did you handle it?

**Expected Answer:**  
Rolling back a Terraform deployment can be handled by reverting to a previous state file, using version control to revert to a previous configuration, or restoring the infrastructure from a backup.

**Example: Reverting to a previous state file.**

**Command:**

```sh
terraform state pull > backup.tfstate
git checkout <previous-commit-hash>
terraform apply
```

---

### 3. How do you handle Terraform state management in a team environment?

**Expected Answer:**  
Use remote backends like AWS S3 with DynamoDB for state locking, Azure Storage, or Terraform Cloud. Ensure state files are not stored locally and enable state locking to avoid conflicts.

**Example: Using AWS S3 for remote state storage with DynamoDB for state locking.**

**Code:**

```hcl
terraform {
  backend "s3" {
    bucket         = "my-terraform-state-bucket"
    key            = "global/s3/terraform.tfstate"
    region         = "us-west-2"
    dynamodb_table = "terraform-lock"
  }
}
```

**Command:**

```sh
terraform init
terraform apply
```

---

### 4. What strategies do you use for organizing and structuring Terraform code in large projects?

**Expected Answer:**  
Use Terraform modules to encapsulate and reuse code, organize resources into logical directories, adopt a consistent naming convention, and utilize workspaces for different environments (e.g., dev, staging, prod).

**Example: Using modules for reusable code.**

**Code:**

```hcl
# main.tf
module "network" {
  source = "./modules/network"
}

module "compute" {
  source = "./modules/compute"
}
```

```hcl
# modules/network/main.tf
resource "aws_vpc" "example" {
  cidr_block = "10.0.0.0/16"
}
```

---

### 5. Explain how you would implement infrastructure as code (IaC) for a multi-region deployment using Terraform.

**Expected Answer:**  
Use Terraform modules to define reusable resource configurations, create separate workspaces or directories for each region, and manage regional differences with variable files and conditional logic.

**Example: Using modules and workspaces.**

**Code:**

```hcl
# main.tf
module "network" {
  source  = "./modules/network"
  region  = var.region
}

module "compute" {
  source  = "./modules/compute"
  region  = var.region
}
```

**Command:**

```sh
terraform workspace new us-west-1
terraform apply -var="region=us-west-1"
terraform workspace new us-east-1
terraform apply -var="region=us-east-1"
```

---

### 6. Describe how you handle dependencies between resources in Terraform.

**Expected Answer:**  
Utilize implicit dependencies based on resource references and explicit dependencies using the `depends_on` attribute. Manage resource creation order by understanding Terraform’s dependency graph.

**Example: Using `depends_on` for explicit dependencies.**

**Code:**

```hcl
resource "aws_instance" "web" {
  ami           = "ami-123456"
  instance_type = "t2.micro"
}

resource "aws_elb" "example" {
  instances = [aws_instance.web.id]

  depends_on = [aws_instance.web]
}
```

---

### 7. How do you manage versioning of Terraform providers and modules?

**Expected Answer:**  
Specify provider and module versions in the Terraform configuration files, use version constraints, and update versions periodically to incorporate bug fixes and new features.

**Example: Specifying versions in the configuration file.**

**Code:**

```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 3.0"
    }
  }
  required_version = ">= 0.14"
}

module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "2.44.0"
}
```

---

### 8. Have you ever encountered issues with Terraform's drift detection? How did you resolve them?

**Expected Answer:**  
Use `terraform plan` to detect drift, `terraform apply` to reconcile the state, and `terraform import` to bring unmanaged resources into Terraform’s state. Manual corrections might be needed if necessary.

**Example: Using `terraform refresh` and `terraform import`.**

**Command:**

```sh
terraform refresh
terraform import aws_instance.example i-12345678
terraform plan
terraform apply
```

---

### 9. How do you handle resource tagging policies across multiple environments in Terraform?

**Expected Answer:**  
Use variable files to define common tags and apply them across resources, create reusable modules with tagging standards, and enforce tagging policies through organization-wide standards or policies.

**Example: Using variable files for common tags.**

**Code:**

```hcl
# variables.tf
variable "tags" {
  type = map(string)
}

# main.tf
resource "aws_instance" "example" {
  ami           = "ami-123456"
  instance_type = "t2.micro"
  tags          = var.tags
}
```

```hcl
# dev.tfvars
tags = {
  "Environment" = "dev"
  "Project"     = "example"
}

# prod.tfvars
tags = {
  "Environment" = "prod"
  "Project"     = "example"
}
```

**Command:**

```sh
terraform apply -var-file="dev.tfvars"
terraform apply -var-file="prod.tfvars"
```

---

### 10. Describe a scenario where you used Terraform to manage a complex infrastructure change.

**Expected Answer:**  
Provide a detailed example, such as migrating resources, scaling infrastructure, or refactoring resource configurations. Discuss the planning, execution, and validation steps, and how you ensured minimal downtime.

**Example: Migrating resources from one region to another.**

**Command:**

```sh
terraform import aws_instance.example i-12345678
terraform state mv aws_instance.example aws_instance.old_region
terraform apply -var="region=us-west-2"
```

---

### 11. How do you handle conditional resource creation in Terraform?

**Expected Answer:**  
Use the `count` or `for_each` attributes with conditional expressions, leverage the `null_resource` for conditional logic, and manage different configurations with input variables and conditionals.

**Example: Using the `count` attribute.**

**Code:**

```hcl
variable "create_instance" {
  type    = bool
  default = true
}

resource "aws_instance" "example" {
  count         = var.create_instance ? 1 : 0
  ami           = "ami-123456"
  instance_type = "t2.micro"
}
```

**Command:**

```sh
terraform apply -var="create_instance=false"
```

---

### 12. Can you explain a situation where you had to troubleshoot Terraform apply errors?

**Expected Answer:**  
Discuss common errors such as provider authentication issues, resource conflicts, or incorrect configurations. Describe the troubleshooting steps, like checking logs, using `terraform plan` to debug, and reviewing provider documentation.

**Example: Debugging provider authentication issues.**

**Command:**

```sh
export AWS_PROFILE=correct_profile
terraform plan
```

---

### 13. How do you automate Terraform deployments in a CI/CD pipeline?

**Expected Answer:**  
Use tools like Jenkins, GitLab CI, GitHub Actions, or AWS CodePipeline. Automate `terraform init`, `terraform plan`, and `terraform apply` steps, and integrate with version control for changes.

**Example: Using GitLab CI.**

**Code:**

```yaml
stages:
  - plan
  - apply

plan:
  stage: plan
  script:
    - terraform init
    - terraform plan -out=tfplan

apply:
  stage: apply
  script:
    - terraform apply tfplan
  when: manual
```

---

### 14. Describe your approach to managing multiple environments (development, staging, production) using Terraform.

**Expected Answer:**  
Use separate workspaces, directories, or repositories for each environment, leverage environment-specific variable files, and maintain consistency with modules and configuration templates.

**Example: Using workspaces and environment-specific variables.**

**Code:**

```hcl
# main.tf
variable "environment" {
  description = "The environment to deploy to"
  type        = string
}

resource "aws_instance" "example" {
  ami           = "ami-123456"
  instance_type = "t2.micro"
  tags = {
    "Environment" = var.environment


  }
}
```

**Command:**

```sh
terraform workspace new dev
terraform apply -var="environment=dev"
terraform workspace new prod
terraform apply -var="environment=prod"
```

---

### 15. How do you ensure the security and compliance of your Terraform-managed infrastructure?

**Expected Answer:**  
Implement role-based access control (RBAC), use secure storage for state files, enable encryption for sensitive data, perform regular audits and compliance checks, and integrate with security scanning tools.

**Example: Using role-based access control (RBAC) and encrypted state files.**

**Code:**

```hcl
# backend.tf
terraform {
  backend "s3" {
    bucket         = "my-secure-bucket"
    key            = "terraform.tfstate"
    region         = "us-west-2"
    encrypt        = true
    dynamodb_table = "terraform-lock"
  }
}
```

```hcl
# IAM policy for restricted access
resource "aws_iam_policy" "terraform_policy" {
  name = "TerraformPolicy"
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Action = [
          "s3:*",
          "dynamodb:*"
        ],
        Effect   = "Allow",
        Resource = [
          "arn:aws:s3:::my-secure-bucket/*",
          "arn:aws:dynamodb:us-west-2:123456789012:table/terraform-lock"
        ]
      }
    ]
  })
}
```

* These examples and explanations should help illustrate how to handle various real-time scenarios in Terraform, providing practical commands and scripts to manage infrastructure effectively.
