
1. **How do you secure sensitive data using Secrets in Kubernetes?**
    - **Explanation**: Secrets store sensitive information like passwords or API keys.
    - **Real-life example**: Storing a database password as a secret and injecting it into an application Pod.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Secret
      metadata:
        name: db-password
      type: Opaque
      data:
        password: dXNlcm5hbWU=
      ```

2. **How do you enable Pod Security Policies (PSP) in Kubernetes?**
    - **Explanation**: PSPs enforce security policies on Pods, like restricting privilege escalation.
    - **Real-life example**: Preventing Pods from running as root.
    - **Command**:
      ```yaml
      apiVersion: policy/v1beta1
      kind: PodSecurityPolicy
      metadata:
        name: restricted
      spec:
        privileged: false
        runAsUser:
          rule: MustRunAsNonRoot
      ```

3. **How do you prevent unauthorized users from accessing the Kubernetes API?**
    - **Explanation**: Use RBAC and Kubernetes authentication methods like certificates or tokens.
    - **Real-life example**: Configuring RBAC to restrict API access based on user roles.
    - **Command**:
      ```bash
      kubectl create rolebinding my-rolebinding --clusterrole=view --user=my-user --namespace=default
      ```

4. **How do you secure a Kubernetes cluster in a multi-tenant environment?**
    - **Explanation**: Use Namespaces, Network Policies, and RBAC to isolate tenants.
    - **Real-life example**: Ensuring that different teams in a company have isolated environments.
    - **Command**:
      ```yaml
      apiVersion: v1
      kind: Namespace
      metadata:
        name: team-a
      ```


5. **How do you troubleshoot a node that is not Ready?**
    - **Explanation**: Use `kubectl describe node` and check logs for issues.
    - **Real-life example**: A node not joining the cluster due to network issues.
    - **Command**:
     

 ```bash
      kubectl describe node <node-name>
 ```

6. **How do you check the resource utilization of a Pod?**
    - **Explanation**: Use `kubectl top` to check CPU and memory usage.
    - **Real-life example**: Monitoring the resource usage of a database Pod to ensure it’s not overconsuming.
    - **Command**:
      ```bash
      kubectl top pod <pod-name>
      ```

7. **How do you check for events in Kubernetes?**
    - **Explanation**: Events can be listed using `kubectl get events` and provide insights into failures or changes.
    - **Real-life example**: Checking for scheduling failures or network policy violations.
    - **Command**:
      ```bash
      kubectl get events
      ```

8. **How do you troubleshoot networking issues in Kubernetes?**
    - **Explanation**: Check network policies, DNS resolution, and kube-proxy logs.
    - **Real-life example**: A service is unreachable due to an incorrect network policy.
    - **Command**:
      ```bash
      kubectl describe networkpolicy <policy-name>
      ```



9. **How do you perform a rolling update in Kubernetes?**
    - **Explanation**: Kubernetes Deployments support rolling updates with zero downtime.
    - **Real-life example**: Deploying a new version of a web application with a rolling update.
    - **Command**:
      ```bash
      kubectl set image deployment/my-app my-container=my-image:v2
      ```

10. **How do you rollback a failed Deployment in Kubernetes?**
    - **Explanation**: Use `kubectl rollout undo` to rollback to a previous version.
    - **Real-life example**: Rolling back a deployment after a failed application update.
    - **Command**:
      ```bash
      kubectl rollout undo deployment/my-app
      ```


