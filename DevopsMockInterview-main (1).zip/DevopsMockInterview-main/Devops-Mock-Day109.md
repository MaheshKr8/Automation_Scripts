
### **1. What is Git?**
**Answer:**  
Git is a distributed version control system that allows multiple developers to work on a project simultaneously, track changes, and collaborate effectively.

---

### **2. What is the difference between Git and GitHub?**
**Answer:**  
- **Git** is a version control tool used locally.  
- **GitHub** is a web-based platform that hosts Git repositories and adds collaboration features like pull requests, issue tracking, and CI/CD.

---

### **3. What are the different Git states?**
**Answer:**  
- **Working Directory:** Modified files.  
- **Staging Area (Index):** Files marked to be committed.  
- **Committed (Repository):** Files safely stored in local database.

---

### **4. How do you check the current status of your Git repository?**
**Answer:**  
```bash
git status
```

---

### **5. How do you track a file in Git?**
**Answer:**  
1. Add the file to staging:
   ```bash
   git add filename
   ```
2. Commit the change:
   ```bash
   git commit -m "Add filename"
   ```

---

### **6. What is the difference between `git pull` and `git fetch`?**
**Answer:**  
- `git fetch` downloads changes but doesn’t merge.  
- `git pull` = `git fetch` + `git merge`.

---

### **7. How do you create and switch to a new branch?**
**Answer:**
```bash
git checkout -b new-branch-name
```

---

### **8. What is a merge conflict and how do you resolve it?**
**Answer:**  
A merge conflict occurs when changes in two branches overlap. You resolve it by manually editing the conflicting files, then:
```bash
git add <file>
git commit
```

---

### **9. How do you delete a branch in Git?**
**Answer:**  
- Local:
  ```bash
  git branch -d branch-name
  ```
- Remote:
  ```bash
  git push origin --delete branch-name
  ```

---

### **10. What is the `.gitignore` file?**
**Answer:**  
A `.gitignore` file tells Git which files or directories to ignore (not track), such as `node_modules/`, `.env`, `*.log`, etc.

---

### **11. How do you undo the last commit but keep the changes?**
**Answer:**  
```bash
git reset --soft HEAD~1
```

---

### **12. What is cherry-picking in Git?**
**Answer:**  
Cherry-picking means selecting a specific commit from one branch and applying it to another:
```bash
git cherry-pick <commit-hash>
```

---

### **13. What is the purpose of `git rebase`?**
**Answer:**  
`git rebase` rewrites commit history to create a linear history, making it cleaner than merge (no extra merge commits).

---

### **14. How do you tag a commit in Git?**
**Answer:**  
```bash
git tag v1.0.0
git push origin v1.0.0
```

---

### **15. How do you clone a remote repository?**
**Answer:**
```bash
git clone <repository-url>
```

