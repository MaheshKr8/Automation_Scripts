
---


### **1. How do you troubleshoot a Pod stuck in `CrashLoopBackOff`?**

**Answer:**

1. Check logs:

   ```bash
   kubectl logs <pod-name> -n <namespace>
   ```
2. Describe the pod:

   ```bash
   kubectl describe pod <pod-name> -n <namespace>
   ```
3. Common causes:

   * App crashes due to wrong config/env variables.
   * Missing files/secrets.
   * Dependency services not reachable.
4. Fix:

   * Update deployment config.
   * Ensure dependencies are available before container starts.
   * Add `initContainers` for dependency checks.

---

### **2. Your service is not reachable inside the cluster. How do you debug it?**

**Answer:**

* Verify Service:

  ```bash
  kubectl get svc <service-name> -n <namespace>
  ```
* Check endpoints:

  ```bash
  kubectl get endpoints <service-name> -n <namespace>
  ```
* Exec into another pod to test:

  ```bash
  kubectl exec -it <pod-name> -- curl <service-name>:<port>
  ```
* If no endpoints, check pod labels match service selector.

---

### **3. How do you roll back a bad Kubernetes deployment?**

**Answer:**

```bash
kubectl rollout undo deployment/<deployment-name> -n <namespace>
```

* Use `kubectl rollout history` to see previous versions.
* Always use versioned images to avoid re-deploying a broken tag.

---

### **4. How do you scale a deployment during high traffic?**

**Answer:**

* Manual scaling:

  ```bash
  kubectl scale deployment <deployment-name> --replicas=10
  ```
* Auto-scaling:

  ```bash
  kubectl autoscale deployment <deployment-name> --min=2 --max=10 --cpu-percent=80
  ```
* For real-time: Enable HPA + metrics-server.

---

### **5. You have a node with `NotReady` status. How do you fix it?**

**Answer:**

* Check node status:

  ```bash
  kubectl describe node <node-name>
  ```
* SSH to node:

  * Check `kubelet` service.
  * Check network/DNS.
* Restart kubelet:

  ```bash
  systemctl restart kubelet
  ```

---

### **6. How do you update a running pod without downtime?**

**Answer:**

* Use rolling updates:

  ```bash
  kubectl set image deployment/<deployment-name> <container-name>=<new-image>
  ```
* Ensure `readinessProbe` is configured so traffic is sent only to healthy pods.

---

### **7. Your Kubernetes pod consumes too much memory and gets OOMKilled. How do you handle it?**

**Answer:**

* Set `resources` in deployment:

  ```yaml
  resources:
    requests:
      memory: "512Mi"
      cpu: "500m"
    limits:
      memory: "1Gi"
      cpu: "1"
  ```
* Optimize the application or increase limits.

---

### **8. How do you give a Pod access to a Kubernetes secret?**

**Answer:**

* Create secret:

  ```bash
  kubectl create secret generic db-secret --from-literal=username=admin --from-literal=password=pass123
  ```
* Mount into pod:

  ```yaml
  envFrom:
    - secretRef:
        name: db-secret
  ```

---

### **9. You need to deploy multiple environments (dev, stage, prod) in Kubernetes. How do you manage this?**

**Answer:**

* Use:

  * **Namespaces** for isolation.
  * **Helm values** for environment-specific configs.
  * **Kustomize overlays** for variations.

---

### **10. How do you troubleshoot a `Pending` pod?**

**Answer:**

* Check events:

  ```bash
  kubectl describe pod <pod-name>
  ```
* Common reasons:

  * Insufficient CPU/memory.
  * NodeSelector/tolerations mismatch.
  * PV/PVC issues.

---

### **11. How do you monitor your Kubernetes cluster?**

**Answer:**

* Use Prometheus + Grafana for metrics.
* Use EFK or Loki for logs.
* Use alerts for CPU, memory, and pod restarts.

---

### **12. You have a Stateful application like MySQL. How do you run it in Kubernetes?**

**Answer:**

* Use **StatefulSet** with:

  * **PersistentVolumeClaim** for data.
  * Headless Service for stable DNS.

---

### **13. How do you perform zero-downtime upgrades for Kubernetes workloads?**

**Answer:**

* Rolling updates with proper `readinessProbe`.
* Ensure new pods pass readiness before old ones terminate.

---

### **14. How do you secure inter-pod communication?**

**Answer:**

* Enable **NetworkPolicies**:

  ```yaml
  kind: NetworkPolicy
  podSelector:
    matchLabels:
      app: frontend
  policyTypes:
    - Ingress
    - Egress
  ```

---

### **15. How do you back up and restore Kubernetes resources?**

**Answer:**

* Backup:

  ```bash
  kubectl get all --all-namespaces -o yaml > backup.yaml
  ```
* Or use tools like Velero for cluster state + PV backups.

---


