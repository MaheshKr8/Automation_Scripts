
---

## 🐳 Docker – Top 5 Interview Questions

---

### **1. What is Docker and why is it used in DevOps?**

**Answer:**
Docker is a containerization platform that allows you to package applications with their dependencies into portable containers. It enables:

* Faster deployment
* Consistent environments across dev/test/prod
* Scalability and isolation

---

### **2. What is the difference between a Docker image and a container?**

**Answer:**

* **Image**: A snapshot or blueprint (read-only) of the app and its dependencies.
* **Container**: A running instance of an image (read-write) that executes the application.

---

### **3. How do you persist data in Docker containers?**

**Answer:**
Use **volumes** or **bind mounts**:

```bash
docker run -v mydata:/app/data myimage
```

This ensures data is not lost after the container restarts.

---

### **4. How do you optimize Docker image size?**

**Answer:**

* Use minimal base images like `alpine`
* Clean up unnecessary files in layers
* Use `.dockerignore` to exclude local files
* Use multi-stage builds

---

### **5. How do you troubleshoot a container that keeps crashing?**

**Answer:**

1. View logs:

   ```bash
   docker logs <container>
   ```
2. Check container events:

   ```bash
   docker inspect <container>
   ```
3. Run in interactive mode to debug:

   ```bash
   docker run -it <image> /bin/sh
   ```

---

## ☸️ Kubernetes – Top 5 Interview Questions

---

### **6. What is Kubernetes and what problem does it solve?**

**Answer:**
Kubernetes is a container orchestration platform that automates deployment, scaling, networking, and management of containers. It helps in managing production-grade containerized applications.

---

### **7. What are the core components of Kubernetes?**

**Answer:**

* **Control Plane**: API Server, etcd, Scheduler, Controller Manager
* **Worker Nodes**: kubelet, kube-proxy, container runtime
* **Objects**: Pod, Deployment, Service, ConfigMap, Secret, Ingress

---

### **8. What is the difference between a Deployment and a StatefulSet?**

**Answer:**

* **Deployment**: Used for stateless applications; supports scaling, rolling updates.
* **StatefulSet**: Used for stateful apps (e.g., databases); maintains persistent identity and stable storage per Pod.

---

### **9. How does Kubernetes handle service discovery and load balancing?**

**Answer:**

* Each Pod gets a unique IP.
* **Services** expose Pods and provide a stable DNS name.
* Internal load balancing is managed by kube-proxy across Pod endpoints.

---

### **10. How do you scale applications in Kubernetes?**

**Answer:**
Manually:

```bash
kubectl scale deployment myapp --replicas=5
```

Automatically:
Use **Horizontal Pod Autoscaler (HPA)**:

```bash
kubectl autoscale deployment myapp --cpu-percent=75 --min=1 --max=10
```

---

