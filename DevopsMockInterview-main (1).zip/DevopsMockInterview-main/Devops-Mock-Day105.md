

**1. What is Git?**

* **Answer:** Git is a distributed version control system (DVCS) that tracks changes in computer files and coordinates work on those files among multiple people. It's primarily used for source code management in software development.




**2. What is the difference between Git and GitHub?**

* **Answer:** Git is the version control system itself, installed locally on your computer. GitHub is a web-based hosting service for Git repositories. It provides a centralized location for collaboration, issue tracking, and other features.



**3. What is a repository in Git?**

* **Answer:** A repository (or "repo") is a directory or storage space where your project files reside. It stores the entire history of changes to those files.




**4. What is a commit in Git?**

* **Answer:** A commit is a snapshot of your repository at a specific point in time. It records the changes you've made to your files.





**5. What is a branch in Git?**

* **Answer:** A branch is a parallel version of your repository. It allows you to work on new features or bug fixes without affecting the main codebase.





**6. What is the main branch called by default?**

* **Answer:** Historically it was called "master", but now the default branch name is often "main".






**7. How do you create a new branch?**

* **Answer:** `git branch <branch_name>`







**8. How do you switch to a different branch?**

* **Answer:** `git checkout <branch_name>` or `git switch <branch_name>`






**9. How do you create and switch to a new branch in one command?**

* **Answer:** `git checkout -b <branch_name>` or `git switch -c <branch_name>`





**10. How do you merge one branch into another?**

* **Answer:** `git merge <branch_name>` (while on the target branch)






**11. What is a merge conflict?**

* **Answer:** A merge conflict occurs when Git cannot automatically merge changes from two branches because the same lines of code have been modified differently.




**12. How do you resolve a merge conflict?**

* **Answer:** Manually edit the conflicting files to choose the desired changes, then use `git add` to stage the resolved files, and finally `git commit` to complete the merge.




**13. What is the difference between `git pull` and `git fetch`?**

* **Answer:**
    * `git fetch` downloads changes from a remote repository but does not merge them into your local branch.
    * `git pull` downloads changes and automatically merges them into your current branch. It is essentially a fetch followed by a merge.


**14. How do you push changes to a remote repository?**

* **Answer:** `git push <remote_name> <branch_name>` (e.g., `git push origin main`)




**15. How do you clone a repository?**

* **Answer:** `git clone <repository_url>`






**16. What is the purpose of `.gitignore`?**

* **Answer:** The `.gitignore` file specifies files and directories that Git should ignore and not track. This is useful for excluding temporary files, build artifacts, and sensitive information.




**17. How do you undo the last commit?**

* **Answer:**
    * `git reset --soft HEAD~1` (keeps changes staged)
    * `git reset --mixed HEAD~1` (keeps changes unstaged, which is the default)
    * `git reset --hard HEAD~1` (discards changes)



**18. How do you revert a commit?**

* **Answer:** `git revert <commit_hash>`. This creates a new commit that undoes the changes made in the specified commit. Revert is safer than reset, because it does not alter the history of the repository.



**19. What is the purpose of `git stash`?**

* **Answer:** `git stash` temporarily saves changes that you don't want to commit immediately. This allows you to switch branches or work on other tasks without committing unfinished work.




**20. How do you view the commit history?**

* **Answer:** `git log` (for a detailed history) or `git log --oneline` (for a concise history). There are many options to customize the output of git log.




