

---

### **1. Scenario: Your Jenkins jobs take too long because each build downloads dependencies (Maven, npm, etc.). How do you optimize it?**

**Answer:**

* Use **caching**:

  * For Maven: Cache `~/.m2` directory.
  * For npm: Cache `node_modules`.
* Configure **Jenkins agents with persistent volumes** or use a Docker image with pre-installed dependencies.
* Use **parallel stages** in Jenkins pipelines to run tasks simultaneously.
* Implement **incremental builds** using tools like `docker build --cache-from`.

---

### **2. Scenario: A Kubernetes Deployment scales up to 50 pods, but some nodes are over-utilized while others are idle. How do you ensure balanced distribution?**

**Answer:**

* Use **Pod Anti-Affinity** to spread pods across nodes:

```yaml
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
    - topologyKey: "kubernetes.io/hostname"
      labelSelector:
        matchLabels:
          app: myapp
```

* Enable **Cluster Autoscaler** to scale nodes.
* Use **`topologySpreadConstraints`** for even distribution.

---

### **3. Scenario: Terraform detects that a manually added resource (like an IAM role) exists. How do you manage it?**

**Answer:**

* Import it into Terraform:

  ```bash
  terraform import aws_iam_role.example <role_arn>
  ```
* Update your Terraform code to match the actual configuration.
* Avoid manual changes by enforcing **state locking and policy checks** in CI/CD.

---

### **4. Scenario: Your application deployed in EKS cannot pull container images from a private ECR registry. What’s the fix?**

**Answer:**

* Create an **IAM role** for the Kubernetes service account (IRSA).
* Attach `AmazonEC2ContainerRegistryReadOnly` policy.
* Create an **imagePullSecret** and reference it in the deployment:

```yaml
imagePullSecrets:
- name: ecr-secret
```

* Make sure the nodes or pods have ECR access.

---

### **5. Scenario: Your website faces sudden traffic spikes during promotions, and you need auto-scaling for EC2 instances. How do you achieve this?**

**Answer:**

* Set up an **Auto Scaling Group (ASG)** with:

  * CPU or request-based scaling policies.
  * Scheduled scaling (if spikes are predictable).
* Use **Application Load Balancer (ALB)** to distribute traffic.
* For cost optimization, combine **On-Demand + Spot Instances**.

---

### **6. Scenario: You need to ensure your production environment can fail over to another AWS region in case of a disaster. How would you set it up?**

**Answer:**

* Replicate data using:

  * **RDS cross-region read replicas** or Aurora Global DB.
  * **S3 cross-region replication**.
* Use **Route 53 failover routing** with health checks.
* Automate infrastructure provisioning in the DR region using **Terraform**.

---

### **7. Scenario: A Docker containerized app needs to connect to another container on a different host. How do you enable communication?**

**Answer:**

* Use **Docker Swarm** or **Kubernetes** for cross-host networking.
* For Docker Swarm:

  * Deploy services to an **overlay network**:

    ```bash
    docker network create --driver overlay my-net
    ```
  * Attach both services to this network.

---

### **8. Scenario: Your pipeline deploys to production, but a bug causes downtime. How do you roll back quickly?**

**Answer:**

* Use **Kubernetes rollbacks**:

  ```bash
  kubectl rollout undo deployment myapp
  ```
* In non-Kubernetes:

  * Use **blue/green** or **canary deployments** for instant rollback.
  * Keep previous builds/artifacts tagged in your CI/CD system for redeployment.

---

### **9. Scenario: You notice high latency between microservices deployed in Kubernetes. How do you debug and fix it?**

**Answer:**

* Check:

  * Pod resource usage (`kubectl top pods`).
  * Node network bandwidth.
  * Service DNS resolution latency.
* Use a **Service Mesh (Istio/Linkerd)** for observability and retries.
* Enable **Jaeger or OpenTelemetry tracing** for latency analysis.

---

### **10. Scenario: You need to enforce quality gates in your CI/CD pipeline before deploying to production. How do you integrate this?**

**Answer:**

* Integrate **SonarQube** for static code analysis:

  ```groovy
  stage('SonarQube Analysis') {
    steps {
      withSonarQubeEnv('SonarQube') {
        sh 'mvn sonar:sonar'
      }
    }
  }
  ```
* Add **Trivy** scans for vulnerabilities.
* Fail pipeline if critical issues are detected.

---

