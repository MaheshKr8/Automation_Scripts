
---

### **1. CI/CD Pipeline Failure**

**Q:** Your Jenkins pipeline fails during the `build` stage. How do you troubleshoot and fix it?
**A:**

* Check **console output logs** for error details.
* Verify **build agent configuration** and required dependencies.
* If it’s a Maven/Gradle build, clear caches and re-run.
* For container builds, check the **Dockerfile syntax** and base image availability.
* Fix the root cause and **retrigger the build**.

---

### **2. Docker Container Keeps Restarting**

**Q:** You deployed a container, but it restarts continuously. How do you handle it?
**A:**

* Check logs: `docker logs <container_id>`
* Look for **application crash errors** or misconfigured environment variables.
* Use `docker inspect` to check **healthcheck** or restart policy.
* Fix the configuration or app issue, then redeploy.

---

### **3. Kubernetes Pod CrashLoopBackOff**

**Q:** A pod is in `CrashLoopBackOff`. How do you troubleshoot?
**A:**

* Check pod logs: `kubectl logs <pod> -n <namespace>`
* Describe the pod: `kubectl describe pod <pod>` to see events.
* Verify if **readiness/liveness probes** are failing.
* If it’s an image issue, check imagePullSecrets or repo access.
* Apply fixes and redeploy.

---

### **4. Terraform Plan Shows Resource Replacement**

**Q:** Terraform shows it will replace a resource. How do you decide?
**A:**

* Review the **change plan** in detail.
* Check if changes are due to **immutable fields** (e.g., instance type, subnet ID).
* If downtime is acceptable, proceed. If not, use `lifecycle { prevent_destroy = true }` or modify configuration to avoid replacement.

---

### **5. AWS S3 Sync Issue**

**Q:** Your S3 bucket sync is missing files. What do you check?
**A:**

* Confirm the **sync command** is correct:

  ```bash
  aws s3 sync /local/path s3://bucket-name --exact-timestamps
  ```
* Check IAM permissions.
* Verify files aren’t excluded with `--exclude`.
* Check for **modified timestamps**.

---

### **6. High Jenkins Build Time**

**Q:** Your Jenkins builds take too long. How do you optimize?
**A:**

* Enable **pipeline parallelization**.
* Use **Docker agents** with preinstalled dependencies.
* Cache Maven/npm artifacts.
* Use incremental builds instead of full rebuilds.

---

### **7. Kubernetes Service Not Accessible**

**Q:** The service is deployed but not reachable. How do you troubleshoot?
**A:**

* Check if pods are running: `kubectl get pods`
* Verify service endpoints: `kubectl get endpoints`
* Ensure correct `targetPort` and container port mapping.
* If external, check Ingress/LoadBalancer configuration and firewall rules.

---

### **8. SonarQube Quality Gate Failure**

**Q:** Your pipeline fails due to SonarQube quality gate. What next?
**A:**

* Review SonarQube dashboard for failing metrics (bugs, coverage, duplications).
* Fix critical/blocker issues first.
* If temporary bypass is needed, set pipeline to **`allowFailure`** for SonarQube step (only for testing environments).

---

### **9. Docker Image Size is Too Large**

**Q:** How do you reduce Docker image size?
**A:**

* Use **lightweight base images** (`alpine`).
* Use multi-stage builds.
* Remove unnecessary dependencies and temp files in the Dockerfile.
* Use `.dockerignore` to skip unneeded files.

---

### **10. Jenkinsfile Specific Stage Execution**

**Q:** You want to run only the `deploy` stage. How?
**A:**

* Use `when {}` conditions or

  ```bash
  build job: 'pipeline', parameters: [string(name: 'RUN_STAGE', value: 'deploy')]
  ```
* Or pass parameters and conditionally run stages.

---

### **11. AWS EC2 Instance SSH Issue**

**Q:** You can’t SSH into an EC2 instance. Steps?
**A:**

* Check **Security Group** for port 22 access.
* Verify **key pair** matches.
* Ensure instance is in running state and **public IP/DNS** is correct.
* Check if SSH service is running inside the instance.

---

### **12. Kubernetes Zero-Downtime Deployment**

**Q:** How do you ensure zero downtime in deployments?
**A:**

* Use **RollingUpdate strategy** with `maxUnavailable=0` and `maxSurge=1`.
* Readiness probes to only route traffic when pod is ready.
* Avoid terminating old pods until new ones are healthy.

---

### **13. Jenkins Slave Node Down**

**Q:** A Jenkins slave node goes offline. What do you do?
**A:**

* Check agent logs for connectivity issues.
* Verify Java version compatibility.
* Check firewall/SSH access to master.
* Restart agent service and reconnect.

---

### **14. Terraform State File Corruption**

**Q:** How do you recover from a corrupted Terraform state?
**A:**

* Restore state file from backup (e.g., S3 versioning).
* If backup unavailable, use `terraform import` to rebuild state.
* Always use **remote backend with locking** to avoid corruption.

---

### **15. Docker Network Communication Issue**

**Q:** Two containers can’t talk to each other. How do you fix it?
**A:**

* Check if both are on the same network: `docker network inspect`.
* If not, connect them to the same custom network.
* Check firewall rules inside containers.
* Use container names as DNS in Docker’s default networking.

---
